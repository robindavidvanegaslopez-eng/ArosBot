# ArosBot 0.2.0

Prototipo Android para detectar un material por imagen de referencia y remarcarlo con un recuadro verde encima del juego.

## Funciones incluidas
- Menú sencillo para crear/seleccionar materiales (por ejemplo, `pearwood`).
- Imagen de referencia independiente guardada para cada material.
- Permiso explícito de Android para capturar pantalla.
- Permiso de superposición para dibujar un recuadro verde encima del juego.
- Reescaneo periódico y actualización del recuadro para seguir el objeto mientras cambia de posición.
- Ajuste de sensibilidad y acciones para pausar/reanudar o detener.
- Workflow de GitHub Actions que construye el APK de depuración.

## Compilar
1. Sube el contenido de este ZIP a la raíz del repositorio GitHub.
2. Abre **Actions → Build ArosBot APK → Run workflow** (o haz un push a `main`).
3. Descarga el artefacto `ArosBot-debug` al terminar la compilación.

## Probar
1. Instala el APK y abre ArosBot.
2. Escribe un nombre de material, por ejemplo `pearwood`, y adjunta una imagen clara del objeto.
3. Concede el permiso para mostrar el recuadro verde.
4. Pulsa **Iniciar captura y detección** y acepta el diálogo del sistema Android.
5. Abre el juego; el recuadro debería aparecer cuando el detector encuentre una coincidencia.

## Limitaciones conocidas
Esta es una primera versión de detección por plantilla, no una visión artificial robusta. El tamaño, zoom, animaciones, iluminación o fondos similares pueden afectar la coincidencia. El detector busca la mejor coincidencia por pantalla y el recuadro puede perderse si el objeto cambia mucho de escala o apariencia. No ejecuta toques automáticos. Prueba primero con una imagen recortada del árbol/material y ajusta la sensibilidad.
