package com.arosbot

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class Detection(val left: Int, val top: Int, val right: Int, val bottom: Int, val centerX: Int, val centerY: Int, val score: Double)

/** Lightweight grayscale normalized cross-correlation matcher; intended as a first prototype. */
object TemplateMatcher {
    fun find(screen: Bitmap, path: String, threshold: Double): Detection? {
        val original = BitmapFactory.decodeFile(path) ?: return null
        try {
            val screenW = min(480, screen.width)
            val scale = screenW.toDouble() / screen.width
            val screenH = max(1, (screen.height * scale).toInt())
            val s = Bitmap.createScaledBitmap(screen, screenW, screenH, true)
            val tw = max(8, (original.width * scale).toInt())
            val th = max(8, (original.height * scale).toInt())
            if (tw >= screenW || th >= screenH || original.width < 8 || original.height < 8) { s.recycle(); return null }
            val t = Bitmap.createScaledBitmap(original, tw, th, true)
            try {
                val tp = IntArray(tw * th); t.getPixels(tp, 0, tw, 0, 0, tw, th)
                val sp = IntArray(screenW * screenH); s.getPixels(sp, 0, screenW, 0, 0, screenW, screenH)
                val sample = max(1, min(tw, th) / 10)
                var meanT = 0.0; var countT = 0
                var yy = 0
                while (yy < th) { var xx = 0; while (xx < tw) { meanT += gray(tp[yy * tw + xx]); countT++; xx += sample }; yy += sample }
                meanT /= countT.coerceAtLeast(1)
                var varT = 0.0; yy = 0
                while (yy < th) { var xx = 0; while (xx < tw) { val d = gray(tp[yy * tw + xx]) - meanT; varT += d * d; xx += sample }; yy += sample }
                if (varT < 1.0) return null
                val stepX = max(2, tw / 5); val stepY = max(2, th / 5)
                var best = -1.0; var bx = 0; var by = 0
                var y = 0
                while (y <= screenH - th) {
                    var x = 0
                    while (x <= screenW - tw) {
                        var meanS = 0.0; var n = 0; var sy = 0
                        while (sy < th) { var sx = 0; while (sx < tw) { meanS += gray(sp[(y + sy) * screenW + x + sx]); n++; sx += sample }; sy += sample }
                        meanS /= n.coerceAtLeast(1)
                        var num = 0.0; var varS = 0.0; sy = 0
                        while (sy < th) { var sx = 0; while (sx < tw) {
                            val sg = gray(sp[(y + sy) * screenW + x + sx]) - meanS
                            val tg = gray(tp[sy * tw + sx]) - meanT
                            num += sg * tg; varS += sg * sg; sx += sample
                        }; sy += sample }
                        val score = if (varS > 0) num / sqrt(varS * varT) else 0.0
                        if (score > best) { best = score; bx = x; by = y }
                        x += stepX
                    }
                    y += stepY
                }
                return if (best >= threshold) {
                    val inv = 1.0 / scale
                    Detection((bx * inv).toInt(), (by * inv).toInt(), ((bx + tw) * inv).toInt(), ((by + th) * inv).toInt(), ((bx + tw / 2) * inv).toInt(), ((by + th / 2) * inv).toInt(), best)
                } else null
            } finally { t.recycle(); s.recycle() }
        } finally { original.recycle() }
    }
    private fun gray(c: Int) = (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100
}
