# ArosBot — detector visual Android

Proyecto Android para detectar objetos a partir de una imagen de referencia y dibujar recuadros verdes sobre la pantalla capturada.

## Incluye
- Menú sencillo para crear materiales y asociar una imagen de referencia independiente.
- Permiso explícito de Android para capturar la pantalla.
- Permiso de superposición para dibujar recuadros verdes sobre el juego.
- Búsqueda repetida de coincidencias para remarcar varios objetos similares en pantalla.
- Control de sensibilidad, pausa/reanudación y botón para detener la captura.
- `gradlew`, un lanzador que descarga Gradle 8.9 automáticamente cuando se ejecuta en un entorno con internet.

## Compilación en GitHub Actions
El archivo ZIP debe extraerse de modo que `gradlew`, `settings.gradle.kts` y `app/` queden en la misma carpeta. El workflow del repositorio puede ejecutar `./gradlew assembleDebug`; el APK se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Prueba
1. Instala el APK generado y abre ArosBot.
2. Escribe un nombre para el material (por ejemplo, `pearwood`) y adjunta una imagen recortada y clara del objeto.
3. Concede el permiso de superposición.
4. Pulsa **Iniciar captura y detección** y acepta el aviso de captura de pantalla de Android.
5. Vuelve al juego. ArosBot buscará coincidencias y dibujará recuadros verdes.

## Limitaciones
Es un prototipo de comparación por plantilla, no un modelo de inteligencia artificial entrenado. Funciona mejor con una referencia recortada, nítida y tomada a una escala parecida a la del objeto en pantalla. Cambios de escala, animaciones, fondos similares o una sensibilidad demasiado alta pueden provocar falsos positivos o que no detecte el objeto. No realiza toques automáticos.
