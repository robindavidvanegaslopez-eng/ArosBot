# ArosBot AI

Aplicación Android nativa (Kotlin) para reconocimiento visual, navegación y recolección autónoma en *Curse of Aros*, con aprendizaje local progresivo.

**Versión actual: 0.3.1 — Fase 3 de 7** (control táctil WASD, detección del personaje, calibración e inicio de sesión de prueba).

## Qué hace esta versión

**Captura de pantalla real** (MediaProjection, servicio en primer plano con notificación):
- Pide el permiso oficial de Android, entrega fotogramas reales a unos 3 por segundo y a media resolución.
- Detecta la pérdida de la sesión, los cambios de resolución u orientación, y libera todos los recursos al detenerse.
- Una burbuja «A» sobre el juego permite capturar un fotograma, mostrar u ocultar los recuadros, detener la captura o hacer la parada de emergencia.

**Materiales** (sección *Materiales*):
- Importa imágenes de la galería, con nombre, categoría, umbral de confianza, tamaño, variantes visuales, estado de reconocimiento y estadísticas.
- Prueba la detección sobre un fotograma real y muestra el resultado con recuadros.

**Detección** (OpenCV, búsqueda de plantillas multiescala en color):
- Encuentra varios ejemplares en un mismo fotograma, tolera pequeños cambios de tamaño y elimina duplicados.
- Dibuja **recuadros verdes** sobre los objetos reconocidos y **recuadros celestes** en las áreas de rastreo.

**Áreas de rastreo** (sección *Áreas de rastreo*):
- Rectángulos ajustables sobre un fotograma real; varias áreas, con nombre, activables, asociables a materiales, editables y borrables.
- La detección en vivo solo procesa las áreas activas. Las coordenadas se guardan normalizadas, y si la proporción de la pantalla cambia (por ejemplo, al girar el teléfono) el área se marca como «hay que recalibrar» y no se usa.

**Memoria persistente**: materiales y áreas se guardan en una base de datos SQLite local (la solución equivalente a Room que permite la especificación, sin procesadores de anotaciones).

**Estado honesto de los módulos**: el panel distingue *verificado*, *implementado, falta verificar* y *pendiente*. Un módulo solo pasa a verificado con una prueba real en tu teléfono (por ejemplo, la captura se verifica cuando llega un fotograma real que no sale negro; OpenCV, con una autoprueba al arrancar). **«Iniciar bot» sigue desactivado hasta que los 18 módulos estén verificados.**

**Automatización (Fase 3)** (sección *Automatización*):
- **Servicio de accesibilidad**: es lo único que permite a una app tocar la pantalla. Se activa a mano en Ajustes de Android. Si tu APK no viene de Play Store y Android 13 o superior lo deja atenuado, usa el botón *Ajustes de la app*, pulsa ⋮ y elige *Permitir ajustes restringidos*.
- **Joystick**: captura un fotograma del juego y marca el rectángulo del joystick virtual. WASD se hace arrastrando ese joystick (Android no permite inyectar teclas).
- **Probar movimiento**: pulsa cada dirección y mide cuánto se desplaza la escena (correlación de fase); guarda la calibración en píxeles por segundo.
- **Probar personaje**: localiza al personaje en pantalla.
- **Probar inicio de sesión**: pulsa «Log in» y elige tu cuenta de Google por su correo (el que guardes en Ajustes). Se detiene ante contraseñas o verificación en dos pasos y nunca las toca.
- Si aparece el selector de cuentas de Google, la burbuja y los recuadros se ocultan, se sueltan los controles y el bot se pausa; reanudar es manual.

Todo lo demás (rutas, spots, inventario, cofre) llega en las fases siguientes, con sus botones desactivados hasta entonces.

## Cómo usarlo

1. **Panel principal → Iniciar captura** y concede el permiso. Concede también la superposición si quieres ver la burbuja y los recuadros sobre el juego.
2. Importa tus materiales en **Materiales**. Consejo importante: recorta cada material de una **captura de pantalla real de tu teléfono, a tamaño completo**. La aplicación captura a media resolución y escala las referencias a ese tamaño; si recortas de una imagen de otra resolución, el tamaño no coincidirá y la detección fallará.
3. Ve al juego y toca la burbuja **A → Capturar fotograma** (o usa **Capturar en 5 s** desde el Panel y cambia al juego).
4. En **Materiales** o **Áreas de rastreo**, usa **Probar** para ver el resultado sobre ese fotograma. Ajusta el umbral si no encuentra el material o si da falsos positivos.
5. En **Áreas de rastreo**, dibuja las zonas donde aparecen los materiales y actívalas. Después activa **Detección en vivo** en el Panel.
6. En **Automatización**: activa la accesibilidad, captura un fotograma del juego ya dentro del mundo, pulsa **Configurar joystick** y luego **Probar movimiento** y **Probar personaje** con el juego en primer plano. Cada prueba superada marca su módulo como verificado.

## Instalación desde el móvil (sin ordenador)

Si tu repositorio ya tiene el flujo `unpack-zip.yml`:
1. Sube `ArosBot-visual-detection.zip` a la raíz de la rama `main` (*Add file → Upload files*).
2. El flujo **Descomprimir ZIP** lo extrae, lo guarda y lanza la compilación.
3. En la pestaña **Actions**, abre la última ejecución de **Android CI** y descarga el artefacto con el APK.
4. Extrae el APK en el teléfono e instálalo.

Sin ese flujo: crea el archivo `.github/workflows/android.yml` pegando el contenido del que viene en el ZIP y sube el ZIP; el flujo lo extrae y compila.

Para actualizar, sustituye el ZIP (mismo nombre). Los archivos antiguos que ya no existan en la versión nueva no se borran del repositorio.

## Compilar en un ordenador

```
./gradlew assembleDebug
./gradlew testDebugUnitTest
```

Requiere JDK 17 y Android SDK (plataforma 35). El APK queda en `app/build/outputs/apk/debug/app-debug.apk`. La aplicación empaqueta OpenCV solo para arm64 (el Moto G86 Power 5G lo es).

## Hoja de ruta

| Fase | Contenido |
|------|-----------|
| 1 | Proyecto Android, interfaz, GitHub Actions y APK |
| 2 | Captura de pantalla, materiales, áreas de rastreo, recuadros verdes y memoria local |
| 3 | Detección del personaje, calibración, control WASD e inicio de sesión (**esta versión**) |
| 4 | Aprendizaje y seguimiento de rutas |
| 5 | Gestor de spots y selección autónoma de destinos |
| 6 | Recolección, inventario lleno, regreso al cofre y depósito |
| 7 | Copia de seguridad, adaptación progresiva, recuperación de errores y optimización |

## Limitaciones de Android

Consulta [`docs/LIMITACIONES.md`](docs/LIMITACIONES.md).

## Pruebas

- **Lógica en entorno simulado** (JUnit, se ejecutan en Actions): máquina de estados, parada de emergencia, registro, lista de módulos, geometría, supresión de duplicados y conversión de áreas, direcciones WASD, calibración y reparto de pasos del movimiento.
- **Pruebas reales en el teléfono**: autoprueba de la base de datos y de OpenCV al arrancar (aparecen en el Registro de actividad), captura de un fotograma real, y la prueba de detección sobre fotogramas del juego desde Materiales y Áreas.
- **Pruebas reales dentro de Curse of Aros**: las haces tú con los pasos de arriba; hasta que lo confirmes con una captura real, esta fase no está probada en el juego.
