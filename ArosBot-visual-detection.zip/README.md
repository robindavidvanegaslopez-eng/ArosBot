# ArosBot AI

Aplicación Android nativa (Kotlin) para reconocimiento visual, navegación y recolección autónoma en *Curse of Aros*, con aprendizaje local progresivo.

**Versión actual: 0.8.1 — Fase 6 de 7** (recolección con verificación, aviso de inventario lleno, regreso al cofre y depósito, sobre los spots de la Fase 5).

## Novedades de la 0.9.5
- **Mensaje del sistema «recolectando» (nuevo requisito)**: importa en Materiales una captura del mensaje que sale al recolectar, con un nombre que contenga «Sistema» (p. ej. «Sistema recolectando Roble»). Si el nombre incluye el del material, solo vale para ese material; si no, sirve para todos. Tras cada interacción el bot espera ese mensaje: si sale, cuenta como intento confirmado y espera a que termine antes de volver a interactuar (cada intento tiene su probabilidad); si no sale tras 3 intentos, apunta de nuevo y prueba otro ángulo. Un material solo cuenta como recogido si el mensaje se vio al menos una vez.
- **Sin botón no se rinde**: si chocando con el material (pantalla quieta) no aparece «Interactuar», apunta directamente hacia él y, si sigue sin aparecer, hace un pequeño paso lateral y vuelve a empujar, y así hasta resolverlo (límite de 3 min por material).
- Interactúa hasta que el material deja de detectarse (se rompe) o se llena el inventario.

## Novedades de la 0.9.4 (rehecha la recolección por ruta a partir de tu prueba de la 0.9.3)
- **Se acabó el personaje obligatorio y la colisión por cuadros.** «Lo bastante cerca» ahora es: caminando hacia el material, la pantalla deja de moverse (choca con él, que ocupa el paso) estando a menos de ~100 px de su punto en el mundo, **y** se ve el botón «Interactuar». Entonces interactúa.
- Detecta todos los materiales cercanos, elige **el más cercano** y no lo suelta hasta que deja de detectarse o se llena el inventario.
- **Puntos en coordenadas del juego**: cada material se anota en el mundo con la posición del bot en el instante de su fotograma, y solo cuenta si aparece en el mismo punto en 3 de las 4 últimas lecturas (así una textura que se parece ya no desvía al bot). El punto final de la ruta es ese punto del mundo, refinado en cada fotograma por un rastreador local.
- **Detección mucho más rápida**: una sola escala (los objetos tienen siempre el mismo tamaño), mitad de resolución, pasada en gris y confirmación en color solo en un entorno minúsculo; sin copiar fotogramas; el botón de interactuar se busca una vez y después se comprueba cada fotograma solo en su sitio. Ya no se detecta el personaje.
- No probado todavía en el juego.

## Novedades de la 0.9.3
- **Interacción mirando al material**: antes de interactuar, el personaje se orienta hacia el material con un toque corto del joystick en su dirección (el personaje mira hacia donde se movió por última vez; no se comprueba visualmente). Se repite tras cada nuevo viaje.

## Novedades de la 0.9.2
- **Rastreo en cada fotograma, en el mundo**: al elegir un material, el bot lo sigue con una plantilla local (empieza con la imagen de referencia del material y se renueva con lo que ve, así aguanta que cambie la textura al acercarse). Busca solo en el entorno de donde debe estar (milisegundos), por lo que va a la velocidad de la captura. Su posición se guarda en coordenadas del **mundo** con la posición del bot en el instante de cada fotograma, de modo que el retraso de la detección ya no desvía el rumbo; el punto final de la ruta es ese punto y se actualiza en cada fotograma.
- Si el material deja de reconocerse al estar muy cerca, el punto del mundo sigue ahí: el bot llega y sigue interactuando. Se da por recogido cuando el rastreador no lo ve durante 6 fotogramas seguidos tras haberlo visto (si nunca lo vio con certeza, tras 3 interacciones sigue adelante).
- **El personaje se rastrea igual** (plantilla local adaptable) y su último cuadro se conserva aunque un instante no se vea (la cámara lo mantiene fijo). La colisión usa el cuadro del material proyectado donde debe estar ahora.
- Detección completa y rastreo van en dos hilos en paralelo; el registro final indica los ciclos/s de cada uno.
- El trazo sobre el juego dibuja el punto final móvil del viaje al material en cada fotograma.

## Novedades de la 0.9.0
- **Cancelar todo**: botón en el Panel y en el menú de la burbuja. Termina rutas, pruebas, spots, recolección, grabación del macro y detección en vivo, suelta el joystick y deja en blanco todos los indicadores de «en marcha» (corrige el caso de que la app creyera que algo seguía activo).
- **Recolección por ruta** (pestaña Inventario y cofre → «Elegir ruta de recolección» y «Recolectar por ruta»): usas solo la ruta cofre → zona. El bot la sigue; al ver un material la ruta se desvía hacia él (su punto final pasa a ser el material, fijo en el mundo) y conduce hasta que el cuadro de detección del material **toca el del personaje** (la imagen del personaje es obligatoria); entonces pulsa «Interactuar» y repite solo mientras ese material siga detectándose (o hasta que se llene el inventario); cuando desaparece pasa al siguiente (los que no alcanza o no se resuelven en 90 s se descartan). Si sale el aviso de inventario lleno (o acaba la ruta) vuelve por la **misma ruta al revés desde donde esté**, ignorando el resto, repite el macro del cofre y reinicia la ruta. Se detiene tras 2 depósitos fallidos o 3 vueltas sin recoger nada.
- **Detección más rápida**: se analiza a mitad de resolución con 3 escalas y sin pausa entre ciclos, con las plantillas ya redimensionadas en caché; la captura va a 30/60 fps mientras la detección está encendida. El Panel y el registro muestran los ciclos por segundo **medidos de verdad**; no se garantiza 30 con muchos materiales: depende del teléfono.
- El trazado sobre el juego se dibuja ahora «en el suelo» (marcas elípticas, sombra y trazo translúcido, anclado al mundo).
- No probado todavía en el juego.

## Novedades de la 0.8.1

- **Anclas fijas**: una captura ancla nunca cambia de sitio. Lo que se corrige es la posición del personaje, no la del ancla: al reconocerla (ahora con precisión de subpíxel) el bot se coloca respecto a ella, y la imagen manda sobre la estimación (un salto grande solo se rechaza si la confianza es baja, por debajo del 85 %).
- **Inicio y final en el mismo píxel**: al terminar de enseñar, si el bot reconoce el lugar de partida a menos de 25 px, el último punto se fija exactamente en el píxel del primero y el resto del recorrido se reparte sin tocar el inicio.
- **Llegada más exacta**: tolerancia final de 15 px (antes 20) con hasta 10 correcciones. El límite físico sigue siendo el toque mínimo del joystick al 100 %.

## Novedades de la 0.8.0

- **Capturas ancla en cada punto**: al enseñar una ruta, la app toma una captura instantánea (un recorte del fotograma) cada ~100 px, no cada 300. Al seguirla, cada ~250 ms el bot busca la captura más cercana a donde cree estar y **fija su posición a esa imagen del juego** en vez de fiarse de la estimación; un salto absurdo (más de 130 px) se rechaza. Así deja de derivar hacia lugares inaccesibles. Las capturas son solo de la ruta (no se mezclan con tu galería ni con los materiales) y se borran al eliminarla. Las anclas ya no impiden simplificar el camino: el bot sigue yendo en línea casi recta entre puntos.
- **Punto final exacto**: al llegar, el bot reconoce la captura final y corrige hasta 6 veces hasta quedar a menos de 20 px. Límite honesto: con el joystick siempre al 100 % el personaje avanza ~150 px/s y el toque más corto son ~100 ms, así que la precisión realista es de unos 15-20 px, no de 1 px.
- **Más fotogramas**: mientras enseñas o conduces la captura va a 30 fotogramas por segundo (antes ~3). En Configuración puedes activar 60. El teléfono mide los que le da tiempo: al terminar un recorrido, el resultado dice «Medición a N fotogramas por segundo (reales)». La medición ahora trabaja a media resolución para ir más rápido.
- **No se rinde al atascarse**: si Android corta el gesto, el bot vuelve a bajar el dedo y reintenta durante hasta 60 s seguidos sin lograr un gesto estable (con pausas de 0,25 a 1 s) antes de dar el error, y el mensaje final dice cuántos reintentos hizo y la causa real.
- **Incorporarse a otra ruta**: si agota los rodeos, busca otras rutas enseñadas hacia el mismo destino (en cualquier sentido) cuyas capturas reconozca en pantalla, y continúa por la que deje menos camino. Solo funciona si el personaje queda cerca de lo enseñado en esas rutas (la búsqueda cubre una zona alrededor de cada captura).
- **Ajuste preciso del joystick** (Automatización → *Ajustar joystick con movimiento*): el bot empuja la bola hasta el tope hacia derecha, izquierda, arriba y abajo, localiza dónde queda la bola en cada caso comparando con el fotograma de reposo, y deduce el centro y el recorrido reales. Solo guarda si las cuatro posiciones forman una cruz coherente; si no, no cambia nada y dice por qué. El personaje se mueve unos pasos durante la prueba. El botón antiguo *Autoajustar* del editor (por círculos en la imagen) se mantiene pero es menos fiable con joysticks translúcidos.
- **Probar conducción continua**: ahora exige movimiento claro (≥ 30 % de lo esperado) y en la dirección correcta (coseno ≥ 0,7), sin límite superior de rapidez, y un corte de Android al final no la invalida si el personaje obedeció.
- **Capa del macro**: la barra aparece al instante al pulsar el botón (antes había una cuenta atrás de 6 s). Cambias al juego, te colocas y pulsas *Empezar a grabar*.
- Nada de esto se ha probado todavía en el juego ni compilado en este entorno: son 231 pruebas de lógica.

## Novedades de la 0.7.2 (a partir de tu registro del 23 de octubre)

Lo que mostró el registro: el cierre de bucle funciona (reconoció el inicio con 93-97 % de confianza y corrigió 212 y 342 px de deriva), «Probar movimiento» y «Probar diagonales» salieron CORRECTAS, pero **Android cortaba el gesto continuo una y otra vez** (en el segmento 2, 4, 8… hasta el 82) y tras 3 cortes el bot abandonaba. Además, cada corte levanta el dedo, el personaje se para y el bot lo tomaba por un choque («no avanza hacia el punto 6»).

- **Cortes del gesto**: las respuestas de Android se atienden ahora en un hilo propio (antes iban al hilo de la interfaz, que se satura al dibujar la trayectoria sobre el juego) y los segmentos duran 200 ms en vez de 100 (la mitad de eslabones que pueden cortarse). Si aun así lo corta, el bot vuelve a bajar el dedo y sigue: solo abandona tras 4 cortes seguidos de gestos que duran menos de 1,5 s.
- **Cortes no son choques**: si el gesto se cortó, la quietud posterior no se interpreta como obstáculo.
- **Diagnóstico**: el mensaje del corte dice a los cuántos milisegundos ocurrió y cuál fue el mayor hueco entre segmentos. Si vuelve a pasar, pega ese texto y se ve si es de tiempos o de Android.
- **Autoajuste del joystick**: el radio crecía en cada pulsación (105 → 157 → 224 → 300 px) porque elegía siempre el círculo mayor. Ahora elige el más parecido al cuadrado que marcaste, así que repetirlo no lo agranda. Marca el cuadrado a ojo sobre la base del joystick y pulsa *Autoajustar* una vez.
- Nada de esto se ha probado en el juego; son 224 pruebas de lógica.

## Novedades de la 0.7.1

- **Copia de seguridad completa** (Configuración → *Copia de seguridad completa*): *Exportar todo* crea un único archivo `.arosbot` con un formato propio (cabecera, entradas y suma de comprobación) que solo ArosBot AI lee. Incluye materiales con sus imágenes, áreas, joystick, macro del cofre, lugar del cofre, captura de trabajo y todo lo aprendido (rutas, spots, calibración, referencias visuales). *Importar* comprueba el archivo, te muestra qué contiene y, si confirmas, sustituye lo actual. Un archivo ajeno, cortado o modificado se rechaza sin tocar nada. No incluye el correo ni las verificaciones de módulos (se repiten en cada teléfono). Cubierto por 7 pruebas JUnit de la lógica; el guardado y la lectura reales en el teléfono no se han probado.

## Novedades de la 0.7.0 (a partir de tus pruebas en el juego)

- **Causa probable del desajuste inicio/final y de los choques no detectados**: la captura entregaba solo ~3 fotogramas por segundo, así que la ventana de detección de bloqueo casi nunca juzgaba y se perdían desplazamientos. Ahora, mientras enseñas o conduces, la captura va a ~16 fotogramas por segundo (en reposo sigue a ~3 para ahorrar batería).
- **Medición más fiable**: se mide en cuatro franjas alrededor del personaje (su sprite, fijo en pantalla, restaba velocidad) y se combinan por mediana. Si una medición no es fiable no se pierde el desplazamiento: se compara con el último fotograma bueno.
- **Choques**: si la imagen no cambia, cuenta como «escena quieta» (0 px) aunque el fondo sea liso; antes se *estimaba* avance a ciegas y nunca se detectaba el bloqueo. Al detectarlo, el bot primero vuelve a tu camino enseñado y, si no basta, **prueba a rodear el obstáculo** por la derecha y por la izquierda (hasta 6 intentos, cada vez más lejos).
- **Cierre de bucle al enseñar**: al terminar, si se reconoce el lugar de partida, la diferencia con lo acumulado se reparte por el recorrido y el punto final coincide con el inicial. Si no se reconoce, no se corrige nada y el texto lo dice.
- **Autoajuste del joystick**: en el editor del joystick marca una zona aproximada y pulsa *Autoajustar*; el bot busca el círculo del joystick y coloca el cuadrado. Si no encuentra un círculo creíble no cambia nada.
- **Pruebas de movimiento y diagonales** reescritas: miden fotograma a fotograma igual que el seguimiento, no mezclan convenciones (personaje/escena) y bastan una ronda buena por dirección. Nueva prueba **Probar conducción continua**, que comprueba el gesto de un solo dedo (W y luego D sin soltar) y muestra los segmentos enviados y el motivo si Android lo cancela.
- **Trayectoria dibujada sobre el juego**: la superposición muestra la ruta que enseñas (verde) y, al seguirla, lo recorrido (azul), lo que falta (amarillo) y el siguiente punto, anclados al personaje.
- **Macro del cofre**: al marcar el lugar del cofre (o con *Grabar macro del cofre*) grabas tus toques; el bot los repite al llegar y vuelve a su ruta. Son requisitos: la imagen **Interactuar**, el aviso de inventario lleno, el macro y una ruta enseñada hasta el cofre.
- **La imagen del personaje es opcional**: solo sirve si la cámara no mantiene al personaje en el centro; sin ella se usa el centro de la pantalla.
- **Nada de esto se ha probado todavía en el juego** (ni compilado en este entorno): las pruebas JUnit (216) solo comprueban la lógica pura.

## Qué hace esta versión

**Captura de pantalla real** (MediaProjection, servicio en primer plano con notificación):
- Pide el permiso oficial de Android, entrega fotogramas reales a unos 3 por segundo y a media resolución.
- Detecta la pérdida de la sesión, los cambios de resolución u orientación, y libera todos los recursos al detenerse.
- Una burbuja «A» sobre el juego permite capturar un fotograma, mostrar u ocultar los recuadros, detener la captura o hacer la parada de emergencia.

**Materiales** (sección *Materiales*):
- Importa imágenes de la galería, con nombre, categoría, umbral de confianza, tamaño, variantes visuales, estado de reconocimiento y estadísticas.
- Prueba la detección sobre un fotograma real y muestra el resultado con recuadros.

**Detección** (OpenCV, búsqueda de plantillas multiescala en color):
- Encuentra varios ejemplares en un mismo fotograma, tolera pequeños cambios de tamaño y elimina duplicados.
- Dibuja **recuadros verdes** sobre los objetos reconocidos y **recuadros celestes** en las áreas de rastreo.

**Áreas de rastreo** (sección *Áreas de rastreo*):
- Rectángulos ajustables sobre un fotograma real; varias áreas, con nombre, activables, asociables a materiales, editables y borrables.
- La detección en vivo solo procesa las áreas activas. Las coordenadas se guardan normalizadas, y si la proporción de la pantalla cambia (por ejemplo, al girar el teléfono) el área se marca como «hay que recalibrar» y no se usa.

**Memoria persistente**: materiales y áreas se guardan en una base de datos SQLite local (la solución equivalente a Room que permite la especificación, sin procesadores de anotaciones).

**Estado honesto de los módulos**: el panel distingue *verificado*, *implementado, falta verificar* y *pendiente*. Un módulo solo pasa a verificado con una prueba real en tu teléfono (por ejemplo, la captura se verifica cuando llega un fotograma real que no sale negro; OpenCV, con una autoprueba al arrancar). **«Iniciar bot» sigue desactivado hasta que los 18 módulos estén verificados.**

**Automatización (Fase 3)** (sección *Automatización*):
- **Servicio de accesibilidad**: es lo único que permite a una app tocar la pantalla. Se activa a mano en Ajustes de Android. Si tu APK no viene de Play Store y Android 13 o superior lo deja atenuado, usa el botón *Ajustes de la app*, pulsa ⋮ y elige *Permitir ajustes restringidos*.
- **Joystick**: captura un fotograma del juego y marca el rectángulo del joystick virtual. WASD se hace arrastrando ese joystick (Android no permite inyectar teclas).
- **Probar movimiento**: mantiene el dedo quieto en el borde del joystick (100 % de velocidad) y mide cuánto se desplaza la escena (correlación de fase); guarda la calibración en píxeles por segundo.
- **Probar diagonales** (nuevo): empuja el joystick hacia W+A, W+D, S+A y S+D y comprueba que el personaje se mueve en esa dirección y con la rapidez esperada. El joystick es analógico: una diagonal es llevarlo a la esquina, siempre al 100 %. Solo si las cuatro salen bien el bot usa diagonales al seguir rutas; si no, sigue con W/A/S/D.
- **Probar personaje**: localiza al personaje en pantalla.
- **Probar inicio de sesión**: pulsa «Log in» y elige tu cuenta de Google por su correo (el que guardes en Ajustes). Se detiene ante contraseñas o verificación en dos pasos y nunca las toca.
- Si aparece el selector de cuentas de Google, la burbuja y los recuadros se ocultan, se sueltan los controles y el bot se pausa; reanudar es manual.

**Rutas y aprendizaje (Fase 4)**:
- **Enseñar rutas**: pulsa *Enseñar ruta*, cambia al juego y recorre un trayecto a mano. ArosBot mide con cada fotograma nuevo (~10 por segundo) cuánto se mueve la escena (el personaje se mueve al revés), guarda puntos cada 100 px y recortes de referencia visual cada 300 px. Termina con **Terminar ruta** en la burbuja A y guárdala con nombre, origen y destino.
- **Trayectoria dibujada y camino optimizado**: mientras enseñas se dibuja tu trayectoria en la pantalla; al terminar y en cada ruta guardada verás en gris lo que hiciste y en color el camino que seguirá el bot. El bot **no repite tus pasos**: quita rodeos y zigzags (algoritmo de Ramer-Douglas-Peucker, con una tolerancia de 45 px) y va de punto a punto en línea casi recta. Los puntos con referencia visual no se quitan nunca. El bot solo sabe que es transitable lo que tú recorriste, así que sus atajos nunca se alejan más de 45 px de tu camino.
- **Seguir la ruta** (y **al revés**): el bot recorre ese camino con el joystick al 100 %, mide lo que se mueve en cada paso y, al llegar a cada punto con referencia, busca el recorte para corregir la deriva. Si en un atajo el personaje deja de avanzar (obstáculo o el juego no responde), vuelve a tu camino enseñado en ese tramo; si tampoco así avanza, se detiene y lo explica en vez de insistir con la misma tecla. Cada paso queda en el Registro de actividad. Si no reconoce el destino lo dice: llegó por estimación y no cuenta como verificado.
- **Aprendizaje**: cada intento real (éxito, duración, pasos, correcciones) se anota. La fiabilidad de cada ruta sale de una cuenta simple de éxitos y fracasos y la velocidad del movimiento se afina con las mediciones. Es estadística local, no una red neuronal. Puedes exportar, importar y restablecer lo aprendido.
- Los módulos 7 (mapa visual), 8 (rutas) y 10 (aprendizaje) solo se verifican con una ruta real: guardada, seguida con éxito, con el destino reconocido visualmente y el intento guardado.

**Spots y destino autónomo (Fase 5)** (sección *Mapa de spots*):
- Un **spot** es un sitio de recolección que está en uno de tus lugares de ruta (los lugares nacen al enseñar rutas). Tiene nombre, prioridad de 1 a 5 y, si quieres, sus materiales.
- **Estoy en…**: el bot necesita saber dónde está el personaje. Lo indicas tú, o se actualiza solo al terminar una ruta con éxito; si una ruta falla a mitad se borra, porque ya no se sabe.
- **Elegir y ir**: el bot elige el spot con mejor relación valor/coste y va por las rutas enseñadas (encadenando varias si hace falta, también al revés). Valor = prioridad × probabilidad de que haya recursos; coste = tiempo de viaje (penalizado por la poca fiabilidad de la ruta) + 30 s. Solo elige spots a los que hay ruta enseñada, y la pantalla muestra la puntuación y el porqué de cada uno.
- **Qué aprende de cada spot**: al llegar mira varias veces si ve algún material buscado y anota si había o no. Si no había, lo da por agotado y estima cuánto tarda en volver a haber (se afina con cada visita: si vuelve a haber antes de lo esperado la estimación baja, si sigue vacío sube). Es estadística local, no una red neuronal.
- **Alcance**: *Mapa de spots* solo llega y *mira*. Recoger es la sección *Inventario y cofre* (Fase 6).
- Los módulos 11 (planificador de navegación) y 13 (gestor de spots) solo se verifican con un destino elegido por el bot, recorrido de verdad y con la visita guardada y releída.

**Seguir rutas con conducción continua (0.6.1)**: el bot ya no avanza «a pasos». Pone el dedo en el joystick y **no lo levanta** durante todo el recorrido (un único toque que Android recibe como trazo continuo en segmentos de 100 ms). Mientras tanto mide la posición del personaje con cada fotograma nuevo (~25 veces por segundo), corrige el ángulo del dedo hacia el siguiente punto y, con diagonales verificadas, usa el ángulo exacto. Suelta solo al llegar al último punto, anticipándose por la inercia, y si queda a más de ~30 px corrige. En los puntos con referencia visual corrige la deriva sin detenerse.

**Recolección, inventario y cofre (Fase 6)** (sección *Inventario y cofre*):
- **Imágenes de referencia** (en Materiales, recortadas de una captura real; la pantalla las lista con ✔/✘): *Inventario lleno* (el aviso «Your inventory is full.»; puedes añadir varias imágenes alternativas), *Cofre*, *Cofre abierto* (la interfaz de almacenamiento), *Depositar*, *Cerrar cofre* y, opcional, *Interactuar*. Además la imagen del personaje y los recursos de siempre. La función de cada una se deduce de su nombre o categoría.
- **Lugar del cofre**: eliges el lugar (nace al enseñar una ruta que termine junto al cofre). El bot vuelve a él por las rutas enseñadas.
- **Recoger con verificación**: elige el recurso más cercano, se acerca con W/A/S/D hasta el rango, se detiene, interactúa (botón «Interactuar» si lo enseñaste; si no, toca el propio recurso) y mira 8 instantes seguidos: el recurso cuenta como recogido solo si deja de verse en su sitio. Si no, reintenta (3 veces) y cuenta el fallo.
- **Inventario lleno**: el aviso debe verse en varias muestras seguidas. Si se ve solo a medias o no llegan fotogramas, el estado es *incierto* y **el bot se detiene** en lugar de adivinar.
- **Depósito**: vuelve al cofre por una ruta enseñada, **repite el macro de toques que grabaste**, comprueba que el aviso ya no sale y lo **confirma con la siguiente recogida real**. Si el aviso reaparece justo después, el depósito cuenta como fallido.
- **Límites**: 5 recogidas fallidas seguidas, 2 depósitos fallidos, 4 spots seguidos sin recoger nada o inventario incierto detienen el bot y lo dicen en pantalla y en el registro. Parada de emergencia lo cancela todo.
- **Estadísticas por spot**: recogidos y fallos, guardados en la base de datos (versión 5).
- Pruebas sueltas para comprobar cada pieza: *Probar aviso de inventario lleno*, *Probar interacción*, *Probar regreso al cofre*.
- El módulo 14 se verifica al ver de verdad el aviso; el 15, con una recogida o un depósito reales.

## Cómo usarlo

1. **Panel principal → Iniciar captura** y concede el permiso. Concede también la superposición si quieres ver la burbuja y los recuadros sobre el juego.
2. Importa tus materiales en **Materiales**. Consejo importante: recorta cada material de una **captura de pantalla real de tu teléfono, a tamaño completo**. La aplicación captura a media resolución y escala las referencias a ese tamaño; si recortas de una imagen de otra resolución, el tamaño no coincidirá y la detección fallará.
3. Ve al juego y toca la burbuja **A → Capturar fotograma** (o usa **Capturar en 5 s** desde el Panel y cambia al juego).
4. En **Materiales** o **Áreas de rastreo**, usa **Probar** para ver el resultado sobre ese fotograma. Ajusta el umbral si no encuentra el material o si da falsos positivos.
5. En **Áreas de rastreo**, dibuja las zonas donde aparecen los materiales y actívalas. Después activa **Detección en vivo** en el Panel.
6. En **Automatización**: activa la accesibilidad, captura un fotograma del juego ya dentro del mundo, pulsa **Configurar joystick** (marca una zona aproximada y pulsa **Autoajustar**) y luego **Probar movimiento** con el juego en primer plano. «Probar personaje» es opcional. Cada prueba superada marca su módulo como verificado.
7. Pulsa **Probar diagonales** y **Probar conducción continua** en Automatización (con el movimiento ya calibrado).
8. En **Enseñar rutas**, enseña un trayecto corto (200 px o más) y pulsa **Seguir**. Antes tiene que estar calibrado el movimiento.
9. En **Mapa de spots**, añade un spot en uno de los lugares de tus rutas, pulsa **Estoy en…** y luego **Elegir y ir**.
10. Para recolectar: importa en Materiales **Interactuar** y **Inventario lleno**; en **Inventario y cofre** marca el lugar del cofre (enseña antes una ruta que llegue hasta él) y graba el macro de toques.

## Instalación desde el móvil (sin ordenador)

Si tu repositorio ya tiene el flujo `unpack-zip.yml`:
1. Sube `ArosBot-visual-detection.zip` a la raíz de la rama `main` (*Add file → Upload files*).
2. El flujo **Descomprimir ZIP** lo extrae, lo guarda y lanza la compilación.
3. En la pestaña **Actions**, abre la última ejecución de **Android CI** y descarga el artefacto con el APK.
4. Extrae el APK en el teléfono e instálalo.

Sin ese flujo: crea el archivo `.github/workflows/android.yml` pegando el contenido del que viene en el ZIP y sube el ZIP; el flujo lo extrae y compila.

Para actualizar, sustituye el ZIP (mismo nombre). Los archivos antiguos que ya no existan en la versión nueva no se borran del repositorio.

## Compilar en un ordenador

```
./gradlew assembleDebug
./gradlew testDebugUnitTest
```

Requiere JDK 17 y Android SDK (plataforma 35). El APK queda en `app/build/outputs/apk/debug/app-debug.apk`. La aplicación empaqueta OpenCV solo para arm64 (el Moto G86 Power 5G lo es).

## Hoja de ruta

| Fase | Contenido |
|------|-----------|
| 1 | Proyecto Android, interfaz, GitHub Actions y APK |
| 2 | Captura de pantalla, materiales, áreas de rastreo, recuadros verdes y memoria local |
| 3 | Detección del personaje, calibración, control WASD e inicio de sesión |
| 4 | Aprendizaje y seguimiento de rutas |
| 5 | Gestor de spots y selección autónoma de destinos (**esta versión**) |
| 6 | Recolección, inventario lleno, regreso al cofre y depósito |
| 7 | Copia de seguridad, adaptación progresiva, recuperación de errores y optimización |

## Limitaciones de Android

Consulta [`docs/LIMITACIONES.md`](docs/LIMITACIONES.md).

## Pruebas

- **Lógica en entorno simulado** (JUnit, se ejecutan en Actions): máquina de estados, parada de emergencia, registro, lista de módulos, geometría, supresión de duplicados y conversión de áreas, direcciones WASD, calibración y reparto de pasos del movimiento.
- **Pruebas reales en el teléfono**: autoprueba de la base de datos y de OpenCV al arrancar (aparecen en el Registro de actividad), captura de un fotograma real, y la prueba de detección sobre fotogramas del juego desde Materiales y Áreas.
- **Pruebas reales dentro de Curse of Aros**: las haces tú con los pasos de arriba; hasta que lo confirmes con una captura real, esta fase no está probada en el juego.
