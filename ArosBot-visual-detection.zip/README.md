# ArosBot AI

Aplicación Android nativa (Kotlin) para reconocimiento visual, navegación y recolección autónoma en *Curse of Aros*, con aprendizaje local progresivo.

**Versión actual: 0.6.1 — Fase 6 de 7** (recolección con verificación, aviso de inventario lleno, regreso al cofre y depósito, sobre los spots de la Fase 5).

## Qué hace esta versión

**Captura de pantalla real** (MediaProjection, servicio en primer plano con notificación):
- Pide el permiso oficial de Android, entrega fotogramas reales a unos 3 por segundo y a media resolución.
- Detecta la pérdida de la sesión, los cambios de resolución u orientación, y libera todos los recursos al detenerse.
- Una burbuja «A» sobre el juego permite capturar un fotograma, mostrar u ocultar los recuadros, detener la captura o hacer la parada de emergencia.

**Materiales** (sección *Materiales*):
- Importa imágenes de la galería, con nombre, categoría, umbral de confianza, tamaño, variantes visuales, estado de reconocimiento y estadísticas.
- Prueba la detección sobre un fotograma real y muestra el resultado con recuadros.

**Detección** (OpenCV, búsqueda de plantillas multiescala en color):
- Encuentra varios ejemplares en un mismo fotograma, tolera pequeños cambios de tamaño y elimina duplicados.
- Dibuja **recuadros verdes** sobre los objetos reconocidos y **recuadros celestes** en las áreas de rastreo.

**Áreas de rastreo** (sección *Áreas de rastreo*):
- Rectángulos ajustables sobre un fotograma real; varias áreas, con nombre, activables, asociables a materiales, editables y borrables.
- La detección en vivo solo procesa las áreas activas. Las coordenadas se guardan normalizadas, y si la proporción de la pantalla cambia (por ejemplo, al girar el teléfono) el área se marca como «hay que recalibrar» y no se usa.

**Memoria persistente**: materiales y áreas se guardan en una base de datos SQLite local (la solución equivalente a Room que permite la especificación, sin procesadores de anotaciones).

**Estado honesto de los módulos**: el panel distingue *verificado*, *implementado, falta verificar* y *pendiente*. Un módulo solo pasa a verificado con una prueba real en tu teléfono (por ejemplo, la captura se verifica cuando llega un fotograma real que no sale negro; OpenCV, con una autoprueba al arrancar). **«Iniciar bot» sigue desactivado hasta que los 18 módulos estén verificados.**

**Automatización (Fase 3)** (sección *Automatización*):
- **Servicio de accesibilidad**: es lo único que permite a una app tocar la pantalla. Se activa a mano en Ajustes de Android. Si tu APK no viene de Play Store y Android 13 o superior lo deja atenuado, usa el botón *Ajustes de la app*, pulsa ⋮ y elige *Permitir ajustes restringidos*.
- **Joystick**: captura un fotograma del juego y marca el rectángulo del joystick virtual. WASD se hace arrastrando ese joystick (Android no permite inyectar teclas).
- **Probar movimiento**: mantiene el dedo quieto en el borde del joystick (100 % de velocidad) y mide cuánto se desplaza la escena (correlación de fase); guarda la calibración en píxeles por segundo.
- **Probar diagonales** (nuevo): empuja el joystick hacia W+A, W+D, S+A y S+D y comprueba que el personaje se mueve en esa dirección y con la rapidez esperada. El joystick es analógico: una diagonal es llevarlo a la esquina, siempre al 100 %. Solo si las cuatro salen bien el bot usa diagonales al seguir rutas; si no, sigue con W/A/S/D.
- **Probar personaje**: localiza al personaje en pantalla.
- **Probar inicio de sesión**: pulsa «Log in» y elige tu cuenta de Google por su correo (el que guardes en Ajustes). Se detiene ante contraseñas o verificación en dos pasos y nunca las toca.
- Si aparece el selector de cuentas de Google, la burbuja y los recuadros se ocultan, se sueltan los controles y el bot se pausa; reanudar es manual.

**Rutas y aprendizaje (Fase 4)**:
- **Enseñar rutas**: pulsa *Enseñar ruta*, cambia al juego y recorre un trayecto a mano. ArosBot mide con cada fotograma nuevo (~10 por segundo) cuánto se mueve la escena (el personaje se mueve al revés), guarda puntos cada 100 px y recortes de referencia visual cada 300 px. Termina con **Terminar ruta** en la burbuja A y guárdala con nombre, origen y destino.
- **Trayectoria dibujada y camino optimizado**: mientras enseñas se dibuja tu trayectoria en la pantalla; al terminar y en cada ruta guardada verás en gris lo que hiciste y en color el camino que seguirá el bot. El bot **no repite tus pasos**: quita rodeos y zigzags (algoritmo de Ramer-Douglas-Peucker, con una tolerancia de 45 px) y va de punto a punto en línea casi recta. Los puntos con referencia visual no se quitan nunca. El bot solo sabe que es transitable lo que tú recorriste, así que sus atajos nunca se alejan más de 45 px de tu camino.
- **Seguir la ruta** (y **al revés**): el bot recorre ese camino con el joystick al 100 %, mide lo que se mueve en cada paso y, al llegar a cada punto con referencia, busca el recorte para corregir la deriva. Si en un atajo el personaje deja de avanzar (obstáculo o el juego no responde), vuelve a tu camino enseñado en ese tramo; si tampoco así avanza, se detiene y lo explica en vez de insistir con la misma tecla. Cada paso queda en el Registro de actividad. Si no reconoce el destino lo dice: llegó por estimación y no cuenta como verificado.
- **Aprendizaje**: cada intento real (éxito, duración, pasos, correcciones) se anota. La fiabilidad de cada ruta sale de una cuenta simple de éxitos y fracasos y la velocidad del movimiento se afina con las mediciones. Es estadística local, no una red neuronal. Puedes exportar, importar y restablecer lo aprendido.
- Los módulos 7 (mapa visual), 8 (rutas) y 10 (aprendizaje) solo se verifican con una ruta real: guardada, seguida con éxito, con el destino reconocido visualmente y el intento guardado.

**Spots y destino autónomo (Fase 5)** (sección *Mapa de spots*):
- Un **spot** es un sitio de recolección que está en uno de tus lugares de ruta (los lugares nacen al enseñar rutas). Tiene nombre, prioridad de 1 a 5 y, si quieres, sus materiales.
- **Estoy en…**: el bot necesita saber dónde está el personaje. Lo indicas tú, o se actualiza solo al terminar una ruta con éxito; si una ruta falla a mitad se borra, porque ya no se sabe.
- **Elegir y ir**: el bot elige el spot con mejor relación valor/coste y va por las rutas enseñadas (encadenando varias si hace falta, también al revés). Valor = prioridad × probabilidad de que haya recursos; coste = tiempo de viaje (penalizado por la poca fiabilidad de la ruta) + 30 s. Solo elige spots a los que hay ruta enseñada, y la pantalla muestra la puntuación y el porqué de cada uno.
- **Qué aprende de cada spot**: al llegar mira varias veces si ve algún material buscado y anota si había o no. Si no había, lo da por agotado y estima cuánto tarda en volver a haber (se afina con cada visita: si vuelve a haber antes de lo esperado la estimación baja, si sigue vacío sube). Es estadística local, no una red neuronal.
- **Alcance**: *Mapa de spots* solo llega y *mira*. Recoger es la sección *Inventario y cofre* (Fase 6).
- Los módulos 11 (planificador de navegación) y 13 (gestor de spots) solo se verifican con un destino elegido por el bot, recorrido de verdad y con la visita guardada y releída.

**Seguir rutas con conducción continua (0.6.1)**: el bot ya no avanza «a pasos». Pone el dedo en el joystick y **no lo levanta** durante todo el recorrido (un único toque que Android recibe como trazo continuo en segmentos de 100 ms). Mientras tanto mide la posición del personaje con cada fotograma nuevo (~25 veces por segundo), corrige el ángulo del dedo hacia el siguiente punto y, con diagonales verificadas, usa el ángulo exacto. Suelta solo al llegar al último punto, anticipándose por la inercia, y si queda a más de ~30 px corrige. En los puntos con referencia visual corrige la deriva sin detenerse.

**Recolección, inventario y cofre (Fase 6)** (sección *Inventario y cofre*):
- **Imágenes de referencia** (en Materiales, recortadas de una captura real; la pantalla las lista con ✔/✘): *Inventario lleno* (el aviso «Your inventory is full.»; puedes añadir varias imágenes alternativas), *Cofre*, *Cofre abierto* (la interfaz de almacenamiento), *Depositar*, *Cerrar cofre* y, opcional, *Interactuar*. Además la imagen del personaje y los recursos de siempre. La función de cada una se deduce de su nombre o categoría.
- **Lugar del cofre**: eliges el lugar (nace al enseñar una ruta que termine junto al cofre). El bot vuelve a él por las rutas enseñadas.
- **Recoger con verificación**: elige el recurso más cercano, se acerca con W/A/S/D hasta el rango, se detiene, interactúa (botón «Interactuar» si lo enseñaste; si no, toca el propio recurso) y mira 8 instantes seguidos: el recurso cuenta como recogido solo si deja de verse en su sitio. Si no, reintenta (3 veces) y cuenta el fallo.
- **Inventario lleno**: el aviso debe verse en varias muestras seguidas. Si se ve solo a medias o no llegan fotogramas, el estado es *incierto* y **el bot se detiene** en lugar de adivinar.
- **Depósito**: vuelve al cofre, lo reconoce, lo abre, reconoce la interfaz, pulsa *Depositar*, cierra, comprueba que el aviso ya no sale y lo **confirma con la siguiente recogida real**. Si el aviso reaparece justo después, el depósito cuenta como fallido.
- **Límites**: 5 recogidas fallidas seguidas, 2 depósitos fallidos, 4 spots seguidos sin recoger nada o inventario incierto detienen el bot y lo dicen en pantalla y en el registro. Parada de emergencia lo cancela todo.
- **Estadísticas por spot**: recogidos y fallos, guardados en la base de datos (versión 5).
- Pruebas sueltas para comprobar cada pieza: *Probar aviso de inventario lleno*, *Probar interacción*, *Probar regreso al cofre*.
- El módulo 14 se verifica al ver de verdad el aviso; el 15, con una recogida o un depósito reales.

## Cómo usarlo

1. **Panel principal → Iniciar captura** y concede el permiso. Concede también la superposición si quieres ver la burbuja y los recuadros sobre el juego.
2. Importa tus materiales en **Materiales**. Consejo importante: recorta cada material de una **captura de pantalla real de tu teléfono, a tamaño completo**. La aplicación captura a media resolución y escala las referencias a ese tamaño; si recortas de una imagen de otra resolución, el tamaño no coincidirá y la detección fallará.
3. Ve al juego y toca la burbuja **A → Capturar fotograma** (o usa **Capturar en 5 s** desde el Panel y cambia al juego).
4. En **Materiales** o **Áreas de rastreo**, usa **Probar** para ver el resultado sobre ese fotograma. Ajusta el umbral si no encuentra el material o si da falsos positivos.
5. En **Áreas de rastreo**, dibuja las zonas donde aparecen los materiales y actívalas. Después activa **Detección en vivo** en el Panel.
6. En **Automatización**: activa la accesibilidad, captura un fotograma del juego ya dentro del mundo, pulsa **Configurar joystick** y luego **Probar movimiento** y **Probar personaje** con el juego en primer plano. Cada prueba superada marca su módulo como verificado.
7. Pulsa **Probar diagonales** en Automatización (con el movimiento ya calibrado).
8. En **Enseñar rutas**, enseña un trayecto corto (200 px o más) y pulsa **Seguir**. Antes tiene que estar calibrado el movimiento.
9. En **Mapa de spots**, añade un spot en uno de los lugares de tus rutas, pulsa **Estoy en…** y luego **Elegir y ir**.

## Instalación desde el móvil (sin ordenador)

Si tu repositorio ya tiene el flujo `unpack-zip.yml`:
1. Sube `ArosBot-visual-detection.zip` a la raíz de la rama `main` (*Add file → Upload files*).
2. El flujo **Descomprimir ZIP** lo extrae, lo guarda y lanza la compilación.
3. En la pestaña **Actions**, abre la última ejecución de **Android CI** y descarga el artefacto con el APK.
4. Extrae el APK en el teléfono e instálalo.

Sin ese flujo: crea el archivo `.github/workflows/android.yml` pegando el contenido del que viene en el ZIP y sube el ZIP; el flujo lo extrae y compila.

Para actualizar, sustituye el ZIP (mismo nombre). Los archivos antiguos que ya no existan en la versión nueva no se borran del repositorio.

## Compilar en un ordenador

```
./gradlew assembleDebug
./gradlew testDebugUnitTest
```

Requiere JDK 17 y Android SDK (plataforma 35). El APK queda en `app/build/outputs/apk/debug/app-debug.apk`. La aplicación empaqueta OpenCV solo para arm64 (el Moto G86 Power 5G lo es).

## Hoja de ruta

| Fase | Contenido |
|------|-----------|
| 1 | Proyecto Android, interfaz, GitHub Actions y APK |
| 2 | Captura de pantalla, materiales, áreas de rastreo, recuadros verdes y memoria local |
| 3 | Detección del personaje, calibración, control WASD e inicio de sesión |
| 4 | Aprendizaje y seguimiento de rutas |
| 5 | Gestor de spots y selección autónoma de destinos (**esta versión**) |
| 6 | Recolección, inventario lleno, regreso al cofre y depósito |
| 7 | Copia de seguridad, adaptación progresiva, recuperación de errores y optimización |

## Limitaciones de Android

Consulta [`docs/LIMITACIONES.md`](docs/LIMITACIONES.md).

## Pruebas

- **Lógica en entorno simulado** (JUnit, se ejecutan en Actions): máquina de estados, parada de emergencia, registro, lista de módulos, geometría, supresión de duplicados y conversión de áreas, direcciones WASD, calibración y reparto de pasos del movimiento.
- **Pruebas reales en el teléfono**: autoprueba de la base de datos y de OpenCV al arrancar (aparecen en el Registro de actividad), captura de un fotograma real, y la prueba de detección sobre fotogramas del juego desde Materiales y Áreas.
- **Pruebas reales dentro de Curse of Aros**: las haces tú con los pasos de arriba; hasta que lo confirmes con una captura real, esta fase no está probada en el juego.
