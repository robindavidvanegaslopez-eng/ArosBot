plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.arosbot.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.arosbot.ai"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "0.3.0-fase3"

        // El Moto G86 Power 5G es arm64. Evita empaquetar OpenCV para otras arquitecturas.
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Visión artificial (búsqueda de plantillas). Publicado en Maven Central.
    implementation("org.opencv:opencv:4.9.0")

    testImplementation("junit:junit:4.13.2")
}
