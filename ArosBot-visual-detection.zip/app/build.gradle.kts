plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
}
android {
    namespace = "com.arosbot"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.arosbot"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
kotlinOptions {
    jvmTarget = "17"
}
