package com.arosbot

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import java.io.File

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "com.arosbot.START"
        const val ACTION_REFRESH = "com.arosbot.REFRESH"
        const val ACTION_STOP = "com.arosbot.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "resultData"
        private const val NOTIFICATION_ID = 2026
        private const val CHANNEL_ID = "arosbot_capture"
    }
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var worker: Handler? = null
    private var overlay: DetectionOverlay? = null
    private var lastProcessed = 0L
    private var processing = false

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { stopCapture(); stopSelf() }
    }

    override fun onCreate() { super.onCreate(); createNotificationChannel() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, notification("Capturando pantalla"))
                @Suppress("DEPRECATION")
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                if (data != null && projection == null) beginProjection(code, data)
            }
            ACTION_REFRESH -> updateNotification("ArosBot listo")
            ACTION_STOP -> { stopCapture(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun beginProjection(resultCode: Int, data: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(projectionCallback, Handler(mainLooper))
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        workerThread = HandlerThread("ArosBot-vision").also { it.start() }
        worker = Handler(workerThread!!.looper)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            image.use { frame ->
                val now = System.currentTimeMillis()
                val prefs = getSharedPreferences("arosbot", MODE_PRIVATE)
                if (!prefs.getBoolean("detection_enabled", false) || processing || now - lastProcessed < 450) return@setOnImageAvailableListener
                processing = true
                lastProcessed = now
                try {
                    val bitmap = imageToBitmap(frame)
                    try {
                        val material = prefs.getString("active_material", "") ?: ""
                        val path = prefs.getString("reference_$material", null)
                        val found = if (path != null && File(path).exists()) {
                            TemplateMatcher.findAll(bitmap, path, prefs.getInt("threshold", 80) / 100.0)
                        } else emptyList()
                        runOnMain {
                            if (found.isNotEmpty()) overlay?.updateDetections(found, material)
                            else overlay?.updateDetections(emptyList(), "Buscando $material…")
                        }
                        val best = found.firstOrNull()
                        prefs.edit().putInt("last_x", best?.centerX ?: -1).putInt("last_y", best?.centerY ?: -1)
                            .putFloat("last_score", (best?.score ?: 0.0).toFloat()).putLong("last_scan_ms", now).apply()
                    } finally { bitmap.recycle() }
                } catch (_: Exception) {
                } finally { processing = false }
            }
        }, worker)
        display = projection?.createVirtualDisplay("ArosBotScreen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, worker)
        runOnMain { showOverlay() }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun showOverlay() {
        if (overlay != null || !android.provider.Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = DetectionOverlay(this)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
        try { wm.addView(overlay, params) } catch (_: Exception) { overlay = null }
    }

    private fun runOnMain(action: () -> Unit) { Handler(mainLooper).post(action) }

    private fun stopCapture() {
        try { display?.release() } catch (_: Exception) {}; display = null
        try { reader?.close() } catch (_: Exception) {}; reader = null
        try { projection?.unregisterCallback(projectionCallback) } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}; projection = null
        workerThread?.quitSafely(); workerThread = null; worker = null
        runOnMain {
            overlay?.let { view -> try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view) } catch (_: Exception) {} }
            overlay = null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL_ID, "ArosBot", NotificationManager.IMPORTANCE_LOW))
    }
    private fun notification(text: String): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return b.setContentTitle("ArosBot").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
    }
    private fun updateNotification(text: String) { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text)) }
    override fun onDestroy() { stopCapture(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private class DetectionOverlay(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GREEN; style = Paint.Style.STROKE; strokeWidth = 5f }
        private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GREEN; style = Paint.Style.FILL; textSize = 34f; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        private var targets: List<Detection> = emptyList()
        private var label: String = "Buscando…"
        fun updateDetections(detections: List<Detection>, text: String) {
            targets = detections
            label = text
            postInvalidate()
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            for (detection in targets) {
                val rect = RectF(detection.left.toFloat(), detection.top.toFloat(), detection.right.toFloat(), detection.bottom.toFloat())
                canvas.drawRect(rect, paint)
                val text = if (targets.size == 1 && label.startsWith("Buscando")) label else "$label ${(detection.score * 100).toInt()}%"
                canvas.drawText(text, rect.left, (rect.top - 12f).coerceAtLeast(38f), labelPaint)
            }
        }
    }
}
