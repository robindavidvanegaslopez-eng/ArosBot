package com.arosbot

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Pauses ArosBot while Google's account chooser is on top, then resumes it when dismissed. */
class GoogleChooserAccessibilityService : AccessibilityService() {
    private var chooserWasDetected = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return

        val root = rootInActiveWindow ?: return
        val packageName = root.packageName?.toString().orEmpty()
        val isChooser = isGoogleAccountChooser(packageName, root)

        if (isChooser && !chooserWasDetected) {
            chooserWasDetected = true
            sendCaptureAction(CaptureService.ACTION_TEMP_PAUSE)
        } else if (!isChooser && chooserWasDetected) {
            chooserWasDetected = false
            sendCaptureAction(CaptureService.ACTION_TEMP_RESUME)
        }
        root.recycleCompat()
    }

    private fun isGoogleAccountChooser(packageName: String, root: AccessibilityNodeInfo): Boolean {
        if (packageName != "com.google.android.gms" &&
            packageName != "com.google.android.googlequicksearchbox") return false

        val className = root.className?.toString()?.lowercase().orEmpty()
        if (className.contains("chooseaccount") || className.contains("accountpicker") ||
            className.contains("accountchooser")) return true

        val phrases = listOf(
            "choose an account", "select an account", "choose account",
            "selecciona una cuenta", "elige una cuenta", "elegir una cuenta",
            "seleccionar una cuenta", "usar otra cuenta", "use another account"
        )
        return treeContainsPhrase(root, phrases, 0)
    }

    private fun treeContainsPhrase(node: AccessibilityNodeInfo?, phrases: List<String>, depth: Int): Boolean {
        if (node == null || depth > 12) return false
        val text = buildString {
            append(node.text?.toString().orEmpty())
            append(' ')
            append(node.contentDescription?.toString().orEmpty())
        }.lowercase()
        if (phrases.any { text.contains(it) }) return true
        for (i in 0 until node.childCount) {
            if (treeContainsPhrase(node.getChild(i), phrases, depth + 1)) return true
        }
        return false
    }

    private fun sendCaptureAction(action: String) {
        try {
            startService(Intent(this, CaptureService::class.java).setAction(action))
        } catch (_: Exception) {
            // The capture service may not be running; in that case there is nothing to pause.
        }
    }

    override fun onInterrupt() {}

    @Suppress("DEPRECATION")
    private fun AccessibilityNodeInfo.recycleCompat() { recycle() }
}
