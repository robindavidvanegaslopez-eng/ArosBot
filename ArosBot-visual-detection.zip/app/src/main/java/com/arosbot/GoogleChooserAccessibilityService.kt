package com.arosbot

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/** Temporarily pauses the detector while a Google account-selection screen/dialog is visible. */
class GoogleChooserAccessibilityService : AccessibilityService() {
    private var chooserWasDetected = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val relevantEvent = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
        if (!relevantEvent) return

        val eventPackage = event.packageName?.toString().orEmpty().lowercase(Locale.ROOT)
        val eventText = buildString {
            for (part in event.text) append(part?.toString().orEmpty()).append(' ')
            append(event.contentDescription?.toString().orEmpty())
        }.lowercase(Locale.ROOT)

        val root = rootInActiveWindow
        val rootPackage = root?.packageName?.toString().orEmpty().lowercase(Locale.ROOT)
        val combinedText = eventText + " " + (root?.let { treeText(it, 0) } ?: "")
        val packageHint = isGooglePackage(eventPackage) || isGooglePackage(rootPackage)
        val chooserText = containsChooserPhrase(combinedText)
        // The Google chooser can be embedded in another app's window, so its event/root
        // package is not always a Google package. The explicit chooser phrases are enough.
        val accountScreen = chooserText || (packageHint && (
            combinedText.contains("account picker") || combinedText.contains("accountchooser") ||
            combinedText.contains("chooseaccount") || combinedText.contains("selección de cuenta") ||
            combinedText.contains("seleccion de cuenta")
        ))

        if (accountScreen && !chooserWasDetected) {
            chooserWasDetected = true
            sendCaptureAction(CaptureService.ACTION_TEMP_PAUSE)
        } else if (chooserWasDetected && !accountScreen &&
            (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
             event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED)) {
            // Resume only on a window transition; content-change events can be transient/empty.
            chooserWasDetected = false
            sendCaptureAction(CaptureService.ACTION_TEMP_RESUME)
        }
        // rootInActiveWindow is owned by Android; don't recycle the service's root node.
    }

    private fun isGooglePackage(packageName: String): Boolean =
        packageName == "com.google.android.gms" ||
        packageName == "com.google.android.googlequicksearchbox" ||
        packageName == "com.google.android.apps.accounts" ||
        packageName.startsWith("com.google.android.gms.")

    private fun containsChooserPhrase(text: String): Boolean {
        val phrases = listOf(
            "choose an account", "select an account", "choose account", "select account",
            "selecciona una cuenta", "seleccione una cuenta", "elige una cuenta", "elegir una cuenta",
            "seleccionar una cuenta", "selección de cuenta", "seleccion de cuenta",
            "usar otra cuenta", "usa otra cuenta", "use another account", "add another account",
            "añadir otra cuenta", "agregar otra cuenta", "elige una cuenta de google"
        )
        return phrases.any { text.contains(it) }
    }

    private fun treeText(node: AccessibilityNodeInfo?, depth: Int): String {
        if (node == null || depth > 14) return ""
        val own = buildString {
            append(node.text?.toString().orEmpty()).append(' ')
            append(node.contentDescription?.toString().orEmpty()).append(' ')
            append(node.className?.toString().orEmpty()).append(' ')
        }
        val children = StringBuilder()
        for (i in 0 until minOf(node.childCount, 80)) {
            children.append(treeText(node.getChild(i), depth + 1)).append(' ')
        }
        return (own + children).lowercase(Locale.ROOT)
    }

    private fun sendCaptureAction(action: String) {
        try {
            val intent = Intent(this, CaptureService::class.java).setAction(action)
            // CaptureService is already foreground while screen capture is active.
            startService(intent)
        } catch (_: Exception) {
            // If screen capture isn't running, there's no active detector to pause.
        }
    }

    override fun onInterrupt() {}
}
