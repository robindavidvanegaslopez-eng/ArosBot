package com.arosbot

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/** Pauses detection while a Google account chooser/sign-in sheet is visible. */
class GoogleChooserAccessibilityService : AccessibilityService() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var chooserWasDetected = false
    private var resumeChecks = 0
    private val delayedResume = object : Runnable {
        override fun run() {
            val root = rootInActiveWindow
            val chooserStillVisible = root != null && looksLikeAccountChooser(
                root.packageName?.toString().orEmpty(), treeText(root, 0)
            )
            if (chooserStillVisible) {
                resumeChecks = 0
                mainHandler.postDelayed(this, 1200L)
                return
            }
            if (root == null && resumeChecks < 5) {
                resumeChecks++
                mainHandler.postDelayed(this, 650L)
                return
            }
            if (chooserWasDetected) {
                chooserWasDetected = false
                resumeChecks = 0
                sendCaptureAction(CaptureService.ACTION_TEMP_RESUME)
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val relevant = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> true
            else -> false
        }
        if (!relevant) return

        val eventPackage = event.packageName?.toString().orEmpty()
        val eventClass = event.className?.toString().orEmpty()
        val eventText = buildString {
            append(eventClass).append(' ')
            for (part in event.text) append(part?.toString().orEmpty()).append(' ')
            append(event.contentDescription?.toString().orEmpty())
        }
        val root = rootInActiveWindow
        val rootPackage = root?.packageName?.toString().orEmpty()
        val rootText = root?.let { treeText(it, 0) }.orEmpty()
        val detected = looksLikeAccountChooser(eventPackage, eventText) ||
            looksLikeAccountChooser(rootPackage, rootText)

        if (detected) {
            mainHandler.removeCallbacks(delayedResume)
            resumeChecks = 0
            if (!chooserWasDetected) {
                chooserWasDetected = true
                sendCaptureAction(CaptureService.ACTION_TEMP_PAUSE)
            }
        } else if (chooserWasDetected && (
                event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED
            )) {
            // Google sheets sometimes emit an empty transition while still open. Wait and
            // inspect the active window again before restoring detection.
            mainHandler.removeCallbacks(delayedResume)
            resumeChecks = 0
            mainHandler.postDelayed(delayedResume, 1800L)
        }
    }

    private fun looksLikeAccountChooser(packageNameRaw: String, textRaw: String): Boolean {
        val packageName = packageNameRaw.lowercase(Locale.ROOT)
        val text = textRaw.lowercase(Locale.ROOT)
        val googlePackage = packageName == "com.google.android.gms" ||
            packageName == "com.google.android.googlequicksearchbox" ||
            packageName == "com.google.android.apps.accounts" ||
            packageName.startsWith("com.google.android.gms.")

        val chooserPhrases = listOf(
            "choose an account", "select an account", "choose account", "select account",
            "chooseaccount", "accountpicker", "account picker", "accountchooser",
            "selecciona una cuenta", "seleccione una cuenta", "elige una cuenta", "elegir una cuenta",
            "seleccionar una cuenta", "selección de cuenta", "seleccion de cuenta",
            "usar otra cuenta", "usa otra cuenta", "use another account", "add another account",
            "añadir otra cuenta", "agregar otra cuenta", "elige una cuenta de google",
            "continuar como", "continue as", "use your google account", "usar tu cuenta de google"
        )
        if (chooserPhrases.any { text.contains(it) }) return true

        val chooserClass = text.contains("chooseaccount") || text.contains("accountpicker") ||
            text.contains("accountchooser") || text.contains("choose_account") ||
            text.contains("account_picker")
        if (chooserClass) return true

        // Some Android/Google versions show only profile names or email addresses, with no
        // translated title. Use these signals only when the window belongs to Google.
        if (googlePackage) {
            val accountWords = listOf("account", "cuenta", "google", "email", "correo", "gmail", "@")
            val actionWords = listOf("cancel", "cancelar", "continue", "continuar", "another", "otra", "use", "usar", "select", "seleccion")
            val hasAccountWord = accountWords.any { text.contains(it) }
            val hasActionWord = actionWords.any { text.contains(it) }
            val hasEmail = Regex("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}").containsMatchIn(text)
            if (hasAccountWord && (hasActionWord || hasEmail)) return true
        }
        return false
    }

    private fun treeText(node: AccessibilityNodeInfo?, depth: Int): String {
        if (node == null || depth > 12) return ""
        val own = buildString {
            append(node.text?.toString().orEmpty()).append(' ')
            append(node.contentDescription?.toString().orEmpty()).append(' ')
            append(node.className?.toString().orEmpty()).append(' ')
            append(node.viewIdResourceName?.toString().orEmpty()).append(' ')
        }
        val children = StringBuilder()
        for (i in 0 until minOf(node.childCount, 70)) {
            children.append(treeText(node.getChild(i), depth + 1)).append(' ')
        }
        return (own + children).lowercase(Locale.ROOT)
    }

    private fun sendCaptureAction(action: String) {
        try {
            startService(Intent(this, CaptureService::class.java).setAction(action))
        } catch (_: Exception) {
            // CaptureService may not be running if the user has not started screen capture.
        }
    }

    override fun onInterrupt() {}
    override fun onDestroy() {
        mainHandler.removeCallbacks(delayedResume)
        super.onDestroy()
    }
}
