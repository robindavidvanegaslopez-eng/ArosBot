package com.arosbot

import androidx.activity.ComponentActivity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.File

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("arosbot", Context.MODE_PRIVATE) }
    private lateinit var materialName: EditText
    private lateinit var materialSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var thresholdLabel: TextView
    private var thresholdValue = 80

    private val imagePicker = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) saveReference(uri)
    }
    private val screenCapture = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val svc = Intent(this, CaptureService::class.java).apply {
                action = CaptureService.ACTION_START
                putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
            status.text = "Captura activa. ArosBot buscará el material seleccionado."
        } else status.text = "No se autorizó la captura de pantalla."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (18 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.TOP
        }
        val title = TextView(this).apply { text = "ArosBot"; textSize = 28f; setTextColor(0xFF176B3A.toInt()) }
        val subtitle = TextView(this).apply { text = "Detector visual de materiales"; textSize = 15f }
        materialName = EditText(this).apply {
            hint = "Nombre del material (ej. pearwood)"
            singleLine = true
        }
        val addReference = makeButton("Añadir / cambiar imagen de referencia") {
            val name = materialName.text.toString().trim()
            if (name.isBlank()) status.text = "Escribe primero el nombre del material."
            else imagePicker.launch("image/*")
        }
        materialSpinner = Spinner(this)
        refreshMaterials()
        materialSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val item = parent?.getItemAtPosition(position)?.toString() ?: return
                materialName.setText(item)
            }
        }
        val threshold = SeekBar(this).apply {
            max = 35
            progress = 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    thresholdValue = 60 + progress
                    thresholdLabel.text = "Sensibilidad: $thresholdValue%"
                    prefs.edit().putInt("threshold", thresholdValue).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        thresholdLabel = TextView(this).apply { text = "Sensibilidad: 80%" }
        val overlay = makeButton("Permitir recuadro verde") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else status.text = "Permiso de recuadro concedido."
        }
        val start = makeButton("Iniciar captura y detección") {
            val name = materialSpinner.selectedItem?.toString() ?: materialName.text.toString().trim()
            val path = prefs.getString("reference_$name", null)
            if (name.isBlank() || path.isNullOrBlank() || !File(path).exists()) {
                status.text = "Selecciona un material y guarda su imagen de referencia primero."
            } else if (!Settings.canDrawOverlays(this)) {
                status.text = "Primero permite mostrar el recuadro verde; vuelve aquí después."
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                prefs.edit().putString("active_material", name).putBoolean("detection_enabled", true).apply()
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                screenCapture.launch(manager.createScreenCaptureIntent())
            }
        }
        val pause = makeButton("Pausar / reanudar detección") {
            val active = !prefs.getBoolean("detection_enabled", false)
            prefs.edit().putBoolean("detection_enabled", active).apply()
            status.text = if (active) "Detección reanudada." else "Detección pausada."
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_REFRESH))
        }
        val stop = makeButton("Detener bot") {
            prefs.edit().putBoolean("detection_enabled", false).apply()
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            status.text = "Bot detenido."
        }
        status = TextView(this).apply { text = "1. Ponle nombre al material. 2. Adjunta una imagen. 3. Inicia la detección."; textSize = 14f }
        val menuLabel = TextView(this).apply { text = "MATERIALES GUARDADOS"; textSize = 12f; setPadding(0, pad / 2, 0, 0) }
        listOf(title, subtitle, materialName, addReference, menuLabel, materialSpinner, thresholdLabel, threshold, overlay, start, pause, stop, status).forEach {
            root.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = pad / 3 })
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun makeButton(text: String, action: () -> Unit) = Button(this).apply { this.text = text; setOnClickListener { action() } }

    private fun saveReference(uri: Uri) {
        val name = materialName.text.toString().trim()
        if (name.isBlank()) { status.text = "Escribe el nombre del material primero."; return }
        try {
            val safe = name.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)
            val target = File(filesDir, "reference_$safe.img")
            contentResolver.openInputStream(uri).use { input ->
                if (input == null) error("No se pudo leer la imagen")
                target.outputStream().use { output -> input.copyTo(output) }
            }
            prefs.edit().putString("reference_$name", target.absolutePath).apply()
            refreshMaterials()
            val idx = (materialSpinner.adapter as ArrayAdapter<String>).getPosition(name)
            if (idx >= 0) materialSpinner.setSelection(idx)
            status.text = "Imagen guardada para $name. Usa una imagen clara y recortada del material."
        } catch (e: Exception) { status.text = "No se pudo guardar la imagen: ${e.message}" }
    }

    private fun refreshMaterials() {
        val names = prefs.all.keys.filter { it.startsWith("reference_") }.map { it.removePrefix("reference_") }.sorted().toMutableList()
        if (names.isEmpty()) names.add("(sin materiales todavía)")
        materialSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
    }
}
