package com.arosbot

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** A match rectangle in the original screen pixel coordinates. */
data class Detection(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val centerX: Int,
    val centerY: Int,
    val score: Double
)

/** Multi-scale sampled normalized cross-correlation for repeated game sprites. */
object TemplateMatcher {
    fun findAll(screen: Bitmap, path: String, threshold: Double, maxMatches: Int = 20): List<Detection> {
        val original = BitmapFactory.decodeFile(path) ?: return emptyList()
        try {
            if (original.width < 8 || original.height < 8 || screen.width < 8 || screen.height < 8) return emptyList()

            // Shrink the captured frame to make the search practical on a phone.
            val screenW = min(480, screen.width)
            val screenScale = screenW.toDouble() / screen.width.toDouble()
            val screenH = max(1, (screen.height * screenScale).toInt())
            val scaledScreen = Bitmap.createScaledBitmap(screen, screenW, screenH, true)
            try {
                val sp = IntArray(screenW * screenH)
                scaledScreen.getPixels(sp, 0, screenW, 0, 0, screenW, screenH)
                val accepted = ArrayList<ScaledMatch>()
                // The reference may have been captured at a different zoom / display scale.
                // Test several sizes around the expected size rather than assuming one exact scale.
                val sizeFactors = doubleArrayOf(0.45, 0.60, 0.75, 0.90, 1.0, 1.15, 1.35, 1.60)
                for (factor in sizeFactors) {
                    val tw = max(8, (original.width * screenScale * factor).toInt())
                    val th = max(8, (original.height * screenScale * factor).toInt())
                    if (tw >= screenW || th >= screenH || tw * th < 64) continue
                    val template = Bitmap.createScaledBitmap(original, tw, th, true)
                    try {
                        val tp = IntArray(tw * th)
                        template.getPixels(tp, 0, tw, 0, 0, tw, th)
                        val sampleStep = max(2, min(6, min(tw, th) / 10))
                        val offsets = ArrayList<Int>()
                        val templateGray = ArrayList<Int>()
                        var y = 0
                        while (y < th) {
                            var x = 0
                            while (x < tw) {
                                offsets.add(y * tw + x)
                                templateGray.add(gray(tp[y * tw + x]))
                                x += sampleStep
                            }
                            y += sampleStep
                        }
                        if (offsets.size < 8) continue
                        val meanT = templateGray.sumOf { it.toDouble() } / templateGray.size
                        var varT = 0.0
                        for (v in templateGray) { val d = v - meanT; varT += d * d }
                        if (varT < 1.0) continue

                        val stepX = max(2, tw / 4)
                        val stepY = max(2, th / 4)
                        val candidates = ArrayList<ScaledMatch>(32)
                        val keepCandidates = 32
                        y = 0
                        while (y <= screenH - th) {
                            var x = 0
                            while (x <= screenW - tw) {
                                var sumS = 0.0
                                for (offset in offsets) sumS += gray(sp[(y + offset / tw) * screenW + x + offset % tw])
                                val meanS = sumS / offsets.size
                                var numerator = 0.0
                                var varS = 0.0
                                for (i in offsets.indices) {
                                    val screenGray = gray(sp[(y + offsets[i] / tw) * screenW + x + offsets[i] % tw]) - meanS
                                    val templateValue = templateGray[i] - meanT
                                    numerator += screenGray * templateValue
                                    varS += screenGray * screenGray
                                }
                                val score = if (varS > 0.0) numerator / sqrt(varS * varT) else 0.0
                                if (score >= threshold) {
                                    val candidate = ScaledMatch(x, y, tw, th, score)
                                    if (candidates.size < keepCandidates) candidates.add(candidate)
                                    else {
                                        var weakest = 0
                                        for (i in 1 until candidates.size) if (candidates[i].score < candidates[weakest].score) weakest = i
                                        if (score > candidates[weakest].score) candidates[weakest] = candidate
                                    }
                                }
                                x += stepX
                            }
                            y += stepY
                        }
                        for (candidate in candidates) {
                            if (accepted.none { intersectionOverUnion(it, candidate) > 0.28 }) accepted.add(candidate)
                        }
                    } finally {
                        if (template !== original) template.recycle()
                    }
                }
                val inverse = 1.0 / screenScale
                return accepted.sortedByDescending { it.score }.take(maxMatches).map { m ->
                    val left = (m.x * inverse).toInt()
                    val top = (m.y * inverse).toInt()
                    val right = ((m.x + m.width) * inverse).toInt()
                    val bottom = ((m.y + m.height) * inverse).toInt()
                    Detection(left, top, right, bottom, (left + right) / 2, (top + bottom) / 2, m.score)
                }
            } finally {
                if (scaledScreen !== screen) scaledScreen.recycle()
            }
        } finally {
            original.recycle()
        }
    }

    private data class ScaledMatch(val x: Int, val y: Int, val width: Int, val height: Int, val score: Double)

    private fun intersectionOverUnion(a: ScaledMatch, b: ScaledMatch): Double {
        val left = max(a.x, b.x)
        val top = max(a.y, b.y)
        val right = min(a.x + a.width, b.x + b.width)
        val bottom = min(a.y + a.height, b.y + b.height)
        val intersection = max(0, right - left) * max(0, bottom - top)
        if (intersection == 0) return 0.0
        val areaA = a.width * a.height
        val areaB = b.width * b.height
        return intersection.toDouble() / (areaA + areaB - intersection).toDouble()
    }

    private fun gray(c: Int): Int = (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100
}
