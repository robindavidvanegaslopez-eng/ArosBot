package com.arosbot

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** A match rectangle in the original screen pixel coordinates. */
data class Detection(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val centerX: Int,
    val centerY: Int,
    val score: Double
)

/** Fast, sampled normalized cross-correlation matcher for finding repeated objects. */
object TemplateMatcher {
    fun findAll(screen: Bitmap, path: String, threshold: Double, maxMatches: Int = 20): List<Detection> {
        val original = BitmapFactory.decodeFile(path) ?: return emptyList()
        try {
            if (original.width < 8 || original.height < 8 || screen.width < 8 || screen.height < 8) return emptyList()

            // Work on a smaller frame to keep CPU usage low on phones.
            val screenW = min(360, screen.width)
            val scale = screenW.toDouble() / screen.width.toDouble()
            val screenH = max(1, (screen.height * scale).toInt())
            val scaledScreen = Bitmap.createScaledBitmap(screen, screenW, screenH, true)
            val tw = max(8, (original.width * scale).toInt())
            val th = max(8, (original.height * scale).toInt())
            if (tw >= screenW || th >= screenH || tw * th < 64) {
                if (scaledScreen !== screen) scaledScreen.recycle()
                return emptyList()
            }
            val template = Bitmap.createScaledBitmap(original, tw, th, true)
            try {
                val tp = IntArray(tw * th)
                template.getPixels(tp, 0, tw, 0, 0, tw, th)
                val sp = IntArray(screenW * screenH)
                scaledScreen.getPixels(sp, 0, screenW, 0, 0, screenW, screenH)

                // Fixed sample locations are reused for every candidate instead of scanning every pixel.
                val sampleStep = max(2, min(5, min(tw, th) / 8))
                val offsets = ArrayList<Int>()
                val templateGray = ArrayList<Int>()
                var y = 0
                while (y < th) {
                    var x = 0
                    while (x < tw) {
                        offsets.add(y * tw + x)
                        templateGray.add(gray(tp[y * tw + x]))
                        x += sampleStep
                    }
                    y += sampleStep
                }
                if (offsets.size < 8) return emptyList()
                val meanT = templateGray.sumOf { it.toDouble() } / templateGray.size
                var varT = 0.0
                for (v in templateGray) { val d = v - meanT; varT += d * d }
                if (varT < 1.0) return emptyList()

                val stepX = max(2, tw / 5)
                val stepY = max(2, th / 5)
                // Keep only the strongest candidates; flat scenes can otherwise create huge lists.
                val candidates = ArrayList<ScaledMatch>(96)
                val keepCandidates = 96
                y = 0
                while (y <= screenH - th) {
                    var x = 0
                    while (x <= screenW - tw) {
                        var sumS = 0.0
                        for (offset in offsets) sumS += gray(sp[(y + offset / tw) * screenW + x + offset % tw])
                        val meanS = sumS / offsets.size
                        var numerator = 0.0
                        var varS = 0.0
                        for (i in offsets.indices) {
                            val screenGray = gray(sp[(y + offsets[i] / tw) * screenW + x + offsets[i] % tw]) - meanS
                            val templateValue = templateGray[i] - meanT
                            numerator += screenGray * templateValue
                            varS += screenGray * screenGray
                        }
                        val score = if (varS > 0.0) numerator / sqrt(varS * varT) else 0.0
                        if (score >= threshold) {
                            val candidate = ScaledMatch(x, y, score)
                            if (candidates.size < keepCandidates) candidates.add(candidate)
                            else {
                                var weakest = 0
                                for (i in 1 until candidates.size) if (candidates[i].score < candidates[weakest].score) weakest = i
                                if (score > candidates[weakest].score) candidates[weakest] = candidate
                            }
                        }
                        x += stepX
                    }
                    y += stepY
                }

                val accepted = ArrayList<ScaledMatch>()
                for (candidate in candidates.sortedByDescending { it.score }) {
                    if (accepted.none { intersectionOverUnion(it, candidate, tw, th) > 0.25 }) {
                        accepted.add(candidate)
                        if (accepted.size >= maxMatches) break
                    }
                }
                val inverse = 1.0 / scale
                return accepted.map { m ->
                    val left = (m.x * inverse).toInt()
                    val top = (m.y * inverse).toInt()
                    val right = ((m.x + tw) * inverse).toInt()
                    val bottom = ((m.y + th) * inverse).toInt()
                    Detection(left, top, right, bottom, (left + right) / 2, (top + bottom) / 2, m.score)
                }
            } finally {
                if (template !== original) template.recycle()
                if (scaledScreen !== screen) scaledScreen.recycle()
            }
        } finally {
            original.recycle()
        }
    }

    private data class ScaledMatch(val x: Int, val y: Int, val score: Double)

    private fun intersectionOverUnion(a: ScaledMatch, b: ScaledMatch, w: Int, h: Int): Double {
        val left = max(a.x, b.x)
        val top = max(a.y, b.y)
        val right = min(a.x + w, b.x + w)
        val bottom = min(a.y + h, b.y + h)
        val intersection = max(0, right - left) * max(0, bottom - top)
        if (intersection == 0) return 0.0
        val area = w * h
        return intersection.toDouble() / (2 * area - intersection).toDouble()
    }

    private fun gray(c: Int): Int = (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100
}
