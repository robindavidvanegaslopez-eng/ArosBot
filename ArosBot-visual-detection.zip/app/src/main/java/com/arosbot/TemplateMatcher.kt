package com.arosbot

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** A match rectangle, in the original screen's pixel coordinates. */
data class Detection(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val centerX: Int,
    val centerY: Int,
    val score: Double
)

/**
 * Lightweight grayscale normalized cross-correlation template matcher.
 * It returns several non-overlapping matches so repeated objects can be boxed.
 * This is a prototype: reference images work best when cropped tightly around one object.
 */
object TemplateMatcher {
    fun findAll(screen: Bitmap, path: String, threshold: Double, maxMatches: Int = 12): List<Detection> {
        val original = BitmapFactory.decodeFile(path) ?: return emptyList()
        try {
            if (original.width < 8 || original.height < 8 || screen.width < 8 || screen.height < 8) return emptyList()

            // Reduce the frame for a reasonable CPU cost, while preserving screen coordinates.
            val screenW = min(480, screen.width)
            val scale = screenW.toDouble() / screen.width.toDouble()
            val screenH = max(1, (screen.height * scale).toInt())
            val scaledScreen = Bitmap.createScaledBitmap(screen, screenW, screenH, true)
            val tw = max(8, (original.width * scale).toInt())
            val th = max(8, (original.height * scale).toInt())
            if (tw >= screenW || th >= screenH) {
                if (scaledScreen !== screen) scaledScreen.recycle()
                return emptyList()
            }
            val template = Bitmap.createScaledBitmap(original, tw, th, true)
            try {
                val tp = IntArray(tw * th)
                template.getPixels(tp, 0, tw, 0, 0, tw, th)
                val sp = IntArray(screenW * screenH)
                scaledScreen.getPixels(sp, 0, screenW, 0, 0, screenW, screenH)

                val sample = max(1, min(tw, th) / 12)
                var meanT = 0.0
                var count = 0
                var yy = 0
                while (yy < th) {
                    var xx = 0
                    while (xx < tw) {
                        meanT += gray(tp[yy * tw + xx])
                        count++
                        xx += sample
                    }
                    yy += sample
                }
                if (count == 0) return emptyList()
                meanT /= count.toDouble()
                var varT = 0.0
                yy = 0
                while (yy < th) {
                    var xx = 0
                    while (xx < tw) {
                        val d = gray(tp[yy * tw + xx]) - meanT
                        varT += d * d
                        xx += sample
                    }
                    yy += sample
                }
                if (varT < 1.0) return emptyList()

                val stepX = max(2, tw / 4)
                val stepY = max(2, th / 4)
                val candidates = ArrayList<ScaledMatch>()
                var y = 0
                while (y <= screenH - th) {
                    var x = 0
                    while (x <= screenW - tw) {
                        var meanS = 0.0
                        var n = 0
                        var sy = 0
                        while (sy < th) {
                            var sx = 0
                            while (sx < tw) {
                                meanS += gray(sp[(y + sy) * screenW + x + sx])
                                n++
                                sx += sample
                            }
                            sy += sample
                        }
                        meanS /= n.coerceAtLeast(1).toDouble()
                        var numerator = 0.0
                        var varS = 0.0
                        sy = 0
                        while (sy < th) {
                            var sx = 0
                            while (sx < tw) {
                                val screenGray = gray(sp[(y + sy) * screenW + x + sx]) - meanS
                                val templateGray = gray(tp[sy * tw + sx]) - meanT
                                numerator += screenGray * templateGray
                                varS += screenGray * screenGray
                                sx += sample
                            }
                            sy += sample
                        }
                        val score = if (varS > 0.0) numerator / sqrt(varS * varT) else 0.0
                        if (score >= threshold) candidates.add(ScaledMatch(x, y, score))
                        x += stepX
                    }
                    y += stepY
                }

                // Highest-scoring matches win; suppress boxes that mostly overlap one another.
                val accepted = ArrayList<ScaledMatch>()
                for (candidate in candidates.sortedByDescending { it.score }) {
                    if (accepted.none { intersectionOverUnion(it, candidate, tw, th) > 0.30 }) {
                        accepted.add(candidate)
                        if (accepted.size >= maxMatches) break
                    }
                }
                val inverse = 1.0 / scale
                return accepted.map { m ->
                    val left = (m.x * inverse).toInt()
                    val top = (m.y * inverse).toInt()
                    val right = ((m.x + tw) * inverse).toInt()
                    val bottom = ((m.y + th) * inverse).toInt()
                    Detection(left, top, right, bottom, (left + right) / 2, (top + bottom) / 2, m.score)
                }
            } finally {
                if (template !== original) template.recycle()
                if (scaledScreen !== screen) scaledScreen.recycle()
            }
        } finally {
            original.recycle()
        }
    }

    private data class ScaledMatch(val x: Int, val y: Int, val score: Double)

    private fun intersectionOverUnion(a: ScaledMatch, b: ScaledMatch, w: Int, h: Int): Double {
        val left = max(a.x, b.x)
        val top = max(a.y, b.y)
        val right = min(a.x + w, b.x + w)
        val bottom = min(a.y + h, b.y + h)
        val intersection = max(0, right - left) * max(0, bottom - top)
        if (intersection == 0) return 0.0
        val area = w * h
        return intersection.toDouble() / (2 * area - intersection).toDouble()
    }

    private fun gray(c: Int): Int = (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100
}
