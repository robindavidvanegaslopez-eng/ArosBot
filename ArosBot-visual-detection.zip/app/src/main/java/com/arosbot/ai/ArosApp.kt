package com.arosbot.ai

import android.app.Application
import com.arosbot.ai.core.BotCore

class ArosApp : Application() {
    override fun onCreate() {
        super.onCreate()
        BotCore.init(this)
    }
}
