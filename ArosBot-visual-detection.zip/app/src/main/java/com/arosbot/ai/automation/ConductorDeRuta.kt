package com.arosbot.ai.automation

import android.os.SystemClock
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.core.Calibracion
import com.arosbot.ai.core.ClasePaso
import com.arosbot.ai.core.ClasificadorDePaso
import com.arosbot.ai.core.DetectorDeBloqueo
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.PilotoDeRumbo
import com.arosbot.ai.core.PuntoDeRuta
import com.arosbot.ai.core.ReferenciaVisual
import com.arosbot.ai.core.Relocalizacion
import com.arosbot.ai.core.SeguimientoDeCamino
import com.arosbot.ai.input.GestoContinuo
import com.arosbot.ai.input.JoystickGestos
import com.arosbot.ai.vision.EstimadorMovimiento
import com.arosbot.ai.vision.ReferenciasVisuales
import kotlin.math.hypot
import kotlinx.coroutines.delay

/**
 * Conducción continua por una lista de puntos (módulos 6 y 12 en acción). El dedo se queda en el
 * joystick todo el recorrido (ver [GestoContinuo]) y el bot, mientras tanto, mide a ~16 Hz (la captura va a ese ritmo mientras se conduce; en reposo solo ~3 Hz) cuánto
 * se mueve la escena entre fotogramas consecutivos, actualiza su posición y corrige el rumbo hacia el
 * siguiente punto. No hay pasos «pulsa, espera, mide»: es un único recorrido, como lo haría una
 * persona. En los puntos con referencia visual corrige la deriva sin detenerse. Solo suelta al llegar
 * al último punto (anticipándose por la inercia) y allí comprueba y, si hace falta, corrige.
 *
 * Mide en el teléfono; no se ha probado todavía en el juego. Si el juego no responde al joystick o
 * hay un obstáculo, lo detecta (poco avance medido) y lo dice.
 */
class ConductorDeRuta(
    private val calibraciones: Map<Direccion, Calibracion>,
    private val diagonales: Boolean,
    private val reconocer: (ReferenciaVisual) -> ReferenciasVisuales.Hallazgo?,
    private val registro: (String) -> Unit,
    private val alProgreso: (String) -> Unit
) {
    var x = 0.0
    var y = 0.0

    var fotogramasMedidos = 0
        private set
    var fotogramasEstimados = 0
        private set
    var fotogramasQuietos = 0
        private set
    var fotogramasSinMedida = 0
        private set
    var referenciasVistas = 0
        private set
    var referenciasPerdidas = 0
        private set
    var correcciones = 0
        private set
    var reintentosDeGesto = 0
        private set
    var seMovio = false
        private set
    var errorFinal: Double? = null
        private set

    sealed class Fin {
        object Llegado : Fin()
        class Bloqueado(val indice: Int) : Fin()
        class Fallo(val texto: String) : Fin()
    }

    @Volatile
    private var rumbo = 0.0

    @Volatile
    private var soltar = false

    private val velocidad: Double = SeguimientoDeCamino.velocidadNominal(calibraciones)

    /**
     * Recorre [puntos] desde el índice [desde] (la posición actual es ([x], [y])) hasta el último.
     * Puede devolver [Fin.Bloqueado] con el punto al que no se avanza: quien llama decide si usa un
     * camino de respaldo y vuelve a llamar con la lista cambiada.
     */
    suspend fun conducir(puntos: List<PuntoDeRuta>, desde: Int, limiteHasta: Long): Fin {
        FrameBus.pedirRapido()
        try {
            return conducirRapido(puntos, desde, limiteHasta)
        } finally {
            FrameBus.soltarRapido()
        }
    }

    private suspend fun conducirRapido(puntos: List<PuntoDeRuta>, desde: Int, limiteHasta: Long): Fin {
        if (velocidad < 1.0) return Fin.Fallo("Falta calibrar el movimiento.")
        var indice = SeguimientoDeCamino.avanzar(x, y, puntos, desde)
        val ultimoIdx = puntos.lastIndex
        val vistaPuntos = puntos.map { com.arosbot.ai.core.PuntoXY(it.x.toFloat(), it.y.toFloat()) }
        val piloto = PilotoDeRumbo(diagonales)
        val bloqueo = DetectorDeBloqueo(pasosSeguidos = PASOS_BLOQUEO)

        var intentosGesto = 0
        while (true) {
            soltar = false
            val objetivo0 = puntos[indice]
            rumbo = piloto.rumbo(objetivo0.x - x, objetivo0.y - y)
            val gesto = JoystickGestos.crearConduccion({ rumbo }, { soltar })
                ?: return Fin.Fallo(JoystickGestos.motivoUltimoFallo ?: "No se pudo crear el gesto")
            var previo = FrameBus.instantanea()
                ?: return Fin.Fallo("Dejaron de llegar fotogramas de la captura.")
            var ultimoNumero = FrameBus.estado.value.fotogramas
            var ultimoInstante = SystemClock.elapsedRealtime()
            if (!gesto.arrancar()) {
                previo.recycle()
                intentosGesto++
                reintentosDeGesto++
                registro(gesto.motivo ?: "El gesto no arrancó")
                if (intentosGesto >= MAX_INTENTOS_GESTO) {
                    return Fin.Fallo("No se pudo enviar el gesto continuo: ${gesto.motivo ?: "motivo desconocido"}.")
                }
                delay(PAUSA_REINTENTO_MS)
                continue
            }
            seMovio = true

            var ventanaInicioMs = SystemClock.elapsedRealtime()
            var ventanaMedidos = 0
            var primeraVentana = true
            var sinMedidaMs = 0.0
            var ventanaX = x
            var ventanaY = y
            var ultimaRelocalizacion = 0L
            var cancelado = false
            var llegoAlFinal = false

            try {
                while (true) {
                    delay(PERIODO_MS)
                    if (SystemClock.elapsedRealtime() > limiteHasta) {
                        soltar = true
                        esperarFin(gesto)
                        previo.recycle()
                        return Fin.Fallo("Se agotó el tiempo del recorrido.")
                    }
                    if (gesto.estado == GestoContinuo.Estado.CANCELADO) {
                        cancelado = true
                        break
                    }
                    val numero = FrameBus.estado.value.fotogramas
                    if (numero == ultimoNumero) continue
                    val actual = FrameBus.instantanea() ?: continue
                    val ahora = SystemClock.elapsedRealtime()
                    val dt = (ahora - ultimoInstante) / 1000.0
                    ultimoNumero = numero
                    ultimoInstante = ahora

                    val lectura = EstimadorMovimiento.medir(previo, actual)
                    when (ClasificadorDePaso.clasificar(lectura)) {
                        ClasePaso.MEDIDO -> {
                            val m = lectura.medicion!!
                            x -= m.dx
                            y -= m.dy
                            fotogramasMedidos++
                            ventanaMedidos++
                            sinMedidaMs = 0.0
                            previo.recycle()
                            previo = actual
                        }
                        ClasePaso.QUIETO -> {
                            // La escena no cambia: el personaje no avanza (choque), aunque no haya textura
                            // para correlacionar. Cuenta como medido, con 0 px.
                            fotogramasQuietos++
                            ventanaMedidos++
                            sinMedidaMs = 0.0
                            previo.recycle()
                            previo = actual
                        }
                        ClasePaso.SIN_MEDIDA -> {
                            // La imagen cambia pero no se sabe cuánto. Se estima solo durante un rato corto;
                            // pasado ese tiempo no se inventa más avance (y no se da por medido).
                            sinMedidaMs += dt * 1000.0
                            if (sinMedidaMs <= ESTIMACION_MAXIMA_MS) {
                                x += kotlin.math.cos(rumbo) * velocidad * dt
                                y += kotlin.math.sin(rumbo) * velocidad * dt
                                fotogramasEstimados++
                            } else {
                                fotogramasSinMedida++
                            }
                            if (sinMedidaMs > REINICIO_SIN_MEDIDA_MS) {
                                previo.recycle()
                                previo = actual
                            } else {
                                actual.recycle()
                            }
                        }
                    }

                    indice = SeguimientoDeCamino.avanzar(x, y, puntos, indice)
                    com.arosbot.ai.capture.TrayectoSobreJuego.publicar(vistaPuntos, x, y, indice, false)
                    val objetivo = puntos[indice]
                    var ex = objetivo.x - x
                    var ey = objetivo.y - y

                    // Corrección de la deriva sin detenerse, al pasar cerca de un punto con referencia.
                    val ref = objetivo.referencia
                    if (ref != null && hypot(ex, ey) < RADIO_REFERENCIA_PX &&
                        ahora - ultimaRelocalizacion > PERIODO_RELOCALIZACION_MS && indice != ultimoIdx
                    ) {
                        ultimaRelocalizacion = ahora
                        val h = reconocer(ref)
                        if (h != null) {
                            referenciasVistas++
                            val (nx, ny) = Relocalizacion.posicion(objetivo, h.dx, h.dy)
                            x = nx
                            y = ny
                            ex = objetivo.x - x
                            ey = objetivo.y - y
                        } else {
                            referenciasPerdidas++
                        }
                    }

                    // ¿Se está avanzando? Se compara cada 600 ms lo medido con lo esperado.
                    if (ahora - ventanaInicioMs >= VENTANA_BLOQUEO_MS) {
                        val recorrido = hypot(x - ventanaX, y - ventanaY)
                        val esperado = velocidad * (ahora - ventanaInicioMs) / 1000.0
                        ventanaInicioMs = ahora
                        ventanaX = x
                        ventanaY = y
                        // Solo se juzga con ventanas medidas de verdad: lo estimado nunca delata un bloqueo.
                        val medidosEnVentana = ventanaMedidos
                        ventanaMedidos = 0
                        if (primeraVentana) {
                            // El gesto tarda un momento en arrancar y el personaje en acelerar: no se juzga.
                            primeraVentana = false
                        } else if (medidosEnVentana >= MEDIDOS_MINIMOS_VENTANA && bloqueo.anotar(esperado, recorrido)) {
                            soltar = true
                            esperarFin(gesto)
                            registro("No avanza hacia el punto $indice de $ultimoIdx (poco movimiento medido)")
                            previo.recycle()
                            return Fin.Bloqueado(indice)
                        }
                    }

                    if (indice == ultimoIdx && SeguimientoDeCamino.hayQueSoltar(hypot(ex, ey), velocidad)) {
                        soltar = true
                        llegoAlFinal = true
                        break
                    }
                    rumbo = piloto.rumbo(ex, ey)
                    alProgreso(
                        "Conduciendo: punto $indice de $ultimoIdx · faltan ${hypot(ex, ey).toInt()} px"
                    )
                }
            } finally {
                if (!llegoAlFinal) soltar = true
            }

            if (cancelado) {
                previo.recycle()
                intentosGesto++
                reintentosDeGesto++
                registro(gesto.motivo ?: "El gesto continuo se canceló")
                if (intentosGesto >= MAX_INTENTOS_GESTO) {
                    return Fin.Fallo("Android canceló el gesto continuo ${MAX_INTENTOS_GESTO} veces: ${gesto.motivo ?: ""}.")
                }
                delay(PAUSA_REINTENTO_MS)
                continue
            }

            // Se ha soltado: se espera a que el dedo suba y el personaje se pare, y se mide lo que
            // todavía avanzó mientras frenaba.
            esperarFin(gesto)
            delay(ASENTAMIENTO_MS)
            val despues = FrameBus.instantanea()
            if (despues != null) {
                val m = EstimadorMovimiento.estimar(previo, despues)
                if (m != null && m.confianza >= CONFIANZA_MEDICION) {
                    x -= m.dx
                    y -= m.dy
                }
                despues.recycle()
            }
            previo.recycle()
            return cerrarEnElPunto(puntos[ultimoIdx])
        }
    }

    private suspend fun esperarFin(gesto: GestoContinuo) {
        val limite = SystemClock.elapsedRealtime() + 1500L
        while (gesto.estado == GestoContinuo.Estado.ACTIVO && SystemClock.elapsedRealtime() < limite) {
            delay(20L)
        }
    }

    /**
     * Tras soltar en el último punto: se mide lo que se movió mientras frenaba, se corrige con la
     * referencia visual si la hay y se informa del error. Si queda lejos, la llamada se repite desde fuera.
     */
    private fun cerrarEnElPunto(ultimo: PuntoDeRuta): Fin {
        errorFinal = null
        val ref = ultimo.referencia
        if (ref != null) {
            val h = reconocer(ref)
            if (h != null) {
                referenciasVistas++
                val (nx, ny) = Relocalizacion.posicion(ultimo, h.dx, h.dy)
                x = nx
                y = ny
                errorFinal = Relocalizacion.error(h.dx, h.dy)
            } else {
                referenciasPerdidas++
            }
        }
        return Fin.Llegado
    }

    companion object {
        const val PERIODO_MS = 40L
        const val CONFIANZA_MEDICION = 0.08
        const val RADIO_REFERENCIA_PX = 90.0
        const val PERIODO_RELOCALIZACION_MS = 700L
        const val VENTANA_BLOQUEO_MS = 600L
        const val MEDIDOS_MINIMOS_VENTANA = 4
        const val PASOS_BLOQUEO = 2
        const val REINICIO_SIN_MEDIDA_MS = 200.0
        const val ESTIMACION_MAXIMA_MS = 500.0
        const val ASENTAMIENTO_MS = 350L
        const val MAX_INTENTOS_GESTO = 3
        const val PAUSA_REINTENTO_MS = 250L
    }
}
