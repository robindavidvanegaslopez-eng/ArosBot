package com.arosbot.ai.automation

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.core.AcumuladorDeTrayecto
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.PuntoDeRuta
import com.arosbot.ai.core.ValidacionDeRuta
import com.arosbot.ai.vision.EstimadorMovimiento
import com.arosbot.ai.vision.ReferenciasVisuales
import java.io.File
import kotlin.math.hypot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class EstadoGrabacion(
    val grabando: Boolean = false,
    val texto: String = "",
    val puntos: Int = 0,
    val distanciaPx: Int = 0
)

/** Ruta enseñada que todavía no se ha guardado con nombre, origen y destino. */
data class RutaPendiente(
    val puntos: List<PuntoDeRuta>,
    val duracionMs: Long,
    val medicionesDescartadas: Int,
    val medicionesTotales: Int
)

/**
 * Enseñar una ruta: mientras el usuario recorre el trayecto a mano en el juego, mide cada 350 ms lo
 * que se mueve la escena (el personaje es lo contrario), acumula la posición y guarda puntos cada
 * 100 px y recortes de referencia visual cada 300 px. Se termina desde la burbuja («Terminar ruta»)
 * o desde la pantalla Enseñar rutas, y queda pendiente hasta que se guarde o se descarte.
 */
object GrabadorDeRuta {

    private const val CUENTA_ATRAS_S = 6
    private const val INTERVALO_MS = 350L

    /** Confianza mínima de la correlación para fiarse de una medición de movimiento. */
    private const val CONFIANZA_MINIMA = 0.08

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trabajo: Job? = null

    @Volatile
    private var terminarSolicitado = false

    private val _estado = MutableStateFlow(EstadoGrabacion())
    val estado: StateFlow<EstadoGrabacion> = _estado.asStateFlow()

    /** Trayectoria que se va dibujando mientras se enseña (incluye la posición actual al final). */
    private val _trayectoVivo = MutableStateFlow<List<PuntoDeRuta>>(emptyList())
    val trayectoVivo: StateFlow<List<PuntoDeRuta>> = _trayectoVivo.asStateFlow()

    private val _pendiente = MutableStateFlow<RutaPendiente?>(null)
    val pendiente: StateFlow<RutaPendiente?> = _pendiente.asStateFlow()

    @Synchronized
    fun iniciar() {
        if (trabajo?.isActive == true) return
        if (_pendiente.value != null) {
            _estado.value = EstadoGrabacion(false, "Hay una ruta sin guardar. Guárdala o descártala antes de enseñar otra.")
            return
        }
        if (!FrameBus.estado.value.activa) {
            _estado.value = EstadoGrabacion(false, "Inicia la captura de pantalla en el Panel principal.")
            return
        }
        if (BotCore.stateMachine.state.value == BotState.PARADA_EMERGENCIA) {
            _estado.value = EstadoGrabacion(false, "Hay una parada de emergencia activa. Pulsa «Restablecer» en el Panel principal.")
            return
        }
        terminarSolicitado = false
        BotCore.log.info("Rutas", "Enseñar ruta: iniciada")
        trabajo = alcance.launch {
            try {
                grabar()
            } catch (e: kotlinx.coroutines.CancellationException) {
                _estado.value = EstadoGrabacion(false, "Enseñanza de la ruta cancelada.")
                throw e
            } catch (e: Exception) {
                BotCore.log.error("Rutas", "Error al enseñar la ruta: ${e.message}")
                _estado.value = EstadoGrabacion(false, "Error al enseñar la ruta (${e.message}).")
            }
        }
    }

    /** Pide terminar: se guarda el último punto y la ruta queda pendiente de nombre. */
    fun terminar() {
        if (trabajo?.isActive == true) terminarSolicitado = true
    }

    /** Aborta sin guardar nada (parada de emergencia o botón de cancelar). */
    fun cancelar() {
        trabajo?.cancel()
    }

    private suspend fun grabar() {
        for (s in CUENTA_ATRAS_S downTo 1) {
            _estado.value = EstadoGrabacion(true, "Cambia al juego… empiezo en $s s")
            delay(1000L)
        }
        val directorio = BotCore.store.directorioReferencias
        val inicio = SystemClock.elapsedRealtime()
        val acumulador = AcumuladorDeTrayecto()

        val fotogramaInicial = FrameBus.instantanea()
        if (fotogramaInicial == null) {
            _estado.value = EstadoGrabacion(false, "No llegan fotogramas de la captura.")
            return
        }
        var anterior: Bitmap = fotogramaInicial
        try {
            val primera = ReferenciasVisuales.capturar(anterior, directorio)
            if (primera == null) {
                _estado.value = EstadoGrabacion(
                    false,
                    "No se pudo guardar una referencia visual al inicio: esa zona de la pantalla es demasiado lisa. " +
                        "Prueba desde otro lugar."
                )
                return
            }
            acumulador.registrar(0L, primera)

            var mediciones = 0
            var descartadas = 0
            while (!terminarSolicitado) {
                _estado.value = EstadoGrabacion(
                    true,
                    "Enseñando la ruta: recorre el trayecto a mano. Termina con «Terminar ruta» en la burbuja A.",
                    acumulador.puntos.size,
                    distancia(acumulador.puntos)
                )
                _trayectoVivo.value = acumulador.puntos +
                    PuntoDeRuta(acumulador.x, acumulador.y, SystemClock.elapsedRealtime() - inicio)
                delay(INTERVALO_MS)
                val actual = FrameBus.instantanea() ?: continue
                val m = EstimadorMovimiento.estimar(anterior, actual)
                mediciones++
                if (m != null && m.confianza >= CONFIANZA_MINIMA) {
                    acumulador.mover(m.dx, m.dy)
                } else {
                    descartadas++
                }
                anterior.recycle()
                anterior = actual

                if (acumulador.puntoPendiente()) {
                    val referencia =
                        if (acumulador.referenciaPendiente()) {
                            ReferenciasVisuales.capturar(actual, directorio)
                        } else {
                            null
                        }
                    acumulador.registrar(SystemClock.elapsedRealtime() - inicio, referencia)
                }
            }

            val duracion = SystemClock.elapsedRealtime() - inicio
            val referenciaFinal = ReferenciasVisuales.capturar(anterior, directorio)
            acumulador.registrar(duracion, referenciaFinal)
            val puntos = acumulador.puntos.toList()
            _pendiente.value = RutaPendiente(puntos, duracion, descartadas, mediciones)
            val texto = "Ruta enseñada: ${puntos.size} puntos, ${distancia(puntos)} px. " +
                "Vuelve a la app y guárdala en Enseñar rutas."
            _estado.value = EstadoGrabacion(false, texto, puntos.size, distancia(puntos))
            BotCore.log.info("Rutas", texto)
            avisar("Ruta enseñada. Vuelve a la app para guardarla.")
        } finally {
            anterior.recycle()
            _trayectoVivo.value = emptyList()
        }
    }

    /**
     * Valida y guarda la ruta pendiente. Devuelve null si todo fue bien o el motivo por el que no se
     * pudo guardar (en ese caso la ruta sigue pendiente).
     */
    fun guardarPendiente(nombre: String, origen: String, destino: String): String? {
        val pendiente = _pendiente.value ?: return "No hay ninguna ruta pendiente."
        val problema = ValidacionDeRuta.problema(pendiente.puntos)
        if (problema != null) return problema
        val id = BotCore.store.insertarRuta(
            nombre, origen, destino, pendiente.puntos, pendiente.duracionMs
        )
        if (id <= 0L) return "No se pudo guardar la ruta en la base de datos."
        _pendiente.value = null
        _estado.value = EstadoGrabacion()
        BotCore.log.info("Rutas", "Ruta «$nombre» guardada ($origen → $destino)")
        return null
    }

    /** Descarta la ruta pendiente y borra sus recortes de referencia. */
    fun descartarPendiente() {
        val pendiente = _pendiente.value ?: return
        borrarReferencias(pendiente.puntos)
        _pendiente.value = null
        _estado.value = EstadoGrabacion()
        BotCore.log.info("Rutas", "Ruta pendiente descartada")
    }

    private fun borrarReferencias(puntos: List<PuntoDeRuta>) {
        for (p in puntos) {
            val nombre = p.referencia?.archivo ?: continue
            File(BotCore.store.directorioReferencias, nombre).delete()
        }
    }

    private fun distancia(puntos: List<PuntoDeRuta>): Int {
        var total = 0.0
        for (i in 1 until puntos.size) {
            total += hypot(puntos[i].x - puntos[i - 1].x, puntos[i].y - puntos[i - 1].y)
        }
        return total.toInt()
    }

    private fun avisar(texto: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(BotCore.appContext, texto, Toast.LENGTH_LONG).show()
        }
    }
}
