package com.arosbot.ai.automation

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.core.AcumuladorDeTrayecto
import com.arosbot.ai.core.CierreDeBucle
import com.arosbot.ai.core.ClasePaso
import com.arosbot.ai.core.ClasificadorDePaso
import com.arosbot.ai.core.Relocalizacion
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.PuntoDeRuta
import com.arosbot.ai.core.ValidacionDeRuta
import com.arosbot.ai.vision.EstimadorMovimiento
import com.arosbot.ai.vision.ReferenciasVisuales
import java.io.File
import kotlin.math.hypot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class EstadoGrabacion(
    val grabando: Boolean = false,
    val texto: String = "",
    val puntos: Int = 0,
    val distanciaPx: Int = 0
)

/** Ruta enseñada que todavía no se ha guardado con nombre, origen y destino. */
data class RutaPendiente(
    val puntos: List<PuntoDeRuta>,
    val duracionMs: Long,
    val medicionesDescartadas: Int,
    val medicionesTotales: Int
)

/**
 * Enseñar una ruta: mientras el usuario recorre el trayecto a mano en el juego, mide, con cada fotograma nuevo (~16 por segundo), lo
 * que se mueve la escena (el personaje es lo contrario), acumula la posición y guarda puntos cada
 * 100 px y recortes de referencia visual cada 300 px. Se termina desde la burbuja («Terminar ruta»)
 * o desde la pantalla Enseñar rutas, y queda pendiente hasta que se guarde o se descarte.
 */
object GrabadorDeRuta {

    private const val CUENTA_ATRAS_S = 6
    private const val INTERVALO_MS = 25L

    /** Fotogramas seguidos sin medida fiable tras los que se deja de acumular el desplazamiento pendiente. */
    private const val MAX_SIN_MEDIDA_SEGUIDOS = 3

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trabajo: Job? = null

    @Volatile
    private var terminarSolicitado = false

    private val _estado = MutableStateFlow(EstadoGrabacion())
    val estado: StateFlow<EstadoGrabacion> = _estado.asStateFlow()

    /** Trayectoria que se va dibujando mientras se enseña (incluye la posición actual al final). */
    private val _trayectoVivo = MutableStateFlow<List<PuntoDeRuta>>(emptyList())
    val trayectoVivo: StateFlow<List<PuntoDeRuta>> = _trayectoVivo.asStateFlow()

    private val _pendiente = MutableStateFlow<RutaPendiente?>(null)
    val pendiente: StateFlow<RutaPendiente?> = _pendiente.asStateFlow()

    @Synchronized
    fun iniciar() {
        if (trabajo?.isActive == true) return
        if (_pendiente.value != null) {
            _estado.value = EstadoGrabacion(false, "Hay una ruta sin guardar. Guárdala o descártala antes de enseñar otra.")
            return
        }
        if (!FrameBus.estado.value.activa) {
            _estado.value = EstadoGrabacion(false, "Inicia la captura de pantalla en el Panel principal.")
            return
        }
        if (BotCore.stateMachine.state.value == BotState.PARADA_EMERGENCIA) {
            _estado.value = EstadoGrabacion(false, "Hay una parada de emergencia activa. Pulsa «Restablecer» en el Panel principal.")
            return
        }
        terminarSolicitado = false
        BotCore.log.info("Rutas", "Enseñar ruta: iniciada")
        trabajo = alcance.launch {
            try {
                grabar()
            } catch (e: kotlinx.coroutines.CancellationException) {
                _estado.value = EstadoGrabacion(false, "Enseñanza de la ruta cancelada.")
                throw e
            } catch (e: Exception) {
                BotCore.log.error("Rutas", "Error al enseñar la ruta: ${e.message}")
                _estado.value = EstadoGrabacion(false, "Error al enseñar la ruta (${e.message}).")
            }
        }
    }

    /** Pide terminar: se guarda el último punto y la ruta queda pendiente de nombre. */
    fun terminar() {
        if (trabajo?.isActive == true) terminarSolicitado = true
    }

    /** Aborta sin guardar nada (parada de emergencia o botón de cancelar). */
    fun cancelar() {
        trabajo?.cancel()
    }

    private suspend fun grabar() {
        for (s in CUENTA_ATRAS_S downTo 1) {
            _estado.value = EstadoGrabacion(true, "Cambia al juego… empiezo en $s s")
            delay(1000L)
        }
        val directorio = BotCore.store.directorioReferencias
        val inicio = SystemClock.elapsedRealtime()
        val acumulador = AcumuladorDeTrayecto(separacionReferenciasPx = 100.0, ruidoPx = 0.7)

        FrameBus.pedirRapido()
        // Se espera a un fotograma nuevo a ritmo rápido antes de tomar el primero.
        delay(150L)
        val fotogramaInicial = FrameBus.instantanea()
        if (fotogramaInicial == null) {
            FrameBus.soltarRapido()
            _estado.value = EstadoGrabacion(false, "No llegan fotogramas de la captura.")
            return
        }
        var anterior: Bitmap = fotogramaInicial
        var referenciaInicio: com.arosbot.ai.core.ReferenciaVisual? = null
        try {
            val primera = ReferenciasVisuales.capturar(anterior, directorio)
            if (primera == null) {
                _estado.value = EstadoGrabacion(
                    false,
                    "No se pudo guardar una referencia visual al inicio: esa zona de la pantalla es demasiado lisa. " +
                        "Prueba desde otro lugar."
                )
                return
            }
            referenciaInicio = primera
            acumulador.registrar(0L, primera)

            var mediciones = 0
            var descartadas = 0
            var quietos = 0
            var sinMedidaSeguidos = 0
            var ultimoNumero = FrameBus.estado.value.fotogramas
            while (!terminarSolicitado) {
                _estado.value = EstadoGrabacion(
                    true,
                    "Enseñando la ruta: recorre el trayecto a mano. Termina con «Terminar ruta» en la burbuja A.",
                    acumulador.puntos.size,
                    distancia(acumulador.puntos)
                )
                _trayectoVivo.value = acumulador.puntos +
                    PuntoDeRuta(acumulador.x, acumulador.y, SystemClock.elapsedRealtime() - inicio)
                com.arosbot.ai.capture.TrayectoSobreJuego.publicar(
                    _trayectoVivo.value.map { com.arosbot.ai.core.PuntoXY(it.x.toFloat(), it.y.toFloat()) },
                    acumulador.x, acumulador.y, -1, true
                )
                delay(INTERVALO_MS)
                // Solo se mide con un fotograma nuevo: medir dos veces el mismo contaría 0 px y falsearía la ruta.
                val numero = FrameBus.estado.value.fotogramas
                if (numero == ultimoNumero) continue
                ultimoNumero = numero
                val actual = FrameBus.instantanea() ?: continue
                val lectura = EstimadorMovimiento.medir(anterior, actual)
                mediciones++
                when (ClasificadorDePaso.clasificar(lectura)) {
                    ClasePaso.MEDIDO -> {
                        val m = lectura.medicion!!
                        acumulador.mover(m.dx, m.dy)
                        sinMedidaSeguidos = 0
                        anterior.recycle()
                        anterior = actual
                    }
                    ClasePaso.QUIETO -> {
                        // La escena no cambia (te paraste o chocaste): no hay desplazamiento que sumar.
                        quietos++
                        sinMedidaSeguidos = 0
                        anterior.recycle()
                        anterior = actual
                    }
                    ClasePaso.SIN_MEDIDA -> {
                        descartadas++
                        sinMedidaSeguidos++
                        if (sinMedidaSeguidos > MAX_SIN_MEDIDA_SEGUIDOS) {
                            // Demasiado tiempo sin poder medir: se rehace la comparación desde aquí.
                            anterior.recycle()
                            anterior = actual
                            sinMedidaSeguidos = 0
                        } else {
                            // Se conserva el fotograma anterior: la siguiente medición abarcará también
                            // este intervalo y no se pierde el desplazamiento.
                            actual.recycle()
                        }
                    }
                }

                if (acumulador.puntoPendiente()) {
                    val referencia =
                        if (acumulador.referenciaPendiente()) {
                            ReferenciasVisuales.capturar(actual, directorio)
                        } else {
                            null
                        }
                    acumulador.registrar(SystemClock.elapsedRealtime() - inicio, referencia)
                }
            }

            val duracion = SystemClock.elapsedRealtime() - inicio
            val ultimoFotograma = FrameBus.instantanea() ?: anterior
            val referenciaFinal = ReferenciasVisuales.capturar(ultimoFotograma, directorio)
            acumulador.registrar(duracion, referenciaFinal)
            var puntos = acumulador.puntos.toList()

            // Cierre de bucle: si se reconoce el lugar de partida, el personaje volvió al inicio y la
            // diferencia con lo acumulado es deriva de la medición: se reparte por el recorrido.
            var notaBucle = ""
            val primeraRef = referenciaInicio
            if (primeraRef != null && puntos.size >= 3) {
                val h = ReferenciasVisuales.reconocer(ultimoFotograma, primeraRef, directorio)
                if (h != null) {
                    val inicial = puntos.first()
                    val (rx, ry) = Relocalizacion.posicion(inicial, h.dx, h.dy)
                    val ultimo = puntos.last()
                    val ex = rx - ultimo.x
                    val ey = ry - ultimo.y
                    if (CierreDeBucle.aplicable(h.confianza, ex, ey, CierreDeBucle.longitud(puntos))) {
                        puntos = CierreDeBucle.corregir(puntos, ex, ey)
                        notaBucle = " Cierre de bucle: reconocí el punto de partida y corregí ${hypot(ex, ey).toInt()} px de deriva."
                        BotCore.log.info("Rutas", "Cierre de bucle aplicado: deriva ${hypot(ex, ey).toInt()} px, " +
                            "confianza ${(h.confianza * 100).toInt()} %")
                    }
                }
            }
            if (ultimoFotograma !== anterior) ultimoFotograma.recycle()
            _pendiente.value = RutaPendiente(puntos, duracion, descartadas, mediciones)
            val texto = "Ruta enseñada: ${puntos.size} puntos, ${distancia(puntos)} px. " +
                "Medido en ${mediciones - descartadas - quietos} fotogramas, quieto en $quietos, " +
                "sin medida fiable en $descartadas.$notaBucle " +
                "Vuelve a la app y guárdala en Enseñar rutas."
            _estado.value = EstadoGrabacion(false, texto, puntos.size, distancia(puntos))
            BotCore.log.info("Rutas", texto)
            avisar("Ruta enseñada. Vuelve a la app para guardarla.")
        } finally {
            FrameBus.soltarRapido()
            com.arosbot.ai.capture.TrayectoSobreJuego.limpiar()
            anterior.recycle()
            _trayectoVivo.value = emptyList()
        }
    }

    /**
     * Valida y guarda la ruta pendiente. Devuelve null si todo fue bien o el motivo por el que no se
     * pudo guardar (en ese caso la ruta sigue pendiente).
     */
    fun guardarPendiente(nombre: String, origen: String, destino: String): String? {
        val pendiente = _pendiente.value ?: return "No hay ninguna ruta pendiente."
        val problema = ValidacionDeRuta.problema(pendiente.puntos)
        if (problema != null) return problema
        val id = BotCore.store.insertarRuta(
            nombre, origen, destino, pendiente.puntos, pendiente.duracionMs
        )
        if (id <= 0L) return "No se pudo guardar la ruta en la base de datos."
        _pendiente.value = null
        _estado.value = EstadoGrabacion()
        BotCore.log.info("Rutas", "Ruta «$nombre» guardada ($origen → $destino)")
        return null
    }

    /** Descarta la ruta pendiente y borra sus recortes de referencia. */
    fun descartarPendiente() {
        val pendiente = _pendiente.value ?: return
        borrarReferencias(pendiente.puntos)
        _pendiente.value = null
        _estado.value = EstadoGrabacion()
        BotCore.log.info("Rutas", "Ruta pendiente descartada")
    }

    private fun borrarReferencias(puntos: List<PuntoDeRuta>) {
        for (p in puntos) {
            val nombre = p.referencia?.archivo ?: continue
            File(BotCore.store.directorioReferencias, nombre).delete()
        }
    }

    private fun distancia(puntos: List<PuntoDeRuta>): Int {
        var total = 0.0
        for (i in 1 until puntos.size) {
            total += hypot(puntos[i].x - puntos[i - 1].x, puntos[i].y - puntos[i - 1].y)
        }
        return total.toInt()
    }

    private fun avisar(texto: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(BotCore.appContext, texto, Toast.LENGTH_LONG).show()
        }
    }
}
