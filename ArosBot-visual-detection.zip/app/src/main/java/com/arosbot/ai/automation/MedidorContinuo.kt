package com.arosbot.ai.automation

import android.graphics.Bitmap
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.core.ClasePaso
import com.arosbot.ai.core.ClasificadorDePaso
import com.arosbot.ai.core.FuenteMedicion
import com.arosbot.ai.core.Medicion
import com.arosbot.ai.vision.EstimadorMovimiento
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.coroutines.coroutineContext

/**
 * Suma, fotograma a fotograma y a ritmo rápido, lo que se desplaza la escena mientras ocurre algo (una
 * pulsación, una conducción). Mide igual que la enseñanza y el seguimiento de rutas, así que las pruebas
 * comprueban el mismo método que luego usa el bot, y no solo la diferencia entre dos fotogramas lejanos.
 * El resultado está en la convención de la escena (el personaje se mueve al revés).
 */
class MedidorContinuo {

    var dx = 0.0
        private set
    var dy = 0.0
        private set
    var medidos = 0
        private set
    var quietos = 0
        private set
    var sinMedida = 0
        private set
    private var sumaConfianza = 0.0
    private var sinMedidaSeguidos = 0
    private var previo: Bitmap? = null
    private var ultimoNumero = 0L
    private var activo = false

    /** Pide fotogramas rápidos y toma el primero. false si no hay fotogramas. */
    fun iniciar(): Boolean {
        FrameBus.pedirRapido()
        activo = true
        previo = FrameBus.instantanea()
        ultimoNumero = FrameBus.estado.value.fotogramas
        return previo != null
    }

    private fun paso() {
        val numero = FrameBus.estado.value.fotogramas
        if (numero == ultimoNumero) return
        val anterior = previo ?: return
        val actual = FrameBus.instantanea() ?: return
        ultimoNumero = numero
        val lectura = EstimadorMovimiento.medir(anterior, actual)
        when (ClasificadorDePaso.clasificar(lectura)) {
            ClasePaso.MEDIDO -> {
                val m = lectura.medicion!!
                dx += m.dx
                dy += m.dy
                sumaConfianza += m.confianza
                medidos++
                sinMedidaSeguidos = 0
                anterior.recycle()
                previo = actual
            }
            ClasePaso.QUIETO -> {
                quietos++
                sinMedidaSeguidos = 0
                anterior.recycle()
                previo = actual
            }
            ClasePaso.SIN_MEDIDA -> {
                sinMedida++
                sinMedidaSeguidos++
                if (sinMedidaSeguidos > 3) {
                    anterior.recycle()
                    previo = actual
                    sinMedidaSeguidos = 0
                } else {
                    actual.recycle()
                }
            }
        }
    }

    /** Mide hasta que se cancele la corrutina que la llama. */
    suspend fun correr() {
        while (coroutineContext.isActive) {
            paso()
            delay(20L)
        }
    }

    /** Termina y devuelve la medición total, o null si no se pudo medir nada. */
    fun terminar(): Medicion? {
        if (activo) {
            FrameBus.soltarRapido()
            activo = false
        }
        previo?.recycle()
        previo = null
        if (medidos == 0 && quietos == 0) return null
        val confianza = if (medidos == 0) 0.0 else sumaConfianza / medidos
        return Medicion(dx, dy, confianza, FuenteMedicion.ESCENA)
    }
}
