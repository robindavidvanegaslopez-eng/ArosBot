package com.arosbot.ai.automation

import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.EleccionDeSpot
import com.arosbot.ai.core.Material
import com.arosbot.ai.core.MaterialesDelSpot
import com.arosbot.ai.core.PlanDeRutas
import com.arosbot.ai.core.PlanificadorDeRutas
import com.arosbot.ai.core.ResultadoDeEleccion
import com.arosbot.ai.core.Spot
import com.arosbot.ai.core.TiempoLegible
import com.arosbot.ai.vision.Deteccion
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Navegador de spots (módulo 11): elige el siguiente destino con [EleccionDeSpot], recorre las rutas
 * enseñadas hasta él con [SeguidorDeRuta], mira si hay materiales a la vista al llegar y anota la
 * visita para aprender cuánto tarda cada spot en volver a tener recursos.
 *
 * Alcance honesto: aquí se llega y se MIRA (detección visual); recoger lo que se ve es la Fase 6. «Había
 * recursos» significa que el detector vio algún material buscado, no que se haya recogido.
 */
object NavegadorDeSpots {

    private const val CUENTA_ATRAS_S = 6
    private const val MUESTRAS = 4
    private const val ESPERA_ENTRE_MUESTRAS_MS = 450L
    private const val MUESTRAS_CON_RECURSOS = 2

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trabajo: Job? = null

    private val _estado = MutableStateFlow(EstadoPrueba())
    val estado: StateFlow<EstadoPrueba> = _estado.asStateFlow()

    val ejecutando: Boolean get() = trabajo?.isActive == true

    /** Lugar actual conocido, o null. Solo cuenta si el lugar sigue existiendo en el grafo. */
    fun lugarActual(): Long? {
        val id = BotCore.settings.lugarActualId
        return if (id >= 0 && BotCore.store.lugares.value.any { it.id == id }) id else null
    }

    /** Evalúa los spots con lo que se sabe ahora, sin moverse. Sirve para enseñar el porqué en pantalla. */
    fun evaluar(): ResultadoDeEleccion = EleccionDeSpot.elegir(
        BotCore.store.spots.value,
        BotCore.store.rutas.value,
        lugarActual(),
        System.currentTimeMillis()
    )

    /** Elige el mejor spot y va. */
    fun irAlMejor() = iniciar(null)

    /** Va a un spot concreto que ha elegido el usuario. */
    fun irA(spotId: Long) = iniciar(spotId)

    @Synchronized
    private fun iniciar(spotId: Long?) {
        if (ejecutando) {
            BotCore.log.aviso("Spots", "Ya hay una navegación en marcha")
            return
        }
        if (SeguidorDeRuta.estado.value.ejecutando) {
            _estado.value = EstadoPrueba(false, "Hay una ruta en marcha. Espera a que termine o cancélala.")
            return
        }
        if (BotCore.stateMachine.state.value == BotState.PARADA_EMERGENCIA) {
            _estado.value = EstadoPrueba(
                false,
                "Hay una parada de emergencia activa. Pulsa «Restablecer» en el Panel principal."
            )
            return
        }
        _estado.value = EstadoPrueba(true, "Spots: preparando…")
        trabajo = alcance.launch {
            val texto = try {
                navegar(spotId)
            } catch (e: CancellationException) {
                BotCore.entrada.soltarTodo()
                alTerminar()
                "Spots: cancelado."
            } catch (e: Exception) {
                BotCore.entrada.soltarTodo()
                alTerminar()
                BotCore.log.error("Spots", "Error inesperado al navegar: ${e.message}")
                "Spots: error inesperado (${e.message})."
            }
            _estado.value = EstadoPrueba(false, texto)
            val resumen = texto.lines().first()
            BotCore.log.info("Spots", resumen)
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(BotCore.appContext, resumen, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun cancelar() {
        trabajo?.cancel()
        SeguidorDeRuta.cancelar()
        BotCore.entrada.soltarTodo()
    }

    private fun progreso(texto: String) {
        _estado.value = EstadoPrueba(true, texto)
    }

    private fun alTerminar() {
        BotCore.telemetry.value = BotCore.telemetry.value.copy(
            objetivoActual = "Ninguno",
            spotActivo = "Ninguno",
            rutaSeleccionada = "Ninguna"
        )
    }

    /** Lo visto al mirar un spot varias veces seguidas. */
    data class Observacion(
        val muestras: Int,
        val conRecursos: Int,
        val maximo: Int,
        val vistos: Set<String>
    )

    /** Mira [MUESTRAS] veces los materiales [buscados] en las áreas activas. Lo usa también el recolector. */
    suspend fun observar(buscados: List<Material>): Observacion {
        var conRecursos = 0
        var muestras = 0
        var maximo = 0
        val vistos = LinkedHashSet<String>()
        repeat(MUESTRAS) {
            val fotograma = FrameBus.instantanea()
            if (fotograma != null) {
                try {
                    val resultado = Deteccion.enAreasActivas(
                        fotograma,
                        BotCore.store.areas.value,
                        buscados,
                        BotCore.store.directorioMateriales
                    )
                    muestras++
                    if (resultado.detecciones.isNotEmpty()) conRecursos++
                    maximo = maxOf(maximo, resultado.detecciones.size)
                    resultado.detecciones.forEach { vistos.add(it.nombre) }
                } finally {
                    fotograma.recycle()
                }
            }
            delay(ESPERA_ENTRE_MUESTRAS_MS)
        }
        return Observacion(muestras, conRecursos, maximo, vistos)
    }

    /** true si la observación cuenta como «hay recursos». */
    fun hayRecursos(o: Observacion): Boolean = o.conRecursos >= MUESTRAS_CON_RECURSOS

    /** true si hubo fotogramas suficientes para fiarse de la observación. */
    fun observacionCompleta(o: Observacion): Boolean = o.muestras >= MUESTRAS

    private suspend fun navegar(spotId: Long?): String {
        val origen = lugarActual()
            ?: return "Spots: no sé dónde estás. Pulsa «Estoy en…» y elige el lugar donde está tu personaje."
        val ahora = System.currentTimeMillis()

        val spot: Spot
        val plan: PlanDeRutas
        val motivo: String
        if (spotId == null) {
            val eleccion = evaluar()
            val elegido = eleccion.elegido
                ?: return if (BotCore.store.spots.value.isEmpty()) {
                    "Spots: no hay ningún spot. Añade uno primero."
                } else {
                    "Spots: ningún spot es alcanzable desde ese lugar con las rutas enseñadas.\n" +
                        eleccion.descartados.joinToString("\n") { "· ${it.first.nombre}: ${it.second}" }
                }
            spot = elegido.spot
            plan = elegido.plan
            motivo = elegido.motivo
        } else {
            val encontrado = BotCore.store.spots.value.firstOrNull { it.id == spotId }
                ?: return "Spots: ese spot ya no existe."
            val ruta = PlanificadorDeRutas.planificar(BotCore.store.rutas.value, origen, encontrado.lugarId)
                ?: return "Spots: no hay ninguna ruta enseñada desde tu lugar hasta «${encontrado.nombre}»."
            spot = encontrado
            plan = ruta
            motivo = "elegido por ti · " +
                "prioridad ${spot.prioridad} · disponibilidad ${(spot.probabilidadDisponible(ahora) * 100).toInt()} %"
        }

        val buscados = MaterialesDelSpot.buscados(spot, BotCore.store.materiales.value)
        if (buscados.isEmpty()) {
            return "Spots: «${spot.nombre}» no tiene materiales que buscar. Añade materiales en la pestaña " +
                "Materiales o asígnaselos al spot."
        }
        val autonomo = spotId == null
        val nombres = BotCore.store.lugares.value
        fun lugar(id: Long) = nombres.firstOrNull { it.id == id }?.nombre ?: "?"

        BotCore.telemetry.value = BotCore.telemetry.value.copy(
            objetivoActual = "Ir a «${spot.nombre}»",
            spotActivo = spot.nombre,
            rutaSeleccionada = if (plan.tramos.isEmpty()) "Ya estás allí"
            else plan.tramos.joinToString(" → ") { it.ruta.nombre }
        )
        BotCore.log.info(
            "Spots",
            "Destino: «${spot.nombre}» ($motivo)" +
                if (plan.tramos.isEmpty()) "" else ", ${plan.tramos.size} ruta(s)"
        )

        for (s in CUENTA_ATRAS_S downTo 1) {
            progreso("Spots: voy a «${spot.nombre}» ($motivo). Cambia al juego… $s")
            delay(1000L)
        }

        var tramosHechos = 0
        for ((i, tramo) in plan.tramos.withIndex()) {
            val desde = if (tramo.inversa) tramo.ruta.destinoId else tramo.ruta.origenId
            val hasta = if (tramo.inversa) tramo.ruta.origenId else tramo.ruta.destinoId
            progreso(
                "Spots: «${spot.nombre}» · tramo ${i + 1} de ${plan.tramos.size}: " +
                    "${lugar(desde)} → ${lugar(hasta)} por «${tramo.ruta.nombre}»"
            )
            val r = SeguidorDeRuta.seguir(tramo.ruta, tramo.inversa, cuentaAtras = false)
            if (!r.exito) {
                alTerminar()
                return "Spots: no llegué a «${spot.nombre}». Falló el tramo ${i + 1} de ${plan.tramos.size}.\n" +
                    r.texto
            }
            tramosHechos++
        }
        if (autonomo && tramosHechos > 0) BotCore.marcarVerificadoPersistente(11)

        // Llegada: se mira lo que hay a la vista varios instantes seguidos.
        progreso("Spots: en «${spot.nombre}». Buscando materiales a la vista…")
        BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = "Mirar en «${spot.nombre}»")
        val obs = observar(buscados)
        val muestras = obs.muestras
        val conRecursos = obs.conRecursos
        val maximo = obs.maximo
        val vistos = obs.vistos
        if (muestras < MUESTRAS) {
            alTerminar()
            return "Spots: no pude mirar en «${spot.nombre}»: llegaron fotogramas en $muestras de $MUESTRAS " +
                "intentos. No se anota la visita. ¿Sigue activa la captura?"
        }

        val encontrado = conRecursos >= MUESTRAS_CON_RECURSOS
        val guardado = BotCore.store.registrarVisita(spot.id, encontrado, System.currentTimeMillis())
        if (guardado) BotCore.marcarVerificadoPersistente(13)
        BotCore.telemetry.value = BotCore.telemetry.value.copy(
            recursosDetectados = maximo,
            objetivoActual = "Ninguno"
        )

        val actualizado = BotCore.store.spots.value.firstOrNull { it.id == spot.id }
        val lineas = ArrayList<String>()
        lineas.add(
            if (encontrado) "Spots: «${spot.nombre}»: hay materiales a la vista (${vistos.joinToString()})."
            else "Spots: «${spot.nombre}»: no hay materiales a la vista."
        )
        lineas.add("Detectados en $conRecursos de $MUESTRAS observaciones (máximo $maximo a la vez).")
        if (actualizado != null) {
            val ahoraFin = System.currentTimeMillis()
            lineas.add(
                "Estado aprendido: ${actualizado.disponibilidad(ahoraFin).etiqueta} · " +
                    "${actualizado.visitas} visitas, ${actualizado.conRecursos} con recursos" +
                    if (actualizado.vuelveEnMs(ahoraFin) > 0) {
                        " · se espera que vuelva a haber en ${TiempoLegible.de(actualizado.vuelveEnMs(ahoraFin))}"
                    } else ""
            )
        }
        lineas.add(
            if (guardado) "La visita queda guardada en el aprendizaje."
            else "No se pudo guardar la visita en el aprendizaje."
        )
        lineas.add("Esto solo mira; para recoger usa «Recolectar» en Inventario y cofre.")
        alTerminar()
        return lineas.joinToString("\n")
    }
}
