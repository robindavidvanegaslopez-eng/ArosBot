package com.arosbot.ai.automation

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.capture.PantallaReal
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.Calibracion
import com.arosbot.ai.core.Calibraciones
import com.arosbot.ai.core.AjusteActivoJoystick
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.GeometriaJoystick
import com.arosbot.ai.core.JoystickConfig
import com.arosbot.ai.vision.LocalizadorDePerilla
import com.arosbot.ai.core.EvaluadorProgreso
import com.arosbot.ai.core.FuenteMedicion
import com.arosbot.ai.core.Medicion
import com.arosbot.ai.core.Material
import com.arosbot.ai.core.SelectorDeMateriales
import com.arosbot.ai.input.ArosAccessibilityService
import com.arosbot.ai.vision.Deteccion
import com.arosbot.ai.vision.EstimadorMovimiento
import com.arosbot.ai.vision.LocalizadorPersonaje
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EstadoPrueba(val ejecutando: Boolean = false, val texto: String = "")

/**
 * Pruebas REALES de la Fase 3, que se ejecutan en el teléfono sobre el juego:
 *  - movimiento: pulsa W, S, A y D en el joystick, mide lo que se mueve y calibra;
 *  - personaje: comprueba que se localiza la imagen de referencia del personaje;
 *  - inicio de sesión: pulsa «Log in» y elige la cuenta en el selector de Google.
 *
 * Todas empiezan con una cuenta atrás para que cambies al juego (los gestos se envían a la app que
 * esté en primer plano). Se cancelan con la parada de emergencia o con el botón de cancelar.
 */
object PruebasAutomatizacion {

    private const val CUENTA_ATRAS_S = 6
    private const val PULSACION_MS = 350L
    private const val REPETICIONES = 2
    private const val ESPERA_PREVIA_MS = 450L
    private const val ASENTAMIENTO_MS = 1000L
    private const val MIN_DESPLAZAMIENTO_PX = 4.0
    private const val MAX_IRREGULARIDAD = 3.0
    private const val TRAMO_CONDUCCION_MS = 1500L

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trabajo: Job? = null

    private val _estado = MutableStateFlow(EstadoPrueba())
    val estado: StateFlow<EstadoPrueba> = _estado.asStateFlow()

    fun probarMovimiento() = lanzar("Prueba de movimiento") { movimiento() }

    fun probarDiagonales() = lanzar("Prueba de diagonales") { diagonales() }

    fun probarConduccion() = lanzar("Prueba de conducción continua") { conduccion() }

    fun ajustarJoystick() = lanzar("Ajuste del joystick") { ajustarJoystickActivo() }

    fun probarPersonaje() = lanzar("Prueba del personaje") { personaje() }

    fun probarInicioSesion() = lanzar("Prueba de inicio de sesión") { inicioSesion() }

    /** Cancela y olvida el trabajo aunque esté colgado, y deja el estado como «sin ejecutar». */
    fun reiniciar() {
        trabajo?.cancel()
        trabajo = null
        BotCore.entrada.soltarTodo()
        _estado.value = EstadoPrueba(false, "Cancelado por el usuario.")
    }

    /** Cancela la prueba en curso y suelta las entradas. */
    fun cancelar() {
        trabajo?.cancel()
        BotCore.entrada.soltarTodo()
    }

    @Synchronized
    private fun lanzar(titulo: String, bloque: suspend () -> String) {
        if (trabajo?.isActive == true) {
            BotCore.log.aviso("Automatización", "Ya hay una prueba en curso")
            return
        }
        if (BotCore.stateMachine.state.value == BotState.PARADA_EMERGENCIA) {
            _estado.value = EstadoPrueba(
                false,
                "$titulo: hay una parada de emergencia activa. Pulsa «Restablecer» en el Panel principal."
            )
            BotCore.log.aviso("Automatización", "$titulo: no se inicia, hay una parada de emergencia activa")
            return
        }
        _estado.value = EstadoPrueba(true, "$titulo: en curso…")
        BotCore.log.info("Automatización", "$titulo: iniciada")
        trabajo = alcance.launch {
            val texto = try {
                bloque()
            } catch (e: CancellationException) {
                BotCore.entrada.soltarTodo()
                "$titulo: cancelada"
            } catch (e: Exception) {
                BotCore.log.error("Automatización", "$titulo: error inesperado: ${e.message}")
                "$titulo: error inesperado (${e.message})"
            }
            _estado.value = EstadoPrueba(false, texto)
            val resumen = texto.lines().first()
            BotCore.log.info("Automatización", resumen)
            avisar(resumen)
        }
    }

    private fun avisar(texto: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(BotCore.appContext, texto, Toast.LENGTH_LONG).show()
        }
    }

    private suspend fun cuentaAtras(titulo: String) {
        avisar("Cambia ahora al juego: $titulo empieza en $CUENTA_ATRAS_S s")
        for (s in CUENTA_ATRAS_S downTo 1) {
            _estado.value = EstadoPrueba(true, "$titulo: cambia al juego… $s")
            delay(1000L)
        }
        _estado.value = EstadoPrueba(true, "$titulo: en curso…")
    }

    private suspend fun esperarHasta(limiteMs: Long, condicion: () -> Boolean): Boolean {
        val fin = SystemClock.elapsedRealtime() + limiteMs
        while (SystemClock.elapsedRealtime() < fin) {
            if (condicion()) return true
            delay(200L)
        }
        return condicion()
    }

    private fun decimal(valor: Double): String = String.format(Locale.US, "%.1f", valor)

    // ---------- Movimiento ----------

    /**
     * Mantiene [direccion] [PULSACION_MS] y mide, fotograma a fotograma, lo que se mueve la escena
     * durante la pulsación y el asentamiento. Devuelve (gesto completado, medición).
     */
    private suspend fun pulsarYMedir(direccion: Direccion): Pair<Boolean, Medicion?> {
        val medidor = MedidorContinuo()
        if (!medidor.iniciar()) {
            medidor.terminar()
            return Pair(true, null)
        }
        var completado = false
        try {
            kotlinx.coroutines.coroutineScope {
                val lector = launch { medidor.correr() }
                completado = BotCore.entrada.mantener(direccion, PULSACION_MS)
                delay(ASENTAMIENTO_MS)
                lector.cancel()
            }
        } finally {
            // se recoge abajo
        }
        val m = medidor.terminar()
        lastMedidor = "${medidor.medidos} medidos, ${medidor.quietos} quietos, ${medidor.sinMedida} ilegibles"
        return Pair(completado, m)
    }

    @Volatile
    private var lastMedidor = ""

    private suspend fun movimiento(): String {
        val titulo = "Prueba de movimiento"
        if (!ArosAccessibilityService.conectado.value) {
            return "$titulo: activa el servicio de accesibilidad de ArosBot AI en los ajustes de Android."
        }
        if (BotCore.settings.joystick == null) {
            return "$titulo: primero configura el joystick (botón «Configurar joystick»)."
        }
        if (!FrameBus.estado.value.activa) {
            return "$titulo: inicia la captura de pantalla en el Panel principal."
        }
        cuentaAtras(titulo)

        val orden = listOf(Direccion.W, Direccion.S, Direccion.A, Direccion.D)
        val calibraciones = HashMap<Direccion, Calibracion>()
        val lineas = ArrayList<String>()
        val magnitudes = HashMap<Direccion, MutableList<Double>>()
        for (ronda in 1..REPETICIONES) {
            for (direccion in orden) {
                _estado.value = EstadoPrueba(
                    true,
                    "$titulo: probando ${direccion.tecla} (ronda $ronda de $REPETICIONES). " +
                        "Hace falta ver las cuatro direcciones, dos veces cada una (unos 20 segundos).\n" +
                        lineas.joinToString("\n")
                )
                BotCore.log.info("Automatización", "Movimiento: ${direccion.tecla}, ronda $ronda")
                delay(ESPERA_PREVIA_MS)
                if (FrameBus.instantanea()?.also { it.recycle() } == null) {
                    return "$titulo: no llegan fotogramas de la captura."
                }
                val (completado, medicion) = pulsarYMedir(direccion)
                if (!completado) {
                    BotCore.entrada.soltarTodo()
                    val motivo = com.arosbot.ai.input.JoystickGestos.motivoUltimoFallo ?: "motivo desconocido"
                    BotCore.log.aviso("Automatización", "Gesto de ${direccion.tecla} fallido: $motivo")
                    return "$titulo: no se pudo enviar el gesto de ${direccion.tecla}.\n" +
                        "Motivo: $motivo.\n" +
                        "Comprueba que la accesibilidad sigue activa, que la captura está en marcha " +
                        "y que el joystick está bien configurado."
                }
                magnitudes.getOrPut(direccion) { ArrayList() }
                    .add(if (medicion == null) 0.0 else hypot(medicion.dx, medicion.dy))
                if (medicion == null) {
                    lineas.add("Ronda $ronda · ${direccion.tecla}: sin medición ($lastMedidor)")
                    continue
                }
                if (hypot(medicion.dx, medicion.dy) >= MIN_DESPLAZAMIENTO_PX) {
                    val previa = calibraciones[direccion] ?: Calibracion.vacia(direccion)
                    calibraciones[direccion] = previa.actualizar(medicion.dx, medicion.dy, PULSACION_MS)
                }
                lineas.add(
                    "Ronda $ronda · ${direccion.tecla}: dx ${decimal(medicion.dx)} px, " +
                        "dy ${decimal(medicion.dy)} px (escena, confianza ${decimal(medicion.confianza * 100)} %; $lastMedidor)"
                )
            }
        }

        for (calibracion in calibraciones.values) BotCore.store.guardarCalibracion(calibracion)

        val problemas = ArrayList(EvaluadorProgreso.calibracionCoherente(calibraciones))
        val avisos = ArrayList<String>()
        for (d in orden) {
            val lista = magnitudes[d].orEmpty()
            // Basta con que una de las rondas muestre movimiento: una ronda sin medida (el personaje
            // chocó, la escena es lisa) no invalida que el joystick funcione.
            if (lista.none { it >= MIN_DESPLAZAMIENTO_PX }) {
                problemas.add("Al pulsar ${d.tecla} no se midió movimiento en ninguna ronda")
            }
            val mayor = lista.maxOrNull() ?: 0.0
            val menor = lista.filter { it >= MIN_DESPLAZAMIENTO_PX }.minOrNull() ?: 0.0
            if (menor > 0.0 && mayor / menor > MAX_IRREGULARIDAD) {
                avisos.add(
                    "Al pulsar ${d.tecla} el movimiento varía mucho entre rondas " +
                        "(${decimal(menor)} px frente a ${decimal(mayor)} px)"
                )
            }
        }
        val partes = ArrayList<String>()
        if (problemas.isEmpty()) {
            BotCore.marcarVerificadoPersistente(12)
            BotCore.marcarVerificadoPersistente(6)
            partes.add("$titulo: CORRECTA. El joystick mueve al personaje y la calibración es coherente.")
        } else {
            partes.add("$titulo: NO superada.")
        }
        partes.addAll(lineas)
        avisos.forEach { partes.add("Aviso: $it") }
        for (d in orden) {
            val c = calibraciones[d] ?: continue
            partes.add("Calibración ${d.tecla}: ${decimal(c.rapidez)} px por segundo de pulsación")
        }
        if (problemas.isNotEmpty()) {
            partes.add("Problemas detectados:")
            problemas.forEach { partes.add("• $it") }
            partes.add(
                "Revisa que el cuadrado del joystick esté justo sobre el joystick del juego " +
                    "(en el editor del joystick puedes pulsar «Autoajustar»)."
            )
        }
        return partes.joinToString("\n")
    }

    // ---------- Diagonales ----------

    /**
     * Empuja el joystick hacia cada esquina (W+A, W+D, S+A, S+D) y comprueba que el personaje se mueve
     * en esa dirección y con la rapidez que se deriva de las cuatro direcciones ya calibradas. Solo si
     * las cuatro salen bien el bot usa diagonales al seguir rutas.
     */
    private suspend fun diagonales(): String {
        val titulo = "Prueba de diagonales"
        if (!ArosAccessibilityService.conectado.value) {
            return "$titulo: activa el servicio de accesibilidad de ArosBot AI en los ajustes de Android."
        }
        if (BotCore.settings.joystick == null) {
            return "$titulo: primero configura el joystick (botón «Configurar joystick»)."
        }
        if (!FrameBus.estado.value.activa) {
            return "$titulo: inicia la captura de pantalla en el Panel principal."
        }
        val calibraciones = BotCore.store.calibraciones.value
        val sinCalibrar = Direccion.CARDINALES.filter { (calibraciones[it]?.muestras ?: 0) == 0 }
        if (sinCalibrar.isNotEmpty()) {
            return "$titulo: antes hay que calibrar W, A, S y D con «Probar movimiento» " +
                "(falta ${sinCalibrar.joinToString { it.tecla }})."
        }
        cuentaAtras(titulo)

        val lineas = ArrayList<String>()
        var correctas = 0
        var total = 0
        val buenas = HashSet<Direccion>()
        for (ronda in 1..REPETICIONES) {
            for (direccion in Direccion.DIAGONALES) {
                _estado.value = EstadoPrueba(
                    true,
                    "$titulo: probando ${direccion.tecla} (ronda $ronda de $REPETICIONES).\n" +
                        lineas.joinToString("\n")
                )
                BotCore.log.info("Automatización", "Diagonal: ${direccion.tecla}, ronda $ronda")
                delay(ESPERA_PREVIA_MS)
                if (FrameBus.instantanea()?.also { it.recycle() } == null) {
                    return "$titulo: no llegan fotogramas de la captura."
                }
                val (completado, medicion) = pulsarYMedir(direccion)
                if (!completado) {
                    BotCore.entrada.soltarTodo()
                    val motivo = com.arosbot.ai.input.JoystickGestos.motivoUltimoFallo ?: "motivo desconocido"
                    return "$titulo: no se pudo enviar el gesto de ${direccion.tecla}.\nMotivo: $motivo."
                }
                total++
                val esperada = Calibraciones.para(calibraciones, direccion)
                if (medicion == null || esperada == null) {
                    lineas.add("Ronda $ronda · ${direccion.tecla}: sin medición")
                    continue
                }
                val ex = esperada.vx * PULSACION_MS / 1000.0
                val ey = esperada.vy * PULSACION_MS / 1000.0
                val veredicto = EvaluadorProgreso.diagonalCorrecta(medicion.dx, medicion.dy, ex, ey)
                if (veredicto == null) {
                    correctas++
                    buenas.add(direccion)
                }
                lineas.add(
                    "Ronda $ronda · ${direccion.tecla}: dx ${decimal(medicion.dx)} px, dy ${decimal(medicion.dy)} px " +
                        "(esperado ${decimal(ex)}, ${decimal(ey)}) → " +
                        (veredicto ?: "bien")
                )
            }
        }

        // Basta con que cada diagonal salga bien en una de las rondas.
        val todas = total > 0 && buenas.size == Direccion.DIAGONALES.size
        BotCore.settings.diagonalesVerificadas = todas
        val partes = ArrayList<String>()
        partes.add(
            if (todas) "$titulo: CORRECTA. El bot usará diagonales al seguir rutas."
            else "$titulo: NO superada (${buenas.size} de ${Direccion.DIAGONALES.size} diagonales bien). El bot seguirá usando solo W, A, S y D."
        )
        partes.addAll(lineas)
        if (!todas) {
            partes.add(
                "Si el personaje no se mueve en diagonal en tu juego, las rutas siguen funcionando con " +
                    "W/A/S/D. Si sí se mueve pero el bot lo mide mal, repite la prueba con el personaje " +
                    "en una zona abierta y con textura."
            )
        }
        return partes.joinToString("\n")
    }

    // ---------- Conducción continua ----------

    /**
     * Comprueba el mecanismo que usa el bot al seguir rutas: UN solo dedo que no se levanta, primero hacia
     * arriba (W) y luego, sin soltar, hacia la derecha (D). Mide lo que se mueve la escena en cada tramo y
     * lo compara con las calibraciones de W y D. Si pasa, el bot puede conducir rutas con ese gesto.
     */
    private suspend fun conduccion(): String {
        val titulo = "Prueba de conducción continua"
        if (!ArosAccessibilityService.conectado.value) {
            return "$titulo: activa el servicio de accesibilidad de ArosBot AI en los ajustes de Android."
        }
        if (BotCore.settings.joystick == null) {
            return "$titulo: primero configura el joystick."
        }
        if (!FrameBus.estado.value.activa) {
            return "$titulo: inicia la captura de pantalla en el Panel principal."
        }
        val calibraciones = BotCore.store.calibraciones.value
        val w = calibraciones[Direccion.W]?.takeIf { it.muestras > 0 }
        val d = calibraciones[Direccion.D]?.takeIf { it.muestras > 0 }
        if (w == null || d == null) {
            return "$titulo: antes hay que calibrar con «Probar movimiento»."
        }
        cuentaAtras(titulo)

        val rumbo = java.util.concurrent.atomic.AtomicReference(-Math.PI / 2)
        val soltar = java.util.concurrent.atomic.AtomicBoolean(false)
        val gesto = com.arosbot.ai.input.JoystickGestos.crearConduccion({ rumbo.get() }, { soltar.get() })
            ?: return "$titulo: no se pudo crear el gesto continuo (${com.arosbot.ai.input.JoystickGestos.motivoUltimoFallo ?: "motivo desconocido"})."

        val medidor = MedidorContinuo()
        if (!medidor.iniciar()) {
            medidor.terminar()
            return "$titulo: no llegan fotogramas de la captura."
        }
        var tramo1x = 0.0
        var tramo1y = 0.0
        var tramo2x = 0.0
        var tramo2y = 0.0
        var arranco = false
        try {
            kotlinx.coroutines.coroutineScope {
                val lector = launch { medidor.correr() }
                arranco = gesto.arrancar()
                if (arranco) {
                    delay(TRAMO_CONDUCCION_MS)
                    tramo1x = medidor.dx
                    tramo1y = medidor.dy
                    rumbo.set(0.0)
                    delay(TRAMO_CONDUCCION_MS)
                    tramo2x = medidor.dx - tramo1x
                    tramo2y = medidor.dy - tramo1y
                }
                soltar.set(true)
                var espera = 0
                while (gesto.estado == com.arosbot.ai.input.GestoContinuo.Estado.ACTIVO && espera < 75) {
                    delay(20L)
                    espera++
                }
                delay(ASENTAMIENTO_MS)
                lector.cancel()
            }
        } finally {
            soltar.set(true)
            BotCore.entrada.soltarTodo()
        }
        val resumen = "${medidor.medidos} medidos, ${medidor.quietos} quietos, ${medidor.sinMedida} ilegibles"
        medidor.terminar()
        if (!arranco) {
            return "$titulo: NO superada. El gesto no arrancó: ${gesto.motivo ?: "motivo desconocido"}."
        }

        val seg = TRAMO_CONDUCCION_MS / 1000.0
        val e1x = w.vx * seg / (PULSACION_MS / 1000.0)
        val e1y = w.vy * seg / (PULSACION_MS / 1000.0)
        val e2x = d.vx * seg / (PULSACION_MS / 1000.0)
        val e2y = d.vy * seg / (PULSACION_MS / 1000.0)
        val v1 = veredictoDeTramo(tramo1x, tramo1y, e1x, e1y)
        val v2 = veredictoDeTramo(tramo2x, tramo2y, e2x, e2y)
        // Un corte de Android al final (al soltar) no invalida un recorrido en el que el personaje sí obedeció.
        val ok = v1 == null && v2 == null
        BotCore.settings.conduccionVerificada = ok
        val partes = ArrayList<String>()
        partes.add(
            if (ok) "$titulo: CORRECTA. Un solo dedo cambió de W a D sin soltar y el personaje lo siguió."
            else "$titulo: NO superada."
        )
        partes.add("Tramo 1 (W): dx ${decimal(tramo1x)}, dy ${decimal(tramo1y)} px (esperado ${decimal(e1x)}, ${decimal(e1y)}) → ${v1 ?: "bien"}")
        partes.add("Tramo 2 (D): dx ${decimal(tramo2x)}, dy ${decimal(tramo2y)} px (esperado ${decimal(e2x)}, ${decimal(e2y)}) → ${v2 ?: "bien"}")
        partes.add("Segmentos de gesto enviados: ${gesto.segmentos} · estado final: ${gesto.estado} · fotogramas: $resumen")
        if (gesto.motivo != null) partes.add("Aviso (no invalida la prueba si el personaje obedeció): ${gesto.motivo}")
        return partes.joinToString("\n")
    }

    private fun veredictoDeTramo(dx: Double, dy: Double, ex: Double, ey: Double): String? =
        EvaluadorProgreso.diagonalCorrecta(dx, dy, ex, ey)


    // ---------- Ajuste preciso del joystick ----------

    /**
     * Empuja la bola del joystick hasta el tope hacia la derecha, la izquierda, arriba y abajo, toma un
     * fotograma con la bola ya en su sitio y deduce el centro y el recorrido reales del joystick. Parte
     * del cuadrado que ya marcaste (aproximado) y solo lo sustituye si la medida forma una cruz coherente.
     * El personaje se mueve unos pasos durante la prueba: hazla en una zona segura.
     */
    private suspend fun ajustarJoystickActivo(): String {
        val titulo = "Ajuste del joystick"
        if (!ArosAccessibilityService.conectado.value) {
            return "$titulo: activa el servicio de accesibilidad de ArosBot AI en los ajustes de Android."
        }
        val actual = BotCore.settings.joystick
            ?: return "$titulo: primero marca el cuadrado aproximado del joystick (botón «Configurar joystick»)."
        if (!FrameBus.estado.value.activa) {
            return "$titulo: inicia la captura de pantalla en el Panel principal."
        }
        val servicio = ArosAccessibilityService.instancia
            ?: return "$titulo: el servicio de accesibilidad no está conectado."
        cuentaAtras(titulo)

        val reposo = FrameBus.instantanea() ?: return "$titulo: no llegan fotogramas de la captura."
        val (anchoReal, altoReal) = PantallaReal.tamano(BotCore.appContext)
        val anchoF = reposo.width
        val altoF = reposo.height
        val zonaCx = (actual.rect.x + actual.rect.w / 2f) * anchoF.toDouble()
        val zonaCy = (actual.rect.y + actual.rect.h / 2f) * altoF.toDouble()
        val zonaR = minOf(actual.rect.w * anchoF, actual.rect.h * altoF) / 2.0

        val pulsados = LinkedHashMap<String, Bitmap>()
        val orden = listOf("D" to Direccion.D, "A" to Direccion.A, "W" to Direccion.W, "S" to Direccion.S)
        try {
            for ((nombre, dir) in orden) {
                _estado.value = EstadoPrueba(true, "$titulo: empujando el joystick hacia $nombre…")
                delay(700L)
                val p = GeometriaJoystick.puntos(actual.rect, anchoReal, altoReal, dir, EMPUJE_AJUSTE)
                var foto: Bitmap? = null
                kotlinx.coroutines.coroutineScope {
                    val gesto = launch {
                        servicio.mantenerArrastre(p.centroX, p.centroY, p.destinoX, p.destinoY, EMPUJE_MS) {
                            BotCore.stateMachine.state.value != BotState.PARADA_EMERGENCIA
                        }
                    }
                    delay(EMPUJE_FOTO_MS)
                    foto = FrameBus.instantanea()
                    gesto.join()
                }
                val f = foto ?: return "$titulo: no llegan fotogramas de la captura."
                pulsados[nombre] = f
            }
        } finally {
            BotCore.entrada.soltarTodo()
        }

        val posiciones = LocalizadorDePerilla.localizar(reposo, pulsados, zonaCx, zonaCy, zonaR)
        val calculo = AjusteActivoJoystick.calcular(
            posiciones["D"], posiciones["A"], posiciones["W"], posiciones["S"]
        )
        val medida = calculo.medida
        val detalle = orden.joinToString("\n") { (n, _) ->
            val q = posiciones[n]
            "Bola hacia $n: " + if (q == null) "no localizada" else "x ${q.x.toInt()}, y ${q.y.toInt()}"
        }
        reposo.recycle()
        pulsados.values.forEach { it.recycle() }
        if (medida == null) {
            return "$titulo: NO se cambió nada. ${calculo.motivo}.\n$detalle\n" +
                "Prueba con el personaje parado en una zona sin nada que se mueva, el juego en primer plano y " +
                "el cuadrado marcado a ojo sobre el joystick (no mayor del doble de su tamaño)."
        }
        val rectNuevo = medida.aRect(anchoF, altoF)
        BotCore.settings.joystick = JoystickConfig(rectNuevo, anchoF, altoF)
        BotCore.log.info(
            "Joystick",
            "Ajuste por movimiento: centro ${medida.cx.toInt()}, ${medida.cy.toInt()}, radio ${medida.radio.toInt()} px"
        )
        return "$titulo: CORRECTO. Centro (${medida.cx.toInt()}, ${medida.cy.toInt()}) y recorrido " +
            "${medida.radio.toInt()} px medidos sobre el movimiento real de la bola (antes: radio " +
            "${zonaR.toInt()} px, centro movido ${hypot(medida.cx - zonaCx, medida.cy - zonaCy).toInt()} px).\n" +
            "$detalle\nDesvío de la cruz: ${medida.errorPx.toInt()} px. Ya está guardado; repite «Probar movimiento» " +
            "para recalibrar."
    }

    private const val EMPUJE_AJUSTE = 2.2f
    private const val EMPUJE_MS = 650L
    private const val EMPUJE_FOTO_MS = 380L

    // ---------- Personaje ----------

    private suspend fun personaje(): String {
        val titulo = "Prueba del personaje"
        if (!FrameBus.estado.value.activa) {
            return "$titulo: inicia la captura de pantalla en el Panel principal."
        }
        if (!LocalizadorPersonaje.hayReferencia()) {
            return "$titulo: esta prueba es opcional. Solo hace falta si la cámara no mantiene al personaje en el centro: " +
                "importa su imagen en Materiales con la categoría «Personaje». Sin ella el bot usa el centro de la pantalla."
        }
        cuentaAtras(titulo)

        val fotograma = FrameBus.instantanea() ?: return "$titulo: no llegan fotogramas de la captura."
        val ancho = fotograma.width
        val alto = fotograma.height
        val localizacion = LocalizadorPersonaje.localizar(fotograma)
        fotograma.recycle()

        if (localizacion == null) {
            BotCore.telemetry.update { it.copy(confianzaLocalizacion = null) }
            return "$titulo: NO se vio al personaje. Comprueba que aparece igual que en la imagen de " +
                "referencia (a tamaño completo, recortada de una captura de tu teléfono) o baja su umbral."
        }
        BotCore.telemetry.update { it.copy(confianzaLocalizacion = localizacion.confianza) }
        BotCore.marcarVerificadoPersistente(5)
        val x = (localizacion.centroX / ancho * 100f).roundToInt()
        val y = (localizacion.centroY / alto * 100f).roundToInt()
        val confianza = (localizacion.confianza * 100f).roundToInt()
        return "$titulo: CORRECTA. Personaje en x $x %, y $y % con $confianza % de confianza."
    }

    // ---------- Inicio de sesión ----------

    /** Busca [material] en un fotograma nuevo y pulsa su centro. true si se pulsó. */
    private suspend fun pulsarPorImagen(
        servicio: ArosAccessibilityService,
        material: Material,
        descripcion: String
    ): Boolean {
        val limite = SystemClock.elapsedRealtime() + 4000L
        while (SystemClock.elapsedRealtime() < limite) {
            val fotograma = FrameBus.instantanea()
            if (fotograma != null) {
                val resultado = Deteccion.enPantallaCompleta(
                    fotograma,
                    listOf(material),
                    BotCore.store.directorioMateriales
                )
                val mejor = resultado.detecciones.maxByOrNull { it.score }
                val ancho = fotograma.width
                val alto = fotograma.height
                fotograma.recycle()
                if (mejor != null) {
                    val (anchoPantalla, altoPantalla) = PantallaReal.tamano(BotCore.appContext)
                    val x = (mejor.box.left + mejor.box.right) / 2f * anchoPantalla / ancho
                    val y = (mejor.box.top + mejor.box.bottom) / 2f * altoPantalla / alto
                    BotCore.log.info(
                        "Inicio de sesión",
                        "Pulsando $descripcion por su imagen (confianza ${(mejor.score * 100f).roundToInt()} %)"
                    )
                    return servicio.tocar(x, y)
                }
            }
            delay(500L)
        }
        return false
    }

    private suspend fun inicioSesion(): String {
        val titulo = "Prueba de inicio de sesión"
        val servicio = ArosAccessibilityService.instancia
            ?: return "$titulo: activa el servicio de accesibilidad de ArosBot AI en los ajustes de Android."
        val correo = BotCore.settings.cuentaGoogle
        if (correo.isBlank()) {
            return "$titulo: escribe el correo de la cuenta de Google en Configuración."
        }
        if (!FrameBus.estado.value.activa) {
            return "$titulo: inicia la captura de pantalla en el Panel principal."
        }
        val material = SelectorDeMateriales.login(BotCore.store.materiales.value)
            ?: return "$titulo: importa en Materiales una imagen del botón «Log in» y ponle ese nombre."
        cuentaAtras(titulo)

        val fotograma = FrameBus.instantanea() ?: return "$titulo: no llegan fotogramas de la captura."
        val resultado = Deteccion.enPantallaCompleta(
            fotograma,
            listOf(material),
            BotCore.store.directorioMateriales
        )
        val mejor = resultado.detecciones.maxByOrNull { it.score }
        val anchoFotograma = fotograma.width
        val altoFotograma = fotograma.height
        fotograma.recycle()
        if (mejor == null) {
            return "$titulo: no se vio el botón «Log in» en pantalla. Ponte en el menú del juego antes " +
                "de que acabe la cuenta atrás."
        }

        val (anchoPantalla, altoPantalla) = PantallaReal.tamano(BotCore.appContext)
        val x = (mejor.box.left + mejor.box.right) / 2f * anchoPantalla / anchoFotograma
        val y = (mejor.box.top + mejor.box.bottom) / 2f * altoPantalla / altoFotograma
        BotCore.log.info(
            "Inicio de sesión",
            "Pulsando «Log in» (confianza ${(mejor.score * 100f).roundToInt()} %)"
        )
        if (!servicio.tocar(x, y)) return "$titulo: no se pudo enviar el toque sobre «Log in»."

        if (!esperarHasta(8000L) { ArosAccessibilityService.ventanaGoogle.value }) {
            return "$titulo: tras pulsar «Log in» no apareció el selector de cuentas de Google en 8 s."
        }
        BotCore.log.info("Inicio de sesión", "Selector de cuentas de Google detectado")
        delay(700L)

        if (servicio.hayCampoDeContrasena()) {
            return "$titulo: Google pide una contraseña o verificación. Hazlo tú: el bot nunca toca esos campos."
        }

        val materialCuenta = SelectorDeMateriales.cuenta(BotCore.store.materiales.value)
        val limite = SystemClock.elapsedRealtime() + (if (materialCuenta != null) 3000L else 6000L)
        var pulsada = false
        while (!pulsada && SystemClock.elapsedRealtime() < limite) {
            pulsada = servicio.pulsarElementoConTexto(correo)
            if (!pulsada) delay(400L)
        }
        if (!pulsada && materialCuenta != null) {
            BotCore.log.info("Inicio de sesión", "La cuenta no está como texto: se busca por su imagen")
            pulsada = pulsarPorImagen(servicio, materialCuenta, "la cuenta de Google")
        }
        if (!pulsada) {
            return if (materialCuenta == null) {
                "$titulo: no encontré la cuenta «$correo» en el selector (no aparece como texto). " +
                    "Importa en Materiales una imagen de cómo se ve la cuenta en el selector y ponle " +
                    "un nombre que contenga «cuenta» (por ejemplo «Cuenta Google»). Por ahora, elígela tú."
            } else {
                "$titulo: no encontré la cuenta ni como texto ni por la imagen «${materialCuenta.nombre}». " +
                    "Comprueba que la imagen está recortada de una captura real del selector, a tamaño " +
                    "completo, o baja su umbral en Materiales. Elígela tú."
            }
        }
        BotCore.log.info("Inicio de sesión", "Cuenta pulsada en el selector")

        val cerrado = esperarHasta(12_000L) { !ArosAccessibilityService.ventanaGoogle.value }
        return if (cerrado) {
            "$titulo: CORRECTA. Se eligió la cuenta y el selector se cerró. Comprueba que entraste al juego."
        } else {
            "$titulo: se pulsó la cuenta, pero el selector sigue abierto. Puede pedir más pasos: revísalo tú."
        }
    }
}
