package com.arosbot.ai.automation

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.capture.PantallaReal
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.Calibracion
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.EvaluadorProgreso
import com.arosbot.ai.core.FuenteMedicion
import com.arosbot.ai.core.Medicion
import com.arosbot.ai.core.SelectorDeMateriales
import com.arosbot.ai.input.ArosAccessibilityService
import com.arosbot.ai.vision.Deteccion
import com.arosbot.ai.vision.EstimadorMovimiento
import com.arosbot.ai.vision.LocalizadorPersonaje
import java.util.Locale
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EstadoPrueba(val ejecutando: Boolean = false, val texto: String = "")

/**
 * Pruebas REALES de la Fase 3, que se ejecutan en el teléfono sobre el juego:
 *  - movimiento: pulsa W, S, A y D en el joystick, mide lo que se mueve y calibra;
 *  - personaje: comprueba que se localiza la imagen de referencia del personaje;
 *  - inicio de sesión: pulsa «Log in» y elige la cuenta en el selector de Google.
 *
 * Todas empiezan con una cuenta atrás para que cambies al juego (los gestos se envían a la app que
 * esté en primer plano). Se cancelan con la parada de emergencia o con el botón de cancelar.
 */
object PruebasAutomatizacion {

    private const val CUENTA_ATRAS_S = 6
    private const val PULSACION_MS = 700L
    private const val REPETICIONES = 2
    private const val ESPERA_PREVIA_MS = 450L
    private const val ASENTAMIENTO_MS = 1000L
    private const val MIN_DESPLAZAMIENTO_PX = 4.0

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trabajo: Job? = null

    private val _estado = MutableStateFlow(EstadoPrueba())
    val estado: StateFlow<EstadoPrueba> = _estado.asStateFlow()

    fun probarMovimiento() = lanzar("Prueba de movimiento") { movimiento() }

    fun probarPersonaje() = lanzar("Prueba del personaje") { personaje() }

    fun probarInicioSesion() = lanzar("Prueba de inicio de sesión") { inicioSesion() }

    /** Cancela la prueba en curso y suelta las entradas. */
    fun cancelar() {
        trabajo?.cancel()
        BotCore.entrada.soltarTodo()
    }

    @Synchronized
    private fun lanzar(titulo: String, bloque: suspend () -> String) {
        if (trabajo?.isActive == true) {
            BotCore.log.aviso("Automatización", "Ya hay una prueba en curso")
            return
        }
        if (BotCore.stateMachine.state.value == BotState.PARADA_EMERGENCIA) {
            _estado.value = EstadoPrueba(
                false,
                "$titulo: hay una parada de emergencia activa. Pulsa «Restablecer» en el Panel principal."
            )
            BotCore.log.aviso("Automatización", "$titulo: no se inicia, hay una parada de emergencia activa")
            return
        }
        _estado.value = EstadoPrueba(true, "$titulo: en curso…")
        BotCore.log.info("Automatización", "$titulo: iniciada")
        trabajo = alcance.launch {
            val texto = try {
                bloque()
            } catch (e: CancellationException) {
                BotCore.entrada.soltarTodo()
                "$titulo: cancelada"
            } catch (e: Exception) {
                BotCore.log.error("Automatización", "$titulo: error inesperado: ${e.message}")
                "$titulo: error inesperado (${e.message})"
            }
            _estado.value = EstadoPrueba(false, texto)
            val resumen = texto.lines().first()
            BotCore.log.info("Automatización", resumen)
            avisar(resumen)
        }
    }

    private fun avisar(texto: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(BotCore.appContext, texto, Toast.LENGTH_LONG).show()
        }
    }

    private suspend fun cuentaAtras(titulo: String) {
        avisar("Cambia ahora al juego: $titulo empieza en $CUENTA_ATRAS_S s")
        for (s in CUENTA_ATRAS_S downTo 1) {
            _estado.value = EstadoPrueba(true, "$titulo: cambia al juego… $s")
            delay(1000L)
        }
        _estado.value = EstadoPrueba(true, "$titulo: en curso…")
    }

    private suspend fun esperarHasta(limiteMs: Long, condicion: () -> Boolean): Boolean {
        val fin = SystemClock.elapsedRealtime() + limiteMs
        while (SystemClock.elapsedRealtime() < fin) {
            if (condicion()) return true
            delay(200L)
        }
        return condicion()
    }

    private fun decimal(valor: Double): String = String.format(Locale.US, "%.1f", valor)

    // ---------- Movimiento ----------

    /**
     * Mide lo que se desplaza lo observado al mantener cada dirección. Prefiere el desplazamiento del
     * personaje (si hay referencia y se mueve) y usa el de la escena si no.
     */
    private fun medir(antes: Bitmap, despues: Bitmap): Medicion? {
        val porEscena = EstimadorMovimiento.estimar(antes, despues)
        val a = LocalizadorPersonaje.localizar(antes)
        val b = LocalizadorPersonaje.localizar(despues)
        if (a != null && b != null) {
            val porPersonaje = Medicion(
                (b.centroX - a.centroX).toDouble(),
                (b.centroY - a.centroY).toDouble(),
                minOf(a.confianza, b.confianza).toDouble(),
                FuenteMedicion.PERSONAJE
            )
            if (EvaluadorProgreso.hayMovimiento(porPersonaje, MIN_DESPLAZAMIENTO_PX)) return porPersonaje
        }
        return porEscena
    }

    private suspend fun movimiento(): String {
        val titulo = "Prueba de movimiento"
        if (!ArosAccessibilityService.conectado.value) {
            return "$titulo: activa el servicio de accesibilidad de ArosBot AI en los ajustes de Android."
        }
        if (BotCore.settings.joystick == null) {
            return "$titulo: primero configura el joystick (botón «Configurar joystick»)."
        }
        if (!FrameBus.estado.value.activa) {
            return "$titulo: inicia la captura de pantalla en el Panel principal."
        }
        cuentaAtras(titulo)

        val orden = listOf(Direccion.W, Direccion.S, Direccion.A, Direccion.D)
        val calibraciones = HashMap<Direccion, Calibracion>()
        val lineas = ArrayList<String>()
        for (ronda in 1..REPETICIONES) {
            for (direccion in orden) {
                delay(ESPERA_PREVIA_MS)
                val antes = FrameBus.instantanea()
                    ?: return "$titulo: no llegan fotogramas de la captura."
                val completado = BotCore.entrada.mantener(direccion, PULSACION_MS)
                if (!completado) {
                    BotCore.entrada.soltarTodo()
                    antes.recycle()
                    return "$titulo: no se pudo enviar el gesto de ${direccion.tecla}. " +
                        "Comprueba que la accesibilidad sigue activa, que la captura está en marcha " +
                        "y que el joystick está bien configurado."
                }
                delay(ASENTAMIENTO_MS)
                val despues = FrameBus.instantanea()
                if (despues == null) {
                    antes.recycle()
                    return "$titulo: no llegan fotogramas de la captura."
                }
                val medicion = medir(antes, despues)
                antes.recycle()
                despues.recycle()
                if (medicion == null) {
                    lineas.add("Ronda $ronda · ${direccion.tecla}: sin medición")
                    continue
                }
                val previa = calibraciones[direccion] ?: Calibracion.vacia(direccion)
                calibraciones[direccion] = previa.actualizar(medicion.dx, medicion.dy, PULSACION_MS)
                val fuente = if (medicion.fuente == FuenteMedicion.PERSONAJE) "personaje" else "escena"
                lineas.add(
                    "Ronda $ronda · ${direccion.tecla}: dx ${decimal(medicion.dx)} px, " +
                        "dy ${decimal(medicion.dy)} px ($fuente)"
                )
            }
        }

        for (calibracion in calibraciones.values) BotCore.store.guardarCalibracion(calibracion)

        val problemas = EvaluadorProgreso.calibracionCoherente(calibraciones)
        val partes = ArrayList<String>()
        if (problemas.isEmpty()) {
            BotCore.marcarVerificadoPersistente(12)
            BotCore.marcarVerificadoPersistente(6)
            partes.add("$titulo: CORRECTA. El joystick mueve al personaje y la calibración es coherente.")
        } else {
            partes.add("$titulo: NO superada.")
        }
        partes.addAll(lineas)
        for (d in orden) {
            val c = calibraciones[d] ?: continue
            partes.add("Calibración ${d.tecla}: ${decimal(c.rapidez)} px por segundo de pulsación")
        }
        if (problemas.isNotEmpty()) {
            partes.add("Problemas detectados:")
            problemas.forEach { partes.add("• $it") }
            partes.add(
                "Revisa que el cuadrado del joystick esté justo sobre el joystick del juego. " +
                    "Si la cámara no sigue al personaje, importa su imagen en Materiales con la " +
                    "categoría «Personaje»."
            )
        }
        return partes.joinToString("\n")
    }

    // ---------- Personaje ----------

    private suspend fun personaje(): String {
        val titulo = "Prueba del personaje"
        if (!FrameBus.estado.value.activa) {
            return "$titulo: inicia la captura de pantalla en el Panel principal."
        }
        if (!LocalizadorPersonaje.hayReferencia()) {
            return "$titulo: importa en Materiales una imagen del personaje con la categoría «Personaje»."
        }
        cuentaAtras(titulo)

        val fotograma = FrameBus.instantanea() ?: return "$titulo: no llegan fotogramas de la captura."
        val ancho = fotograma.width
        val alto = fotograma.height
        val localizacion = LocalizadorPersonaje.localizar(fotograma)
        fotograma.recycle()

        if (localizacion == null) {
            BotCore.telemetry.update { it.copy(confianzaLocalizacion = null) }
            return "$titulo: NO se vio al personaje. Comprueba que aparece igual que en la imagen de " +
                "referencia (a tamaño completo, recortada de una captura de tu teléfono) o baja su umbral."
        }
        BotCore.telemetry.update { it.copy(confianzaLocalizacion = localizacion.confianza) }
        BotCore.marcarVerificadoPersistente(5)
        val x = (localizacion.centroX / ancho * 100f).roundToInt()
        val y = (localizacion.centroY / alto * 100f).roundToInt()
        val confianza = (localizacion.confianza * 100f).roundToInt()
        return "$titulo: CORRECTA. Personaje en x $x %, y $y % con $confianza % de confianza."
    }

    // ---------- Inicio de sesión ----------

    private suspend fun inicioSesion(): String {
        val titulo = "Prueba de inicio de sesión"
        val servicio = ArosAccessibilityService.instancia
            ?: return "$titulo: activa el servicio de accesibilidad de ArosBot AI en los ajustes de Android."
        val correo = BotCore.settings.cuentaGoogle
        if (correo.isBlank()) {
            return "$titulo: escribe el correo de la cuenta de Google en Configuración."
        }
        if (!FrameBus.estado.value.activa) {
            return "$titulo: inicia la captura de pantalla en el Panel principal."
        }
        val material = SelectorDeMateriales.login(BotCore.store.materiales.value)
            ?: return "$titulo: importa en Materiales una imagen del botón «Log in» y ponle ese nombre."
        cuentaAtras(titulo)

        val fotograma = FrameBus.instantanea() ?: return "$titulo: no llegan fotogramas de la captura."
        val resultado = Deteccion.enPantallaCompleta(
            fotograma,
            listOf(material),
            BotCore.store.directorioMateriales
        )
        val mejor = resultado.detecciones.maxByOrNull { it.score }
        val anchoFotograma = fotograma.width
        val altoFotograma = fotograma.height
        fotograma.recycle()
        if (mejor == null) {
            return "$titulo: no se vio el botón «Log in» en pantalla. Ponte en el menú del juego antes " +
                "de que acabe la cuenta atrás."
        }

        val (anchoPantalla, altoPantalla) = PantallaReal.tamano(BotCore.appContext)
        val x = (mejor.box.left + mejor.box.right) / 2f * anchoPantalla / anchoFotograma
        val y = (mejor.box.top + mejor.box.bottom) / 2f * altoPantalla / altoFotograma
        BotCore.log.info(
            "Inicio de sesión",
            "Pulsando «Log in» (confianza ${(mejor.score * 100f).roundToInt()} %)"
        )
        if (!servicio.tocar(x, y)) return "$titulo: no se pudo enviar el toque sobre «Log in»."

        if (!esperarHasta(8000L) { ArosAccessibilityService.ventanaGoogle.value }) {
            return "$titulo: tras pulsar «Log in» no apareció el selector de cuentas de Google en 8 s."
        }
        BotCore.log.info("Inicio de sesión", "Selector de cuentas de Google detectado")
        delay(700L)

        if (servicio.hayCampoDeContrasena()) {
            return "$titulo: Google pide una contraseña o verificación. Hazlo tú: el bot nunca toca esos campos."
        }

        val limite = SystemClock.elapsedRealtime() + 6000L
        var pulsada = false
        while (!pulsada && SystemClock.elapsedRealtime() < limite) {
            pulsada = servicio.pulsarElementoConTexto(correo)
            if (!pulsada) delay(400L)
        }
        if (!pulsada) {
            return "$titulo: no encontré la cuenta «$correo» en el selector (quizá no aparece como texto). " +
                "Elígela tú."
        }
        BotCore.log.info("Inicio de sesión", "Cuenta pulsada en el selector")

        val cerrado = esperarHasta(12_000L) { !ArosAccessibilityService.ventanaGoogle.value }
        return if (cerrado) {
            "$titulo: CORRECTA. Se eligió la cuenta y el selector se cerró. Comprueba que entraste al juego."
        } else {
            "$titulo: se pulsó la cuenta, pero el selector sigue abierto. Puede pedir más pasos: revísalo tú."
        }
    }
}
