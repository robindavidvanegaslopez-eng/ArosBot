package com.arosbot.ai.automation

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.capture.PantallaReal
import com.arosbot.ai.core.MacroDeClics
import com.arosbot.ai.core.Acercamiento
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.Calibracion
import com.arosbot.ai.core.ControlDeSesion
import com.arosbot.ai.core.Decision
import com.arosbot.ai.core.Detection
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.Evento
import com.arosbot.ai.core.FuncionVisual
import com.arosbot.ai.core.Guia
import com.arosbot.ai.core.GuiaDeAcercamiento
import com.arosbot.ai.core.GuiaDeRuta
import com.arosbot.ai.core.LecturaInventario
import com.arosbot.ai.core.LectorDeInventario
import com.arosbot.ai.core.Material
import com.arosbot.ai.core.Objetivo
import com.arosbot.ai.core.PlanDeRutas
import com.arosbot.ai.core.PlanificadorDeObjetivos
import com.arosbot.ai.core.PlanificadorDeRutas
import com.arosbot.ai.core.PuntoXY
import com.arosbot.ai.core.ResultadoDeRecogida
import com.arosbot.ai.core.SecuenciaDeCofre
import com.arosbot.ai.core.SelectorDeFunciones
import com.arosbot.ai.core.Spot
import com.arosbot.ai.core.VerificadorDeDeposito
import com.arosbot.ai.core.VerificadorDeRecogida
import com.arosbot.ai.core.MaterialesDelSpot
import com.arosbot.ai.input.ArosAccessibilityService
import com.arosbot.ai.input.JoystickGestos
import com.arosbot.ai.vision.Deteccion
import com.arosbot.ai.vision.EstimadorMovimiento
import com.arosbot.ai.vision.LocalizadorPersonaje
import kotlin.math.hypot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Recolección con verificación, inventario lleno y depósito en el cofre (módulos 14 y 15).
 *
 * Todo lo que se da por hecho se comprueba mirando la pantalla: el recurso se recoge solo si deja de
 * verse tras interactuar; el inventario está lleno solo si el aviso se ve en varias muestras; el
 * depósito cuenta solo si el aviso deja de aparecer y se confirma con la siguiente recogida. Ante
 * cualquier duda (inventario incierto, fallos repetidos) el bot se detiene en lugar de insistir.
 *
 * Limitaciones: pulsar usa el servicio de accesibilidad con toques en coordenadas de pantalla; Android
 * no garantiza que cualquier botón del juego responda. Si el juego no reacciona, la comprobación visual
 * lo detecta y cuenta como fallo.
 */
object Recolector {

    enum class Modo { SESION, LEER_INVENTARIO, PROBAR_INTERACCION, PROBAR_DEPOSITO }

    private const val CUENTA_ATRAS_S = 6
    private const val MUESTRAS_INVENTARIO = 6
    private const val MUESTRAS_POST_INTERACCION = 8
    private const val ESPERA_MUESTRA_MS = 350L
    private const val MAX_PASOS_ACERCAMIENTO = 10
    private const val MAX_PASOS_REGRESO = 14
    private const val ASENTAMIENTO_MS = 450L
    private const val CONFIANZA_MEDICION = 0.08
    private const val LIMITE_SPOT_MS = 5 * 60_000L

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trabajo: Job? = null

    private val _estado = MutableStateFlow(EstadoPrueba())
    val estado: StateFlow<EstadoPrueba> = _estado.asStateFlow()

    val ejecutando: Boolean get() = trabajo?.isActive == true

    // Posición relativa al último punto conocido (final de ruta), en píxeles del fotograma.
    private var px = 0.0
    private var py = 0.0

    /** Depósito hecho pero aún sin confirmar con la siguiente recogida. */
    private var depositoPorConfirmar = false

    @Synchronized
    fun iniciar(modo: Modo) {
        if (ejecutando) {
            BotCore.log.aviso("Recolección", "Ya hay una recolección en marcha")
            return
        }
        val otra = SeguidorDeRuta.estado.value.ejecutando || NavegadorDeSpots.ejecutando
        if (otra) {
            _estado.value = EstadoPrueba(false, "Hay una ruta o una navegación en marcha. Cancélala primero.")
            return
        }
        if (BotCore.stateMachine.state.value == BotState.PARADA_EMERGENCIA) {
            _estado.value = EstadoPrueba(
                false, "Hay una parada de emergencia activa. Pulsa «Restablecer» en el Panel principal."
            )
            return
        }
        _estado.value = EstadoPrueba(true, "Preparando…")
        trabajo = alcance.launch {
            val texto = try {
                val previo = precondiciones(modo)
                previo ?: when (modo) {
                    Modo.SESION -> sesion()
                    Modo.LEER_INVENTARIO -> probarInventario()
                    Modo.PROBAR_INTERACCION -> probarInteraccion()
                    Modo.PROBAR_DEPOSITO -> probarDeposito()
                }
            } catch (e: CancellationException) {
                "Recolección: cancelada."
            } catch (e: Exception) {
                BotCore.log.error("Recolección", "Error inesperado: ${e.message}")
                "Recolección: error inesperado (${e.message})."
            } finally {
                BotCore.entrada.soltarTodo()
                BotCore.telemetry.value = BotCore.telemetry.value.copy(
                    objetivoActual = "Ninguno", spotActivo = "Ninguno", rutaSeleccionada = "Ninguna"
                )
            }
            _estado.value = EstadoPrueba(false, texto)
            val resumen = texto.lines().first()
            BotCore.log.info("Recolección", resumen)
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(BotCore.appContext, resumen, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun cancelar() {
        trabajo?.cancel()
        BotCore.entrada.soltarTodo()
    }

    private fun progreso(texto: String) {
        _estado.value = EstadoPrueba(true, texto)
    }

    // ---------- Comprobaciones previas ----------

    private fun materiales(): List<Material> = BotCore.store.materiales.value

    private fun precondiciones(modo: Modo): String? {
        if (!FrameBus.estado.value.activa) return "Recolección: inicia la captura de pantalla en el Panel principal."
        if (modo == Modo.LEER_INVENTARIO) {
            return if (SelectorDeFunciones.con(FuncionVisual.INVENTARIO_LLENO, materiales()).isEmpty()) {
                "Recolección: falta la imagen del aviso. Importa en Materiales una captura del aviso " +
                    "«Your inventory is full.» con nombre «Inventario lleno»."
            } else null
        }
        if (!ArosAccessibilityService.conectado.value) {
            return "Recolección: activa el servicio de accesibilidad de ArosBot AI en los ajustes de Android."
        }
        if (BotCore.settings.joystick == null) return "Recolección: primero configura el joystick en Automatización."
        val sinCalibrar = Direccion.CARDINALES.filter {
            (BotCore.store.calibraciones.value[it]?.muestras ?: 0) == 0
        }
        if (sinCalibrar.isNotEmpty()) {
            return "Recolección: falta calibrar el movimiento (${sinCalibrar.joinToString { it.tecla }}). " +
                "Haz antes «Probar movimiento» en Automatización."
        }
        // La imagen del personaje es opcional: sin ella se toma el centro de la pantalla (la cámara sigue al personaje).
        if (modo == Modo.PROBAR_INTERACCION || modo == Modo.SESION) {
            if (SelectorDeFunciones.con(FuncionVisual.INTERACTUAR, materiales()).isEmpty()) {
                return "Recolección: falta la imagen del botón de interactuar. Impórtala en Materiales con el nombre «Interactuar» " +
                    "(es un requisito: el bot pulsa ese botón para recoger)."
            }
        }
        if (modo == Modo.PROBAR_DEPOSITO || modo == Modo.SESION) {
            MacroDeClics.problema(MacroDeClics.decodificar(BotCore.settings.macroCofre))?.let {
                return "Recolección: falta el macro del cofre ($it) Grábalo en «Inventario y cofre»."
            }
        }
        if (modo == Modo.SESION) {
            if (SelectorDeFunciones.con(FuncionVisual.INVENTARIO_LLENO, materiales()).isEmpty()) {
                return "Recolección: falta la imagen del aviso «Inventario lleno» en Materiales."
            }
            if (!cofreConfigurado()) {
                return "Recolección: marca el lugar del cofre en «Inventario y cofre» y enseña una ruta que llegue hasta él."
            }
            val actual = NavegadorDeSpots.lugarActual()
                ?: return "Recolección: no sé dónde estás. Pulsa «Estoy en…» en Spots."
            val cofre = BotCore.settings.lugarCofreId
            if (actual != cofre &&
                PlanificadorDeRutas.planificar(BotCore.store.rutas.value, actual, cofre) == null
            ) {
                val nombreActual = BotCore.store.lugares.value.firstOrNull { it.id == actual }?.nombre ?: "tu lugar actual"
                return "Recolección: no hay ninguna ruta enseñada que lleve desde «$nombreActual» hasta el lugar del cofre " +
                    "(requisito: el bot debe poder localizar el cofre con una ruta enseñada)."
            }
            if (BotCore.store.spots.value.isEmpty()) return "Recolección: no hay ningún spot. Añade uno primero."
        }
        return null
    }

    fun cofreConfigurado(): Boolean {
        val id = BotCore.settings.lugarCofreId
        return id >= 0 && BotCore.store.lugares.value.any { it.id == id }
    }

    // ---------- Lectura de pantalla ----------

    private fun indicadores(): List<Material> =
        SelectorDeFunciones.con(FuncionVisual.INVENTARIO_LLENO, materiales())

    private fun buscarEnPantalla(lista: List<Material>): Pair<Detection?, Pair<Int, Int>>? {
        if (lista.isEmpty()) return null
        val f = FrameBus.instantanea() ?: return null
        try {
            val r = Deteccion.enPantallaCompleta(f, lista, BotCore.store.directorioMateriales)
            return Pair(r.detecciones.maxByOrNull { it.score }, Pair(f.width, f.height))
        } finally {
            f.recycle()
        }
    }

    /** Espera hasta [limiteMs] a que [funcion] se vea y devuelve su detección y el tamaño del fotograma. */
    private suspend fun esperarVisual(
        funcion: FuncionVisual,
        limiteMs: Long
    ): Pair<Detection, Pair<Int, Int>>? {
        val lista = SelectorDeFunciones.con(funcion, materiales())
        val fin = SystemClock.elapsedRealtime() + limiteMs
        while (SystemClock.elapsedRealtime() < fin) {
            val r = buscarEnPantalla(lista)
            val d = r?.first
            if (r != null && d != null) return Pair(d, r.second)
            delay(400L)
        }
        return null
    }

    private suspend fun lecturaDeInventario(
        muestras: Int = MUESTRAS_INVENTARIO,
        positivasParaLleno: Int = LectorDeInventario.POSITIVAS_PARA_LLENO
    ): LecturaInventario {
        val lista = indicadores()
        val marcas = ArrayList<Boolean?>()
        repeat(muestras) {
            val r = buscarEnPantalla(lista)
            marcas.add(if (r == null) null else r.first != null)
            delay(ESPERA_MUESTRA_MS)
        }
        val lectura = LectorDeInventario.leer(marcas, positivasParaLleno = positivasParaLleno)
        BotCore.telemetry.value = BotCore.telemetry.value.copy(inventario = lectura.etiqueta)
        return lectura
    }

    private fun pantalla(): Pair<Int, Int> = PantallaReal.tamano(BotCore.appContext)

    private suspend fun tocarDeteccion(d: Detection, tam: Pair<Int, Int>): Boolean {
        val servicio = ArosAccessibilityService.instancia ?: return false
        val (ap, hp) = pantalla()
        val x = (d.box.left + d.box.right) / 2f * ap / tam.first
        val y = (d.box.top + d.box.bottom) / 2f * hp / tam.second
        return servicio.tocar(x, y)
    }

    private fun pesoPersonaje(): Pair<Float, Float>? {
        val f = FrameBus.instantanea() ?: return null
        try {
            val l = LocalizadorPersonaje.localizar(f)
            return if (l != null) Pair(l.centroX, l.centroY) else Pair(f.width * 0.5f, f.height * 0.47f)
        } finally {
            f.recycle()
        }
    }

    // ---------- Movimiento medido ----------

    private suspend fun pasoMedido(
        direccion: Direccion,
        ms: Long,
        calibraciones: Map<Direccion, Calibracion>
    ): Boolean {
        val antes = FrameBus.instantanea() ?: return false
        val ok = BotCore.entrada.mantener(direccion, ms)
        if (!ok) {
            antes.recycle()
            BotCore.entrada.soltarTodo()
            return false
        }
        delay(ASENTAMIENTO_MS)
        val despues = FrameBus.instantanea()
        if (despues == null) {
            antes.recycle()
            return false
        }
        val m = EstimadorMovimiento.estimar(antes, despues)
        antes.recycle()
        despues.recycle()
        if (m != null && m.confianza >= CONFIANZA_MEDICION) {
            px -= m.dx
            py -= m.dy
        } else {
            val c = com.arosbot.ai.core.Calibraciones.para(calibraciones, direccion)
            if (c != null) {
                px -= c.vx * ms / 1000.0
                py -= c.vy * ms / 1000.0
            }
        }
        return true
    }

    /** Devuelve al personaje al punto donde acabó la última ruta, para poder seguir rutas desde ahí. */
    private suspend fun volverAlPunto(): Boolean {
        val diagonales = BotCore.settings.diagonalesVerificadas
        val cal = HashMap<Direccion, Calibracion>(BotCore.store.calibraciones.value)
        repeat(MAX_PASOS_REGRESO) {
            val g = GuiaDeRuta.siguientePaso(px, py, 0.0, 0.0, cal, diagonales = diagonales)
            when (g) {
                is Guia.Llegado -> return true
                is Guia.SinCalibracion -> return false
                is Guia.Mover -> {
                    if (!pasoMedido(g.direccion, g.duracionMs, cal)) return false
                }
            }
        }
        return false
    }

    // ---------- Acercarse e interactuar ----------

    private fun detectarRecursos(buscados: List<Material>): List<Detection> {
        val f = FrameBus.instantanea() ?: return emptyList()
        try {
            return Deteccion.enAreasActivas(
                f, BotCore.store.areas.value, buscados, BotCore.store.directorioMateriales
            ).detecciones
        } finally {
            f.recycle()
        }
    }

    private fun centro(d: Detection) = PuntoXY((d.box.left + d.box.right) / 2f, (d.box.top + d.box.bottom) / 2f)

    private fun masCercano(lista: List<Detection>, ref: PuntoXY): Detection? =
        lista.minByOrNull {
            val c = centro(it)
            hypot((c.x - ref.x).toDouble(), (c.y - ref.y).toDouble())
        }

    private class Intento(
        val resultado: ResultadoDeRecogida,
        /** null si no se llegó a mirar el inventario (por ejemplo, falló el movimiento). */
        val inventario: LecturaInventario?,
        val detalle: String
    )

    /**
     * Un intento completo con un recurso: acercarse hasta el rango, detenerse, interactuar y mirar
     * varios instantes seguidos si desapareció y si salió el aviso de inventario lleno.
     */
    private suspend fun intentarRecoger(objetivo: Detection, buscados: List<Material>): Intento {
        val cal = HashMap<Direccion, Calibracion>(BotCore.store.calibraciones.value)
        val diagonales = BotCore.settings.diagonalesVerificadas
        var actual = objetivo
        var enRango = false
        var tam = FrameBus.estado.value.let { Pair(it.ancho, it.alto) }

        for (paso in 1..MAX_PASOS_ACERCAMIENTO) {
            val yo = pesoPersonaje() ?: return Intento(
                ResultadoDeRecogida.DUDOSO, null, "no llegan fotogramas"
            )
            val c = centro(actual)
            val g = GuiaDeAcercamiento.siguiente((c.x - yo.first).toDouble(), (c.y - yo.second).toDouble(), cal, diagonales)
            when (g) {
                is Acercamiento.EnRango -> {
                    enRango = true
                }
                is Acercamiento.SinCalibracion -> return Intento(
                    ResultadoDeRecogida.NO_RECOGIDO, null, "falta calibrar ${g.direccion.tecla}"
                )
                is Acercamiento.Mover -> {
                    if (!pasoMedido(g.direccion, g.duracionMs, cal)) {
                        return Intento(
                            ResultadoDeRecogida.NO_RECOGIDO, null,
                            "no se pudo enviar el gesto: ${JoystickGestos.motivoUltimoFallo ?: "motivo desconocido"}"
                        )
                    }
                    // El recurso se mueve en pantalla al avanzar: se vuelve a buscar el mismo.
                    val de = masCercano(detectarRecursos(buscados), c)
                    if (de == null) {
                        return Intento(
                            ResultadoDeRecogida.DUDOSO, null,
                            "el recurso dejó de verse mientras me acercaba"
                        )
                    }
                    actual = de
                }
            }
            if (enRango) break
        }
        if (!enRango) {
            return Intento(ResultadoDeRecogida.NO_RECOGIDO, null, "no conseguí llegar al rango")
        }

        BotCore.entrada.soltarTodo()
        val objetivoFinal = centro(actual)
        tam = FrameBus.estado.value.let { Pair(it.ancho, it.alto) }

        // Interactuar: botón «Interactuar» si el usuario aportó su imagen; si no, pulsar sobre el recurso.
        val boton = SelectorDeFunciones.con(FuncionVisual.INTERACTUAR, materiales())
        val pulsado = if (boton.isNotEmpty()) {
            val v = esperarVisual(FuncionVisual.INTERACTUAR, 2500L)
            if (v != null) tocarDeteccion(v.first, v.second) else false
        } else {
            tocarDeteccion(actual, tam)
        }
        if (!pulsado) {
            return Intento(
                ResultadoDeRecogida.NO_RECOGIDO, null,
                if (boton.isNotEmpty()) "no vi el botón de interactuar" else "no se pudo enviar el toque"
            )
        }

        // Observación posterior: recurso presente/ausente y aviso de inventario.
        val posiciones = ArrayList<List<PuntoXY>?>()
        val avisos = ArrayList<Boolean?>()
        val indic = indicadores()
        repeat(MUESTRAS_POST_INTERACCION) { i ->
            val f = FrameBus.instantanea()
            if (f == null) {
                posiciones.add(null)
                avisos.add(null)
            } else {
                try {
                    val r = Deteccion.enAreasActivas(
                        f, BotCore.store.areas.value, buscados, BotCore.store.directorioMateriales
                    )
                    // Las primeras muestras dan tiempo a que termine la recogida.
                    if (i >= 3) posiciones.add(r.detecciones.map { centro(it) })
                    avisos.add(
                        if (indic.isEmpty()) null
                        else Deteccion.enPantallaCompleta(f, indic, BotCore.store.directorioMateriales)
                            .detecciones.isNotEmpty()
                    )
                } finally {
                    f.recycle()
                }
            }
            delay(ESPERA_MUESTRA_MS)
        }
        val inventario = LectorDeInventario.leer(avisos, positivasParaLleno = 2)
        BotCore.telemetry.value = BotCore.telemetry.value.copy(inventario = inventario.etiqueta)
        val recogida = VerificadorDeRecogida.evaluar(objetivoFinal, posiciones)
        return Intento(recogida, inventario, "")
    }

    private class ResultadoDeSpot(val evento: Evento, val recogidos: Int, val fallos: Int, val texto: String)

    private suspend fun recogerEnSpot(
        spot: Spot,
        buscados: List<Material>,
        control: ControlDeSesion
    ): ResultadoDeSpot {
        control.nuevoSpot()
        var recogidos = 0
        var fallos = 0
        val inicio = SystemClock.elapsedRealtime()
        while (true) {
            if (SystemClock.elapsedRealtime() - inicio > LIMITE_SPOT_MS) {
                return ResultadoDeSpot(Evento.SPOT_AGOTADO, recogidos, fallos, "tiempo máximo en el spot")
            }
            val visibles = detectarRecursos(buscados)
            BotCore.telemetry.value = BotCore.telemetry.value.copy(recursosDetectados = visibles.size)
            if (visibles.isEmpty()) {
                val o = NavegadorDeSpots.observar(buscados)
                if (!NavegadorDeSpots.observacionCompleta(o)) {
                    return ResultadoDeSpot(Evento.FALLO, recogidos, fallos, "dejaron de llegar fotogramas")
                }
                if (!NavegadorDeSpots.hayRecursos(o)) {
                    return ResultadoDeSpot(Evento.SPOT_AGOTADO, recogidos, fallos, "no quedan recursos a la vista")
                }
                continue
            }
            val yo = pesoPersonaje() ?: return ResultadoDeSpot(Evento.FALLO, recogidos, fallos, "sin fotogramas")
            val objetivo = masCercano(visibles, PuntoXY(yo.first, yo.second))!!

            var hecho = false
            for (n in 1..control.intentosPermitidos()) {
                progreso("Recolectando en «${spot.nombre}»: recurso ${recogidos + 1}, intento $n…")
                val intento = intentarRecoger(objetivo, buscados)
                BotCore.log.info(
                    "Recolección",
                    "«${objetivo.nombre}» intento $n: ${intento.resultado.etiqueta} · inventario " +
                        "${intento.inventario?.etiqueta ?: "sin mirar"}" +
                        if (intento.detalle.isNotEmpty()) " · ${intento.detalle}" else ""
                )
                if (intento.inventario == LecturaInventario.LLENO) {
                    BotCore.marcarVerificadoPersistente(14)
                    if (depositoPorConfirmar) {
                        // El depósito no sirvió: sigue lleno justo después de vaciar.
                        depositoPorConfirmar = false
                        val d = control.deposito(false)
                        if (d is Decision.Detener) return ResultadoDeSpot(Evento.FALLO, recogidos, fallos, d.motivo)
                    }
                    return ResultadoDeSpot(Evento.INVENTARIO_LLENO, recogidos, fallos, "inventario lleno")
                }
                if (intento.inventario == LecturaInventario.INCIERTO) {
                    val d = control.inventarioIncierto() as Decision.Detener
                    return ResultadoDeSpot(Evento.FALLO, recogidos, fallos, d.motivo)
                }
                val decision = control.recogida(intento.resultado)
                if (intento.resultado == ResultadoDeRecogida.RECOGIDO) {
                    recogidos++
                    hecho = true
                    if (depositoPorConfirmar) {
                        depositoPorConfirmar = false
                        control.deposito(true)
                        BotCore.marcarVerificadoPersistente(15)
                        BotCore.log.info("Recolección", "Depósito confirmado: se pudo recoger tras vaciar el inventario")
                    }
                } else {
                    fallos++
                }
                if (decision is Decision.Detener) {
                    return ResultadoDeSpot(Evento.FALLO, recogidos, fallos, decision.motivo)
                }
                if (hecho) break
            }
            if (!hecho) {
                // Agotados los intentos con este recurso: se pasa al siguiente spot en vez de insistir.
                return ResultadoDeSpot(Evento.SPOT_AGOTADO, recogidos, fallos, "no pude recoger un recurso tras reintentar")
            }
        }
    }

    // ---------- Cofre ----------

    private class ResultadoDeDeposito(val ok: Boolean, val texto: String, val lectura: LecturaInventario)

    /**
     * Depósito: el bot ya está en el lugar del cofre y repite los toques que el usuario grabó (abrir el
     * cofre, depositar, salir). Después mira el aviso de inventario lleno varias veces: solo si ya no se
     * ve se da por hecho, y aun así se confirma con la siguiente recogida.
     */
    private suspend fun depositar(): ResultadoDeDeposito {
        fun falla(texto: String, l: LecturaInventario = LecturaInventario.INCIERTO) =
            ResultadoDeDeposito(false, texto, l)

        val grabado = MacroDeClics.decodificar(BotCore.settings.macroCofre)
        MacroDeClics.problema(grabado)?.let { return falla(it) }
        val macro = grabado!!
        progreso("Cofre: repitiendo los toques que grabaste (${MacroDeClics.resumen(macro)})…")
        val motivo = ReproductorDeMacro.reproducir(macro) { i, n ->
            progreso("Cofre: paso $i de $n del macro")
        }
        if (motivo != null) return falla(motivo)
        delay(1200L)

        progreso("Cofre: comprobando el inventario…")
        val despues = lecturaDeInventario()
        val exito = VerificadorDeDeposito.exito(LecturaInventario.LLENO, despues)
        return when (despues) {
            LecturaInventario.NO_LLENO -> ResultadoDeDeposito(
                exito,
                "Depósito hecho: el aviso de inventario lleno ya no se ve. Se confirmará con la siguiente recogida.",
                despues
            )
            LecturaInventario.LLENO -> ResultadoDeDeposito(
                false, "el inventario sigue lleno tras repetir el macro (¿cofre lleno o macro incompleto?)", despues
            )
            LecturaInventario.INCIERTO -> ResultadoDeDeposito(false, "no pude comprobar el inventario tras el macro", despues)
        }
    }

    // ---------- Pruebas sueltas ----------

    private suspend fun probarInventario(): String {
        progreso("Mirando el inventario varias veces…")
        val lectura = lecturaDeInventario()
        if (lectura == LecturaInventario.LLENO) BotCore.marcarVerificadoPersistente(14)
        return "Prueba del inventario: ${lectura.etiqueta.lowercase()}.\n" +
            when (lectura) {
                LecturaInventario.LLENO -> "El aviso se vio en varias muestras seguidas. Módulo verificado."
                LecturaInventario.NO_LLENO -> "El aviso no se vio en ninguna muestra. Para verificar el detector, " +
                    "repite la prueba mientras el aviso «Your inventory is full.» está en pantalla."
                LecturaInventario.INCIERTO -> "Resultado incierto: el aviso se vio solo en parte de las muestras o " +
                    "llegaron pocos fotogramas. El bot se detendría por precaución."
            }
    }

    private suspend fun probarInteraccion(): String {
        val mats = materiales()
        val buscados = mats.filter { SelectorDeFunciones.esDeRecoleccion(it) }
        if (buscados.isEmpty()) return "Prueba de interacción: importa en Materiales al menos un recurso a recoger."
        for (s in CUENTA_ATRAS_S downTo 1) {
            progreso("Prueba de interacción: cambia al juego, junto a un recurso… $s")
            delay(1000L)
        }
        px = 0.0
        py = 0.0
        val visibles = detectarRecursos(buscados)
        if (visibles.isEmpty()) return "Prueba de interacción: no veo ningún recurso de tus materiales en las áreas activas."
        val yo = pesoPersonaje() ?: return "Prueba de interacción: no llegan fotogramas."
        val objetivo = masCercano(visibles, PuntoXY(yo.first, yo.second))!!
        val intento = intentarRecoger(objetivo, buscados)
        if (intento.resultado == ResultadoDeRecogida.RECOGIDO) BotCore.marcarVerificadoPersistente(15)
        return "Prueba de interacción: ${intento.resultado.etiqueta}.\n" +
            "Recurso: ${objetivo.nombre} · inventario: ${intento.inventario?.etiqueta ?: "sin mirar"}" +
            (if (intento.detalle.isNotEmpty()) "\n${intento.detalle}" else "") +
            "\nLo comprobado es visual: el recurso dejó de verse en el mismo sitio tras interactuar."
    }

    private suspend fun probarDeposito(): String {
        for (s in CUENTA_ATRAS_S downTo 1) {
            progreso("Prueba de depósito: cambia al juego, cerca del cofre… $s")
            delay(1000L)
        }
        px = 0.0
        py = 0.0
        val r = depositar()
        if (r.ok) BotCore.marcarVerificadoPersistente(15)
        return "Prueba de depósito: ${if (r.ok) "CORRECTA" else "NO completada"}.\n${r.texto}"
    }

    // ---------- Sesión autónoma ----------

    private suspend fun irPorRutas(plan: PlanDeRutas, nombre: String): Boolean {
        for ((i, tramo) in plan.tramos.withIndex()) {
            progreso("Yendo a $nombre: tramo ${i + 1} de ${plan.tramos.size} por «${tramo.ruta.nombre}»")
            val r = SeguidorDeRuta.seguir(tramo.ruta, tramo.inversa, cuentaAtras = false)
            if (!r.exito) {
                BotCore.log.aviso("Recolección", "Falló el tramo ${i + 1}: ${r.texto.lines().first()}")
                return false
            }
        }
        px = 0.0
        py = 0.0
        return true
    }

    private suspend fun sesion(): String {
        for (s in CUENTA_ATRAS_S downTo 1) {
            progreso("Recolección autónoma: cambia al juego… $s")
            delay(1000L)
        }
        val control = ControlDeSesion()
        var objetivo = Objetivo.ELEGIR_SPOT
        var spot: Spot? = null
        var plan: PlanDeRutas? = null
        var buscados: List<Material> = emptyList()
        var motivoParada = ""
        var recogidosTotal = 0
        px = 0.0
        py = 0.0
        depositoPorConfirmar = false

        fun parar(motivo: String) {
            motivoParada = motivo
            objetivo = Objetivo.DETENIDO
        }

        while (objetivo != Objetivo.DETENIDO) {
            BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = objetivo.etiqueta)
            when (objetivo) {
                Objetivo.ELEGIR_SPOT -> {
                    val e = NavegadorDeSpots.evaluar().elegido
                    if (e == null) {
                        parar("ningún spot es alcanzable con las rutas enseñadas")
                    } else {
                        val b = MaterialesDelSpot.buscados(e.spot, materiales())
                            .filter { SelectorDeFunciones.esDeRecoleccion(it) }
                        if (b.isEmpty()) {
                            parar("«${e.spot.nombre}» no tiene materiales de recolección que buscar")
                        } else {
                            spot = e.spot
                            plan = e.plan
                            buscados = b
                            BotCore.telemetry.value = BotCore.telemetry.value.copy(spotActivo = e.spot.nombre)
                            BotCore.log.info("Recolección", "Destino: «${e.spot.nombre}» (${e.motivo})")
                            objetivo = PlanificadorDeObjetivos.siguiente(objetivo, Evento.SPOT_ELEGIDO)
                        }
                    }
                }
                Objetivo.IR_AL_SPOT -> {
                    val s = spot!!
                    if (!irPorRutas(plan!!, "«${s.nombre}»")) {
                        parar("no pude llegar a «${s.nombre}»")
                    } else {
                        val o = NavegadorDeSpots.observar(buscados)
                        if (!NavegadorDeSpots.observacionCompleta(o)) {
                            parar("dejaron de llegar fotogramas al mirar «${s.nombre}»")
                        } else {
                            val hay = NavegadorDeSpots.hayRecursos(o)
                            BotCore.store.registrarVisita(s.id, hay, System.currentTimeMillis())
                            val d = control.spotTerminado(if (hay) 1 else 0)
                            objetivo = when {
                                d is Decision.Detener -> { parar(d.motivo); Objetivo.DETENIDO }
                                hay -> PlanificadorDeObjetivos.siguiente(objetivo, Evento.LLEGADO)
                                else -> PlanificadorDeObjetivos.siguiente(objetivo, Evento.SPOT_AGOTADO)
                            }
                        }
                    }
                }
                Objetivo.RECOGER -> {
                    val s = spot!!
                    val r = recogerEnSpot(s, buscados, control)
                    recogidosTotal += r.recogidos
                    BotCore.store.registrarRecoleccion(s.id, r.recogidos, r.fallos, System.currentTimeMillis())
                    BotCore.log.info(
                        "Recolección",
                        "«${s.nombre}»: ${r.recogidos} recogidos, ${r.fallos} fallos (${r.texto})"
                    )
                    val volvio = volverAlPunto()
                    if (!volvio) {
                        BotCore.settings.lugarActualId = -1L
                        parar("no pude volver al punto de la ruta en «${s.nombre}»; ya no sé dónde estoy")
                    } else {
                        if (r.evento == Evento.SPOT_AGOTADO) {
                            BotCore.store.registrarVisita(s.id, false, System.currentTimeMillis())
                            val d = control.spotTerminado(r.recogidos)
                            if (d is Decision.Detener) parar(d.motivo)
                            else objetivo = PlanificadorDeObjetivos.siguiente(objetivo, Evento.SPOT_AGOTADO)
                        } else if (r.evento == Evento.INVENTARIO_LLENO) {
                            objetivo = PlanificadorDeObjetivos.siguiente(objetivo, Evento.INVENTARIO_LLENO)
                        } else {
                            parar(r.texto)
                        }
                    }
                }
                Objetivo.IR_AL_COFRE -> {
                    val origen = NavegadorDeSpots.lugarActual()
                    val destino = BotCore.settings.lugarCofreId
                    val p = if (origen == null) null
                    else PlanificadorDeRutas.planificar(BotCore.store.rutas.value, origen, destino)
                    if (p == null) {
                        parar("no hay ruta enseñada desde aquí hasta el cofre")
                    } else if (!irPorRutas(p, "el cofre")) {
                        parar("no pude llegar al cofre")
                    } else {
                        objetivo = PlanificadorDeObjetivos.siguiente(objetivo, Evento.LLEGADO_AL_COFRE)
                    }
                }
                Objetivo.DEPOSITAR -> {
                    var listo = false
                    var intentos = 0
                    while (!listo && objetivo != Objetivo.DETENIDO) {
                        intentos++
                        val r = depositar()
                        BotCore.log.info("Recolección", "Depósito (intento $intentos): ${r.texto}")
                        if (r.lectura == LecturaInventario.INCIERTO && !r.ok) {
                            val d = control.deposito(false)
                            if (d is Decision.Detener) parar(d.motivo)
                        } else if (r.ok) {
                            listo = true
                            depositoPorConfirmar = true
                        } else {
                            val d = control.deposito(false)
                            if (d is Decision.Detener) parar(d.motivo)
                        }
                        if (!volverAlPunto() && objetivo != Objetivo.DETENIDO) {
                            BotCore.settings.lugarActualId = -1L
                            parar("no pude volver al punto de la ruta junto al cofre")
                        }
                    }
                    if (listo && objetivo != Objetivo.DETENIDO) {
                        objetivo = PlanificadorDeObjetivos.siguiente(objetivo, Evento.DEPOSITADO)
                    }
                }
                Objetivo.DETENIDO -> Unit
            }
        }
        return "Recolección autónoma detenida: $motivoParada.\n" +
            "Recogidos: ${control.recogidos} · fallos: ${control.fallos} · depósitos confirmados: ${control.depositos}"
    }
}
