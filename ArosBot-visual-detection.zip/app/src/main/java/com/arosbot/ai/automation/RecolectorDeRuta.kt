package com.arosbot.ai.automation

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.capture.PantallaReal
import com.arosbot.ai.capture.TrayectoSobreJuego
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.Calibracion
import com.arosbot.ai.core.CaminoDeVuelta
import com.arosbot.ai.core.FiltroDeEstabilidad
import com.arosbot.ai.core.MaterialEnMundo
import com.arosbot.ai.core.Detection
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.ElectorDeMaterial
import com.arosbot.ai.core.FuncionVisual
import com.arosbot.ai.core.ListaNegraDeMateriales
import com.arosbot.ai.core.MacroDeClics
import com.arosbot.ai.core.Material
import com.arosbot.ai.core.OptimizadorDeTrayecto
import com.arosbot.ai.core.Persistencia
import com.arosbot.ai.core.PuntoDeRuta
import com.arosbot.ai.core.ReferenciaVisual
import com.arosbot.ai.core.Relocalizacion
import com.arosbot.ai.core.Rodeo
import java.util.concurrent.CopyOnWriteArrayList
import com.arosbot.ai.core.SelectorDeFunciones
import com.arosbot.ai.input.ArosAccessibilityService
import com.arosbot.ai.vision.Deteccion
import com.arosbot.ai.vision.PlantillaCache
import com.arosbot.ai.vision.SeguidorLocal
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import com.arosbot.ai.vision.VisionEngine
import com.arosbot.ai.vision.ReferenciasVisuales
import kotlin.math.hypot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield

/**
 * Recolección automática por una única ruta enseñada del cofre a la zona de materiales.
 *
 *  1. Sigue la ruta hacia la zona. Un vigilante analiza la pantalla en segundo plano (detección rápida).
 *  2. Si ve un material, para, se acerca hasta dejarlo muy cerca del centro (sin tocarlo), pulsa
 *     «Interactuar» y repite mientras ese mismo material siga viéndose; cuando desaparece pasa al
 *     siguiente. Lo que no se alcanza o no se recoge se descarta.
 *  3. Cuando sale el aviso de inventario lleno (o acaba la ruta) vuelve por la MISMA ruta, al revés,
 *     desde donde esté (se ignora el resto del recorrido), repite el macro del cofre y reinicia la ruta.
 *
 * No se ha probado todavía en el juego.
 */
object RecolectorDeRuta {

    private const val CUENTA_ATRAS_S = 6
    private const val MAX_VIAJES_POR_MATERIAL = 8
    private const val LIMITE_MATERIAL_MS = 180_000L
    private const val ESPERA_MENSAJE_MS = 1500L
    private const val MENSAJE_TERMINA_MS = 4000L
    private const val SIN_MENSAJE_PARA_REAJUSTAR = 3
    private const val NUDGE_LATERAL_MS = 160L
    private const val CONTACTO_BASE_PX = 45.0
    private const val MISMO_MATERIAL_PX = 45.0
    private const val ESPERA_TRAS_INTERACTUAR_MS = 700L
    private const val LIMITE_CONDUCCION_MS = 120_000L
    private const val CICLOS_VACIOS_MAXIMOS = 3
    private const val FALLOS_DEPOSITO_MAXIMOS = 2
    private const val TOLERANCIA_INICIO_PX = 30.0
    private const val RADIO_RASTREO_PX = 90
    private const val RADIO_BOTON_PX = 24
    private const val UMBRAL_RASTREO = 0.55
    private const val UMBRAL_BOTON = 0.6
    private const val FOTOGRAMAS_AUSENTE = 6
    private const val INTERACCIONES_SI_NO_SE_VIO = 3
    /** Distancia (centro a centro, px del mundo) a la que el personaje ya puede estar topando con el material. */
    private const val CERCA_PX = 100.0
    /** Fotogramas seguidos con la escena inmóvil para dar por hecho que choca. */
    private const val QUIETOS_PARA_CHOQUE = 4
    private const val MEDIDOS_PARA_ARRANQUE = 3
    private const val ESPERA_BOTON_MS = 1000L
    private const val TOQUE_DE_GIRO_MS = 110L

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trabajo: Job? = null

    private val _estado = MutableStateFlow(EstadoPrueba())
    val estado: StateFlow<EstadoPrueba> = _estado.asStateFlow()

    val ejecutando: Boolean get() = trabajo?.isActive == true

    @Synchronized
    fun iniciar() {
        if (ejecutando) return
        val otra = SeguidorDeRuta.estado.value.ejecutando || NavegadorDeSpots.ejecutando ||
            Recolector.ejecutando || PruebasAutomatizacion.estado.value.ejecutando
        if (otra) {
            _estado.value = EstadoPrueba(false, "Hay otro proceso en marcha. Pulsa «Cancelar todo» y vuelve a intentarlo.")
            return
        }
        if (BotCore.stateMachine.state.value == BotState.PARADA_EMERGENCIA) {
            _estado.value = EstadoPrueba(
                false, "Hay una parada de emergencia activa. Pulsa «Restablecer» en el Panel principal."
            )
            return
        }
        _estado.value = EstadoPrueba(true, "Preparando…")
        trabajo = alcance.launch {
            val texto = try {
                sesion()
            } catch (e: CancellationException) {
                "Recolección por ruta: cancelada."
            } catch (e: Exception) {
                BotCore.log.error("Recolección", "Error inesperado: ${e.message}")
                "Recolección por ruta: error inesperado (${e.message})."
            } finally {
                BotCore.entrada.soltarTodo()
                TrayectoSobreJuego.limpiar()
                BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = "Ninguno")
            }
            _estado.value = EstadoPrueba(false, texto)
            val resumen = texto.lines().first()
            BotCore.log.info("Recolección", resumen)
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(BotCore.appContext, resumen, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun cancelar() {
        trabajo?.cancel()
        BotCore.entrada.soltarTodo()
    }

    fun reiniciar() {
        trabajo?.cancel()
        trabajo = null
        BotCore.entrada.soltarTodo()
        _estado.value = EstadoPrueba(false, "Cancelado por el usuario.")
    }

    private fun progreso(texto: String) {
        _estado.value = EstadoPrueba(true, texto)
    }

    /** Requisitos; null si todo está listo. */
    fun problema(): String? {
        val mats = BotCore.store.materiales.value
        if (!FrameBus.estado.value.activa) return "Inicia la captura de pantalla en el Panel principal."
        if (!ArosAccessibilityService.conectado.value) return "Activa el servicio de accesibilidad de ArosBot AI."
        if (BotCore.settings.joystick == null) return "Primero configura el joystick en Automatización."
        val sinCalibrar = Direccion.CARDINALES.filter {
            (BotCore.store.calibraciones.value[it]?.muestras ?: 0) == 0
        }
        if (sinCalibrar.isNotEmpty()) return "Falta calibrar el movimiento (${sinCalibrar.joinToString { it.tecla }})."
        if (BotCore.store.rutas.value.none { it.id == BotCore.settings.rutaRecoleccionId }) {
            return "Elige la ruta de recolección (la que va del cofre a la zona de materiales)."
        }
        if (SelectorDeFunciones.con(FuncionVisual.MENSAJE_SISTEMA, mats).isEmpty()) {
            return "Falta la imagen del mensaje del sistema «recolectando» en Materiales (nómbrala «Sistema …», " +
                "p. ej. «Sistema recolectando Roble»): confirma que se está recolectando ese material."
        }
        if (SelectorDeFunciones.con(FuncionVisual.INTERACTUAR, mats).isEmpty()) {
            return "Falta la imagen del botón «Interactuar» en Materiales."
        }
        if (SelectorDeFunciones.con(FuncionVisual.INVENTARIO_LLENO, mats).isEmpty()) {
            return "Falta la imagen del aviso «Inventario lleno» en Materiales."
        }
        MacroDeClics.problema(MacroDeClics.decodificar(BotCore.settings.macroCofre))?.let {
            return "Falta el macro del cofre ($it)"
        }
        if (mats.none { SelectorDeFunciones.esDeRecoleccion(it) }) return "No hay materiales de recolección importados."
        return null
    }

    // ---------- Vigilante: detección y rastreo rápidos en segundo plano ----------

    /** Estado del material seguido, anclado al mundo (marco de la ruta). */
    private class Rastro(
        val mundoX: Double,
        val mundoY: Double,
        val ancho: Int,
        val alto: Int,
        val score: Double,
        val visible: Boolean,
        val numero: Long
    )

    /**
     * Dos bucles en paralelo que exprimen la pantalla, sin copiar fotogramas (se leen tal cual llegan):
     *  - descubrir: detección rápida (una escala, mitad de resolución, gris + confirmación en color) de
     *    materiales, del botón de interactuar y del aviso de inventario lleno. Cada material se anota en
     *    coordenadas del MUNDO con la posición del bot en el instante de ese fotograma, y solo se considera
     *    si aparece en el mismo punto en varias lecturas seguidas (filtro de falsos positivos).
     *  - rastrear: en CADA fotograma sigue con una plantilla local adaptable el material elegido y el botón
     *    de interactuar, buscando solo en su entorno (milisegundos).
     */
    private class Vigilante(
        private val buscados: List<Material>,
        private val indicadores: List<Material>,
        private val botones: List<Material>,
        private val mensajes: List<Material>,
        private val posicion: () -> Pair<Double, Double>
    ) {
        /** Último instante en que se vio cada imagen del mensaje del sistema. */
        val mensajeVistoMs = java.util.concurrent.ConcurrentHashMap<Long, Long>()

        /** Último instante en que se vio alguno de los mensajes [ids] (0 si nunca). */
        fun ultimoMensaje(ids: Set<Long>): Long = ids.maxOfOrNull { mensajeVistoMs[it] ?: 0L } ?: 0L

        val filtro = FiltroDeEstabilidad()
        @Volatile var numero = 0L
        @Volatile var ancho = 0
        @Volatile var alto = 0
        @Volatile var fps = 0f
        @Volatile var fpsRastreo = 0f
        @Volatile var llenoSeguidas = 0
        /** Cuadro del botón de interactuar (fijo en pantalla) y si se ve en este momento. */
        @Volatile var cajaBoton: com.arosbot.ai.core.Box? = null
        @Volatile var botonVisible = false
        @Volatile var rastro: Rastro? = null
        @Volatile var fotogramasSinVer = 0
        @Volatile var numeroRastreo = 0L

        private class Pedido(val seguidor: SeguidorLocal, val mundoX: Double, val mundoY: Double)

        @Volatile private var pedido: Pedido? = null
        @Volatile private var soltarPedido = false

        /** Centro del personaje en pantalla: la cámara lo mantiene fijo. */
        fun centroX() = (if (ancho > 0) ancho else FrameBus.estado.value.ancho) * 0.5
        fun centroY() = (if (alto > 0) alto else FrameBus.estado.value.alto) * 0.47

        /**
         * Empieza a seguir [m] fijándolo en el mundo. La plantilla inicial es la IMAGEN DE REFERENCIA del
         * material (la variante que mejor casa ahora donde debería estar), no un recorte del fotograma.
         */
        fun fijarObjetivo(m: MaterialEnMundo): Boolean {
            val f = FrameBus.ultimoFotograma() ?: return false
            val pos = posicion()
            val ex = f.width * 0.5 + (m.x - pos.first)
            val ey = f.height * 0.47 + (m.y - pos.second)
            VisionEngine.preparar(f).use { esc ->
                val material = BotCore.store.materiales.value.firstOrNull { it.id == m.id }
                val carga = material?.let { PlantillaCache.obtener(it, BotCore.store.directorioMateriales) }
                val tw = m.ancho.coerceAtLeast(6)
                val th = m.alto.coerceAtLeast(6)
                var mejorMat: Mat? = null
                var mejorScore = 0.0
                if (carga != null) {
                    for (variante in carga.variantes) {
                        val t = Mat()
                        Imgproc.resize(variante, t, Size(tw.toDouble(), th.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
                        val r = VisionEngine.buscarLocal(esc, t, ex, ey, RADIO_RASTREO_PX)
                        if (r != null && r.score > mejorScore) {
                            mejorMat?.release()
                            mejorMat = t
                            mejorScore = r.score
                        } else {
                            t.release()
                        }
                    }
                }
                if (mejorMat == null || mejorScore < 0.4) {
                    mejorMat?.release()
                    val caja = com.arosbot.ai.core.Box(
                        (ex - tw / 2.0).toInt(), (ey - th / 2.0).toInt(),
                        (ex + tw / 2.0).toInt(), (ey + th / 2.0).toInt()
                    )
                    mejorMat = VisionEngine.recortar(esc, caja) ?: return false
                }
                rastro = null
                fotogramasSinVer = 0
                pedido = Pedido(SeguidorLocal(mejorMat!!), m.x, m.y)
            }
            return true
        }

        fun soltarObjetivo() {
            soltarPedido = true
        }

        fun arrancar(): List<Job> = listOf(descubrir(), rastrear())

        private fun descubrir(): Job = alcance.launch {
            var ultimo = -1L
            var ciclos = 0
            val marcas = ArrayDeque<Long>()
            while (isActive) {
                val n = FrameBus.estado.value.fotogramas
                val f = FrameBus.ultimoFotograma()
                if (n == ultimo || f == null) {
                    delay(1L)
                    continue
                }
                ultimo = n
                val pos = posicion()
                try {
                    val r = Deteccion.rapidaEnAreasActivas(
                        f, BotCore.store.areas.value, buscados, BotCore.store.directorioMateriales
                    )
                    ancho = f.width
                    alto = f.height
                    val cx = f.width * 0.5
                    val cy = f.height * 0.47
                    filtro.anotar(
                        r.detecciones.map {
                            MaterialEnMundo(
                                it.materialId, it.nombre,
                                pos.first + (it.box.left + it.box.right) / 2.0 - cx,
                                pos.second + (it.box.top + it.box.bottom) / 2.0 - cy,
                                it.box.width, it.box.height
                            )
                        }
                    )
                    ciclos++
                    if (botones.isNotEmpty() && (cajaBoton == null || !botonVisible) && ciclos % 2 == 0) {
                        val b = Deteccion.rapidaEnPantallaCompleta(
                            f, botones, BotCore.store.directorioMateriales
                        ).detecciones.maxByOrNull { it.score }
                        if (b != null) cajaBoton = b.box
                    }
                    if (mensajes.isNotEmpty() && ciclos % 2 == 1) {
                        val ahoraMs = SystemClock.elapsedRealtime()
                        for (d in Deteccion.rapidaEnPantallaCompleta(
                            f, mensajes, BotCore.store.directorioMateriales
                        ).detecciones) mensajeVistoMs[d.materialId] = ahoraMs
                    }
                    if (ciclos % 3 == 0 && indicadores.isNotEmpty()) {
                        val hay = Deteccion.rapidaEnPantallaCompleta(
                            f, indicadores, BotCore.store.directorioMateriales
                        ).detecciones.isNotEmpty()
                        llenoSeguidas = if (hay) llenoSeguidas + 1 else 0
                    }
                    val t = SystemClock.elapsedRealtime()
                    marcas.addLast(t)
                    while (marcas.isNotEmpty() && t - marcas.first() > 1000L) marcas.removeFirst()
                    if (marcas.size >= 2) fps = (marcas.size - 1) * 1000f / (t - marcas.first()).coerceAtLeast(1L)
                    numero = n
                } catch (e: Exception) {
                    delay(50L)
                }
                yield()
            }
        }

        private fun rastrear(): Job = alcance.launch {
            var ultimo = -1L
            var seguidorObj: SeguidorLocal? = null
            var seguidorBoton: SeguidorLocal? = null
            var cajaBotonUsada: com.arosbot.ai.core.Box? = null
            var mundoX = 0.0
            var mundoY = 0.0
            val marcas = ArrayDeque<Long>()
            try {
                while (isActive) {
                    val n = FrameBus.estado.value.fotogramas
                    val f = FrameBus.ultimoFotograma()
                    if (n == ultimo || f == null) {
                        delay(1L)
                        continue
                    }
                    ultimo = n
                    val pos = posicion()
                    try {
                        if (soltarPedido) {
                            soltarPedido = false
                            pedido = null
                            seguidorObj?.liberar()
                            seguidorObj = null
                            rastro = null
                        }
                        pedido?.let {
                            seguidorObj?.liberar()
                            seguidorObj = it.seguidor
                            mundoX = it.mundoX
                            mundoY = it.mundoY
                            pedido = null
                        }
                        VisionEngine.preparar(f).use { esc ->
                            val cxP = f.width * 0.5
                            val cyP = f.height * 0.47
                            // Botón de interactuar: fijo en pantalla; se comprueba solo en su sitio.
                            val cb = cajaBoton
                            if (cb != null) {
                                if (cb != cajaBotonUsada || seguidorBoton == null) {
                                    seguidorBoton?.liberar()
                                    seguidorBoton = VisionEngine.recortar(esc, cb)?.let { SeguidorLocal(it) }
                                    cajaBotonUsada = cb
                                }
                                val h = seguidorBoton?.buscar(
                                    esc, (cb.left + cb.right) / 2.0, (cb.top + cb.bottom) / 2.0, RADIO_BOTON_PX
                                )
                                botonVisible = h != null && h.score >= UMBRAL_BOTON
                            }
                            // Material elegido: se sigue por su punto fijo en el mundo.
                            val seg = seguidorObj
                            if (seg != null) {
                                val h = seg.buscar(
                                    esc, cxP + (mundoX - pos.first), cyP + (mundoY - pos.second), RADIO_RASTREO_PX
                                )
                                val visible = h != null && h.score >= UMBRAL_RASTREO
                                if (visible) {
                                    mundoX = pos.first + (h!!.centroX - cxP)
                                    mundoY = pos.second + (h.centroY - cyP)
                                    fotogramasSinVer = 0
                                } else {
                                    fotogramasSinVer++
                                }
                                rastro = Rastro(mundoX, mundoY, seg.ancho, seg.alto, h?.score ?: 0.0, visible, n)
                            }
                        }
                        numeroRastreo++
                        val t = SystemClock.elapsedRealtime()
                        marcas.addLast(t)
                        while (marcas.isNotEmpty() && t - marcas.first() > 1000L) marcas.removeFirst()
                        if (marcas.size >= 2) fpsRastreo = (marcas.size - 1) * 1000f / (t - marcas.first()).coerceAtLeast(1L)
                    } catch (e: Exception) {
                        delay(30L)
                    }
                }
            } finally {
                seguidorObj?.liberar()
                seguidorBoton?.liberar()
            }
        }
    }

    private enum class Resultado { RECOGIDO, NO_RECOGIDO, BLOQUEADO, DESAPARECIDO, LLENO }

    private class Ejecucion(
        val ruta: com.arosbot.ai.core.Ruta,
        val conductor: ConductorDeRuta,
        val puntos: List<PuntoDeRuta>,
        val vig: Vigilante,
        val buscados: List<Material>
    ) {
        val negra = ListaNegraDeMateriales()
        var recogidosTotal = 0
        var recogidosCiclo = 0
        var rodeos = 0
    }

    private fun reconocerAhora(referencia: ReferenciaVisual): ReferenciasVisuales.Hallazgo? {
        val f = FrameBus.instantanea() ?: return null
        return try {
            ReferenciasVisuales.reconocer(f, referencia, BotCore.store.directorioReferencias)
                ?.takeIf { Relocalizacion.fiable(it.confianza) }
        } finally {
            f.recycle()
        }
    }

    private fun limite() = SystemClock.elapsedRealtime() + LIMITE_CONDUCCION_MS

    private fun aqui(e: Ejecucion) = PuntoDeRuta(e.conductor.x, e.conductor.y, 0L)

    // ---------- Sesión ----------

    private suspend fun sesion(): String {
        problema()?.let { return "Recolección por ruta: $it" }
        val ruta = BotCore.store.rutas.value.first { it.id == BotCore.settings.rutaRecoleccionId }
        val original = ruta.puntosEnSentido(false)
        if (original.size < 2) return "Recolección por ruta: la ruta no tiene recorrido."
        val puntos = OptimizadorDeTrayecto.simplificar(original).puntos
        val mats = BotCore.store.materiales.value
        val buscados = mats.filter { SelectorDeFunciones.esDeRecoleccion(it) }
        val indicadores = SelectorDeFunciones.con(FuncionVisual.INVENTARIO_LLENO, mats)
        val calibraciones = HashMap<Direccion, Calibracion>(BotCore.store.calibraciones.value)
        val diagonales = BotCore.settings.diagonalesVerificadas

        for (s in CUENTA_ATRAS_S downTo 1) {
            progreso("Recolección por ruta: colócate junto al cofre, en el inicio de la ruta… $s")
            delay(1000L)
        }
        val conductor = ConductorDeRuta(
            calibraciones, diagonales, original.filter { it.referencia != null },
            { reconocerAhora(it) },
            { BotCore.log.info("Recolección", it) },
            { progreso(it) }
        )
        val vig = Vigilante(
            buscados, indicadores, SelectorDeFunciones.con(FuncionVisual.INTERACTUAR, mats),
            SelectorDeFunciones.con(FuncionVisual.MENSAJE_SISTEMA, mats)
        ) {
            Pair(conductor.x, conductor.y)
        }
        val e = Ejecucion(ruta, conductor, puntos, vig, buscados)

        // Posición inicial: se fija a la captura del punto de partida (el cofre).
        val inicio = puntos.first()
        if (inicio.referencia != null) {
            val h = reconocerAhora(inicio.referencia!!)
                ?: return "Recolección por ruta: no reconozco el inicio de la ruta. Colócate junto al cofre, " +
                    "donde empezaste a enseñarla."
            val (nx, ny) = Relocalizacion.posicion(inicio, h.dx, h.dy)
            conductor.x = nx
            conductor.y = ny
        } else {
            conductor.x = inicio.x
            conductor.y = inicio.y
        }

        FrameBus.pedirRapido()
        val trabajoVig = vig.arrancar()
        try {
            var ciclo = 0
            var vacios = 0
            var fallosDeposito = 0
            while (true) {
                ciclo++
                e.recogidosCiclo = 0
                e.negra.vaciar()
                BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = "Ida (ciclo $ciclo)")
                val ida = ida(e)
                if (ida != null) return fin(e, ciclo, ida)
                BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = "Vuelta al cofre")
                val vuelta = vuelta(e)
                if (vuelta != null) return fin(e, ciclo, vuelta)
                BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = "Depositar")
                val dep = depositar(e)
                if (dep != null) {
                    fallosDeposito++
                    BotCore.log.aviso("Recolección", "Depósito fallido: $dep")
                    if (fallosDeposito >= FALLOS_DEPOSITO_MAXIMOS) {
                        return fin(e, ciclo, "el depósito falló $fallosDeposito veces ($dep)")
                    }
                } else {
                    fallosDeposito = 0
                }
                vacios = if (e.recogidosCiclo == 0) vacios + 1 else 0
                if (vacios >= CICLOS_VACIOS_MAXIMOS) {
                    return fin(e, ciclo, "$CICLOS_VACIOS_MAXIMOS vueltas seguidas sin recoger nada")
                }
                relocalizarInicio(e)
            }
        } finally {
            conductor.interrupcion = null
            trabajoVig.forEach { it.cancel() }
            FrameBus.soltarRapido()
        }
    }

    private fun fin(e: Ejecucion, ciclos: Int, motivo: String): String =
        "Recolección por ruta: detenida ($motivo).\n" +
            "Vueltas: $ciclos · materiales recogidos: ${e.recogidosTotal} · descartados: ${e.negra.tamano}\n" +
            "Detección: ${"%.0f".format(e.vig.fps)} ciclos/s · rastreo: ${"%.0f".format(e.vig.fpsRastreo)} fotogramas/s · conducción: ${"%.0f".format(e.conductor.fps)} fps medidos"

    // ---------- Ida ----------

    /** El material estable (visto en el mismo punto del mundo varias veces) más cercano, no descartado. */
    private fun candidato(e: Ejecucion): MaterialEnMundo? {
        val c = e.conductor
        return ElectorDeMaterial.elegir(
            e.vig.filtro.estables(), { m -> Pair(m.x - c.x, m.y - c.y) }, c.x, c.y, e.negra
        )
    }

    /** null si acabó la ida con normalidad (lleno o fin de ruta); si no, el motivo del fallo. */
    private suspend fun ida(e: Ejecucion): String? {
        val c = e.conductor
        var lista = e.puntos
        var desde = 1
        while (true) {
            c.interrupcion = { e.vig.llenoSeguidas >= 2 || candidato(e) != null }
            progreso("Siguiendo la ruta hacia la zona de materiales…")
            val fin = c.conducir(lista, desde, limite())
            c.interrupcion = null
            when (fin) {
                is ConductorDeRuta.Fin.Llegado -> return null
                is ConductorDeRuta.Fin.Fallo -> return fin.texto
                is ConductorDeRuta.Fin.Bloqueado -> {
                    val paso = Rodeo.puntoDePaso(c.x, c.y, lista[fin.indice].x, lista[fin.indice].y, e.rodeos++)
                        ?: return "no pude rodear un obstáculo en la ida"
                    lista = listOf(aqui(e), PuntoDeRuta(paso.x.toDouble(), paso.y.toDouble(), 0L)) +
                        lista.drop(fin.indice)
                    desde = 1
                    continue
                }
                is ConductorDeRuta.Fin.Interrumpido -> {
                    e.rodeos = 0
                    if (e.vig.llenoSeguidas >= 2) return null
                    val lleno = recogerVisibles(e)
                    if (lleno) return null
                    lista = e.puntos
                    desde = maxOf(1, CaminoDeVuelta.indiceMasCercano(lista, c.x, c.y))
                }
            }
        }
    }

    /** Recoge todo lo que se ve, siempre el más cercano. Devuelve true si el inventario se llenó. */
    private suspend fun recogerVisibles(e: Ejecucion): Boolean {
        var vacio = 0
        while (true) {
            if (e.vig.llenoSeguidas >= 2) return true
            val objetivo = candidato(e)
            if (objetivo == null) {
                delay(100L)
                vacio++
                if (vacio >= 4) return false
                continue
            }
            vacio = 0
            if (tratarMaterial(e, objetivo) == Resultado.LLENO) return true
        }
    }

    private suspend fun esperarFotogramas(e: Ejecucion, cuantos: Int, maxMs: Long) {
        val meta = e.vig.numero + cuantos
        val fin = SystemClock.elapsedRealtime() + maxMs
        while (e.vig.numero < meta && SystemClock.elapsedRealtime() < fin) delay(3L)
    }

    private suspend fun esperarRastreo(v: Vigilante, cuantos: Int, maxMs: Long) {
        val meta = v.numeroRastreo + cuantos
        val fin = SystemClock.elapsedRealtime() + maxMs
        while (v.numeroRastreo < meta && SystemClock.elapsedRealtime() < fin) delay(3L)
    }

    /**
     * Va hacia [objetivo] (el más cercano) y NO lo suelta hasta que deje de detectarse o se llene el
     * inventario. El punto final de la ruta pasa a ser el material, fijo en el mundo y refinado en cada
     * fotograma por el rastreador. «Lo bastante cerca» = caminando hacia él la pantalla deja de moverse
     * (choca con el material, que ocupa el paso) estando a su distancia de contacto y el botón de interactuar
     * se ve; entonces interactúa y repite mientras el material siga a la vista.
     */
    private suspend fun tratarMaterial(e: Ejecucion, objetivo: MaterialEnMundo): Resultado {
        val c = e.conductor
        val v = e.vig
        BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = "Material: ${objetivo.nombre}")
        if (!v.fijarObjetivo(objetivo)) return Resultado.NO_RECOGIDO
        val limiteMs = SystemClock.elapsedRealtime() + LIMITE_MATERIAL_MS
        val viaje = CopyOnWriteArrayList<PuntoDeRuta>()
        viaje.add(aqui(e))
        viaje.add(PuntoDeRuta(objetivo.x, objetivo.y, 0L))
        var mundoX = objetivo.x
        var mundoY = objetivo.y
        var visibleAlgunaVez = false
        var confirmaciones = 0
        var sinMensaje = 0
        var lado = 1
        val idsMensaje = SelectorDeFunciones
            .mensajesPara(objetivo.nombre, BotCore.store.materiales.value).map { it.id }.toSet()

        /** Un toque corto de lado (perpendicular al material) para encontrar otro ángulo de contacto. */
        suspend fun rodearUnPoco() {
            val dx = mundoX - c.x
            val dy = mundoY - c.y
            val dir = com.arosbot.ai.core.Direccion.masCercana(-dy * lado, dx * lado)
            lado = -lado
            val d = if (dir.esDiagonal) {
                if (Math.abs(dx) >= Math.abs(dy)) com.arosbot.ai.core.Direccion.W else com.arosbot.ai.core.Direccion.A
            } else dir
            BotCore.entrada.mantener(d, NUDGE_LATERAL_MS)
            delay(120L)
        }

        fun refrescar() {
            val r = v.rastro ?: return
            if (r.visible) {
                visibleAlgunaVez = true
                mundoX = r.mundoX
                mundoY = r.mundoY
                viaje[1] = PuntoDeRuta(mundoX, mundoY, 0L)
            }
        }

        fun distancia() = hypot(mundoX - c.x, mundoY - c.y)
        fun ausente() = v.fotogramasSinVer >= FOTOGRAMAS_AUSENTE

        /** Distancia centro a centro a la que el personaje ya topa con ESTE material (según su tamaño). */
        val contacto = maxOf(objetivo.ancho, objetivo.alto) / 2.0 + CONTACTO_BASE_PX

        /** ¿Este material es el más cercano al personaje? (Si hay otro al lado más cerca, se interactuaría con él.) */
        fun esElMasCercano(): Boolean {
            val otros = v.filtro.estables()
            val yo = otros.minByOrNull { hypot(it.x - c.x, it.y - c.y) } ?: return true
            return hypot(yo.x - mundoX, yo.y - mundoY) <= MISMO_MATERIAL_PX
        }

        try {
            var viajes = 0
            var tocado = false           // ya se pulsó «Interactuar» (una sola vez por recolección)
            var confirmadoEnEsteToque = false
            var ultimoToqueMs = 0L
            var enContacto = false
            esperarRastreo(v, 2, 400L)
            refrescar()
            if (distancia() < contacto * 0.6) enContacto = true
            while (SystemClock.elapsedRealtime() < limiteMs) {
                if (v.llenoSeguidas >= 2) return Resultado.LLENO
                refrescar()
                if (confirmaciones > 0 && ausente()) return registrarRecogido(e, objetivo)
                if (!tocado && viajes > 0 && ausente() && !visibleAlgunaVez) {
                    return Resultado.DESAPARECIDO   // falso positivo: el rastreador nunca lo vio
                }
                if (enContacto && distancia() > contacto * 1.6) {
                    enContacto = false
                    tocado = false
                }

                if (!enContacto) {
                    if (viajes >= MAX_VIAJES_POR_MATERIAL) {
                        e.negra.agregar(mundoX, mundoY)
                        return Resultado.NO_RECOGIDO
                    }
                    viajes++
                    tocado = false
                    viaje[0] = aqui(e)
                    progreso("Yendo hacia ${objetivo.nombre} (faltan ${distancia().toInt()} px)…")
                    val inicioMs = SystemClock.elapsedRealtime()
                    val medidosAlSalir = c.fotogramasMedidos
                    c.interrupcion = {
                        refrescar()
                        v.llenoSeguidas >= 2 ||
                            (distancia() < contacto &&
                                SystemClock.elapsedRealtime() - inicioMs > 500L &&
                                c.fotogramasMedidos - medidosAlSalir >= MEDIDOS_PARA_ARRANQUE &&
                                c.quietosSeguidos >= QUIETOS_PARA_CHOQUE)
                    }
                    val fin = try {
                        c.conducir(viaje, 1, limite())
                    } finally {
                        c.interrupcion = null
                    }
                    if (fin is ConductorDeRuta.Fin.Fallo) throw IllegalStateException(fin.texto)
                    esperarRastreo(v, 2, 300L)
                    refrescar()
                    if (distancia() > contacto * 1.15) {
                        // Se quedó parado lejos del material (otro objeto, p. ej. un árbol vecino, le cierra el
                        // paso): se prueba otro ángulo en vez de interactuar con lo que tenga delante.
                        BotCore.log.aviso("Recolección", "${objetivo.nombre}: parado a ${distancia().toInt()} px (contacto a ${contacto.toInt()}); pruebo otro ángulo")
                        rodearUnPoco()
                        continue
                    }
                    enContacto = true
                    viajes = 0
                }

                if (!tocado) {
                    // Contacto con ESTE material: tiene que ser el más cercano y el personaje debe mirarlo.
                    if (!esElMasCercano()) {
                        BotCore.log.aviso("Recolección", "${objetivo.nombre}: hay otro material más cerca del personaje; me recoloco")
                        rodearUnPoco()
                        enContacto = false
                        continue
                    }
                    BotCore.entrada.soltarTodo()
                    progreso("Apuntando a ${objetivo.nombre}…")
                    orientarHacia(mundoX - c.x, mundoY - c.y)
                    // Debe verse el botón de interactuar; si no aparece, se sigue intentando en esta zona.
                    val limiteBoton = SystemClock.elapsedRealtime() + ESPERA_BOTON_MS
                    while (!v.botonVisible && SystemClock.elapsedRealtime() < limiteBoton) delay(20L)
                    if (!v.botonVisible) {
                        progreso("Buscando el botón «Interactuar» junto a ${objetivo.nombre}…")
                        rodearUnPoco()
                        enContacto = false
                        continue
                    }
                    if (!pulsarInteractuar(v)) {
                        rodearUnPoco()
                        enContacto = false
                        continue
                    }
                    // UNA sola pulsación: el juego sigue recolectando hasta que el material se rompe o se llena
                    // el inventario. Repetir el toque cortaría la recolección.
                    tocado = true
                    confirmadoEnEsteToque = false
                    ultimoToqueMs = SystemClock.elapsedRealtime()
                    progreso("Recolectando ${objetivo.nombre}…")
                }

                // Vigilancia: mientras se vea el mensaje del sistema se está recolectando; no se toca nada.
                val ahora = SystemClock.elapsedRealtime()
                val esperaMs = BotCore.settings.esperaSinMensajeS * 1000L
                val ultimoMsg = v.ultimoMensaje(idsMensaje)
                if (ultimoMsg >= ultimoToqueMs) {
                    if (!confirmadoEnEsteToque) {
                        confirmadoEnEsteToque = true
                        confirmaciones++
                        sinMensaje = 0
                    }
                    if (ahora - ultimoMsg > esperaMs) {
                        // La recolección terminó pero el material sigue: se vuelve a pulsar una vez.
                        tocado = false
                    }
                } else if (ahora - ultimoToqueMs > esperaMs) {
                    // Pasó el toque y no salió el mensaje: no se está recolectando este material.
                    sinMensaje++
                    tocado = false
                    if (sinMensaje >= SIN_MENSAJE_PARA_REAJUSTAR) {
                        BotCore.log.aviso("Recolección", "${objetivo.nombre}: sin mensaje de «recolectando» tras $sinMensaje intentos; reajusto")
                        sinMensaje = 0
                        rodearUnPoco()
                        enContacto = false
                    }
                }
                delay(60L)
            }
            e.negra.agregar(mundoX, mundoY)
            BotCore.log.aviso("Recolección", "${objetivo.nombre}: no se resolvió en ${LIMITE_MATERIAL_MS / 1000} s; lo descarto")
            return if (v.llenoSeguidas >= 2) Resultado.LLENO else Resultado.NO_RECOGIDO
        } finally {
            v.soltarObjetivo()
        }
    }

    private fun registrarRecogido(e: Ejecucion, objetivo: MaterialEnMundo): Resultado {
        e.recogidosTotal++
        e.recogidosCiclo++
        BotCore.log.info("Recolección", "${objetivo.nombre} recogido (${e.recogidosTotal} en total)")
        return Resultado.RECOGIDO
    }

    /** Un toque corto del joystick hacia el material: el personaje queda mirándolo (apenas se mueve, choca). */
    private suspend fun orientarHacia(dx: Double, dy: Double) {
        if (hypot(dx, dy) < 4.0) return
        var dir = com.arosbot.ai.core.Direccion.masCercana(dx, dy)
        if (dir.esDiagonal && !BotCore.settings.diagonalesVerificadas) {
            dir = if (Math.abs(dx) >= Math.abs(dy)) {
                if (dx > 0) com.arosbot.ai.core.Direccion.D else com.arosbot.ai.core.Direccion.A
            } else {
                if (dy > 0) com.arosbot.ai.core.Direccion.S else com.arosbot.ai.core.Direccion.W
            }
        }
        BotCore.entrada.mantener(dir, TOQUE_DE_GIRO_MS)
        delay(120L)
    }

    /** Pulsa el botón de interactuar en su sitio (ya localizado y comprobado por el rastreador). */
    private suspend fun pulsarInteractuar(v: Vigilante): Boolean {
        val fin = SystemClock.elapsedRealtime() + 1500L
        while (SystemClock.elapsedRealtime() < fin) {
            val caja = v.cajaBoton
            if (caja != null && v.botonVisible) {
                val servicio = ArosAccessibilityService.instancia ?: return false
                val (ap, hp) = PantallaReal.tamano(BotCore.appContext)
                val fw = v.ancho.coerceAtLeast(1)
                val fh = v.alto.coerceAtLeast(1)
                val x = (caja.left + caja.right) / 2f * ap / fw
                val y = (caja.top + caja.bottom) / 2f * hp / fh
                return servicio.tocar(x, y)
            }
            delay(15L)
        }
        return false
    }

    // ---------- Vuelta y depósito ----------

    /** Vuelve por la misma ruta al revés. null si llegó al cofre; si no, el motivo. */
    private suspend fun vuelta(e: Ejecucion): String? {
        val c = e.conductor
        c.interrupcion = null
        val primero = e.puntos.first()
        var intentos = 0
        var lista = CaminoDeVuelta.desde(e.puntos, CaminoDeVuelta.indiceMasCercano(e.puntos, c.x, c.y))
        var desde = 0
        e.rodeos = 0
        while (intentos < 4) {
            progreso("Volviendo al cofre por la misma ruta…")
            val fin = c.conducir(lista, desde, limite())
            when (fin) {
                is ConductorDeRuta.Fin.Fallo -> return fin.texto
                is ConductorDeRuta.Fin.Interrumpido -> return "interrumpido"
                is ConductorDeRuta.Fin.Bloqueado -> {
                    val destino = lista[fin.indice]
                    val paso = Rodeo.puntoDePaso(c.x, c.y, destino.x, destino.y, e.rodeos++)
                        ?: return "no pude rodear un obstáculo en la vuelta"
                    lista = listOf(aqui(e), PuntoDeRuta(paso.x.toDouble(), paso.y.toDouble(), 0L)) +
                        lista.drop(fin.indice)
                    desde = 1
                }
                is ConductorDeRuta.Fin.Llegado -> {
                    if (hypot(primero.x - c.x, primero.y - c.y) <= TOLERANCIA_INICIO_PX) return null
                    intentos++
                    lista = listOf(aqui(e), primero)
                    desde = 1
                }
            }
        }
        return "no logré quedar junto al cofre (${hypot(primero.x - c.x, primero.y - c.y).toInt()} px de error)"
    }

    /** Repite el macro del cofre y comprueba que el aviso de inventario lleno desaparece. null si fue bien. */
    private suspend fun depositar(e: Ejecucion): String? {
        val macro = MacroDeClics.decodificar(BotCore.settings.macroCofre)
        MacroDeClics.problema(macro)?.let { return it }
        val estabaLleno = e.vig.llenoSeguidas >= 1
        progreso("Cofre: repitiendo los toques grabados…")
        val motivo = ReproductorDeMacro.reproducir(macro!!) { i, n -> progreso("Cofre: paso $i de $n del macro") }
        if (motivo != null) return motivo
        delay(1500L)
        esperarFotogramas(e, 9, 2500L)
        if (estabaLleno && e.vig.llenoSeguidas >= 2) return "el inventario sigue lleno tras el macro"
        BotCore.log.info("Recolección", "Depósito hecho; reinicio la ruta")
        return null
    }

    private suspend fun relocalizarInicio(e: Ejecucion) {
        val inicio = e.puntos.first()
        val ref = inicio.referencia
        if (ref != null) {
            val h = reconocerAhora(ref)
            if (h != null) {
                val (nx, ny) = Relocalizacion.posicion(inicio, h.dx, h.dy)
                e.conductor.x = nx
                e.conductor.y = ny
                return
            }
        }
        e.conductor.x = inicio.x
        e.conductor.y = inicio.y
    }
}
