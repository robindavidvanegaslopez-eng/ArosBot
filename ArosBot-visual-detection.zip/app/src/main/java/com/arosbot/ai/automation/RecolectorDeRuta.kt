package com.arosbot.ai.automation

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.capture.PantallaReal
import com.arosbot.ai.capture.TrayectoSobreJuego
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.Calibracion
import com.arosbot.ai.core.CaminoDeVuelta
import com.arosbot.ai.core.Colision
import com.arosbot.ai.core.SelectorDeMateriales
import com.arosbot.ai.core.Detection
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.ElectorDeMaterial
import com.arosbot.ai.core.FuncionVisual
import com.arosbot.ai.core.ListaNegraDeMateriales
import com.arosbot.ai.core.MacroDeClics
import com.arosbot.ai.core.Material
import com.arosbot.ai.core.OptimizadorDeTrayecto
import com.arosbot.ai.core.Persistencia
import com.arosbot.ai.core.PuntoDeAcercamiento
import com.arosbot.ai.core.PuntoDeRuta
import com.arosbot.ai.core.ReferenciaVisual
import com.arosbot.ai.core.Relocalizacion
import com.arosbot.ai.core.Rodeo
import java.util.concurrent.CopyOnWriteArrayList
import com.arosbot.ai.core.SelectorDeFunciones
import com.arosbot.ai.input.ArosAccessibilityService
import com.arosbot.ai.vision.Deteccion
import com.arosbot.ai.vision.PlantillaCache
import com.arosbot.ai.vision.SeguidorLocal
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import com.arosbot.ai.vision.VisionEngine
import com.arosbot.ai.vision.ReferenciasVisuales
import kotlin.math.hypot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield

/**
 * Recolección automática por una única ruta enseñada del cofre a la zona de materiales.
 *
 *  1. Sigue la ruta hacia la zona. Un vigilante analiza la pantalla en segundo plano (detección rápida).
 *  2. Si ve un material, para, se acerca hasta dejarlo muy cerca del centro (sin tocarlo), pulsa
 *     «Interactuar» y repite mientras ese mismo material siga viéndose; cuando desaparece pasa al
 *     siguiente. Lo que no se alcanza o no se recoge se descarta.
 *  3. Cuando sale el aviso de inventario lleno (o acaba la ruta) vuelve por la MISMA ruta, al revés,
 *     desde donde esté (se ignora el resto del recorrido), repite el macro del cofre y reinicia la ruta.
 *
 * No se ha probado todavía en el juego.
 */
object RecolectorDeRuta {

    private const val CUENTA_ATRAS_S = 6
    private const val MAX_VIAJES_POR_MATERIAL = 8
    private const val LIMITE_MATERIAL_MS = 90_000L
    private const val MARGEN_COLISION_PX = 6
    private const val RADIO_RASTREO_PX = 90
    private const val TOQUE_DE_GIRO_MS = 110L
    private const val DISTANCIA_CERCA_SIN_CUADRO_PX = 28.0
    private const val RADIO_PERSONAJE_PX = 40
    private const val UMBRAL_RASTREO = 0.55
    private const val UMBRAL_PERSONAJE = 0.6
    private const val FOTOGRAMAS_AUSENTE = 6
    private const val INTERACCIONES_SI_NO_SE_VIO = 3
    private const val ESPERA_TRAS_INTERACTUAR_MS = 800L
    private const val LIMITE_CONDUCCION_MS = 120_000L
    private const val CICLOS_VACIOS_MAXIMOS = 3
    private const val FALLOS_DEPOSITO_MAXIMOS = 2
    private const val TOLERANCIA_INICIO_PX = 30.0
    private const val RADIO_MISMO_MATERIAL_PX = 60.0

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trabajo: Job? = null

    private val _estado = MutableStateFlow(EstadoPrueba())
    val estado: StateFlow<EstadoPrueba> = _estado.asStateFlow()

    val ejecutando: Boolean get() = trabajo?.isActive == true

    @Synchronized
    fun iniciar() {
        if (ejecutando) return
        val otra = SeguidorDeRuta.estado.value.ejecutando || NavegadorDeSpots.ejecutando ||
            Recolector.ejecutando || PruebasAutomatizacion.estado.value.ejecutando
        if (otra) {
            _estado.value = EstadoPrueba(false, "Hay otro proceso en marcha. Pulsa «Cancelar todo» y vuelve a intentarlo.")
            return
        }
        if (BotCore.stateMachine.state.value == BotState.PARADA_EMERGENCIA) {
            _estado.value = EstadoPrueba(
                false, "Hay una parada de emergencia activa. Pulsa «Restablecer» en el Panel principal."
            )
            return
        }
        _estado.value = EstadoPrueba(true, "Preparando…")
        trabajo = alcance.launch {
            val texto = try {
                sesion()
            } catch (e: CancellationException) {
                "Recolección por ruta: cancelada."
            } catch (e: Exception) {
                BotCore.log.error("Recolección", "Error inesperado: ${e.message}")
                "Recolección por ruta: error inesperado (${e.message})."
            } finally {
                BotCore.entrada.soltarTodo()
                TrayectoSobreJuego.limpiar()
                BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = "Ninguno")
            }
            _estado.value = EstadoPrueba(false, texto)
            val resumen = texto.lines().first()
            BotCore.log.info("Recolección", resumen)
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(BotCore.appContext, resumen, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun cancelar() {
        trabajo?.cancel()
        BotCore.entrada.soltarTodo()
    }

    fun reiniciar() {
        trabajo?.cancel()
        trabajo = null
        BotCore.entrada.soltarTodo()
        _estado.value = EstadoPrueba(false, "Cancelado por el usuario.")
    }

    private fun progreso(texto: String) {
        _estado.value = EstadoPrueba(true, texto)
    }

    /** Requisitos; null si todo está listo. */
    fun problema(): String? {
        val mats = BotCore.store.materiales.value
        if (!FrameBus.estado.value.activa) return "Inicia la captura de pantalla en el Panel principal."
        if (!ArosAccessibilityService.conectado.value) return "Activa el servicio de accesibilidad de ArosBot AI."
        if (BotCore.settings.joystick == null) return "Primero configura el joystick en Automatización."
        val sinCalibrar = Direccion.CARDINALES.filter {
            (BotCore.store.calibraciones.value[it]?.muestras ?: 0) == 0
        }
        if (sinCalibrar.isNotEmpty()) return "Falta calibrar el movimiento (${sinCalibrar.joinToString { it.tecla }})."
        if (BotCore.store.rutas.value.none { it.id == BotCore.settings.rutaRecoleccionId }) {
            return "Elige la ruta de recolección (la que va del cofre a la zona de materiales)."
        }
        if (SelectorDeMateriales.personaje(mats) == null) {
            return "Falta la imagen del personaje en Materiales (categoría «Personaje»): es obligatoria para saber cuándo el material lo toca."
        }
        if (SelectorDeFunciones.con(FuncionVisual.INTERACTUAR, mats).isEmpty()) {
            return "Falta la imagen del botón «Interactuar» en Materiales."
        }
        if (SelectorDeFunciones.con(FuncionVisual.INVENTARIO_LLENO, mats).isEmpty()) {
            return "Falta la imagen del aviso «Inventario lleno» en Materiales."
        }
        MacroDeClics.problema(MacroDeClics.decodificar(BotCore.settings.macroCofre))?.let {
            return "Falta el macro del cofre ($it)"
        }
        if (mats.none { SelectorDeFunciones.esDeRecoleccion(it) }) return "No hay materiales de recolección importados."
        return null
    }

    // ---------- Vigilante: detección y rastreo rápidos en segundo plano ----------

    /** Estado del material seguido, anclado al mundo (marco de la ruta). */
    private class Rastro(
        val mundoX: Double,
        val mundoY: Double,
        val ancho: Int,
        val alto: Int,
        val score: Double,
        val visible: Boolean,
        val numero: Long
    )

    /**
     * Dos bucles en paralelo que exprimen la pantalla:
     *  - descubrir: detección completa rápida (materiales + aviso de inventario lleno).
     *  - rastrear: en CADA fotograma sigue con una plantilla local adaptable al personaje y al material
     *    elegido, buscando solo en su entorno (milisegundos), y lo guarda en coordenadas del MUNDO usando la
     *    posición del bot en el instante de ese fotograma, así el retraso de la detección no desvía el rumbo.
     */
    private class Vigilante(
        private val buscados: List<Material>,
        private val indicadores: List<Material>,
        private val personaje: Material?,
        private val posicion: () -> Pair<Double, Double>
    ) {
        @Volatile var detecciones: List<Detection> = emptyList()
        @Volatile var numero = 0L
        @Volatile var ancho = 0
        @Volatile var alto = 0
        @Volatile var fps = 0f
        @Volatile var fpsRastreo = 0f
        /** Posición del bot (marco de la ruta) cuando se tomó el fotograma de [detecciones]. */
        @Volatile var posX = 0.0
        @Volatile var posY = 0.0
        @Volatile var llenoSeguidas = 0
        @Volatile var ciclosConMaterial = 0
        /** Último cuadro conocido del personaje: no se borra si deja de verse (la cámara lo mantiene fijo). */
        @Volatile var cajaPersonaje: com.arosbot.ai.core.Box? = null
        @Volatile var rastro: Rastro? = null
        /** Fotogramas seguidos en los que el material seguido no se ve. */
        @Volatile var fotogramasSinVer = 0
        /** Fotogramas rastreados (avanza con cada fotograma nuevo). */
        @Volatile var numeroRastreo = 0L

        private class Pedido(val seguidor: SeguidorLocal, val mundoX: Double, val mundoY: Double)

        @Volatile private var pedido: Pedido? = null
        @Volatile private var soltarPedido = false

        /**
         * Empieza a seguir [d] fijándolo en el mundo en (mundoX, mundoY). La plantilla inicial es la IMAGEN DE
         * REFERENCIA del material (la variante que mejor casa ahora donde debería estar), no un recorte del
         * fotograma: el recorte saldría de un instante posterior al de la detección y estaría desplazado.
         */
        fun fijarObjetivo(d: Detection, mundoX: Double, mundoY: Double): Boolean {
            val f = FrameBus.instantanea() ?: return false
            try {
                val pos = posicion()
                val cj = cajaPersonaje
                val cxP = if (cj != null) (cj.left + cj.right) / 2.0 else f.width * 0.5
                val cyP = if (cj != null) (cj.top + cj.bottom) / 2.0 else f.height * 0.47
                val ex = cxP + (mundoX - pos.first)
                val ey = cyP + (mundoY - pos.second)
                VisionEngine.preparar(f).use { esc ->
                    val material = BotCore.store.materiales.value.firstOrNull { it.id == d.materialId }
                    val carga = material?.let { PlantillaCache.obtener(it, BotCore.store.directorioMateriales) }
                    val tw = d.box.width.coerceAtLeast(6)
                    val th = d.box.height.coerceAtLeast(6)
                    var mejorMat: Mat? = null
                    var mejorScore = 0.0
                    if (carga != null) {
                        for (variante in carga.variantes) {
                            val m = Mat()
                            Imgproc.resize(variante, m, Size(tw.toDouble(), th.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
                            val r = VisionEngine.buscarLocal(esc, m, ex, ey, RADIO_RASTREO_PX)
                            if (r != null && r.score > mejorScore) {
                                mejorMat?.release()
                                mejorMat = m
                                mejorScore = r.score
                            } else {
                                m.release()
                            }
                        }
                    }
                    if (mejorMat == null || mejorScore < 0.4) {
                        // Sin referencia utilizable: se recorta lo que hay donde debería estar.
                        mejorMat?.release()
                        val caja = com.arosbot.ai.core.Box(
                            (ex - tw / 2.0).toInt(), (ey - th / 2.0).toInt(),
                            (ex + tw / 2.0).toInt(), (ey + th / 2.0).toInt()
                        )
                        mejorMat = VisionEngine.recortar(esc, caja) ?: return false
                    }
                    rastro = null
                    fotogramasSinVer = 0
                    pedido = Pedido(SeguidorLocal(mejorMat!!), mundoX, mundoY)
                }
            } finally {
                f.recycle()
            }
            return true
        }

        fun soltarObjetivo() {
            soltarPedido = true
        }

        fun arrancar(): List<Job> = listOf(descubrir(), rastrear())

        private fun descubrir(): Job = alcance.launch {
            var ultimo = -1L
            var ciclos = 0
            val marcas = ArrayDeque<Long>()
            while (isActive) {
                val n = FrameBus.estado.value.fotogramas
                if (n == ultimo) {
                    delay(2L)
                    continue
                }
                val pos = posicion()
                val f = FrameBus.instantanea()
                if (f == null) {
                    delay(10L)
                    continue
                }
                try {
                    ultimo = n
                    val r = Deteccion.rapidaEnAreasActivas(
                        f, BotCore.store.areas.value, buscados, BotCore.store.directorioMateriales
                    )
                    ancho = f.width
                    alto = f.height
                    posX = pos.first
                    posY = pos.second
                    detecciones = r.detecciones
                    ciclosConMaterial = if (r.detecciones.isNotEmpty()) ciclosConMaterial + 1 else 0
                    ciclos++
                    if (ciclos % 3 == 0 && indicadores.isNotEmpty()) {
                        val hay = Deteccion.rapidaEnPantallaCompleta(
                            f, indicadores, BotCore.store.directorioMateriales
                        ).detecciones.isNotEmpty()
                        llenoSeguidas = if (hay) llenoSeguidas + 1 else 0
                    }
                    val t = SystemClock.elapsedRealtime()
                    marcas.addLast(t)
                    while (marcas.isNotEmpty() && t - marcas.first() > 1000L) marcas.removeFirst()
                    if (marcas.size >= 2) fps = (marcas.size - 1) * 1000f / (t - marcas.first()).coerceAtLeast(1L)
                    numero = n
                } catch (e: Exception) {
                    delay(100L)
                } finally {
                    f.recycle()
                }
                yield()
            }
        }

        private fun rastrear(): Job = alcance.launch {
            var ultimo = -1L
            var seguidorPj: SeguidorLocal? = null
            var seguidorObj: SeguidorLocal? = null
            var mundoX = 0.0
            var mundoY = 0.0
            var cuenta = 0
            val marcas = ArrayDeque<Long>()
            try {
                while (isActive) {
                    val n = FrameBus.estado.value.fotogramas
                    if (n == ultimo) {
                        delay(1L)
                        continue
                    }
                    val pos = posicion()
                    val f = FrameBus.instantanea()
                    if (f == null) {
                        delay(8L)
                        continue
                    }
                    try {
                        ultimo = n
                        cuenta++
                        // Cambios pedidos desde fuera.
                        if (soltarPedido) {
                            soltarPedido = false
                            pedido = null
                            seguidorObj?.liberar()
                            seguidorObj = null
                            rastro = null
                        }
                        pedido?.let {
                            seguidorObj?.liberar()
                            seguidorObj = it.seguidor
                            mundoX = it.mundoX
                            mundoY = it.mundoY
                            pedido = null
                        }
                        VisionEngine.preparar(f).use { esc ->
                            // Personaje: búsqueda completa hasta encontrarlo; después, solo a su alrededor.
                            val caja = cajaPersonaje
                            if (personaje != null && (caja == null || seguidorPj == null)) {
                                if (cuenta % 6 == 1) {
                                    val d = Deteccion.rapidaEnPantallaCompleta(
                                        f, listOf(personaje), BotCore.store.directorioMateriales
                                    ).detecciones.maxByOrNull { it.score }
                                    if (d != null) {
                                        cajaPersonaje = d.box
                                        VisionEngine.recortar(esc, d.box)?.let { seguidorPj = SeguidorLocal(it) }
                                    }
                                }
                            } else if (caja != null && seguidorPj != null) {
                                val h = seguidorPj!!.buscar(
                                    esc, (caja.left + caja.right) / 2.0, (caja.top + caja.bottom) / 2.0, RADIO_PERSONAJE_PX
                                )
                                if (h != null && h.score >= UMBRAL_PERSONAJE) {
                                    val w = seguidorPj!!.ancho
                                    val hh = seguidorPj!!.alto
                                    cajaPersonaje = com.arosbot.ai.core.Box(
                                        (h.centroX - w / 2.0).toInt(), (h.centroY - hh / 2.0).toInt(),
                                        (h.centroX + w / 2.0).toInt(), (h.centroY + hh / 2.0).toInt()
                                    )
                                }
                            }
                            // Material elegido: se sigue por su punto fijo en el mundo.
                            val seg = seguidorObj
                            val cj = cajaPersonaje
                            val cxP = if (cj != null) (cj.left + cj.right) / 2.0 else f.width * 0.5
                            val cyP = if (cj != null) (cj.top + cj.bottom) / 2.0 else f.height * 0.47
                            if (seg != null) {
                                val esperadoX = cxP + (mundoX - pos.first)
                                val esperadoY = cyP + (mundoY - pos.second)
                                val h = seg.buscar(esc, esperadoX, esperadoY, RADIO_RASTREO_PX)
                                val visible = h != null && h.score >= UMBRAL_RASTREO
                                if (visible) {
                                    mundoX = pos.first + (h!!.centroX - cxP)
                                    mundoY = pos.second + (h.centroY - cyP)
                                    fotogramasSinVer = 0
                                } else {
                                    fotogramasSinVer++
                                }
                                rastro = Rastro(
                                    mundoX, mundoY, seg.ancho, seg.alto, h?.score ?: 0.0, visible, n
                                )
                            }
                        }
                        numeroRastreo++
                        val t = SystemClock.elapsedRealtime()
                        marcas.addLast(t)
                        while (marcas.isNotEmpty() && t - marcas.first() > 1000L) marcas.removeFirst()
                        if (marcas.size >= 2) fpsRastreo = (marcas.size - 1) * 1000f / (t - marcas.first()).coerceAtLeast(1L)
                    } catch (e: Exception) {
                        delay(50L)
                    } finally {
                        f.recycle()
                    }
                }
            } finally {
                seguidorPj?.liberar()
                seguidorObj?.liberar()
            }
        }
    }

    private enum class Resultado { RECOGIDO, NO_RECOGIDO, BLOQUEADO, DESAPARECIDO, LLENO }

    private class Ejecucion(
        val ruta: com.arosbot.ai.core.Ruta,
        val conductor: ConductorDeRuta,
        val puntos: List<PuntoDeRuta>,
        val vig: Vigilante,
        val buscados: List<Material>
    ) {
        val negra = ListaNegraDeMateriales()
        var recogidosTotal = 0
        var recogidosCiclo = 0
        var rodeos = 0
    }

    private fun reconocerAhora(referencia: ReferenciaVisual): ReferenciasVisuales.Hallazgo? {
        val f = FrameBus.instantanea() ?: return null
        return try {
            ReferenciasVisuales.reconocer(f, referencia, BotCore.store.directorioReferencias)
                ?.takeIf { Relocalizacion.fiable(it.confianza) }
        } finally {
            f.recycle()
        }
    }

    private fun limite() = SystemClock.elapsedRealtime() + LIMITE_CONDUCCION_MS

    private fun aqui(e: Ejecucion) = PuntoDeRuta(e.conductor.x, e.conductor.y, 0L)

    // ---------- Sesión ----------

    private suspend fun sesion(): String {
        problema()?.let { return "Recolección por ruta: $it" }
        val ruta = BotCore.store.rutas.value.first { it.id == BotCore.settings.rutaRecoleccionId }
        val original = ruta.puntosEnSentido(false)
        if (original.size < 2) return "Recolección por ruta: la ruta no tiene recorrido."
        val puntos = OptimizadorDeTrayecto.simplificar(original).puntos
        val mats = BotCore.store.materiales.value
        val buscados = mats.filter { SelectorDeFunciones.esDeRecoleccion(it) }
        val indicadores = SelectorDeFunciones.con(FuncionVisual.INVENTARIO_LLENO, mats)
        val calibraciones = HashMap<Direccion, Calibracion>(BotCore.store.calibraciones.value)
        val diagonales = BotCore.settings.diagonalesVerificadas

        for (s in CUENTA_ATRAS_S downTo 1) {
            progreso("Recolección por ruta: colócate junto al cofre, en el inicio de la ruta… $s")
            delay(1000L)
        }
        val conductor = ConductorDeRuta(
            calibraciones, diagonales, original.filter { it.referencia != null },
            { reconocerAhora(it) },
            { BotCore.log.info("Recolección", it) },
            { progreso(it) }
        )
        val vig = Vigilante(buscados, indicadores, SelectorDeMateriales.personaje(mats)) {
            Pair(conductor.x, conductor.y)
        }
        val e = Ejecucion(ruta, conductor, puntos, vig, buscados)

        // Posición inicial: se fija a la captura del punto de partida (el cofre).
        val inicio = puntos.first()
        if (inicio.referencia != null) {
            val h = reconocerAhora(inicio.referencia!!)
                ?: return "Recolección por ruta: no reconozco el inicio de la ruta. Colócate junto al cofre, " +
                    "donde empezaste a enseñarla."
            val (nx, ny) = Relocalizacion.posicion(inicio, h.dx, h.dy)
            conductor.x = nx
            conductor.y = ny
        } else {
            conductor.x = inicio.x
            conductor.y = inicio.y
        }

        FrameBus.pedirRapido()
        val trabajoVig = vig.arrancar()
        try {
            var ciclo = 0
            var vacios = 0
            var fallosDeposito = 0
            while (true) {
                ciclo++
                e.recogidosCiclo = 0
                e.negra.vaciar()
                BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = "Ida (ciclo $ciclo)")
                val ida = ida(e)
                if (ida != null) return fin(e, ciclo, ida)
                BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = "Vuelta al cofre")
                val vuelta = vuelta(e)
                if (vuelta != null) return fin(e, ciclo, vuelta)
                BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = "Depositar")
                val dep = depositar(e)
                if (dep != null) {
                    fallosDeposito++
                    BotCore.log.aviso("Recolección", "Depósito fallido: $dep")
                    if (fallosDeposito >= FALLOS_DEPOSITO_MAXIMOS) {
                        return fin(e, ciclo, "el depósito falló $fallosDeposito veces ($dep)")
                    }
                } else {
                    fallosDeposito = 0
                }
                vacios = if (e.recogidosCiclo == 0) vacios + 1 else 0
                if (vacios >= CICLOS_VACIOS_MAXIMOS) {
                    return fin(e, ciclo, "$CICLOS_VACIOS_MAXIMOS vueltas seguidas sin recoger nada")
                }
                relocalizarInicio(e)
            }
        } finally {
            conductor.interrupcion = null
            trabajoVig.forEach { it.cancel() }
            FrameBus.soltarRapido()
        }
    }

    private fun fin(e: Ejecucion, ciclos: Int, motivo: String): String =
        "Recolección por ruta: detenida ($motivo).\n" +
            "Vueltas: $ciclos · materiales recogidos: ${e.recogidosTotal} · descartados: ${e.negra.tamano}\n" +
            "Detección: ${"%.0f".format(e.vig.fps)} ciclos/s · rastreo: ${"%.0f".format(e.vig.fpsRastreo)} fotogramas/s · conducción: ${"%.0f".format(e.conductor.fps)} fps medidos"

    // ---------- Ida ----------

    private fun candidato(e: Ejecucion): Detection? {
        val v = e.vig
        if (v.ciclosConMaterial < 2) return null
        val (cx, cy) = centroPersonaje(v)
        return ElectorDeMaterial.elegir(
            v.detecciones, { d -> desplazamiento(d, cx, cy) }, v.posX, v.posY, e.negra
        )
    }

    private fun centroPersonaje(v: Vigilante): Pair<Double, Double> {
        val b = v.cajaPersonaje
        return if (b != null) Pair((b.left + b.right) / 2.0, (b.top + b.bottom) / 2.0)
        else Pair(v.ancho * 0.5, v.alto * 0.47)
    }

    private fun desplazamiento(d: Detection, cx: Double, cy: Double): Pair<Double, Double> =
        Pair((d.box.left + d.box.right) / 2.0 - cx, (d.box.top + d.box.bottom) / 2.0 - cy)

    /** null si acabó la ida con normalidad (lleno o fin de ruta); si no, el motivo del fallo. */
    private suspend fun ida(e: Ejecucion): String? {
        val c = e.conductor
        var lista = e.puntos
        var desde = 1
        while (true) {
            c.interrupcion = { e.vig.llenoSeguidas >= 2 || candidato(e) != null }
            progreso("Siguiendo la ruta hacia la zona de materiales…")
            val fin = c.conducir(lista, desde, limite())
            c.interrupcion = null
            when (fin) {
                is ConductorDeRuta.Fin.Llegado -> return null
                is ConductorDeRuta.Fin.Fallo -> return fin.texto
                is ConductorDeRuta.Fin.Bloqueado -> {
                    val paso = Rodeo.puntoDePaso(c.x, c.y, lista[fin.indice].x, lista[fin.indice].y, e.rodeos++)
                        ?: return "no pude rodear un obstáculo en la ida"
                    lista = listOf(aqui(e), PuntoDeRuta(paso.x.toDouble(), paso.y.toDouble(), 0L)) +
                        lista.drop(fin.indice)
                    desde = 1
                    continue
                }
                is ConductorDeRuta.Fin.Interrumpido -> {
                    e.rodeos = 0
                    if (e.vig.llenoSeguidas >= 2) return null
                    val lleno = recogerVisibles(e)
                    if (lleno) return null
                    lista = e.puntos
                    desde = maxOf(1, CaminoDeVuelta.indiceMasCercano(lista, c.x, c.y))
                }
            }
        }
    }

    /** Recoge todo lo que se ve. Devuelve true si el inventario se llenó. */
    private suspend fun recogerVisibles(e: Ejecucion): Boolean {
        var vacio = 0
        while (true) {
            if (e.vig.llenoSeguidas >= 2) return true
            val objetivo = candidatoInmediato(e)
            if (objetivo == null) {
                // Un instante de gracia por si el material parpadea.
                delay(150L)
                vacio++
                if (vacio >= 3) return false
                continue
            }
            vacio = 0
            when (tratarMaterial(e, objetivo)) {
                Resultado.LLENO -> return true
                else -> Unit
            }
        }
    }

    private fun candidatoInmediato(e: Ejecucion): Detection? {
        val v = e.vig
        val (cx, cy) = centroPersonaje(v)
        return ElectorDeMaterial.elegir(
            v.detecciones, { d -> desplazamiento(d, cx, cy) }, v.posX, v.posY, e.negra
        )
    }

    private suspend fun esperarFotogramas(e: Ejecucion, cuantos: Int, maxMs: Long) {
        val meta = e.vig.numero + cuantos
        val fin = SystemClock.elapsedRealtime() + maxMs
        while (e.vig.numero < meta && SystemClock.elapsedRealtime() < fin) delay(5L)
    }

    /**
     * La ruta se desvía hacia [objetivo]: su punto final pasa a ser el material, FIJO en el mundo y
     * actualizado en cada fotograma por el rastreador local (que sigue aunque la textura cambie al
     * acercarse). Se conduce hasta que su cuadro toca el del personaje; entonces interactúa y repite
     * mientras el material siga a la vista. Si el rastreador lo pierde cerca, no se pierde el rumbo: el
     * punto del mundo sigue ahí. Termina cuando desaparece (recogido) o se llena el inventario; si no
     * se resuelve en [LIMITE_MATERIAL_MS] se descarta.
     */
    private suspend fun tratarMaterial(e: Ejecucion, objetivo: Detection): Resultado {
        val c = e.conductor
        val v = e.vig
        val (cx0, cy0) = centroPersonaje(v)
        val (dx0, dy0) = desplazamiento(objetivo, cx0, cy0)
        // Posición de la instantánea de la detección (no la actual): así el retraso no desvía el punto.
        val mundoX0 = v.posX + dx0
        val mundoY0 = v.posY + dy0
        BotCore.telemetry.value = BotCore.telemetry.value.copy(objetivoActual = "Material: ${objetivo.nombre}")
        if (!v.fijarObjetivo(objetivo, mundoX0, mundoY0)) return Resultado.NO_RECOGIDO
        val limiteMs = SystemClock.elapsedRealtime() + LIMITE_MATERIAL_MS
        val viaje = CopyOnWriteArrayList<PuntoDeRuta>()
        viaje.add(aqui(e))
        viaje.add(PuntoDeRuta(mundoX0, mundoY0, 0L))
        var mundoX = mundoX0
        var mundoY = mundoY0
        var visibleAlgunaVez = false

        /** Actualiza el punto final con lo último que vio el rastreador. */
        fun refrescar() {
            val r = v.rastro ?: return
            if (r.visible) {
                visibleAlgunaVez = true
                mundoX = r.mundoX
                mundoY = r.mundoY
                viaje[1] = PuntoDeRuta(mundoX, mundoY, 0L)
            }
        }

        /** ¿El cuadro del material, proyectado donde debe estar ahora, toca al personaje? */
        fun toca(): Boolean {
            val pj = v.cajaPersonaje ?: return false
            val r = v.rastro
            val w = r?.ancho ?: objetivo.box.width
            val h = r?.alto ?: objetivo.box.height
            val (cx, cy) = centroPersonaje(v)
            val px = cx + (mundoX - c.x)
            val py = cy + (mundoY - c.y)
            val caja = com.arosbot.ai.core.Box(
                (px - w / 2.0).toInt(), (py - h / 2.0).toInt(), (px + w / 2.0).toInt(), (py + h / 2.0).toInt()
            )
            return Colision.tocan(caja, pj, MARGEN_COLISION_PX)
        }

        fun ausente() = v.fotogramasSinVer >= FOTOGRAMAS_AUSENTE

        try {
            var viajes = 0
            var interacciones = 0
            var orientado = false
            // Espera a que el rastreador dé su primera lectura.
            esperarRastreo(v, 2, 400L)
            while (SystemClock.elapsedRealtime() < limiteMs) {
                if (v.llenoSeguidas >= 2) return Resultado.LLENO
                refrescar()
                if (interacciones > 0 && ausente()) {
                    return if (visibleAlgunaVez) registrarRecogido(e, objetivo) else Resultado.DESAPARECIDO
                }
                if (interacciones == 0 && ausente() && !visibleAlgunaVez && viajes > 0) {
                    // Nunca llegó a verse con el rastreador: era un falso positivo.
                    return Resultado.DESAPARECIDO
                }
                if (!toca()) {
                    if (viajes >= MAX_VIAJES_POR_MATERIAL) {
                        e.negra.agregar(mundoX, mundoY)
                        return Resultado.NO_RECOGIDO
                    }
                    viajes++
                    orientado = false
                    viaje[0] = aqui(e)
                    progreso("Yendo hacia ${objetivo.nombre} (faltan ${hypot(mundoX - c.x, mundoY - c.y).toInt()} px)…")
                    c.interrupcion = {
                        refrescar()
                        v.llenoSeguidas >= 2 || toca()
                    }
                    val fin = try {
                        c.conducir(viaje, 1, limite())
                    } finally {
                        c.interrupcion = null
                    }
                    when (fin) {
                        is ConductorDeRuta.Fin.Bloqueado -> {
                            e.negra.agregar(mundoX, mundoY)
                            return Resultado.BLOQUEADO
                        }
                        is ConductorDeRuta.Fin.Fallo -> throw IllegalStateException(fin.texto)
                        else -> Unit
                    }
                    esperarRastreo(v, 2, 300L)
                    refrescar()
                    // Llegó al punto del mundo pero el cuadro no lo da por tocando (el sprite pudo no
                    // verse): se da por cerca si el punto está prácticamente encima.
                    if (!toca() && hypot(mundoX - c.x, mundoY - c.y) > DISTANCIA_CERCA_SIN_CUADRO_PX) continue
                }

                // Lo bastante cerca: primero el personaje debe mirar hacia el material, y solo entonces interactúa.
                BotCore.entrada.soltarTodo()
                if (!orientado) {
                    progreso("Girando hacia ${objetivo.nombre}…")
                    orientarHacia(mundoX - c.x, mundoY - c.y)
                    orientado = true
                    esperarRastreo(v, 3, 400L)
                    refrescar()
                    if (!toca() && hypot(mundoX - c.x, mundoY - c.y) > DISTANCIA_CERCA_SIN_CUADRO_PX) continue
                }
                interacciones++
                progreso("Interactuando con ${objetivo.nombre} ($interacciones)…")
                if (!pulsarInteractuar()) {
                    e.negra.agregar(mundoX, mundoY)
                    return Resultado.NO_RECOGIDO
                }
                delay(ESPERA_TRAS_INTERACTUAR_MS)
                esperarRastreo(v, FOTOGRAMAS_AUSENTE + 2, 900L)
                if (!visibleAlgunaVez && interacciones >= INTERACCIONES_SI_NO_SE_VIO) {
                    // El rastreador nunca lo vio con certeza: no se puede saber si desapareció.
                    BotCore.log.aviso("Recolección", "${objetivo.nombre}: no se confirma que desaparezca; sigo adelante")
                    return registrarRecogido(e, objetivo)
                }
            }
            e.negra.agregar(mundoX, mundoY)
            BotCore.log.aviso("Recolección", "${objetivo.nombre}: no se resolvió en ${LIMITE_MATERIAL_MS / 1000} s; lo descarto")
            return if (v.llenoSeguidas >= 2) Resultado.LLENO else Resultado.NO_RECOGIDO
        } finally {
            v.soltarObjetivo()
        }
    }

    /**
     * El personaje mira hacia donde se movió por última vez, así que para quedar apuntando al material se
     * da un toque corto del joystick en su dirección (el material lo frena, apenas avanza). No se puede
     * comprobar visualmente hacia dónde mira: se deduce de esa última dirección de movimiento.
     */
    private suspend fun orientarHacia(dx: Double, dy: Double) {
        if (hypot(dx, dy) < 4.0) return
        var dir = com.arosbot.ai.core.Direccion.masCercana(dx, dy)
        if (dir.esDiagonal && !BotCore.settings.diagonalesVerificadas) {
            dir = if (Math.abs(dx) >= Math.abs(dy)) {
                if (dx > 0) com.arosbot.ai.core.Direccion.D else com.arosbot.ai.core.Direccion.A
            } else {
                if (dy > 0) com.arosbot.ai.core.Direccion.S else com.arosbot.ai.core.Direccion.W
            }
        }
        BotCore.entrada.mantener(dir, TOQUE_DE_GIRO_MS)
        delay(150L)
    }

    private suspend fun esperarRastreo(v: Vigilante, cuantos: Int, maxMs: Long) {
        val meta = v.numeroRastreo + cuantos
        val fin = SystemClock.elapsedRealtime() + maxMs
        while (v.numeroRastreo < meta && SystemClock.elapsedRealtime() < fin) delay(3L)
    }

    private fun registrarRecogido(e: Ejecucion, objetivo: Detection): Resultado {
        e.recogidosTotal++
        e.recogidosCiclo++
        BotCore.log.info("Recolección", "${objetivo.nombre} recogido (${e.recogidosTotal} en total)")
        return Resultado.RECOGIDO
    }

    /** Busca el botón «Interactuar» en pantalla y lo pulsa. */
    private suspend fun pulsarInteractuar(): Boolean {
        val botones = SelectorDeFunciones.con(FuncionVisual.INTERACTUAR, BotCore.store.materiales.value)
        val fin = SystemClock.elapsedRealtime() + 2500L
        while (SystemClock.elapsedRealtime() < fin) {
            val f = FrameBus.instantanea()
            if (f != null) {
                try {
                    val d = Deteccion.rapidaEnPantallaCompleta(f, botones, BotCore.store.directorioMateriales)
                        .detecciones.maxByOrNull { it.score }
                    if (d != null) {
                        val servicio = ArosAccessibilityService.instancia ?: return false
                        val (ap, hp) = PantallaReal.tamano(BotCore.appContext)
                        val x = (d.box.left + d.box.right) / 2f * ap / f.width
                        val y = (d.box.top + d.box.bottom) / 2f * hp / f.height
                        return servicio.tocar(x, y)
                    }
                } finally {
                    f.recycle()
                }
            }
            delay(60L)
        }
        return false
    }

    // ---------- Vuelta y depósito ----------

    /** Vuelve por la misma ruta al revés. null si llegó al cofre; si no, el motivo. */
    private suspend fun vuelta(e: Ejecucion): String? {
        val c = e.conductor
        c.interrupcion = null
        val primero = e.puntos.first()
        var intentos = 0
        var lista = CaminoDeVuelta.desde(e.puntos, CaminoDeVuelta.indiceMasCercano(e.puntos, c.x, c.y))
        var desde = 0
        e.rodeos = 0
        while (intentos < 4) {
            progreso("Volviendo al cofre por la misma ruta…")
            val fin = c.conducir(lista, desde, limite())
            when (fin) {
                is ConductorDeRuta.Fin.Fallo -> return fin.texto
                is ConductorDeRuta.Fin.Interrumpido -> return "interrumpido"
                is ConductorDeRuta.Fin.Bloqueado -> {
                    val destino = lista[fin.indice]
                    val paso = Rodeo.puntoDePaso(c.x, c.y, destino.x, destino.y, e.rodeos++)
                        ?: return "no pude rodear un obstáculo en la vuelta"
                    lista = listOf(aqui(e), PuntoDeRuta(paso.x.toDouble(), paso.y.toDouble(), 0L)) +
                        lista.drop(fin.indice)
                    desde = 1
                }
                is ConductorDeRuta.Fin.Llegado -> {
                    if (hypot(primero.x - c.x, primero.y - c.y) <= TOLERANCIA_INICIO_PX) return null
                    intentos++
                    lista = listOf(aqui(e), primero)
                    desde = 1
                }
            }
        }
        return "no logré quedar junto al cofre (${hypot(primero.x - c.x, primero.y - c.y).toInt()} px de error)"
    }

    /** Repite el macro del cofre y comprueba que el aviso de inventario lleno desaparece. null si fue bien. */
    private suspend fun depositar(e: Ejecucion): String? {
        val macro = MacroDeClics.decodificar(BotCore.settings.macroCofre)
        MacroDeClics.problema(macro)?.let { return it }
        val estabaLleno = e.vig.llenoSeguidas >= 1
        progreso("Cofre: repitiendo los toques grabados…")
        val motivo = ReproductorDeMacro.reproducir(macro!!) { i, n -> progreso("Cofre: paso $i de $n del macro") }
        if (motivo != null) return motivo
        delay(1500L)
        esperarFotogramas(e, 9, 2500L)
        if (estabaLleno && e.vig.llenoSeguidas >= 2) return "el inventario sigue lleno tras el macro"
        BotCore.log.info("Recolección", "Depósito hecho; reinicio la ruta")
        return null
    }

    private suspend fun relocalizarInicio(e: Ejecucion) {
        val inicio = e.puntos.first()
        val ref = inicio.referencia
        if (ref != null) {
            val h = reconocerAhora(ref)
            if (h != null) {
                val (nx, ny) = Relocalizacion.posicion(inicio, h.dx, h.dy)
                e.conductor.x = nx
                e.conductor.y = ny
                return
            }
        }
        e.conductor.x = inicio.x
        e.conductor.y = inicio.y
    }
}
