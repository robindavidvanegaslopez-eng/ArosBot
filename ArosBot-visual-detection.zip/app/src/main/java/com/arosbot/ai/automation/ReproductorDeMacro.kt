package com.arosbot.ai.automation

import com.arosbot.ai.capture.PantallaReal
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.FrameGeometry
import com.arosbot.ai.core.MacroDeClics
import com.arosbot.ai.core.MacroGrabado
import com.arosbot.ai.core.TipoDePaso
import com.arosbot.ai.input.ArosAccessibilityService
import kotlinx.coroutines.delay

/** Repite los toques de un macro grabado, con las mismas pausas que tuvo al grabarlo. */
object ReproductorDeMacro {

    /** Devuelve null si se repitió entero o el motivo por el que se detuvo. */
    suspend fun reproducir(macro: MacroGrabado, avance: (Int, Int) -> Unit = { _, _ -> }): String? {
        MacroDeClics.problema(macro)?.let { return it }
        val servicio = ArosAccessibilityService.instancia
            ?: return "El servicio de accesibilidad no está conectado."
        val (ancho, alto) = PantallaReal.tamano(BotCore.appContext)
        if (!FrameGeometry.relacionCompatible(macro.refAncho, macro.refAlto, ancho, alto)) {
            return "El macro se grabó con otra orientación o tamaño de pantalla: grábalo de nuevo."
        }
        for ((i, p) in macro.pasos.withIndex()) {
            avance(i + 1, macro.pasos.size)
            delay(p.esperaMs)
            val ok = when (p.tipo) {
                TipoDePaso.TOQUE -> servicio.tocar(p.x * ancho, p.y * alto, p.duracionMs)
                TipoDePaso.DESLIZAR ->
                    servicio.deslizar(p.x * ancho, p.y * alto, p.x2 * ancho, p.y2 * alto, p.duracionMs)
            }
            if (!ok) return "Android canceló el paso ${i + 1} de ${macro.pasos.size} del macro."
        }
        return null
    }
}
