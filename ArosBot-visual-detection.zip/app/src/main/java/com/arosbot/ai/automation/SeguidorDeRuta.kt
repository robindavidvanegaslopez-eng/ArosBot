package com.arosbot.ai.automation

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.Calibracion
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.Guia
import com.arosbot.ai.core.GuiaDeRuta
import com.arosbot.ai.core.ReferenciaVisual
import com.arosbot.ai.core.Relocalizacion
import com.arosbot.ai.core.Ruta
import com.arosbot.ai.input.ArosAccessibilityService
import com.arosbot.ai.input.JoystickGestos
import com.arosbot.ai.vision.EstimadorMovimiento
import com.arosbot.ai.vision.ReferenciasVisuales
import kotlin.math.hypot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Seguimiento de una ruta enseñada (módulos 7, 8 y 10 en acción). El bot recorre los puntos de la
 * ruta con el joystick: en cada paso decide la dirección corrigiendo el eje con más error, mantiene
 * la pulsación lo que dicta la calibración, mide lo que se movió la escena y actualiza su posición.
 * En los puntos con referencia visual busca el recorte guardado para corregir la deriva. Cada
 * intento real queda anotado (éxito, duración, pasos, correcciones) y alimenta lo aprendido.
 *
 * Comienza con una cuenta atrás para que cambies al juego y se cancela con la parada de emergencia.
 */
object SeguidorDeRuta {

    private const val CUENTA_ATRAS_S = 6
    private const val ESPERA_ANTES_MS = 200L
    private const val ASENTAMIENTO_MS = 500L
    private const val MAX_PASOS_POR_PUNTO = 12
    private const val MAX_REFINAMIENTOS = 3
    private const val CONFIANZA_MEDICION = 0.08
    private const val PULSACION_MINIMA_APRENDER_MS = 250L
    private const val LIMITE_MINIMO_MS = 90_000L

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trabajo: Job? = null

    private val _estado = MutableStateFlow(EstadoPrueba())
    val estado: StateFlow<EstadoPrueba> = _estado.asStateFlow()

    @Synchronized
    fun reproducir(rutaId: Long, inversa: Boolean) {
        if (trabajo?.isActive == true) {
            BotCore.log.aviso("Rutas", "Ya hay una ruta en marcha")
            return
        }
        if (BotCore.stateMachine.state.value == BotState.PARADA_EMERGENCIA) {
            _estado.value = EstadoPrueba(
                false,
                "Hay una parada de emergencia activa. Pulsa «Restablecer» en el Panel principal."
            )
            return
        }
        val ruta = BotCore.store.rutas.value.firstOrNull { it.id == rutaId }
        if (ruta == null) {
            _estado.value = EstadoPrueba(false, "Esa ruta ya no existe.")
            return
        }
        _estado.value = EstadoPrueba(true, "Ruta «${ruta.nombre}»: preparando…")
        BotCore.log.info("Rutas", "Seguir ruta «${ruta.nombre}»${if (inversa) " al revés" else ""}: iniciada")
        trabajo = alcance.launch {
            val texto = try {
                recorrer(ruta, inversa)
            } catch (e: CancellationException) {
                BotCore.entrada.soltarTodo()
                "Ruta «${ruta.nombre}»: cancelada."
            } catch (e: Exception) {
                BotCore.entrada.soltarTodo()
                BotCore.log.error("Rutas", "Error inesperado al seguir la ruta: ${e.message}")
                "Ruta «${ruta.nombre}»: error inesperado (${e.message})."
            }
            _estado.value = EstadoPrueba(false, texto)
            val resumen = texto.lines().first()
            BotCore.log.info("Rutas", resumen)
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(BotCore.appContext, resumen, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun cancelar() {
        trabajo?.cancel()
        BotCore.entrada.soltarTodo()
    }

    private fun progreso(texto: String) {
        _estado.value = EstadoPrueba(true, texto)
    }

    private fun reconocerAhora(referencia: ReferenciaVisual): ReferenciasVisuales.Hallazgo? {
        val fotograma = FrameBus.instantanea() ?: return null
        return try {
            ReferenciasVisuales
                .reconocer(fotograma, referencia, BotCore.store.directorioReferencias)
                ?.takeIf { Relocalizacion.fiable(it.confianza) }
        } finally {
            fotograma.recycle()
        }
    }

    private suspend fun recorrer(ruta: Ruta, inversa: Boolean): String {
        val nombre = "Ruta «${ruta.nombre}»"
        if (!ArosAccessibilityService.conectado.value) {
            return "$nombre: activa el servicio de accesibilidad de ArosBot AI en los ajustes de Android."
        }
        if (BotCore.settings.joystick == null) {
            return "$nombre: primero configura el joystick en Automatización."
        }
        if (!FrameBus.estado.value.activa) {
            return "$nombre: inicia la captura de pantalla en el Panel principal."
        }
        val calibraciones = HashMap<Direccion, Calibracion>(BotCore.store.calibraciones.value)
        val sinCalibrar = Direccion.values().filter { (calibraciones[it]?.muestras ?: 0) == 0 }
        if (sinCalibrar.isNotEmpty()) {
            return "$nombre: falta calibrar el movimiento (${sinCalibrar.joinToString { it.tecla.toString() }}). " +
                "Haz antes «Probar movimiento» en Automatización."
        }
        val puntos = ruta.puntosEnSentido(inversa)
        if (puntos.size < 2) return "$nombre: la ruta no tiene recorrido."

        for (s in CUENTA_ATRAS_S downTo 1) {
            progreso("$nombre: cambia al juego, colócate en el punto de partida… $s")
            delay(1000L)
        }
        progreso("$nombre: comprobando el punto de partida…")

        // Punto de partida: se reconoce visualmente y fija la posición inicial.
        val inicio = puntos.first()
        val referenciaInicial = inicio.referencia
        var x = 0.0
        var y = 0.0
        if (referenciaInicial != null) {
            val h = reconocerAhora(referenciaInicial)
                ?: return "$nombre: no reconozco el lugar de partida. Colócate donde empezaste a enseñar " +
                    "la ruta${if (inversa) " (donde terminó, porque va al revés)" else ""} y vuelve a probar."
            val (nx, ny) = Relocalizacion.posicion(inicio, h.dx, h.dy)
            x = nx
            y = ny
        }

        val empezo = SystemClock.elapsedRealtime()
        val limiteMs = maxOf(LIMITE_MINIMO_MS, (ruta.duracionEstimadaMs * 5).toLong())
        var pasos = 0
        var correcciones = 0
        var medidos = 0
        var estimados = 0
        var referenciasVistas = 0
        var referenciasPerdidas = 0
        var errorFinal: Double? = null
        val aprendidas = HashSet<Direccion>()

        fun cerrar(exito: Boolean, motivo: String, detalle: String): String {
            val duracion = SystemClock.elapsedRealtime() - empezo
            for (d in aprendidas) calibraciones[d]?.let { BotCore.store.guardarCalibracion(it) }
            var guardado = false
            if (pasos > 0) {
                guardado = BotCore.store.registrarIntento(
                    ruta.id, exito, duracion, pasos, correcciones, motivo
                )
                if (guardado) BotCore.marcarVerificadoPersistente(10)
            }
            if (exito) BotCore.marcarVerificadoPersistente(8)
            val error = errorFinal
            if (exito && error != null && error <= Relocalizacion.ERROR_MAXIMO_PX) {
                BotCore.marcarVerificadoPersistente(7)
            }
            val cabecera = if (exito) "$nombre: CORRECTA. $motivo" else "$nombre: NO completada. $motivo"
            val lineas = ArrayList<String>()
            lineas.add(cabecera)
            lineas.add("Duración: ${duracion / 1000} s · pasos: $pasos · correcciones: $correcciones")
            lineas.add("Movimiento medido en $medidos pasos y estimado en $estimados")
            lineas.add("Referencias visuales: $referenciasVistas reconocidas, $referenciasPerdidas no reconocidas")
            if (error != null) lineas.add("Error al llegar según la referencia final: ${error.toInt()} px")
            if (pasos > 0) {
                lineas.add(
                    if (guardado) "El intento queda guardado en el aprendizaje."
                    else "No se pudo guardar el intento en el aprendizaje."
                )
            }
            if (detalle.isNotEmpty()) lineas.add(detalle)
            return lineas.joinToString("\n")
        }

        for (i in 1 until puntos.size) {
            val objetivo = puntos[i]
            val ultimo = i == puntos.lastIndex
            var pasosPunto = 0
            var refinamientos = 0

            while (true) {
                if (SystemClock.elapsedRealtime() - empezo > limiteMs) {
                    BotCore.entrada.soltarTodo()
                    return cerrar(false, "Se agotó el tiempo (${limiteMs / 1000} s).", "")
                }
                progreso("$nombre: punto $i de ${puntos.size - 1}, paso $pasos…")

                val guia = GuiaDeRuta.siguientePaso(x, y, objetivo.x, objetivo.y, calibraciones)
                if (guia is Guia.SinCalibracion) {
                    return cerrar(false, "Falta calibrar ${guia.direccion.tecla}.", "")
                }
                if (guia is Guia.Llegado) {
                    val referencia = objetivo.referencia ?: break
                    val h = reconocerAhora(referencia)
                    if (h == null) {
                        referenciasPerdidas++
                        if (ultimo) errorFinal = null
                        break
                    }
                    referenciasVistas++
                    val error = Relocalizacion.error(h.dx, h.dy)
                    val (nx, ny) = Relocalizacion.posicion(objetivo, h.dx, h.dy)
                    x = nx
                    y = ny
                    if (error > GuiaDeRuta.TOLERANCIA_PX && refinamientos < MAX_REFINAMIENTOS) {
                        refinamientos++
                        correcciones++
                        continue
                    }
                    if (ultimo) errorFinal = error
                    break
                }

                val mover = guia as Guia.Mover
                delay(ESPERA_ANTES_MS)
                val antes = FrameBus.instantanea()
                    ?: return cerrar(false, "Dejaron de llegar fotogramas de la captura.", "")
                val completado = BotCore.entrada.mantener(mover.direccion, mover.duracionMs)
                if (!completado) {
                    antes.recycle()
                    BotCore.entrada.soltarTodo()
                    val motivo = JoystickGestos.motivoUltimoFallo ?: "motivo desconocido"
                    return cerrar(false, "No se pudo enviar el gesto de ${mover.direccion.tecla}: $motivo.", "")
                }
                delay(ASENTAMIENTO_MS)
                val despues = FrameBus.instantanea()
                if (despues == null) {
                    antes.recycle()
                    return cerrar(false, "Dejaron de llegar fotogramas de la captura.", "")
                }
                val medicion = EstimadorMovimiento.estimar(antes, despues)
                antes.recycle()
                despues.recycle()

                pasos++
                pasosPunto++
                if (pasosPunto > 1) correcciones++

                val calibracion = calibraciones.getValue(mover.direccion)
                val segundos = mover.duracionMs / 1000.0
                if (medicion != null && medicion.confianza >= CONFIANZA_MEDICION) {
                    x -= medicion.dx
                    y -= medicion.dy
                    medidos++
                    // Aprendizaje: la velocidad observada afina la calibración, salvo mediciones raras.
                    val observada = hypot(medicion.dx, medicion.dy) / segundos
                    val base = calibracion.rapidez
                    if (mover.duracionMs >= PULSACION_MINIMA_APRENDER_MS &&
                        observada > base * 0.5 && observada < base * 1.5
                    ) {
                        calibraciones[mover.direccion] =
                            calibracion.actualizar(medicion.dx, medicion.dy, mover.duracionMs)
                        aprendidas.add(mover.direccion)
                    }
                } else {
                    // Sin medición fiable: se estima con la calibración y se avisa en el resultado.
                    x -= calibracion.vx * segundos
                    y -= calibracion.vy * segundos
                    estimados++
                }

                if (pasosPunto > MAX_PASOS_POR_PUNTO) {
                    BotCore.entrada.soltarTodo()
                    return cerrar(false, "No consigo llegar al punto $i de ${puntos.size - 1}.", "")
                }
            }
        }

        val error = errorFinal
        val ultimaReferencia = puntos.last().referencia
        return when {
            error != null && error > Relocalizacion.ERROR_MAXIMO_PX ->
                cerrar(false, "Llegué a ${error.toInt()} px del lugar de destino.", "")
            error != null ->
                cerrar(true, "Se reconoció el lugar de destino a ${error.toInt()} px.", "")
            ultimaReferencia == null ->
                cerrar(true, "Recorrí toda la ruta (sin referencia visual al final).", "")
            else ->
                cerrar(
                    true,
                    "Recorrí toda la ruta, pero no pude reconocer visualmente el destino: llegué por estimación.",
                    "Mira si el personaje está donde debería. El mapa visual no se da por verificado sin ese reconocimiento."
                )
        }
    }
}
