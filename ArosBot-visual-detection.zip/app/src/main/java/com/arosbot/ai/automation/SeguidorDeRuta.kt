package com.arosbot.ai.automation

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.Calibracion
import com.arosbot.ai.core.Calibraciones
import com.arosbot.ai.core.DetectorDeBloqueo
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.Guia
import com.arosbot.ai.core.GuiaDeRuta
import com.arosbot.ai.core.OptimizadorDeTrayecto
import com.arosbot.ai.core.PuntoDeRuta
import com.arosbot.ai.core.ReferenciaVisual
import com.arosbot.ai.core.Rodeo
import com.arosbot.ai.core.Relocalizacion
import com.arosbot.ai.core.Ruta
import com.arosbot.ai.input.ArosAccessibilityService
import com.arosbot.ai.input.JoystickGestos
import com.arosbot.ai.vision.EstimadorMovimiento
import com.arosbot.ai.vision.ReferenciasVisuales
import kotlin.math.hypot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Seguimiento de una ruta enseñada (módulos 7, 8 y 10 en acción). El bot recorre los puntos de la
 * ruta con el joystick: en cada paso decide la dirección corrigiendo el eje con más error, mantiene
 * la pulsación lo que dicta la calibración, mide lo que se movió la escena y actualiza su posición.
 * En los puntos con referencia visual busca el recorte guardado para corregir la deriva. Cada
 * intento real queda anotado (éxito, duración, pasos, correcciones) y alimenta lo aprendido.
 *
 * Comienza con una cuenta atrás para que cambies al juego y se cancela con la parada de emergencia.
 */
object SeguidorDeRuta {

    private const val CUENTA_ATRAS_S = 6
    private const val ESPERA_ANTES_MS = 200L
    private const val ASENTAMIENTO_MS = 500L
    private const val MAX_PASOS_POR_PUNTO = 12
    private const val MAX_REFINAMIENTOS = 10
    private const val TOLERANCIA_FINAL_PX = 15.0
    private const val MAX_ALTERNATIVAS = 3
    private const val MAX_ANCLAS_POR_RUTA = 24
    private const val CONFIANZA_MEDICION = 0.08
    private const val PULSACION_MINIMA_APRENDER_MS = 250L
    private const val LIMITE_MINIMO_MS = 90_000L

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trabajo: Job? = null

    private val _estado = MutableStateFlow(EstadoPrueba())
    val estado: StateFlow<EstadoPrueba> = _estado.asStateFlow()

    @Synchronized
    fun reproducir(rutaId: Long, inversa: Boolean) {
        if (trabajo?.isActive == true) {
            BotCore.log.aviso("Rutas", "Ya hay una ruta en marcha")
            return
        }
        if (NavegadorDeSpots.ejecutando) {
            _estado.value = EstadoPrueba(false, "El navegador de spots está en marcha. Cancélalo primero.")
            return
        }
        if (BotCore.stateMachine.state.value == BotState.PARADA_EMERGENCIA) {
            _estado.value = EstadoPrueba(
                false,
                "Hay una parada de emergencia activa. Pulsa «Restablecer» en el Panel principal."
            )
            return
        }
        val ruta = BotCore.store.rutas.value.firstOrNull { it.id == rutaId }
        if (ruta == null) {
            _estado.value = EstadoPrueba(false, "Esa ruta ya no existe.")
            return
        }
        _estado.value = EstadoPrueba(true, "Ruta «${ruta.nombre}»: preparando…")
        BotCore.log.info("Rutas", "Seguir ruta «${ruta.nombre}»${if (inversa) " al revés" else ""}: iniciada")
        trabajo = alcance.launch {
            val texto = try {
                seguir(ruta, inversa, cuentaAtras = true).texto
            } catch (e: CancellationException) {
                "Ruta «${ruta.nombre}»: cancelada."
            }
            _estado.value = EstadoPrueba(false, texto)
            val resumen = texto.lines().first()
            BotCore.log.info("Rutas", resumen)
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(BotCore.appContext, resumen, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun cancelar() {
        trabajo?.cancel()
        BotCore.entrada.soltarTodo()
    }

    /** Resultado de recorrer una ruta: si se completó y el texto para mostrar. */
    data class Resultado(val exito: Boolean, val texto: String)

    /** Se puso en marcha algún gesto en el recorrido actual (la posición real ya pudo cambiar). */
    @Volatile
    private var seMovio = false

    @Volatile
    private var exitoDelRecorrido = false

    /** Conductor del recorrido en marcha, para volcar sus contadores al cerrar. */
    @Volatile
    private var conductorActual: ConductorDeRuta? = null

    /**
     * Recorre la ruta y espera a que termine. Lo usan la pantalla de rutas (con cuenta atrás) y el
     * navegador de spots (que enlaza varios tramos sin repetir la cuenta atrás). Al terminar con éxito
     * el personaje queda en el otro extremo de la ruta; si falla a medias, deja de saberse dónde está.
     * Nunca lanza excepciones salvo la cancelación de la corrutina, que se propaga tras soltar el joystick.
     */
    suspend fun seguir(ruta: Ruta, inversa: Boolean, cuentaAtras: Boolean): Resultado {
        seMovio = false
        exitoDelRecorrido = false
        val destinoId = if (inversa) ruta.origenId else ruta.destinoId
        return try {
            val texto = recorrer(ruta, inversa, cuentaAtras)
            if (exitoDelRecorrido) {
                BotCore.settings.lugarActualId = destinoId
            } else if (seMovio) {
                BotCore.settings.lugarActualId = -1L
            }
            Resultado(exitoDelRecorrido, texto)
        } catch (e: CancellationException) {
            BotCore.entrada.soltarTodo()
            if (seMovio) BotCore.settings.lugarActualId = -1L
            throw e
        } catch (e: Exception) {
            BotCore.entrada.soltarTodo()
            BotCore.log.error("Rutas", "Error inesperado al seguir la ruta: ${e.message}")
            if (seMovio) BotCore.settings.lugarActualId = -1L
            Resultado(false, "Ruta «${ruta.nombre}»: error inesperado (${e.message}).")
        }
    }

    /** Otra ruta enseñada por la que continuar: sus puntos, desde dónde y dónde se cree estar en su marco. */
    private class Alternativa(
        val ruta: Ruta,
        val puntos: List<com.arosbot.ai.core.PuntoDeRuta>,
        val indice: Int,
        val x: Double,
        val y: Double,
        val restantePx: Double,
        val confianza: Double
    )

    /**
     * Busca, entre las demás rutas que llevan al mismo destino (en cualquier sentido), cuál tiene una
     * captura que se reconozca ahora en pantalla. Entre las reconocidas elige la que deja menos camino por
     * recorrer. Solo reconoce lo que está cerca de lo enseñado (la búsqueda cubre una zona alrededor de
     * donde se tomó cada captura): si el personaje está lejos de las demás rutas, no encuentra ninguna.
     */
    private fun buscarAlternativa(actual: Ruta, destinoId: Long): Alternativa? {
        val fotograma = FrameBus.instantanea() ?: return null
        try {
            var mejor: Alternativa? = null
            for (r in BotCore.store.rutas.value) {
                if (r.id == actual.id) continue
                for (inv in listOf(false, true)) {
                    val destino = if (inv) r.origenId else r.destinoId
                    if (destino != destinoId) continue
                    val pts = r.puntosEnSentido(inv)
                    val conCaptura = pts.withIndex().filter { it.value.referencia != null }
                    val paso = maxOf(1, conCaptura.size / MAX_ANCLAS_POR_RUTA)
                    var k = 0
                    while (k < conCaptura.size) {
                        val (i, p) = conCaptura[k]
                        k += paso
                        val h = ReferenciasVisuales
                            .reconocer(fotograma, p.referencia!!, BotCore.store.directorioReferencias)
                            ?.takeIf { Relocalizacion.fiable(it.confianza) } ?: continue
                        val (nx, ny) = Relocalizacion.posicion(p, h.dx, h.dy)
                        var resto = 0.0
                        for (j in i + 1 until pts.size) {
                            resto += hypot(pts[j].x - pts[j - 1].x, pts[j].y - pts[j - 1].y)
                        }
                        val c = Alternativa(r, pts, i, nx, ny, resto, h.confianza)
                        if (mejor == null || c.restantePx < mejor.restantePx) mejor = c
                    }
                }
            }
            return mejor
        } finally {
            fotograma.recycle()
        }
    }

    private fun progreso(texto: String) {
        _estado.value = EstadoPrueba(true, texto)
    }

    private fun reconocerAhora(referencia: ReferenciaVisual): ReferenciasVisuales.Hallazgo? {
        val fotograma = FrameBus.instantanea() ?: return null
        return try {
            ReferenciasVisuales
                .reconocer(fotograma, referencia, BotCore.store.directorioReferencias)
                ?.takeIf { Relocalizacion.fiable(it.confianza) }
        } finally {
            fotograma.recycle()
        }
    }

    private suspend fun recorrer(ruta: Ruta, inversa: Boolean, cuentaAtras: Boolean): String {
        val nombre = "Ruta «${ruta.nombre}»"
        if (!ArosAccessibilityService.conectado.value) {
            return "$nombre: activa el servicio de accesibilidad de ArosBot AI en los ajustes de Android."
        }
        if (BotCore.settings.joystick == null) {
            return "$nombre: primero configura el joystick en Automatización."
        }
        if (!FrameBus.estado.value.activa) {
            return "$nombre: inicia la captura de pantalla en el Panel principal."
        }
        val calibraciones = HashMap<Direccion, Calibracion>(BotCore.store.calibraciones.value)
        val sinCalibrar = Direccion.CARDINALES.filter { (calibraciones[it]?.muestras ?: 0) == 0 }
        if (sinCalibrar.isNotEmpty()) {
            return "$nombre: falta calibrar el movimiento (${sinCalibrar.joinToString { it.tecla }}). " +
                "Haz antes «Probar movimiento» en Automatización."
        }
        val rutaOriginal = ruta.puntosEnSentido(inversa)
        var original = rutaOriginal
        if (original.size < 2) return "$nombre: la ruta no tiene recorrido."

        // El bot no repite tus pasos: reduce tu trayectoria a los puntos que hacen falta y va de uno a
        // otro en línea casi recta. Si un atajo falla, vuelve a tu camino en ese tramo.
        val optimizado = OptimizadorDeTrayecto.simplificar(original)
        val puntos = ArrayList(optimizado.puntos)
        val origenDe = ArrayList(optimizado.indices)
        val diagonales = BotCore.settings.diagonalesVerificadas
        var respaldos = 0
        var alternativas = 0
        val rutasAlternativas = ArrayList<String>()
        val destinoDeseado = if (inversa) ruta.origenId else ruta.destinoId
        var rodeos = 0
        var rodeosTotales = 0
        var indiceDelRodeo = -1
        var ultimoBloqueado = -1
        BotCore.log.info(
            "Rutas",
            "$nombre: camino de ${original.size} a ${puntos.size} puntos " +
                "(${(optimizado.ahorro * 100).toInt()} % menos recorrido); " +
                "diagonales ${if (diagonales) "activadas" else "sin verificar (solo W/A/S/D)"}"
        )

        if (cuentaAtras) {
            for (s in CUENTA_ATRAS_S downTo 1) {
                progreso("$nombre: cambia al juego, colócate en el punto de partida… $s")
                delay(1000L)
            }
        }
        progreso("$nombre: comprobando el punto de partida…")

        // Punto de partida: se reconoce visualmente y fija la posición inicial.
        val inicio = puntos.first()
        val referenciaInicial = inicio.referencia
        var x = 0.0
        var y = 0.0
        if (referenciaInicial != null) {
            val h = reconocerAhora(referenciaInicial)
                ?: return "$nombre: no reconozco el lugar de partida. Colócate donde empezaste a enseñar " +
                    "la ruta${if (inversa) " (donde terminó, porque va al revés)" else ""} y vuelve a probar."
            val (nx, ny) = Relocalizacion.posicion(inicio, h.dx, h.dy)
            x = nx
            y = ny
            BotCore.log.info(
                "Rutas",
                "$nombre: salida reconocida (desfase ${h.dx.toInt()}, ${h.dy.toInt()} px, " +
                    "confianza ${(h.confianza * 100).toInt()} %)"
            )
        }

        val empezo = SystemClock.elapsedRealtime()
        val limiteMs = maxOf(LIMITE_MINIMO_MS, (ruta.duracionEstimadaMs * 5).toLong())
        var pasos = 0
        var correcciones = 0
        var medidos = 0
        var estimados = 0
        var quietosC = 0
        var fpsC = 0.0
        var sinMedidaC = 0
        var referenciasVistas = 0
        var referenciasPerdidas = 0
        var errorFinal: Double? = null
        val aprendidas = HashSet<Direccion>()

        fun cerrar(exito: Boolean, motivo: String, detalle: String): String {
            conductorActual?.let { c ->
                pasos = c.fotogramasMedidos + c.fotogramasEstimados
                medidos = c.fotogramasMedidos
                estimados = c.fotogramasEstimados
                quietosC = c.fotogramasQuietos
                fpsC = c.fps
                sinMedidaC = c.fotogramasSinMedida
                referenciasVistas = c.referenciasVistas
                referenciasPerdidas = c.referenciasPerdidas
                correcciones += c.reintentosDeGesto
                errorFinal = c.errorFinal
            }
            conductorActual = null
            com.arosbot.ai.capture.TrayectoSobreJuego.limpiar()
            val duracion = SystemClock.elapsedRealtime() - empezo
            for (d in aprendidas) calibraciones[d]?.let { BotCore.store.guardarCalibracion(it) }
            var guardado = false
            if (pasos > 0) {
                guardado = BotCore.store.registrarIntento(
                    ruta.id, exito, duracion, pasos, correcciones, motivo
                )
                if (guardado) BotCore.marcarVerificadoPersistente(10)
            }
            exitoDelRecorrido = exito
            if (exito) BotCore.marcarVerificadoPersistente(8)
            val error = errorFinal
            if (exito && error != null && error <= Relocalizacion.ERROR_MAXIMO_PX) {
                BotCore.marcarVerificadoPersistente(7)
            }
            val cabecera = if (exito) "$nombre: CORRECTA. $motivo" else "$nombre: NO completada. $motivo"
            val lineas = ArrayList<String>()
            lineas.add(cabecera)
            lineas.add("Duración: ${duracion / 1000} s · pasos: $pasos · correcciones: $correcciones")
            lineas.add(
                "Camino: ${original.size} puntos enseñados reducidos a ${optimizado.puntos.size} " +
                    "(${(optimizado.ahorro * 100).toInt()} % menos recorrido)" +
                    (if (respaldos > 0) " · volví a tu camino en $respaldos tramo(s)" else "") +
                    (if (rodeosTotales > 0) " · rodeos de obstáculos: $rodeosTotales" else "") +
                    (if (rutasAlternativas.isNotEmpty()) " · me incorporé a: ${rutasAlternativas.joinToString()}" else "")
            )
            lineas.add("Medición a ${fpsC.toInt()} fotogramas por segundo (reales)")
            lineas.add("Movimiento medido en $medidos fotogramas, estimado en $estimados, escena quieta en $quietosC y sin medida en $sinMedidaC")
            lineas.add("Referencias visuales: $referenciasVistas reconocidas, $referenciasPerdidas no reconocidas")
            if (error != null) lineas.add("Error al llegar según la referencia final: ${error.toInt()} px")
            if (pasos > 0) {
                lineas.add(
                    if (guardado) "El intento queda guardado en el aprendizaje."
                    else "No se pudo guardar el intento en el aprendizaje."
                )
            }
            if (detalle.isNotEmpty()) lineas.add(detalle)
            return lineas.joinToString("\n")
        }

        // Conducción continua: el dedo no se levanta; el rumbo se corrige midiendo la pantalla ~25 veces
        // por segundo. Solo se vuelve a empezar si hay un bloqueo (camino de respaldo) o al quedar lejos.
        val anclas = original.filter { it.referencia != null }
        val conductor = ConductorDeRuta(
            calibraciones,
            diagonales,
            anclas,
            { reconocerAhora(it) },
            { BotCore.log.info("Rutas", "$nombre: $it") },
            { progreso("$nombre: $it") }
        )
        conductorActual = conductor
        conductor.x = x
        conductor.y = y
        var indice = 1
        var refinamientos = 0
        while (true) {
            if (SystemClock.elapsedRealtime() - empezo > limiteMs) {
                BotCore.entrada.soltarTodo()
                return cerrar(false, "Se agotó el tiempo (${limiteMs / 1000} s).", "")
            }
            val fin = conductor.conducir(puntos, indice, empezo + limiteMs)
            seMovio = conductor.seMovio
            when (fin) {
                is ConductorDeRuta.Fin.Fallo -> return cerrar(false, fin.texto, "")
                is ConductorDeRuta.Fin.Bloqueado -> {
                    val i = fin.indice
                    if (indiceDelRodeo == i) {
                        // Tampoco se avanza hacia el punto de rodeo: se quita y se prueba el otro lado.
                        puntos.removeAt(i)
                        origenDe.removeAt(i)
                        indiceDelRodeo = -1
                    } else if (i != ultimoBloqueado) {
                        rodeos = 0
                    }
                    ultimoBloqueado = i
                    val intermedios = if (i >= 1 && i < origenDe.size) {
                        (origenDe[i - 1] + 1) until origenDe[i]
                    } else {
                        IntRange.EMPTY
                    }
                    if (!intermedios.isEmpty()) {
                        // El atajo no es transitable: se vuelve al camino que enseñó el usuario.
                        val lista = intermedios.toList()
                        puntos.addAll(i, lista.map { original[it] })
                        origenDe.addAll(i, lista)
                        respaldos++
                        indice = i
                        BotCore.log.aviso(
                            "Rutas",
                            "$nombre: el personaje no avanza hacia el punto $i por el atajo; " +
                                "sigo tu camino enseñado (${lista.size} puntos más)"
                        )
                        continue
                    }
                    // Obstáculo: se prueba a rodearlo por un lado y por el otro, cada vez más lejos.
                    val objetivo = puntos[i]
                    val paso = Rodeo.puntoDePaso(conductor.x, conductor.y, objetivo.x, objetivo.y, rodeos)
                    if (paso != null) {
                        rodeos++
                        rodeosTotales++
                        puntos.add(i, PuntoDeRuta(paso.x.toDouble(), paso.y.toDouble(), 0L, null))
                        origenDe.add(i, origenDe[maxOf(0, i - 1)])
                        indiceDelRodeo = i
                        indice = i
                        correcciones++
                        BotCore.log.aviso(
                            "Rutas",
                            "$nombre: el personaje se detuvo antes del punto $i; pruebo a rodear el obstáculo " +
                                "(intento $rodeos de ${Rodeo.INTENTOS_MAXIMOS}, lado " +
                                "${if ((rodeos - 1) % 2 == 0) "derecho" else "izquierdo"})"
                        )
                        continue
                    }
                    // Sin más rodeos posibles: se busca otra ruta enseñada hacia el mismo destino cuyas capturas
                    // se reconozcan desde aquí, y se continúa por ella.
                    if (alternativas < MAX_ALTERNATIVAS) {
                        val alt = buscarAlternativa(ruta, destinoDeseado)
                        if (alt != null) {
                            alternativas++
                            val sub = alt.puntos.drop(alt.indice)
                            val opt = OptimizadorDeTrayecto.simplificar(sub)
                            original = sub
                            puntos.clear()
                            puntos.addAll(opt.puntos)
                            origenDe.clear()
                            origenDe.addAll(opt.indices)
                            conductor.anclas = sub.filter { it.referencia != null }
                            conductor.x = alt.x
                            conductor.y = alt.y
                            indice = 1.coerceAtMost(puntos.lastIndex)
                            rodeos = 0
                            indiceDelRodeo = -1
                            ultimoBloqueado = -1
                            rutasAlternativas.add(alt.ruta.nombre)
                            correcciones++
                            BotCore.log.aviso(
                                "Rutas",
                                "$nombre: sin salida por este camino; me incorporo a la ruta «${alt.ruta.nombre}» " +
                                    "(reconocí su punto ${alt.indice}, a ${alt.restantePx.toInt()} px del destino)"
                            )
                            continue
                        }
                    }
                    return cerrar(
                        false,
                        "El personaje no avanza hacia el punto $i de ${puntos.size - 1}: parece haber un " +
                            "obstáculo que no pude rodear o el juego no responde al joystick.",
                        "Probé ${Rodeo.INTENTOS_MAXIMOS} rodeos laterales sin éxito. Se midió menos del " +
                            "${(DetectorDeBloqueo.FRACCION_MINIMA * 100).toInt()} % del movimiento esperado " +
                            "durante ${ConductorDeRuta.PASOS_BLOQUEO} ventanas seguidas. Mira el registro de actividad."
                    )
                }
                is ConductorDeRuta.Fin.Llegado -> {
                    val ultimo = puntos.last()
                    val distancia = hypot(ultimo.x - conductor.x, ultimo.y - conductor.y)
                    val lejos = distancia > TOLERANCIA_FINAL_PX
                    if (lejos && refinamientos < MAX_REFINAMIENTOS) {
                        refinamientos++
                        correcciones++
                        indice = puntos.lastIndex
                        BotCore.log.info("Rutas", "$nombre: corrijo, quedé a ${distancia.toInt()} px del punto final")
                        continue
                    }
                    break
                }
            }
        }
        conductorActual = null
        com.arosbot.ai.capture.TrayectoSobreJuego.limpiar()

        conductor.let { c ->
            pasos = c.fotogramasMedidos + c.fotogramasEstimados
            medidos = c.fotogramasMedidos
            estimados = c.fotogramasEstimados
            quietosC = c.fotogramasQuietos
            sinMedidaC = c.fotogramasSinMedida
            fpsC = c.fps
            referenciasVistas = c.referenciasVistas
            referenciasPerdidas = c.referenciasPerdidas
            correcciones += c.reintentosDeGesto
            errorFinal = c.errorFinal
        }
        val error = errorFinal
        val ultimaReferencia = puntos.last().referencia
        return when {
            error != null && error > Relocalizacion.ERROR_MAXIMO_PX ->
                cerrar(false, "Llegué a ${error.toInt()} px del lugar de destino.", "")
            error != null ->
                cerrar(true, "Se reconoció el lugar de destino a ${error.toInt()} px.", "")
            ultimaReferencia == null ->
                cerrar(true, "Recorrí toda la ruta (sin referencia visual al final).", "")
            else ->
                cerrar(
                    true,
                    "Recorrí toda la ruta, pero no pude reconocer visualmente el destino: llegué por estimación.",
                    "Mira si el personaje está donde debería. El mapa visual no se da por verificado sin ese reconocimiento."
                )
        }
    }
}
