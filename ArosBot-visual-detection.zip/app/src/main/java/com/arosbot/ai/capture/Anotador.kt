package com.arosbot.ai.capture

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import com.arosbot.ai.core.Box
import com.arosbot.ai.core.Detection
import kotlin.math.max

/** Dibuja recuadros verdes (objetos) y celestes (áreas) sobre una copia de un fotograma. */
object Anotador {

    fun dibujar(
        origen: Bitmap,
        detecciones: List<Detection>,
        areas: List<Pair<String, Box>> = emptyList()
    ): Bitmap {
        val copia = origen.copy(Bitmap.Config.ARGB_8888, true) ?: return origen
        val lienzo = Canvas(copia)
        val grosor = max(2f, copia.width / 250f)

        val verde = Paint()
        verde.color = Color.rgb(0, 230, 60)
        verde.style = Paint.Style.STROKE
        verde.strokeWidth = grosor

        val textoVerde = Paint()
        textoVerde.color = Color.rgb(0, 230, 60)
        textoVerde.style = Paint.Style.FILL
        textoVerde.isAntiAlias = true
        textoVerde.textSize = max(16f, copia.width / 38f)

        val celeste = Paint()
        celeste.color = Color.rgb(0, 170, 255)
        celeste.style = Paint.Style.STROKE
        celeste.strokeWidth = max(1.5f, grosor / 2f)
        celeste.pathEffect = DashPathEffect(floatArrayOf(14f, 9f), 0f)

        val textoCeleste = Paint()
        textoCeleste.color = Color.rgb(0, 170, 255)
        textoCeleste.style = Paint.Style.FILL
        textoCeleste.isAntiAlias = true
        textoCeleste.textSize = textoVerde.textSize

        for ((nombre, caja) in areas) {
            lienzo.drawRect(
                caja.left.toFloat(),
                caja.top.toFloat(),
                caja.right.toFloat(),
                caja.bottom.toFloat(),
                celeste
            )
            lienzo.drawText(nombre, caja.left + 4f, caja.top + textoCeleste.textSize, textoCeleste)
        }
        for (d in detecciones) {
            lienzo.drawRect(
                d.box.left.toFloat(),
                d.box.top.toFloat(),
                d.box.right.toFloat(),
                d.box.bottom.toFloat(),
                verde
            )
            val etiqueta = d.nombre + " " + (d.score * 100f).toInt() + "%"
            lienzo.drawText(
                etiqueta,
                d.box.left.toFloat(),
                max(textoVerde.textSize, d.box.top - 4f),
                textoVerde
            )
        }
        return copia
    }
}
