package com.arosbot.ai.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.arosbot.ai.R
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.ui.MainActivity

/**
 * Gestor de captura de pantalla (módulo 1) con MediaProjection.
 *
 * - Se ejecuta como servicio en primer plano de tipo mediaProjection (obligatorio desde Android 14).
 * - Entrega fotogramas reales a [FrameBus] a una frecuencia limitada y a media resolución.
 * - Gestiona los cambios de resolución y orientación redimensionando la pantalla virtual.
 * - Detecta la pérdida de la sesión (el sistema o el usuario la detienen) y detiene el bot si estaba activo.
 * - Libera todos los recursos al terminar.
 */
class CaptureService : Service() {

    private var proyeccion: MediaProjection? = null
    private var lector: ImageReader? = null
    private var pantallaVirtual: VirtualDisplay? = null
    private var hilo: HandlerThread? = null
    private var manejador: Handler? = null
    private var superposicion: OverlayController? = null
    private lateinit var displayManager: DisplayManager

    private var anchoCaptura = 0
    private var altoCaptura = 0
    private var dpi = 0
    private var ultimoFotogramaMs = 0L
    private var finalizado = false

    private val llamadaProyeccion = object : MediaProjection.Callback() {
        override fun onStop() {
            // Se llama en el hilo de captura; el resto del servicio trabaja en el principal.
            Handler(Looper.getMainLooper()).post { alPerderLaCaptura() }
        }
    }

    private val escuchaPantalla = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}

        override fun onDisplayRemoved(displayId: Int) {}

        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY) ajustarATamanoDePantalla()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val h = HandlerThread("arosbot-captura")
        h.start()
        hilo = h
        manejador = Handler(h.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACCION_DETENER -> {
                detener("Captura detenida por el usuario")
            }
            ACCION_EMERGENCIA -> {
                BotCore.stateMachine.emergencyStop("Parada de emergencia desde la notificación")
            }
            else -> {
                val codigo = intent?.getIntExtra(EXTRA_CODIGO, Activity.RESULT_CANCELED)
                    ?: Activity.RESULT_CANCELED
                val datos = intent?.let {
                    IntentCompat.getParcelableExtra(it, EXTRA_DATOS, Intent::class.java)
                }
                iniciar(codigo, datos)
            }
        }
        return START_NOT_STICKY
    }

    private fun iniciar(codigo: Int, datos: Intent?) {
        if (proyeccion != null) return

        // Android exige llamar a startForeground enseguida y ANTES de obtener la proyección.
        crearCanalDeNotificacion()
        ServiceCompat.startForeground(
            this,
            ID_NOTIFICACION,
            construirNotificacion(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        if (codigo != Activity.RESULT_OK || datos == null) {
            BotCore.log.error("Captura", "El usuario no concedió el permiso de captura de pantalla")
            detener("Permiso de captura no concedido")
            return
        }

        val gestor = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val nueva = try {
            gestor.getMediaProjection(codigo, datos)
        } catch (e: Exception) {
            BotCore.log.error("Captura", "No se pudo obtener la proyección: ${e.message}")
            null
        }
        if (nueva == null) {
            detener("No se pudo iniciar la captura")
            return
        }
        proyeccion = nueva
        // Desde Android 14 hay que registrar la llamada antes de crear la pantalla virtual.
        nueva.registerCallback(llamadaProyeccion, manejador)

        medirPantalla()
        val nuevoLector = crearLector(anchoCaptura, altoCaptura)
        lector = nuevoLector
        pantallaVirtual = nueva.createVirtualDisplay(
            "ArosBot-captura",
            anchoCaptura,
            altoCaptura,
            dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            nuevoLector.surface,
            null,
            manejador
        )
        displayManager.registerDisplayListener(escuchaPantalla, manejador)

        var hayCapaSuperpuesta = false
        if (Settings.canDrawOverlays(this)) {
            val controlador = OverlayController(this)
            controlador.mostrar()
            superposicion = controlador
            hayCapaSuperpuesta = true
        } else {
            BotCore.log.aviso(
                "Captura",
                "Sin permiso de superposición: la captura funciona, pero no se verán los recuadros sobre el juego"
            )
        }

        FrameBus.sesionIniciada(hayCapaSuperpuesta)
        BotCore.log.info("Captura", "Captura iniciada a ${anchoCaptura}x$altoCaptura")
    }

    private fun alPerderLaCaptura() {
        if (finalizado) return
        BotCore.log.aviso("Captura", "Se perdió la sesión de captura de pantalla")
        val estado = BotCore.stateMachine.state.value
        if (estado == BotState.PREPARANDO || estado == BotState.ACTIVO ||
            estado == BotState.PAUSADO || estado == BotState.INICIANDO_SESION
        ) {
            BotCore.stateMachine.fail("Se perdió la captura de pantalla")
        }
        detener("Sesión de captura terminada")
    }

    private fun medirPantalla() {
        val metricas = DisplayMetrics()
        leerMetricasReales(metricas)
        anchoCaptura = ((metricas.widthPixels * FrameBus.ESCALA_CAPTURA).toInt()).coerceAtLeast(64) and 1.inv()
        altoCaptura = ((metricas.heightPixels * FrameBus.ESCALA_CAPTURA).toInt()).coerceAtLeast(64) and 1.inv()
        dpi = metricas.densityDpi
    }

    @Suppress("DEPRECATION")
    private fun leerMetricasReales(metricas: DisplayMetrics) {
        displayManager.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(metricas)
    }

    /** Cambio de resolución u orientación: se redimensiona la pantalla virtual y se recrea el lector. */
    private fun ajustarATamanoDePantalla() {
        if (finalizado || pantallaVirtual == null) return
        val anchoAntes = anchoCaptura
        val altoAntes = altoCaptura
        medirPantalla()
        if (anchoCaptura == anchoAntes && altoCaptura == altoAntes) return

        val nuevoLector = crearLector(anchoCaptura, altoCaptura)
        pantallaVirtual?.resize(anchoCaptura, altoCaptura, dpi)
        pantallaVirtual?.surface = nuevoLector.surface
        lector?.close()
        lector = nuevoLector
        BotCore.log.info("Captura", "Resolución u orientación cambiada: ${anchoCaptura}x$altoCaptura")
    }

    private fun crearLector(ancho: Int, alto: Int): ImageReader {
        val nuevo = ImageReader.newInstance(ancho, alto, PixelFormat.RGBA_8888, 2)
        nuevo.setOnImageAvailableListener({ r ->
            val imagen = try {
                r.acquireLatestImage()
            } catch (e: Exception) {
                null
            }
            if (imagen != null) {
                try {
                    val ahora = SystemClock.elapsedRealtime()
                    if (ahora - ultimoFotogramaMs >= FrameBus.intervaloMs) {
                        ultimoFotogramaMs = ahora
                        FrameBus.publicar(imagenABitmap(imagen))
                    }
                } finally {
                    imagen.close()
                }
            }
        }, manejador)
        return nuevo
    }

    private fun imagenABitmap(imagen: Image): Bitmap {
        val plano = imagen.planes[0]
        val buffer = plano.buffer
        val tamanoPixel = plano.pixelStride
        val relleno = plano.rowStride - tamanoPixel * imagen.width
        val ancho = imagen.width + relleno / tamanoPixel
        val completo = Bitmap.createBitmap(ancho, imagen.height, Bitmap.Config.ARGB_8888)
        completo.copyPixelsFromBuffer(buffer)
        if (relleno == 0) return completo
        val recortado = Bitmap.createBitmap(completo, 0, 0, imagen.width, imagen.height)
        completo.recycle()
        return recortado
    }

    private fun detener(motivo: String) {
        if (finalizado) return
        finalizado = true

        LiveDetection.detener()
        superposicion?.ocultar()
        superposicion = null
        try {
            displayManager.unregisterDisplayListener(escuchaPantalla)
        } catch (e: Exception) {
            // Ya estaba desregistrada.
        }
        pantallaVirtual?.release()
        pantallaVirtual = null
        lector?.close()
        lector = null
        proyeccion?.let {
            try {
                it.unregisterCallback(llamadaProyeccion)
                it.stop()
            } catch (e: Exception) {
                // La proyección ya estaba detenida.
            }
        }
        proyeccion = null

        FrameBus.sesionTerminada()
        BotCore.log.info("Captura", "Captura detenida: $motivo")
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        detener("Servicio destruido")
        hilo?.quitSafely()
        hilo = null
        super.onDestroy()
    }

    private fun crearCanalDeNotificacion() {
        val canal = NotificationChannel(
            CANAL,
            getString(R.string.captura_canal),
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(canal)
    }

    private fun construirNotificacion(): Notification {
        val abrir = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val detenerIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, CaptureService::class.java).setAction(ACCION_DETENER),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val emergenciaIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, CaptureService::class.java).setAction(ACCION_EMERGENCIA),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CANAL)
            .setSmallIcon(R.drawable.ic_stat_arosbot)
            .setContentTitle(getString(R.string.captura_notif_titulo))
            .setContentText(getString(R.string.captura_notif_texto))
            .setOngoing(true)
            .setContentIntent(abrir)
            .addAction(0, getString(R.string.captura_notif_detener), detenerIntent)
            .addAction(0, getString(R.string.captura_notif_emergencia), emergenciaIntent)
            .build()
    }

    companion object {
        private const val CANAL = "captura"
        private const val ID_NOTIFICACION = 1001
        private const val ACCION_DETENER = "com.arosbot.ai.DETENER_CAPTURA"
        private const val ACCION_EMERGENCIA = "com.arosbot.ai.PARADA_EMERGENCIA"
        private const val EXTRA_CODIGO = "codigo"
        private const val EXTRA_DATOS = "datos"

        fun iniciar(contexto: Context, codigoResultado: Int, datos: Intent?) {
            val intent = Intent(contexto, CaptureService::class.java)
            intent.putExtra(EXTRA_CODIGO, codigoResultado)
            if (datos != null) intent.putExtra(EXTRA_DATOS, datos)
            ContextCompat.startForegroundService(contexto, intent)
        }

        fun detener(contexto: Context) {
            if (!FrameBus.estado.value.activa) return
            contexto.startService(
                Intent(contexto, CaptureService::class.java).setAction(ACCION_DETENER)
            )
        }
    }
}
