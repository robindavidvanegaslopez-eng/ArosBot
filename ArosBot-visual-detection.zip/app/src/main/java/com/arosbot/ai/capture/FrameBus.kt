package com.arosbot.ai.capture

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.arosbot.ai.core.BotCore
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class EstadoCaptura(
    val activa: Boolean = false,
    val ancho: Int = 0,
    val alto: Int = 0,
    val fotogramas: Long = 0L,
    val ultimoMs: Long = 0L,
    val superposicion: Boolean = false
)

/**
 * Canal entre la captura de pantalla y el resto de módulos: guarda el último fotograma
 * real recibido de MediaProjection y el estado de la sesión.
 */
object FrameBus {

    /** Los fotogramas se capturan a esta fracción de la resolución real de la pantalla. */
    const val ESCALA_CAPTURA = 0.5f

    @Volatile
    private var ultimo: Bitmap? = null
    private val contador = AtomicLong(0L)

    private val _estado = MutableStateFlow(EstadoCaptura())
    val estado: StateFlow<EstadoCaptura> = _estado.asStateFlow()

    fun publicar(fotograma: Bitmap) {
        ultimo = fotograma
        val n = contador.incrementAndGet()
        _estado.value = _estado.value.copy(
            ancho = fotograma.width,
            alto = fotograma.height,
            fotogramas = n,
            ultimoMs = System.currentTimeMillis()
        )
    }

    fun ultimoFotograma(): Bitmap? = ultimo

    /** Copia independiente del último fotograma. */
    fun instantanea(): Bitmap? = ultimo?.copy(Bitmap.Config.ARGB_8888, false)

    fun sesionIniciada(superposicion: Boolean) {
        ultimo = null
        contador.set(0L)
        _estado.value = EstadoCaptura(activa = true, superposicion = superposicion)
    }

    fun sesionTerminada() {
        ultimo = null
        _estado.value = EstadoCaptura()
    }

    /** Heurística sencilla: una captura bloqueada por el juego (FLAG_SECURE) sale completamente negra. */
    fun pareceNegro(b: Bitmap): Boolean {
        if (b.width <= 0 || b.height <= 0) return true
        val pasosX = 16
        val pasosY = 16
        for (i in 0 until pasosX) {
            for (j in 0 until pasosY) {
                val p = b.getPixel(
                    (i * (b.width - 1)) / (pasosX - 1),
                    (j * (b.height - 1)) / (pasosY - 1)
                )
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val bl = p and 0xFF
                if (r + g + bl > 24) return false
            }
        }
        return true
    }
}

/**
 * Fotograma de trabajo: una captura real que el usuario toma mientras está en el juego
 * (con la burbuja o con la cuenta atrás) y que luego se usa para dibujar áreas y probar
 * la detección dentro de la aplicación.
 */
object CapturaDeTrabajo {

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var cuenta: Job? = null

    private val _fotograma = MutableStateFlow<Bitmap?>(null)
    val fotograma: StateFlow<Bitmap?> = _fotograma.asStateFlow()

    /** Segundos que faltan para la captura; 0 si no hay cuenta atrás en marcha. */
    private val _cuentaAtras = MutableStateFlow(0)
    val cuentaAtras: StateFlow<Int> = _cuentaAtras.asStateFlow()

    /** Toma el último fotograma recibido. Devuelve false si no hay captura activa. */
    fun capturarAhora(): Boolean {
        val copia = FrameBus.instantanea()
        if (copia == null) {
            avisar("No hay captura activa o todavía no llegó ningún fotograma")
            BotCore.log.aviso("Captura", "No se pudo guardar el fotograma de trabajo: sin fotogramas")
            return false
        }
        _fotograma.value = copia
        val negro = FrameBus.pareceNegro(copia)
        // Un fotograma real y no negro prueba que MediaProjection funciona en este dispositivo.
        if (!negro) BotCore.marcarVerificadoPersistente(1)
        BotCore.log.info(
            "Captura",
            "Fotograma de trabajo guardado (${copia.width}x${copia.height})" +
                if (negro) " — AVISO: sale completamente negro" else ""
        )
        avisar(
            if (negro) {
                "Fotograma guardado, pero sale negro: el juego puede bloquear la captura"
            } else {
                "Fotograma guardado. Vuelve a ArosBot AI para usarlo"
            }
        )
        return true
    }

    @Synchronized
    fun iniciarCuentaAtras(segundos: Int) {
        cuenta?.cancel()
        cuenta = alcance.launch {
            for (s in segundos downTo 1) {
                _cuentaAtras.value = s
                delay(1000L)
            }
            _cuentaAtras.value = 0
            capturarAhora()
        }
    }

    private fun avisar(texto: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(BotCore.appContext, texto, Toast.LENGTH_LONG).show()
        }
    }
}
