package com.arosbot.ai.capture

import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.MacroDeClics
import com.arosbot.ai.core.MacroGrabado
import com.arosbot.ai.core.PasoDeMacro
import com.arosbot.ai.input.ArosAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class EstadoMacro(val grabando: Boolean = false, val texto: String = "", val pasos: Int = 0)

/**
 * Graba el macro del cofre. Android no deja a una app leer los toques que haces en otra, así que durante la
 * grabación se pone una capa transparente (teñida de azul para que se note) que recibe tus toques, los
 * anota con su posición, duración y pausa, y al instante los repite en el juego mediante el servicio de
 * accesibilidad, quitando la capa de en medio solo durante ese toque. Para ti es como tocar el juego con
 * un retardo de una fracción de segundo. Se termina con el botón «Terminar macro» de la propia capa.
 */
object GrabadorDeMacro {

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _estado = MutableStateFlow(EstadoMacro())
    val estado: StateFlow<EstadoMacro> = _estado.asStateFlow()

    private var raiz: FrameLayout? = null
    private var parametros: LayoutParams? = null
    private var etiqueta: TextView? = null
    private val pasos = ArrayList<PasoDeMacro>()
    private var ultimoFinMs = 0L
    private var ocupado = false
    private var bajaX = 0f
    private var bajaY = 0f
    private var bajaMs = 0L
    private var ultimaX = 0f
    private var ultimaY = 0f
    private var anchoPantalla = 0
    private var altoPantalla = 0
    private var cuenta: kotlinx.coroutines.Job? = null
    private var barraEspera: View? = null

    fun iniciar() {
        if (_estado.value.grabando) return
        val ctx = BotCore.appContext
        if (!ArosAccessibilityService.conectado.value) {
            _estado.value = EstadoMacro(false, "Activa el servicio de accesibilidad de ArosBot AI: sin él no se pueden repetir los toques.")
            return
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(ctx)) {
            _estado.value = EstadoMacro(false, "Falta el permiso de superposición (se pide al iniciar la captura).")
            return
        }
        // La barra de espera sale al instante (antes había una cuenta atrás de 6 s que parecía un retraso):
        // cambia al juego, colócate en el cofre y pulsa «Empezar a grabar» cuando estés listo.
        _estado.value = EstadoMacro(
            true,
            "Cambia al juego y colócate donde el bot llegará al cofre; luego pulsa «Empezar a grabar» en la barra azul."
        )
        mostrarEspera()
    }

    private fun mostrarEspera() {
        val ctx = BotCore.appContext
        val wm = ctx.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager
        val d = ctx.resources.displayMetrics.density
        val barra = LinearLayout(ctx)
        barra.orientation = LinearLayout.HORIZONTAL
        barra.gravity = Gravity.CENTER_VERTICAL
        barra.setBackgroundColor(Color.argb(230, 20, 30, 50))
        barra.setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
        val texto = TextView(ctx)
        texto.setTextColor(Color.WHITE)
        texto.textSize = 13f
        texto.text = "Macro del cofre: coloca el juego como al llegar al cofre y pulsa «Empezar a grabar»."
        val btnEmpezar = Button(ctx)
        btnEmpezar.text = "Empezar a grabar"
        btnEmpezar.setOnClickListener {
            quitarEspera()
            mostrar()
        }
        val btnCancelar = Button(ctx)
        btnCancelar.text = "Cancelar"
        btnCancelar.setOnClickListener { cancelar() }
        barra.addView(texto, LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        barra.addView(btnEmpezar)
        barra.addView(btnCancelar)
        val p = LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP
        p.alpha = 0.8f
        wm.addView(barra, p)
        barraEspera = barra
    }

    private fun quitarEspera() {
        val b = barraEspera ?: return
        barraEspera = null
        try {
            (BotCore.appContext.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager).removeView(b)
        } catch (e: IllegalArgumentException) {
            // Ya no estaba.
        }
    }

    private fun mostrar() {
        val ctx = BotCore.appContext
        val wm = ctx.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager
        val (ancho, alto) = PantallaReal.tamano(ctx)
        anchoPantalla = ancho
        altoPantalla = alto
        pasos.clear()
        ultimoFinMs = SystemClock.elapsedRealtime()
        ocupado = false
        val d = ctx.resources.displayMetrics.density

        val capa = FrameLayout(ctx)
        capa.setBackgroundColor(Color.argb(40, 0, 120, 255))

        val barra = LinearLayout(ctx)
        barra.orientation = LinearLayout.HORIZONTAL
        barra.gravity = Gravity.CENTER_VERTICAL
        barra.setBackgroundColor(Color.argb(230, 20, 30, 50))
        barra.setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
        val texto = TextView(ctx)
        texto.setTextColor(Color.WHITE)
        texto.textSize = 13f
        texto.text = "● Grabando macro: 0 pasos. Haz en el juego los toques del cofre."
        etiqueta = texto
        val btnTerminar = Button(ctx)
        btnTerminar.text = "Terminar macro"
        btnTerminar.setOnClickListener { terminar() }
        val btnCancelar = Button(ctx)
        btnCancelar.text = "Cancelar"
        btnCancelar.setOnClickListener { cancelar() }
        barra.addView(texto, LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        barra.addView(btnTerminar)
        barra.addView(btnCancelar)
        capa.addView(
            barra,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            )
        )

        capa.setOnTouchListener { _, e -> tocar(e) }

        val p = LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.MATCH_PARENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN or LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.alpha = 0.8f
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(capa, p)
        raiz = capa
        parametros = p
        _estado.value = EstadoMacro(true, "Grabando: haz en el juego los toques del cofre y pulsa «Terminar macro».", 0)
    }

    private fun tocar(e: MotionEvent): Boolean {
        if (ocupado) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                bajaX = e.rawX
                bajaY = e.rawY
                ultimaX = e.rawX
                ultimaY = e.rawY
                bajaMs = SystemClock.elapsedRealtime()
            }
            MotionEvent.ACTION_MOVE -> {
                ultimaX = e.rawX
                ultimaY = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                ultimaX = e.rawX
                ultimaY = e.rawY
                val ahora = SystemClock.elapsedRealtime()
                if (pasos.size >= MacroDeClics.MAX_PASOS) {
                    Toast.makeText(BotCore.appContext, "Máximo de pasos alcanzado: pulsa «Terminar macro».", Toast.LENGTH_SHORT).show()
                    return true
                }
                val paso = MacroDeClics.clasificar(
                    bajaX, bajaY, ultimaX, ultimaY, ahora - bajaMs, anchoPantalla, altoPantalla, bajaMs - ultimoFinMs
                )
                pasos.add(paso)
                etiqueta?.text = "● Grabando macro: ${pasos.size} paso(s). Sigue con el siguiente toque o termina."
                _estado.value = EstadoMacro(true, "Grabando: ${pasos.size} paso(s).", pasos.size)
                repetirAhora(paso)
            }
        }
        return true
    }

    /** Repite el toque en el juego quitando la capa de en medio solo mientras dura. */
    private fun repetirAhora(paso: PasoDeMacro) {
        val servicio = ArosAccessibilityService.instancia ?: return
        val wm = BotCore.appContext.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager
        val capa = raiz ?: return
        val p = parametros ?: return
        ocupado = true
        p.flags = p.flags or LayoutParams.FLAG_NOT_TOUCHABLE
        try {
            wm.updateViewLayout(capa, p)
        } catch (e: Exception) {
            ocupado = false
            return
        }
        alcance.launch {
            val x = paso.x * anchoPantalla
            val y = paso.y * altoPantalla
            when (paso.tipo) {
                com.arosbot.ai.core.TipoDePaso.TOQUE -> servicio.tocar(x, y, paso.duracionMs)
                com.arosbot.ai.core.TipoDePaso.DESLIZAR ->
                    servicio.deslizar(x, y, paso.x2 * anchoPantalla, paso.y2 * altoPantalla, paso.duracionMs)
            }
            p.flags = p.flags and LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            try {
                if (raiz != null) wm.updateViewLayout(capa, p)
            } catch (e: Exception) {
                // La capa ya se había quitado.
            }
            ultimoFinMs = SystemClock.elapsedRealtime()
            ocupado = false
        }
    }

    fun terminar() {
        val macro = MacroGrabado(anchoPantalla, altoPantalla, pasos.toList())
        quitar()
        val problema = MacroDeClics.problema(macro)
        if (problema != null) {
            _estado.value = EstadoMacro(false, "Macro no guardado: $problema")
            return
        }
        BotCore.settings.macroCofre = MacroDeClics.codificar(macro)
        val texto = "Macro del cofre guardado: ${MacroDeClics.resumen(macro)}."
        BotCore.log.info("Cofre", texto)
        _estado.value = EstadoMacro(false, texto, macro.pasos.size)
    }

    /** Cancela la grabación en curso (también desde la parada de emergencia, que puede venir de otro hilo). */
    fun cancelar() {
        if (!_estado.value.grabando) return
        val accion = {
            quitar()
            _estado.value = EstadoMacro(false, "Grabación del macro cancelada: no se guardó nada.")
        }
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) accion()
        else android.os.Handler(android.os.Looper.getMainLooper()).post { accion() }
    }

    private fun quitar() {
        quitarEspera()
        cuenta?.cancel()
        cuenta = null
        val capa = raiz
        raiz = null
        if (capa != null) {
            try {
                (BotCore.appContext.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager).removeView(capa)
            } catch (e: IllegalArgumentException) {
                // La capa ya no estaba.
            }
        }
        ocupado = false
    }
}
