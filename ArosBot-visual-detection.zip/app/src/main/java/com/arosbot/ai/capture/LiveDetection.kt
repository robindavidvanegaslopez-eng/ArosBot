package com.arosbot.ai.capture

import android.os.SystemClock
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.Detection
import com.arosbot.ai.vision.Deteccion
import com.arosbot.ai.vision.VisionEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class EstadoDeteccion(
    val activa: Boolean = false,
    val detecciones: List<Detection> = emptyList(),
    val ancho: Int = 0,
    val alto: Int = 0,
    val duracionMs: Long = 0L
)

/**
 * Bucle de detección sobre los fotogramas reales de la captura. Solo procesa fotogramas nuevos
 * (si la pantalla no cambia, Android no entrega fotogramas y se conservan las últimas detecciones).
 * Se apaga solo si la captura termina y con la parada de emergencia.
 */
object LiveDetection {

    private const val PAUSA_MINIMA_MS = 400L
    private const val AVISO_CADA_MS = 15_000L
    private const val INTERVALO_ESTADISTICAS_MS = 5_000L

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var trabajo: Job? = null

    private val _estado = MutableStateFlow(EstadoDeteccion())
    val estado: StateFlow<EstadoDeteccion> = _estado.asStateFlow()

    @Synchronized
    fun iniciar(): Boolean {
        if (trabajo?.isActive == true) return true
        if (!VisionEngine.inicializar()) {
            BotCore.log.error("Detección", "No se puede iniciar: OpenCV no está disponible")
            return false
        }
        if (!FrameBus.estado.value.activa) {
            BotCore.log.aviso("Detección", "No se puede iniciar: la captura de pantalla no está activa")
            return false
        }
        _estado.value = EstadoDeteccion(activa = true)
        trabajo = alcance.launch { bucle() }
        BotCore.log.info("Detección", "Detección en vivo iniciada")
        return true
    }

    @Synchronized
    fun detener() {
        val estabaActiva = trabajo?.isActive == true
        trabajo?.cancel()
        trabajo = null
        _estado.value = EstadoDeteccion()
        BotCore.telemetry.update { it.copy(recursosDetectados = 0) }
        if (estabaActiva) BotCore.log.info("Detección", "Detección en vivo detenida")
    }

    private suspend fun bucle() {
        var ultimoProcesado = -1L
        var ultimoAviso = 0L
        var ultimoRegistro = 0L
        while (currentCoroutineContext().isActive) {
            if (!FrameBus.estado.value.activa) {
                detener()
                return
            }
            val fotograma = FrameBus.ultimoFotograma()
            val numero = FrameBus.estado.value.fotogramas
            if (fotograma == null || numero == ultimoProcesado) {
                delay(100L)
                continue
            }
            ultimoProcesado = numero

            try {
                val resultado = Deteccion.enAreasActivas(
                    fotograma,
                    BotCore.store.areas.value,
                    BotCore.store.materiales.value,
                    BotCore.store.directorioMateriales
                )
                _estado.value = EstadoDeteccion(
                    activa = true,
                    detecciones = resultado.detecciones,
                    ancho = fotograma.width,
                    alto = fotograma.height,
                    duracionMs = resultado.duracionMs
                )
                BotCore.telemetry.update { it.copy(recursosDetectados = resultado.detecciones.size) }

                val ahora = SystemClock.elapsedRealtime()
                if (resultado.avisos.isNotEmpty() && ahora - ultimoAviso > AVISO_CADA_MS) {
                    ultimoAviso = ahora
                    resultado.avisos.forEach { BotCore.log.aviso("Detección", it) }
                }

                // Estadísticas por material. Se anotan como máximo cada INTERVALO_ESTADISTICAS_MS
                // para no escribir en la base de datos (ni redibujar las listas) en cada ciclo.
                if (ahora - ultimoRegistro >= INTERVALO_ESTADISTICAS_MS) {
                    val porMaterial = resultado.detecciones.groupBy { it.materialId }
                    if (porMaterial.isNotEmpty()) ultimoRegistro = ahora
                    porMaterial.forEach { (id, lista) ->
                        BotCore.store.registrarResultado(id, lista.size, lista.maxOf { it.score })
                    }
                }
            } catch (e: Exception) {
                BotCore.log.error("Detección", "Error en un ciclo de detección: ${e.message}")
                delay(1000L)
            }
            delay(PAUSA_MINIMA_MS)
        }
    }
}
