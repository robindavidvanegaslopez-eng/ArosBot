package com.arosbot.ai.capture

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.widget.LinearLayout
import android.widget.TextView
import com.arosbot.ai.automation.GrabadorDeRuta
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.Detection
import com.arosbot.ai.core.NormRect
import com.arosbot.ai.input.ArosAccessibilityService
import kotlin.math.abs
import kotlin.math.max
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Superposición sobre el juego: una capa transparente que no captura toques, donde se dibujan
 * los recuadros verdes y las áreas de rastreo, y una pequeña burbuja con controles.
 *
 * Android no permite colocar una superposición por DEBAJO de otra ventana. Por eso, cuando
 * aparezca el selector de cuentas de Google (Fase 3), se llamará a [ocultarTemporalmente]
 * para quitarla de en medio y el bot se pausará.
 */
class OverlayController(private val contexto: Context) {

    private val wm = contexto.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var capa: CapaDeteccionView? = null
    private var burbuja: LinearLayout? = null
    private var menu: LinearLayout? = null
    private var recuadrosVisibles = true

    fun mostrar() {
        val vistaCapa = CapaDeteccionView(contexto)
        val parametrosCapa = LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.MATCH_PARENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or
                LayoutParams.FLAG_NOT_TOUCHABLE or
                LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        // Desde Android 12, una ventana superpuesta con opacidad mayor que 0,8 bloquea los toques
        // hacia las apps de debajo (el juego, el selector de cuentas de Google, el selector de
        // archivos...), aunque no sea táctil. Con 0,8 o menos los toques pasan.
        parametrosCapa.alpha = 0.8f
        if (Build.VERSION.SDK_INT >= 28) {
            parametrosCapa.layoutInDisplayCutoutMode =
                LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(vistaCapa, parametrosCapa)
        capa = vistaCapa

        crearBurbuja()

        alcance.launch {
            LiveDetection.estado.collect { e ->
                capa?.actualizar(e.detecciones, e.ancho, e.alto)
            }
        }
        alcance.launch {
            BotCore.store.areas.collect { lista ->
                capa?.areas = lista.filter { it.activa }.map { Pair(it.nombre, it.rect) }
            }
        }
        // Selector de cuentas de Google: Android no permite poner la superposición por debajo de
        // otra ventana, así que se quita de en medio, se suelta toda entrada y el bot se pausa.
        alcance.launch {
            ArosAccessibilityService.ventanaGoogle.collect { hayGoogle ->
                ocultarTemporalmente(hayGoogle)
                if (hayGoogle) {
                    BotCore.entrada.soltarTodo()
                    if (BotCore.stateMachine.state.value == BotState.ACTIVO) {
                        BotCore.stateMachine.transition(
                            BotState.PAUSADO,
                            "Selector de cuentas de Google en pantalla"
                        )
                    }
                }
            }
        }
    }

    private fun crearBurbuja() {
        val d = contexto.resources.displayMetrics.density
        fun dp(v: Int): Int = (v * d).toInt()

        val raiz = LinearLayout(contexto)
        raiz.orientation = LinearLayout.VERTICAL

        val circulo = TextView(contexto)
        circulo.text = "A"
        circulo.gravity = Gravity.CENTER
        circulo.setTextColor(Color.WHITE)
        circulo.textSize = 18f
        circulo.typeface = Typeface.DEFAULT_BOLD
        val fondoCirculo = GradientDrawable()
        fondoCirculo.shape = GradientDrawable.OVAL
        fondoCirculo.setColor(Color.parseColor("#CC1F6F5C"))
        circulo.background = fondoCirculo
        circulo.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))

        val contenedorMenu = LinearLayout(contexto)
        contenedorMenu.orientation = LinearLayout.VERTICAL
        contenedorMenu.visibility = View.GONE
        contenedorMenu.setPadding(dp(8), dp(8), dp(8), dp(8))
        val fondoMenu = GradientDrawable()
        fondoMenu.cornerRadius = dp(12).toFloat()
        fondoMenu.setColor(Color.parseColor("#E6212121"))
        contenedorMenu.background = fondoMenu

        fun elemento(texto: String, color: Int, accion: () -> Unit): TextView {
            val t = TextView(contexto)
            t.text = texto
            t.setTextColor(color)
            t.textSize = 14f
            t.setPadding(dp(12), dp(10), dp(12), dp(10))
            t.setOnClickListener {
                contenedorMenu.visibility = View.GONE
                accion()
            }
            return t
        }

        contenedorMenu.addView(
            elemento("Capturar fotograma", Color.WHITE) { CapturaDeTrabajo.capturarAhora() }
        )
        val terminarRuta = elemento("Terminar ruta", Color.parseColor("#8FE3A0")) {
            GrabadorDeRuta.terminar()
        }
        terminarRuta.visibility = View.GONE
        contenedorMenu.addView(terminarRuta)
        alcance.launch {
            GrabadorDeRuta.estado.collect { e ->
                terminarRuta.visibility = if (e.grabando) View.VISIBLE else View.GONE
            }
        }
        contenedorMenu.addView(
            elemento("Mostrar / ocultar recuadros", Color.WHITE) { alternarRecuadros() }
        )
        contenedorMenu.addView(
            elemento("Detener captura", Color.WHITE) { CaptureService.detener(contexto) }
        )
        contenedorMenu.addView(
            elemento("PARADA DE EMERGENCIA", Color.parseColor("#FF6B6B")) {
                BotCore.stateMachine.emergencyStop("Parada de emergencia desde la burbuja")
            }
        )

        raiz.addView(circulo)
        raiz.addView(contenedorMenu)

        val parametros = LayoutParams(
            LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        parametros.gravity = Gravity.TOP or Gravity.START
        parametros.x = dp(8)
        parametros.y = dp(160)
        // Desde Android 12 una ventana con opacidad alta bloquea los toques hacia la app de debajo.
        parametros.alpha = 0.8f

        circulo.setOnTouchListener(object : View.OnTouchListener {
            private var xInicial = 0
            private var yInicial = 0
            private var toqueX = 0f
            private var toqueY = 0f
            private var movido = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        xInicial = parametros.x
                        yInicial = parametros.y
                        toqueX = e.rawX
                        toqueY = e.rawY
                        movido = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - toqueX).toInt()
                        val dy = (e.rawY - toqueY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) movido = true
                        if (movido) {
                            parametros.x = xInicial + dx
                            parametros.y = yInicial + dy
                            wm.updateViewLayout(raiz, parametros)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!movido) {
                            contenedorMenu.visibility =
                                if (contenedorMenu.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                            wm.updateViewLayout(raiz, parametros)
                        }
                        return true
                    }
                }
                return false
            }
        })

        wm.addView(raiz, parametros)
        burbuja = raiz
        menu = contenedorMenu
    }

    private fun alternarRecuadros() {
        recuadrosVisibles = !recuadrosVisibles
        capa?.visibility = if (recuadrosVisibles) View.VISIBLE else View.INVISIBLE
    }

    /** Oculta o devuelve toda la superposición (por ejemplo, mientras aparece el selector de Google). */
    fun ocultarTemporalmente(oculto: Boolean) {
        capa?.visibility = when {
            oculto -> View.GONE
            recuadrosVisibles -> View.VISIBLE
            else -> View.INVISIBLE
        }
        burbuja?.visibility = if (oculto) View.GONE else View.VISIBLE
    }

    fun ocultar() {
        alcance.cancel()
        capa?.let { quitar(it) }
        burbuja?.let { quitar(it) }
        capa = null
        burbuja = null
        menu = null
    }

    private fun quitar(vista: View) {
        try {
            wm.removeView(vista)
        } catch (e: IllegalArgumentException) {
            // La vista ya no estaba añadida.
        }
    }
}

/** Capa transparente que dibuja las áreas de rastreo y los recuadros verdes de los objetos reconocidos. */
class CapaDeteccionView(contexto: Context) : View(contexto) {

    private var detecciones: List<Detection> = emptyList()
    private var anchoFotograma = 0
    private var altoFotograma = 0

    var areas: List<Pair<String, NormRect>> = emptyList()
        set(valor) {
            field = valor
            postInvalidate()
        }

    private val verde = Paint().apply {
        color = Color.rgb(0, 230, 60)
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val textoVerde = Paint().apply {
        color = Color.rgb(0, 230, 60)
        style = Paint.Style.FILL
        textSize = 30f
        isAntiAlias = true
    }
    private val celeste = Paint().apply {
        color = Color.rgb(0, 170, 255)
        style = Paint.Style.STROKE
        strokeWidth = 3f
        pathEffect = DashPathEffect(floatArrayOf(16f, 10f), 0f)
    }
    private val textoCeleste = Paint().apply {
        color = Color.rgb(0, 170, 255)
        style = Paint.Style.FILL
        textSize = 28f
        isAntiAlias = true
    }

    fun actualizar(nuevas: List<Detection>, ancho: Int, alto: Int) {
        detecciones = nuevas
        anchoFotograma = ancho
        altoFotograma = alto
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return
        val w = width.toFloat()
        val h = height.toFloat()

        for ((nombre, r) in areas) {
            val izq = r.x * w
            val arr = r.y * h
            canvas.drawRect(izq, arr, (r.x + r.w) * w, (r.y + r.h) * h, celeste)
            canvas.drawText(nombre, izq + 6f, arr + textoCeleste.textSize, textoCeleste)
        }

        if (anchoFotograma <= 0 || altoFotograma <= 0) return
        val sx = w / anchoFotograma
        val sy = h / altoFotograma
        for (d in detecciones) {
            val izq = d.box.left * sx
            val arr = d.box.top * sy
            canvas.drawRect(izq, arr, d.box.right * sx, d.box.bottom * sy, verde)
            val etiqueta = d.nombre + " " + (d.score * 100f).toInt() + "%"
            canvas.drawText(etiqueta, izq, max(textoVerde.textSize, arr - 6f), textoVerde)
        }
    }
}
