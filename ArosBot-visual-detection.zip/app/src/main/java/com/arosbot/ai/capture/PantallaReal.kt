package com.arosbot.ai.capture

import android.content.Context
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.view.Display

/** Tamaño real de la pantalla en píxeles (el mismo sobre el que actúan los gestos y la captura). */
object PantallaReal {

    @Suppress("DEPRECATION")
    fun tamano(contexto: Context): Pair<Int, Int> {
        val gestor = contexto.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val metricas = DisplayMetrics()
        gestor.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(metricas)
        return Pair(metricas.widthPixels, metricas.heightPixels)
    }
}
