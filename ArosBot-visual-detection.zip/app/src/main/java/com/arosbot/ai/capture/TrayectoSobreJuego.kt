package com.arosbot.ai.capture

import com.arosbot.ai.core.PuntoXY
import com.arosbot.ai.core.VistaDeTrayecto
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Canal de la trayectoria que la superposición dibuja directamente sobre el juego. */
object TrayectoSobreJuego {

    private val _vista = MutableStateFlow<VistaDeTrayecto?>(null)
    val vista: StateFlow<VistaDeTrayecto?> = _vista.asStateFlow()

    fun publicar(puntos: List<PuntoXY>, x: Double, y: Double, indiceObjetivo: Int, ensenando: Boolean) {
        _vista.value = VistaDeTrayecto(puntos, x, y, indiceObjetivo, ensenando)
    }

    fun limpiar() {
        _vista.value = null
    }
}
