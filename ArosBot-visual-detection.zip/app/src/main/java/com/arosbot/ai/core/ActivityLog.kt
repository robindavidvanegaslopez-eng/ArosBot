package com.arosbot.ai.core

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class LogLevel { INFO, AVISO, ERROR }

data class LogEntry(
    val timeMillis: Long,
    val level: LogLevel,
    val source: String,
    val message: String
) {
    fun format(): String {
        val fecha = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(timeMillis))
        return "$fecha [${level.name}] $source: $message"
    }
}

/**
 * Registro de actividad y errores (módulo 18).
 *
 * - Mantiene en memoria las últimas [capacity] entradas para mostrarlas en pantalla.
 * - Si se indica un [file], añade cada entrada a ese archivo (con rotación a ~512 KB).
 *   La escritura se hace en un hilo aparte para no bloquear la interfaz.
 * - Es Kotlin puro, sin dependencias de Android, para poder probarlo con JUnit.
 */
class ActivityLog(
    private val file: File?,
    private val capacity: Int = 500
) {
    private val _entries = MutableStateFlow<List<LogEntry>>(emptyList())
    val entries: StateFlow<List<LogEntry>> = _entries.asStateFlow()

    private val writer: ExecutorService? =
        if (file != null) {
            Executors.newSingleThreadExecutor(ThreadFactory { r ->
                Thread(r, "arosbot-registro").apply { isDaemon = true }
            })
        } else {
            null
        }

    fun info(source: String, message: String) = add(LogLevel.INFO, source, message)

    fun aviso(source: String, message: String) = add(LogLevel.AVISO, source, message)

    fun error(source: String, message: String) = add(LogLevel.ERROR, source, message)

    /** Vacía la lista en pantalla. El archivo de historial no se toca. */
    fun clear() {
        _entries.value = emptyList()
    }

    @Synchronized
    private fun add(level: LogLevel, source: String, message: String) {
        val entry = LogEntry(System.currentTimeMillis(), level, source, message)
        val actual = _entries.value
        _entries.value =
            if (actual.size >= capacity) {
                actual.drop(actual.size - capacity + 1) + entry
            } else {
                actual + entry
            }
        persist(entry)
    }

    private fun persist(entry: LogEntry) {
        val destino = file ?: return
        writer?.execute {
            try {
                if (destino.exists() && destino.length() > MAX_FILE_BYTES) {
                    val anterior = File(destino.parentFile, destino.name + ".1")
                    anterior.delete()
                    destino.renameTo(anterior)
                }
                destino.appendText(entry.format() + "\n")
            } catch (_: Exception) {
                // El registro nunca debe romper la aplicación.
            }
        }
    }

    private companion object {
        const val MAX_FILE_BYTES = 512L * 1024L
    }
}
