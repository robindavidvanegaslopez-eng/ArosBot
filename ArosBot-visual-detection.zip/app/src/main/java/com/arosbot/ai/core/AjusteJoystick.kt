package com.arosbot.ai.core

import kotlin.math.abs
import kotlin.math.hypot

/** Círculo candidato encontrado en la imagen, en píxeles. [rango] 0 = el de más votos de la detección. */
data class Circulo(val cx: Double, val cy: Double, val radio: Double, val rango: Int)

/**
 * Elige cuál de los círculos detectados es el joystick, dado el cuadrado aproximado que marcó el
 * usuario (centro y radio en píxeles). Lógica pura, sin Android.
 *
 * Un joystick suele tener una base grande y una bola interior: el alcance del arrastre lo marca la base.
 * Se elige el círculo más parecido, en tamaño y posición, al cuadrado marcado: marca el cuadrado a ojo sobre
 * la base y el autoajuste lo afina; no busca el círculo mayor.
 */
object ElegirCirculoJoystick {

    const val RADIO_MINIMO = 0.4
    const val RADIO_MAXIMO = 1.6
    const val DESVIO_MAXIMO = 0.7
    const val CANDIDATOS_CONSIDERADOS = 6

    fun elegir(candidatos: List<Circulo>, zonaCx: Double, zonaCy: Double, zonaRadio: Double): Circulo? {
        if (zonaRadio <= 0.0) return null
        val validos = candidatos
            .sortedBy { it.rango }
            .take(CANDIDATOS_CONSIDERADOS)
            .filter {
                it.radio >= zonaRadio * RADIO_MINIMO &&
                    it.radio <= zonaRadio * RADIO_MAXIMO &&
                    hypot(it.cx - zonaCx, it.cy - zonaCy) <= zonaRadio * DESVIO_MAXIMO
            }
        if (validos.isEmpty()) return null
        // Se elige el círculo más parecido a lo marcado (tamaño y centro), con un pequeño premio a los de
        // más votos. Así repetir el autoajuste no hace crecer el círculo cada vez: se queda en el que
        // el usuario señaló, afinado, y no salta a círculos mayores del fondo.
        return validos.minByOrNull {
            abs(it.radio - zonaRadio) / zonaRadio +
                hypot(it.cx - zonaCx, it.cy - zonaCy) / zonaRadio +
                it.rango * 0.03
        }
    }

    /** Distancia en píxeles entre el centro marcado y el detectado, por si se quiere mostrar. */
    fun desplazamiento(a: Circulo, zonaCx: Double, zonaCy: Double): Double =
        hypot(a.cx - zonaCx, a.cy - zonaCy)

    fun cambioDeRadio(a: Circulo, zonaRadio: Double): Double = abs(a.radio - zonaRadio)
}
