package com.arosbot.ai.core

import kotlin.math.abs
import kotlin.math.hypot

/** Círculo candidato encontrado en la imagen, en píxeles. [rango] 0 = el de más votos de la detección. */
data class Circulo(val cx: Double, val cy: Double, val radio: Double, val rango: Int)

/**
 * Elige cuál de los círculos detectados es el joystick, dado el cuadrado aproximado que marcó el
 * usuario (centro y radio en píxeles). Lógica pura, sin Android.
 *
 * Un joystick suele tener una base grande y una bola interior: el alcance del arrastre lo marca la base,
 * así que entre los círculos cercanos al centro marcado y de tamaño razonable se prefiere el mayor de los
 * mejor puntuados.
 */
object ElegirCirculoJoystick {

    const val RADIO_MINIMO = 0.4
    const val RADIO_MAXIMO = 1.8
    const val DESVIO_MAXIMO = 0.7
    const val CANDIDATOS_CONSIDERADOS = 6

    fun elegir(candidatos: List<Circulo>, zonaCx: Double, zonaCy: Double, zonaRadio: Double): Circulo? {
        if (zonaRadio <= 0.0) return null
        val validos = candidatos
            .sortedBy { it.rango }
            .take(CANDIDATOS_CONSIDERADOS)
            .filter {
                it.radio >= zonaRadio * RADIO_MINIMO &&
                    it.radio <= zonaRadio * RADIO_MAXIMO &&
                    hypot(it.cx - zonaCx, it.cy - zonaCy) <= zonaRadio * DESVIO_MAXIMO
            }
        if (validos.isEmpty()) return null
        // Mayor radio; a igualdad aproximada (5 %), el mejor puntuado.
        return validos.sortedWith(
            compareByDescending<Circulo> { Math.round(it.radio / (zonaRadio * 0.05)) }.thenBy { it.rango }
        ).first()
    }

    /** Distancia en píxeles entre el centro marcado y el detectado, por si se quiere mostrar. */
    fun desplazamiento(a: Circulo, zonaCx: Double, zonaCy: Double): Double =
        hypot(a.cx - zonaCx, a.cy - zonaCy)

    fun cambioDeRadio(a: Circulo, zonaRadio: Double): Double = abs(a.radio - zonaRadio)
}
