package com.arosbot.ai.core

import kotlin.math.abs
import kotlin.math.hypot

/** Círculo candidato encontrado en la imagen, en píxeles. [rango] 0 = el de más votos de la detección. */
data class Circulo(val cx: Double, val cy: Double, val radio: Double, val rango: Int)

/**
 * Elige cuál de los círculos detectados es el joystick, dado el cuadrado aproximado que marcó el
 * usuario (centro y radio en píxeles). Lógica pura, sin Android.
 *
 * Un joystick suele tener una base grande y una bola interior: el alcance del arrastre lo marca la base.
 * Se elige el círculo más parecido, en tamaño y posición, al cuadrado marcado: marca el cuadrado a ojo sobre
 * la base y el autoajuste lo afina; no busca el círculo mayor.
 */
object ElegirCirculoJoystick {

    const val RADIO_MINIMO = 0.4
    const val RADIO_MAXIMO = 1.6
    const val DESVIO_MAXIMO = 0.7
    const val CANDIDATOS_CONSIDERADOS = 6

    fun elegir(candidatos: List<Circulo>, zonaCx: Double, zonaCy: Double, zonaRadio: Double): Circulo? {
        if (zonaRadio <= 0.0) return null
        val validos = candidatos
            .sortedBy { it.rango }
            .take(CANDIDATOS_CONSIDERADOS)
            .filter {
                it.radio >= zonaRadio * RADIO_MINIMO &&
                    it.radio <= zonaRadio * RADIO_MAXIMO &&
                    hypot(it.cx - zonaCx, it.cy - zonaCy) <= zonaRadio * DESVIO_MAXIMO
            }
        if (validos.isEmpty()) return null
        // Se elige el círculo más parecido a lo marcado (tamaño y centro), con un pequeño premio a los de
        // más votos. Así repetir el autoajuste no hace crecer el círculo cada vez: se queda en el que
        // el usuario señaló, afinado, y no salta a círculos mayores del fondo.
        return validos.minByOrNull {
            abs(it.radio - zonaRadio) / zonaRadio +
                hypot(it.cx - zonaCx, it.cy - zonaCy) / zonaRadio +
                it.rango * 0.03
        }
    }

    /** Distancia en píxeles entre el centro marcado y el detectado, por si se quiere mostrar. */
    fun desplazamiento(a: Circulo, zonaCx: Double, zonaCy: Double): Double =
        hypot(a.cx - zonaCx, a.cy - zonaCy)

    fun cambioDeRadio(a: Circulo, zonaRadio: Double): Double = abs(a.radio - zonaRadio)
}

/** Un punto en píxeles del fotograma. */
data class PuntoPx(val x: Double, val y: Double)

/** Centro y recorrido máximo del joystick, medidos al empujar la bola hasta el tope en cada dirección. */
data class MedidaJoystick(val cx: Double, val cy: Double, val radio: Double, val errorPx: Double) {

    /** Cuadrado normalizado (respecto a un fotograma de [ancho] x [alto]) con ese centro y radio. */
    fun aRect(ancho: Int, alto: Int): NormRect {
        val w = (2 * radio / ancho).toFloat().coerceIn(0.01f, 1f)
        val h = (2 * radio / alto).toFloat().coerceIn(0.01f, 1f)
        val x = ((cx - radio) / ancho).toFloat().coerceIn(0f, 1f - w)
        val y = ((cy - radio) / alto).toFloat().coerceIn(0f, 1f - h)
        return NormRect(x, y, w, h)
    }
}

/**
 * Ajuste activo del joystick. El bot empuja la bola del joystick hasta el tope hacia la derecha, la
 * izquierda, arriba y abajo y localiza dónde queda la bola en cada caso. Con esas cuatro posiciones el centro
 * es el punto medio de cada par y el radio, la mitad de la separación: es el recorrido real del juego, no
 * una aproximación visual del dibujo. Si las cuatro posiciones no forman una cruz coherente (mismo radio en
 * horizontal y vertical, centrada) no se da por buena la medida y no se cambia nada. Lógica pura.
 */
object AjusteActivoJoystick {

    /** Diferencia relativa máxima tolerada entre el radio horizontal y el vertical y entre ejes. */
    const val TOLERANCIA = 0.2

    class Resultado(val medida: MedidaJoystick?, val motivo: String?)

    fun calcular(derecha: PuntoPx?, izquierda: PuntoPx?, arriba: PuntoPx?, abajo: PuntoPx?): Resultado {
        if (derecha == null || izquierda == null || arriba == null || abajo == null) {
            val faltan = listOfNotNull(
                if (derecha == null) "derecha" else null,
                if (izquierda == null) "izquierda" else null,
                if (arriba == null) "arriba" else null,
                if (abajo == null) "abajo" else null
            )
            return Resultado(null, "No se localizó la bola al empujar hacia: ${faltan.joinToString()}")
        }
        val rh = (derecha.x - izquierda.x) / 2.0
        val rv = (abajo.y - arriba.y) / 2.0
        if (rh <= 4.0 || rv <= 4.0) return Resultado(null, "La bola casi no se movió (¿el juego está en primer plano?)")
        val r = (rh + rv) / 2.0
        if (abs(rh - rv) / r > TOLERANCIA) {
            return Resultado(
                null,
                "El recorrido horizontal (${rh.toInt()} px) y el vertical (${rv.toInt()} px) no coinciden"
            )
        }
        val cx = (derecha.x + izquierda.x) / 2.0
        val cy = (arriba.y + abajo.y) / 2.0
        // Las posiciones de los otros ejes deben quedar sobre la cruz.
        val desvios = listOf(
            abs(derecha.y - cy), abs(izquierda.y - cy), abs(arriba.x - cx), abs(abajo.x - cx)
        )
        val peor = desvios.maxOrNull() ?: 0.0
        if (peor > r * TOLERANCIA + 3.0) {
            return Resultado(null, "Las posiciones no forman una cruz centrada (desvío ${peor.toInt()} px)")
        }
        return Resultado(MedidaJoystick(cx, cy, r, peor), null)
    }
}
