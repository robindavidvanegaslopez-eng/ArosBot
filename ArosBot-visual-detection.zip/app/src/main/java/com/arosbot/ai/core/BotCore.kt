package com.arosbot.ai.core

import android.content.Context
import com.arosbot.ai.automation.GrabadorDeRuta
import com.arosbot.ai.automation.NavegadorDeSpots
import com.arosbot.ai.automation.PruebasAutomatizacion
import com.arosbot.ai.automation.Recolector
import com.arosbot.ai.automation.SeguidorDeRuta
import com.arosbot.ai.capture.LiveDetection
import com.arosbot.ai.input.JoystickGestos
import com.arosbot.ai.vision.VisionEngine
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * Punto único de acceso a los módulos compartidos. La interfaz solo lee de aquí
 * y envía órdenes a la máquina de estados; nunca contiene lógica de navegación.
 */
object BotCore {

    @Volatile
    private var inicializado = false

    lateinit var appContext: Context
        private set
    lateinit var log: ActivityLog
        private set
    lateinit var stateMachine: BotStateMachine
        private set
    lateinit var modules: ModuleRegistry
        private set
    lateinit var settings: SettingsStore
        private set
    lateinit var store: Store
        private set

    /** Controlador WASD (módulo 12): traduce W/A/S/D en gestos sobre el joystick del juego. */
    lateinit var entrada: ControladorEntrada
        private set

    val telemetry = MutableStateFlow(Telemetry())

    @Volatile
    private var visionOk = false

    @Volatile
    private var bdOk = false

    @Synchronized
    fun init(context: Context) {
        if (inicializado) return
        val app = context.applicationContext
        appContext = app
        log = ActivityLog(File(app.filesDir, "registro-actividad.log"))
        stateMachine = BotStateMachine(log)
        modules = ModuleRegistry()
        settings = SettingsStore(app)
        store = Store(app)
        entrada = JoystickGestos()
        inicializado = true

        // Parada de emergencia, detención y errores: se apaga la detección en vivo, se sueltan
        // todas las entradas y se cancela cualquier prueba de automatización en curso.
        stateMachine.registrarGanchoDeParada("Detección en vivo") { LiveDetection.detener() }
        stateMachine.registrarGanchoDeParada("Entrada WASD") { entrada.soltarTodo() }
        stateMachine.registrarGanchoDeParada("Pruebas de automatización") {
            PruebasAutomatizacion.cancelar()
        }
        stateMachine.registrarGanchoDeParada("Enseñanza de rutas") { GrabadorDeRuta.cancelar() }
        stateMachine.registrarGanchoDeParada("Seguimiento de rutas") { SeguidorDeRuta.cancelar() }
        stateMachine.registrarGanchoDeParada("Navegación a spots") { NavegadorDeSpots.cancelar() }
        stateMachine.registrarGanchoDeParada("Recolección y cofre") { Recolector.cancelar() }
        stateMachine.registrarGanchoDeParada("Recolección por ruta") {
            com.arosbot.ai.automation.RecolectorDeRuta.cancelar()
        }
        stateMachine.registrarGanchoDeParada("Grabación del macro") { com.arosbot.ai.capture.GrabadorDeMacro.cancelar() }
        store.alCambiar = { recalcularVerificaciones() }
        registrarCancelarTodo()

        log.info("Núcleo", "ArosBot AI iniciado (0.9.5, Fase 6)")
        recalcularVerificaciones()

        // Autopruebas reales del dispositivo, fuera del hilo principal.
        Thread({ ejecutarAutopruebas() }, "arosbot-autopruebas").start()
    }

    private fun ejecutarAutopruebas() {
        bdOk = store.autoprueba()
        log.info("Autopruebas", if (bdOk) "Base de datos: correcta" else "Base de datos: FALLA")
        if (!bdOk) log.error("Autopruebas", "La base de datos no pudo escribir y leer un valor")

        visionOk = VisionEngine.autoprueba()
        if (visionOk) {
            log.info("Autopruebas", "OpenCV: carga y búsqueda de plantillas correctas")
        } else {
            log.error("Autopruebas", "OpenCV no se cargó o la búsqueda de plantillas falló")
        }
        recalcularVerificaciones()
    }

    /** Marca como verificado, de forma persistente, un módulo que el usuario ha comprobado. */
    @Synchronized
    fun marcarVerificadoPersistente(id: Int) {
        settings.modulosVerificados = settings.modulosVerificados + id
        recalcularVerificaciones()
    }

    @Synchronized
    fun recalcularVerificaciones() {
        if (!inicializado) return
        val persistidos = settings.modulosVerificados

        fun estado(ok: Boolean): EstadoModulo =
            if (ok) EstadoModulo.VERIFICADO else EstadoModulo.IMPLEMENTADO

        val hayMaterial = store.materiales.value.any {
            it.archivoPrincipal.isNotEmpty() &&
                File(store.directorioMateriales, it.archivoPrincipal).exists()
        }
        val hayArea = store.areas.value.isNotEmpty()

        modules.fijar(1, estado(1 in persistidos))
        modules.fijar(2, estado(visionOk))
        modules.fijar(3, estado(hayMaterial))
        modules.fijar(4, estado(4 in persistidos && hayArea))
        // Fase 3: estos tres módulos solo se verifican con las pruebas reales de Automatización.
        // El localizador del personaje es opcional: si el movimiento funciona (12), se usa el centro de la pantalla.
        modules.fijar(5, estado(5 in persistidos || 12 in persistidos))
        modules.fijar(6, estado(6 in persistidos))
        modules.fijar(12, estado(12 in persistidos))
        // Fase 4: solo se verifican al enseñar y seguir una ruta real (ver SeguidorDeRuta).
        modules.fijar(7, estado(7 in persistidos))
        modules.fijar(8, estado(8 in persistidos && store.rutas.value.isNotEmpty()))
        modules.fijar(10, estado(10 in persistidos && store.intentosTotales.value > 0))
        // Fase 5: solo se verifican al ir de verdad a un spot elegido por el bot (ver NavegadorDeSpots).
        modules.fijar(11, estado(11 in persistidos))
        modules.fijar(13, estado(13 in persistidos && store.spots.value.isNotEmpty()))
        // Fase 6: el aviso de inventario lleno solo se verifica al verlo de verdad; el cofre, al depositar.
        modules.fijar(14, estado(14 in persistidos))
        modules.fijar(15, estado(15 in persistidos))
        modules.fijar(9, estado(bdOk))
    }

    private val alcanceCancelar = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.Default
    )

    /** Trabajos extra (p. ej. la recolección por ruta) que también deben cancelarse. */
    private val cancelables = java.util.concurrent.CopyOnWriteArrayList<() -> Unit>()

    private fun registrarCancelarTodo() {
        cancelables.add { com.arosbot.ai.automation.RecolectorDeRuta.reiniciar() }
    }

    /**
     * Botón «Cancelar todo»: termina cualquier proceso (pruebas, enseñanza y seguimiento de rutas,
     * spots, recolección, grabación del macro, detección en vivo), suelta el joystick, libera el
     * modo de captura rápida y deja todos los indicadores de «en marcha» a cero. Se repite el
     * reinicio un instante después por si algún trabajo cancelado escribió su estado tarde.
     */
    fun cancelarTodo() {
        reiniciarTodo()
        log.aviso("Núcleo", "Cancelar todo: se terminaron todos los procesos")
        alcanceCancelar.launch {
            kotlinx.coroutines.delay(400L)
            reiniciarTodo()
        }
    }

    private fun reiniciarTodo() {
        for (c in cancelables) try { c() } catch (e: Throwable) { }
        try { Recolector.reiniciar() } catch (e: Throwable) { }
        try { NavegadorDeSpots.reiniciar() } catch (e: Throwable) { }
        try { SeguidorDeRuta.reiniciar() } catch (e: Throwable) { }
        try { PruebasAutomatizacion.reiniciar() } catch (e: Throwable) { }
        try { GrabadorDeRuta.reiniciar() } catch (e: Throwable) { }
        try { com.arosbot.ai.capture.GrabadorDeMacro.cancelar() } catch (e: Throwable) { }
        try { LiveDetection.reiniciar() } catch (e: Throwable) { }
        try { entrada.soltarTodo() } catch (e: Throwable) { }
        try { com.arosbot.ai.capture.FrameBus.reiniciarRapido() } catch (e: Throwable) { }
    }
}
