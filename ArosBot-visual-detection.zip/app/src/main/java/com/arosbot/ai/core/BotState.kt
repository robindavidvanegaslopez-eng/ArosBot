package com.arosbot.ai.core

/**
 * Estados de la máquina de estados autónoma (módulo 16).
 *
 * INICIANDO_SESION se usará en la Fase 3 (inicio de sesión en el juego,
 * con la superposición oculta mientras aparece el selector de cuentas de Google).
 */
enum class BotState(val etiqueta: String) {
    DETENIDO("Detenido"),
    PREPARANDO("Preparando"),
    INICIANDO_SESION("Iniciando sesión"),
    ACTIVO("Activo"),
    PAUSADO("Pausado"),
    DETENIDO_POR_ERROR("Detenido por error"),
    PARADA_EMERGENCIA("Parada de emergencia")
}
