package com.arosbot.ai.core

import java.util.concurrent.CopyOnWriteArrayList
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Máquina de estados del bot.
 *
 * Reglas:
 *  - Solo se permiten las transiciones de la tabla [permitidas].
 *  - La parada de emergencia es la única transición que se acepta desde cualquier estado.
 *  - Al detener, fallar o hacer una parada de emergencia se ejecutan TODOS los "ganchos"
 *    registrados (por ejemplo, liberar las teclas WASD). Si un gancho falla, el resto
 *    se ejecuta igualmente y el fallo queda registrado.
 */
class BotStateMachine(private val log: ActivityLog) {

    private class Gancho(val nombre: String, val accion: () -> Unit)

    private val _state = MutableStateFlow(BotState.DETENIDO)
    val state: StateFlow<BotState> = _state.asStateFlow()

    private val _reason = MutableStateFlow("")
    val reason: StateFlow<String> = _reason.asStateFlow()

    private val ganchos = CopyOnWriteArrayList<Gancho>()

    private val permitidas: Map<BotState, Set<BotState>> = mapOf(
        BotState.DETENIDO to setOf(BotState.PREPARANDO),
        BotState.PREPARANDO to setOf(
            BotState.ACTIVO, BotState.INICIANDO_SESION,
            BotState.DETENIDO, BotState.DETENIDO_POR_ERROR
        ),
        BotState.INICIANDO_SESION to setOf(
            BotState.ACTIVO, BotState.PAUSADO,
            BotState.DETENIDO, BotState.DETENIDO_POR_ERROR
        ),
        BotState.ACTIVO to setOf(
            BotState.PAUSADO, BotState.INICIANDO_SESION,
            BotState.DETENIDO, BotState.DETENIDO_POR_ERROR
        ),
        BotState.PAUSADO to setOf(BotState.ACTIVO, BotState.DETENIDO),
        BotState.DETENIDO_POR_ERROR to setOf(BotState.DETENIDO, BotState.PREPARANDO),
        BotState.PARADA_EMERGENCIA to setOf(BotState.DETENIDO)
    )

    /**
     * Registra una acción que debe ejecutarse al detener el bot por cualquier motivo
     * (liberar entradas, cerrar la captura, etc.).
     */
    fun registrarGanchoDeParada(nombre: String, accion: () -> Unit) {
        ganchos.add(Gancho(nombre, accion))
    }

    /** Intenta cambiar de estado. Devuelve false (y lo registra) si la transición no está permitida. */
    @Synchronized
    fun transition(to: BotState, reason: String): Boolean {
        val desde = _state.value
        val destinos = permitidas.getValue(desde)
        if (to !in destinos) {
            log.aviso("Estados", "Transición no permitida: ${desde.name} → ${to.name}")
            return false
        }
        _state.value = to
        _reason.value = reason
        log.info("Estados", "${desde.etiqueta} → ${to.etiqueta}: $reason")
        return true
    }

    /** Detiene el bot de forma ordenada y libera las entradas. */
    fun stop(reason: String): Boolean {
        val cambio = transition(BotState.DETENIDO, reason)
        if (cambio) ejecutarGanchos()
        return cambio
    }

    /** Detiene el bot por una condición de error (captura perdida, localización perdida, etc.). */
    fun fail(reason: String): Boolean {
        val cambio = transition(BotState.DETENIDO_POR_ERROR, reason)
        if (cambio) {
            log.error("Estados", "Detenido por error: $reason")
            ejecutarGanchos()
        }
        return cambio
    }

    /** Parada inmediata: se acepta desde cualquier estado y libera todas las entradas. */
    fun emergencyStop(reason: String = "Parada de emergencia solicitada por el usuario") {
        synchronized(this) {
            _state.value = BotState.PARADA_EMERGENCIA
            _reason.value = reason
        }
        log.aviso("Estados", "PARADA DE EMERGENCIA: $reason")
        ejecutarGanchos()
    }

    private fun ejecutarGanchos() {
        for (gancho in ganchos) {
            try {
                gancho.accion()
            } catch (e: Throwable) {
                log.error("Estados", "Falló '${gancho.nombre}' al detener: ${e.message}")
            }
        }
    }
}
