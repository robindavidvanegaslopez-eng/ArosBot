package com.arosbot.ai.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/*
 * Lógica pura (sin Android) de la conducción continua del joystick: el dedo no se levanta mientras el
 * bot sigue una ruta; solo cambia el ángulo en el borde del joystick según lo que mide en la pantalla.
 */

/** Dónde pone el dedo el bot sobre el joystick y cómo lo desliza al cambiar de rumbo. */
object ArcoDeJoystick {

    /** Punto del borde del joystick en el ángulo [rumbo] (radianes, coordenadas de pantalla). */
    fun punto(cx: Float, cy: Float, radio: Float, rumbo: Double): PuntoXY =
        PuntoXY((cx + cos(rumbo) * radio).toFloat(), (cy + sin(rumbo) * radio).toFloat())

    /** Diferencia de ángulos normalizada a (-π, π]. */
    fun diferencia(desde: Double, hasta: Double): Double {
        var d = (hasta - desde) % (2 * PI)
        if (d > PI) d -= 2 * PI
        if (d <= -PI) d += 2 * PI
        return d
    }

    /**
     * Puntos por los que desliza el dedo, por el borde, del rumbo [desde] al rumbo [hasta]. No incluye
     * el punto de partida (el trazo ya está ahí). Siempre devuelve al menos un punto: si el rumbo no
     * cambia, el dedo se mueve 1 px (a lo largo del borde) para que el trazo no tenga longitud cero.
     */
    fun deslizar(
        cx: Float,
        cy: Float,
        radio: Float,
        desde: Double,
        hasta: Double,
        signoTemblor: Int = 1,
        pasoMaximoRad: Double = PI / 12.0
    ): List<PuntoXY> {
        val delta = diferencia(desde, hasta)
        val lista = ArrayList<PuntoXY>()
        if (abs(delta) < 1e-3) {
            val tangente = 1.0 / max(1f, radio) * signoTemblor
            lista.add(punto(cx, cy, radio, desde + tangente))
            return lista
        }
        val n = max(1, ceil(abs(delta) / pasoMaximoRad).toInt())
        for (k in 1..n) lista.add(punto(cx, cy, radio, desde + delta * k / n))
        return lista
    }
}

/**
 * Elige el rumbo (ángulo del dedo) para ir hacia un objetivo. Con diagonales verificadas apunta al
 * ángulo exacto; sin ellas solo usa los cuatro ejes, con histéresis para no cambiar de eje a cada
 * fotograma.
 */
class PilotoDeRumbo(private val diagonales: Boolean) {

    private var horizontal = true
    private var iniciado = false

    fun rumbo(ex: Double, ey: Double): Double {
        if (diagonales) return atan2(ey, ex)
        if (!iniciado) {
            horizontal = abs(ex) >= abs(ey)
            iniciado = true
        } else if (horizontal) {
            if (abs(ey) > abs(ex) * HISTERESIS + MARGEN_PX) horizontal = false
        } else {
            if (abs(ex) > abs(ey) * HISTERESIS + MARGEN_PX) horizontal = true
        }
        return if (horizontal) {
            if (ex >= 0) 0.0 else PI
        } else {
            if (ey >= 0) PI / 2 else -PI / 2
        }
    }

    companion object {
        const val HISTERESIS = 1.3
        const val MARGEN_PX = 10.0
    }
}

/** Seguimiento de los puntos de una ruta mientras se avanza sin detenerse. */
object SeguimientoDeCamino {

    const val RADIO_PASO_PX = 40.0
    const val DISTANCIA_MAXIMA_SALTO_PX = 110.0

    /** Latencia aproximada entre pedir soltar el joystick y que el personaje se detenga. */
    const val LATENCIA_PARADA_MS = 180L

    /**
     * Avanza el índice del punto objetivo mientras se haya llegado a él o se le haya pasado de largo
     * (sin alejarse demasiado del camino). El último punto nunca se salta: allí se frena.
     */
    fun avanzar(x: Double, y: Double, puntos: List<PuntoDeRuta>, indice: Int): Int {
        var i = indice
        while (i < puntos.lastIndex) {
            val p = puntos[i]
            val d = hypot(p.x - x, p.y - y)
            val llegado = d < RADIO_PASO_PX
            val ant = puntos[max(0, i - 1)]
            val sx = p.x - ant.x
            val sy = p.y - ant.y
            val largo2 = sx * sx + sy * sy
            val t = if (largo2 < 1e-6) 0.0 else ((x - ant.x) * sx + (y - ant.y) * sy) / largo2
            val pasado = i > 0 && t > 1.0 && d < DISTANCIA_MAXIMA_SALTO_PX
            if (llegado || pasado) i++ else break
        }
        return i
    }

    /** Distancia al último punto a la que hay que soltar para quedar parado en él. */
    fun distanciaDeFrenado(velocidadPxS: Double, latenciaMs: Long = LATENCIA_PARADA_MS): Double =
        velocidadPxS * latenciaMs / 1000.0

    fun hayQueSoltar(distanciaAlFinal: Double, velocidadPxS: Double): Boolean =
        distanciaAlFinal <= max(distanciaDeFrenado(velocidadPxS), MINIMA_PARA_SOLTAR_PX)

    const val MINIMA_PARA_SOLTAR_PX = 12.0

    /** Velocidad nominal (px/s) a partir de la calibración de las direcciones cardinales. */
    fun velocidadNominal(calibraciones: Map<Direccion, Calibracion>): Double {
        val v = Direccion.CARDINALES.mapNotNull { calibraciones[it]?.takeIf { c -> c.muestras > 0 }?.rapidez }
        return if (v.isEmpty()) 0.0 else v.average()
    }

    /** Tiempo máximo razonable para recorrer [distanciaPx] a [velocidadPxS], con margen. */
    fun tiempoMaximoMs(distanciaPx: Double, velocidadPxS: Double): Long {
        if (velocidadPxS <= 1.0) return 60_000L
        return min(600_000.0, max(8_000.0, distanciaPx / velocidadPxS * 1000.0 * 4.0)).toLong()
    }
}
