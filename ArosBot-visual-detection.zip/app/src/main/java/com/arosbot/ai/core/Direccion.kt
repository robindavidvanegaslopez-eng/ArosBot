package com.arosbot.ai.core

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Las cuatro direcciones de movimiento (teclas W, A, S, D). Vectores en coordenadas de pantalla (y hacia abajo). */
enum class Direccion(val tecla: Char, val ux: Int, val uy: Int) {
    W('W', 0, -1),
    A('A', -1, 0),
    S('S', 0, 1),
    D('D', 1, 0);

    val opuesta: Direccion
        get() = when (this) {
            W -> S
            S -> W
            A -> D
            D -> A
        }
}

/** Un desplazamiento: mantener una dirección durante [duracionMs]. */
data class Paso(val direccion: Direccion, val duracionMs: Long)

/**
 * Controlador de movimiento (módulo 12). Debe liberar siempre lo que pulsa: al terminar el paso,
 * al fallar, al cancelarse la corrutina que lo llama y en [soltarTodo].
 */
interface ControladorEntrada {
    /** true si el mecanismo de entrada existe y está configurado. */
    val disponible: Boolean

    /** Mantiene [direccion] durante [duracionMs]. Devuelve false si no pudo completarse. */
    suspend fun mantener(direccion: Direccion, duracionMs: Long): Boolean

    /** Detiene de inmediato cualquier pulsación en curso. */
    fun soltarTodo()
}

/**
 * Combina desplazamientos secuenciales. Si un paso falla se detiene y libera las entradas:
 * nunca se siguen enviando pasos después de un fallo.
 */
suspend fun ControladorEntrada.ejecutar(pasos: List<Paso>): Boolean {
    for (paso in pasos) {
        if (!mantener(paso.direccion, paso.duracionMs)) {
            soltarTodo()
            return false
        }
    }
    return true
}

/**
 * Cómo responde lo observado (personaje o escena) a mantener una dirección.
 * [vx] y [vy] son píxeles del fotograma capturado por segundo de pulsación. No son metros ni
 * distancia del juego: es una estimación que se corrige con cada medición.
 */
data class Calibracion(
    val direccion: Direccion,
    val vx: Double,
    val vy: Double,
    val muestras: Int
) {
    val rapidez: Double get() = hypot(vx, vy)

    /** Incorpora una medición: el desplazamiento observado ([dx], [dy]) tras mantener [duracionMs]. */
    fun actualizar(dx: Double, dy: Double, duracionMs: Long): Calibracion {
        if (duracionMs <= 0L) return this
        val segundos = duracionMs / 1000.0
        val nx = dx / segundos
        val ny = dy / segundos
        if (muestras == 0) return copy(vx = nx, vy = ny, muestras = 1)
        val alfa = max(1.0 / (muestras + 1), ALFA_MINIMO)
        return copy(vx = vx + (nx - vx) * alfa, vy = vy + (ny - vy) * alfa, muestras = muestras + 1)
    }

    /** Duración estimada para desplazarse [distanciaPx] píxeles, o null si no hay calibración útil. */
    fun duracionParaMs(distanciaPx: Double): Long? {
        val r = rapidez
        if (r < 1e-6) return null
        return (distanciaPx / r * 1000.0).toLong().coerceIn(DURACION_MINIMA_MS, DURACION_MAXIMA_MS)
    }

    companion object {
        const val ALFA_MINIMO = 0.2
        const val DURACION_MINIMA_MS = 50L
        const val DURACION_MAXIMA_MS = 5000L

        fun vacia(direccion: Direccion) = Calibracion(direccion, 0.0, 0.0, 0)
    }
}

enum class FuenteMedicion { PERSONAJE, ESCENA }

/** Desplazamiento observado entre dos fotogramas, en píxeles del fotograma. */
data class Medicion(
    val dx: Double,
    val dy: Double,
    val confianza: Double,
    val fuente: FuenteMedicion
)

object EvaluadorProgreso {

    const val MIN_RAPIDEZ_PX_S = 8.0

    /** true si la medición muestra un desplazamiento de al menos [minimoPx]. */
    fun hayMovimiento(m: Medicion, minimoPx: Double): Boolean = hypot(m.dx, m.dy) >= minimoPx

    /**
     * Comprueba que la calibración tiene sentido: las cuatro direcciones calibradas, con movimiento
     * observable, en el eje esperado y con sentidos opuestos entre W/S y entre A/D.
     * Devuelve la lista de problemas (vacía si todo es coherente). Sirve igual si lo observado es el
     * personaje o la escena, porque solo compara signos entre direcciones.
     */
    fun calibracionCoherente(
        calibraciones: Map<Direccion, Calibracion>,
        minimoPxPorSegundo: Double = MIN_RAPIDEZ_PX_S
    ): List<String> {
        val problemas = ArrayList<String>()
        for (d in Direccion.values()) {
            val c = calibraciones[d]
            if (c == null || c.muestras == 0) {
                problemas.add("Falta calibrar ${d.tecla}")
                continue
            }
            if (c.rapidez < minimoPxPorSegundo) {
                problemas.add("Al pulsar ${d.tecla} casi no se observó movimiento")
                continue
            }
            val vertical = d == Direccion.W || d == Direccion.S
            val ejeEsperado = if (vertical) abs(c.vy) > abs(c.vx) else abs(c.vx) > abs(c.vy)
            if (!ejeEsperado) {
                problemas.add("Al pulsar ${d.tecla} el movimiento observado no va en el eje esperado")
            }
        }
        if (problemas.isNotEmpty()) return problemas

        val w = calibraciones.getValue(Direccion.W)
        val s = calibraciones.getValue(Direccion.S)
        val a = calibraciones.getValue(Direccion.A)
        val d = calibraciones.getValue(Direccion.D)
        if (w.vy * s.vy >= 0.0) problemas.add("W y S producen movimiento en el mismo sentido")
        if (a.vx * d.vx >= 0.0) problemas.add("A y D producen movimiento en el mismo sentido")
        return problemas
    }
}

/** Divide una pulsación larga en segmentos cortos para poder soltarla casi de inmediato. */
object PlanDeSegmentos {
    fun dividir(duracionMs: Long, segmentoMs: Long): List<Long> {
        val total = max(1L, duracionMs)
        val tamano = max(1L, segmentoMs)
        val partes = ArrayList<Long>()
        var restante = total
        while (restante > 0L) {
            val parte = min(tamano, restante)
            partes.add(parte)
            restante -= parte
        }
        return partes
    }
}
