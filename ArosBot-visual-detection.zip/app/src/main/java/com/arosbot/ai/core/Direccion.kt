package com.arosbot.ai.core

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Las ocho direcciones de movimiento: las cuatro de las teclas W, A, S, D y las cuatro combinaciones
 * (W+A, W+D, S+A, S+D). Vectores en coordenadas de pantalla (y hacia abajo). El joystick del juego es
 * analógico: una diagonal es empujarlo hacia la esquina, siempre hasta el borde del círculo (100 %).
 */
enum class Direccion(val tecla: String, val ux: Int, val uy: Int) {
    W("W", 0, -1),
    A("A", -1, 0),
    S("S", 0, 1),
    D("D", 1, 0),
    WA("W+A", -1, -1),
    WD("W+D", 1, -1),
    SA("S+A", -1, 1),
    SD("S+D", 1, 1);

    /** Componentes del vector unitario (las diagonales miden 1, no raíz de 2). */
    val unitarioX: Double get() = if (ux != 0 && uy != 0) ux * RAIZ_MEDIA else ux.toDouble()
    val unitarioY: Double get() = if (ux != 0 && uy != 0) uy * RAIZ_MEDIA else uy.toDouble()

    val esDiagonal: Boolean get() = ux != 0 && uy != 0

    val opuesta: Direccion
        get() = when (this) {
            W -> S
            S -> W
            A -> D
            D -> A
            WA -> SD
            SD -> WA
            WD -> SA
            SA -> WD
        }

    companion object {
        private const val RAIZ_MEDIA = 0.7071067811865476

        /** Las cuatro que se calibran con la prueba de movimiento. */
        val CARDINALES: List<Direccion> = listOf(W, S, A, D)

        val DIAGONALES: List<Direccion> = listOf(WA, WD, SA, SD)

        /** La dirección de las ocho más cercana al ángulo de (ex, ey), en coordenadas de pantalla. */
        fun masCercana(ex: Double, ey: Double): Direccion {
            val octante = Math.round(Math.atan2(ey, ex) / (Math.PI / 4.0)).toInt()
            return when (((octante % 8) + 8) % 8) {
                0 -> D
                1 -> SD
                2 -> S
                3 -> SA
                4 -> A
                5 -> WA
                6 -> W
                else -> WD
            }
        }
    }
}

/** Un desplazamiento: mantener una dirección durante [duracionMs]. */
data class Paso(val direccion: Direccion, val duracionMs: Long)

/**
 * Controlador de movimiento (módulo 12). Debe liberar siempre lo que pulsa: al terminar el paso,
 * al fallar, al cancelarse la corrutina que lo llama y en [soltarTodo].
 */
interface ControladorEntrada {
    /** true si el mecanismo de entrada existe y está configurado. */
    val disponible: Boolean

    /** Mantiene [direccion] durante [duracionMs]. Devuelve false si no pudo completarse. */
    suspend fun mantener(direccion: Direccion, duracionMs: Long): Boolean

    /** Detiene de inmediato cualquier pulsación en curso. */
    fun soltarTodo()
}

/**
 * Combina desplazamientos secuenciales. Si un paso falla se detiene y libera las entradas:
 * nunca se siguen enviando pasos después de un fallo.
 */
suspend fun ControladorEntrada.ejecutar(pasos: List<Paso>): Boolean {
    for (paso in pasos) {
        if (!mantener(paso.direccion, paso.duracionMs)) {
            soltarTodo()
            return false
        }
    }
    return true
}

/**
 * Cómo responde lo observado (personaje o escena) a mantener una dirección.
 * [vx] y [vy] son píxeles del fotograma capturado por segundo de pulsación. No son metros ni
 * distancia del juego: es una estimación que se corrige con cada medición.
 */
data class Calibracion(
    val direccion: Direccion,
    val vx: Double,
    val vy: Double,
    val muestras: Int
) {
    val rapidez: Double get() = hypot(vx, vy)

    /** Incorpora una medición: el desplazamiento observado ([dx], [dy]) tras mantener [duracionMs]. */
    fun actualizar(dx: Double, dy: Double, duracionMs: Long): Calibracion {
        if (duracionMs <= 0L) return this
        val segundos = duracionMs / 1000.0
        val nx = dx / segundos
        val ny = dy / segundos
        if (muestras == 0) return copy(vx = nx, vy = ny, muestras = 1)
        val alfa = max(1.0 / (muestras + 1), ALFA_MINIMO)
        return copy(vx = vx + (nx - vx) * alfa, vy = vy + (ny - vy) * alfa, muestras = muestras + 1)
    }

    /** Duración estimada para desplazarse [distanciaPx] píxeles, o null si no hay calibración útil. */
    fun duracionParaMs(distanciaPx: Double): Long? {
        val r = rapidez
        if (r < 1e-6) return null
        return (distanciaPx / r * 1000.0).toLong().coerceIn(DURACION_MINIMA_MS, DURACION_MAXIMA_MS)
    }

    companion object {
        const val ALFA_MINIMO = 0.2
        const val DURACION_MINIMA_MS = 50L
        const val DURACION_MAXIMA_MS = 5000L

        fun vacia(direccion: Direccion) = Calibracion(direccion, 0.0, 0.0, 0)
    }
}

enum class FuenteMedicion { PERSONAJE, ESCENA }

/** Desplazamiento observado entre dos fotogramas, en píxeles del fotograma. */
data class Medicion(
    val dx: Double,
    val dy: Double,
    val confianza: Double,
    val fuente: FuenteMedicion
)

object EvaluadorProgreso {

    const val MIN_RAPIDEZ_PX_S = 8.0

    const val RAPIDEZ_RELATIVA_MINIMA = 0.5
    const val RAPIDEZ_RELATIVA_MAXIMA = 1.6
    const val COSENO_MINIMO = 0.85

    /**
     * Compara lo medido ([dx], [dy]) con lo esperado ([esperadoX], [esperadoY]) para una diagonal.
     * Devuelve null si es correcto o el motivo en texto si no: sin movimiento, rapidez fuera de lo
     * razonable o dirección que se desvía más de unos 30 grados.
     */
    fun diagonalCorrecta(dx: Double, dy: Double, esperadoX: Double, esperadoY: Double): String? {
        val medido = hypot(dx, dy)
        val esperado = hypot(esperadoX, esperadoY)
        if (esperado < 1e-6) return "no hay calibración con la que comparar"
        if (medido < esperado * RAPIDEZ_RELATIVA_MINIMA) return "se movió muy poco"
        if (medido > esperado * RAPIDEZ_RELATIVA_MAXIMA) return "se movió demasiado"
        val coseno = (dx * esperadoX + dy * esperadoY) / (medido * esperado)
        if (coseno < COSENO_MINIMO) return "fue en otra dirección"
        return null
    }

    /** true si la medición muestra un desplazamiento de al menos [minimoPx]. */
    fun hayMovimiento(m: Medicion, minimoPx: Double): Boolean = hypot(m.dx, m.dy) >= minimoPx

    /**
     * Comprueba que la calibración tiene sentido: las cuatro direcciones calibradas, con movimiento
     * observable, en el eje esperado y con sentidos opuestos entre W/S y entre A/D.
     * Devuelve la lista de problemas (vacía si todo es coherente). Sirve igual si lo observado es el
     * personaje o la escena, porque solo compara signos entre direcciones.
     */
    fun calibracionCoherente(
        calibraciones: Map<Direccion, Calibracion>,
        minimoPxPorSegundo: Double = MIN_RAPIDEZ_PX_S
    ): List<String> {
        val problemas = ArrayList<String>()
        for (d in Direccion.CARDINALES) {
            val c = calibraciones[d]
            if (c == null || c.muestras == 0) {
                problemas.add("Falta calibrar ${d.tecla}")
                continue
            }
            if (c.rapidez < minimoPxPorSegundo) {
                problemas.add("Al pulsar ${d.tecla} casi no se observó movimiento")
                continue
            }
            val vertical = d == Direccion.W || d == Direccion.S
            val ejeEsperado = if (vertical) abs(c.vy) > abs(c.vx) else abs(c.vx) > abs(c.vy)
            if (!ejeEsperado) {
                problemas.add("Al pulsar ${d.tecla} el movimiento observado no va en el eje esperado")
            }
        }
        if (problemas.isNotEmpty()) return problemas

        val w = calibraciones.getValue(Direccion.W)
        val s = calibraciones.getValue(Direccion.S)
        val a = calibraciones.getValue(Direccion.A)
        val d = calibraciones.getValue(Direccion.D)
        if (w.vy * s.vy >= 0.0) problemas.add("W y S producen movimiento en el mismo sentido")
        if (a.vx * d.vx >= 0.0) problemas.add("A y D producen movimiento en el mismo sentido")
        return problemas
    }
}

/**
 * Calibración de cualquiera de las ocho direcciones. Las cuatro cardinales se miden con la prueba de
 * movimiento; las diagonales se DERIVAN de ellas (el joystick al 100 % da la misma rapidez en todas
 * las direcciones, así que una diagonal es la suma de sus dos componentes). Que el juego se comporte
 * así se comprueba con «Probar diagonales».
 */
object Calibraciones {

    fun para(calibraciones: Map<Direccion, Calibracion>, direccion: Direccion): Calibracion? {
        if (!direccion.esDiagonal) {
            val c = calibraciones[direccion]
            return if (c == null || c.muestras == 0) null else c
        }
        val horizontal = calibraciones[if (direccion.ux > 0) Direccion.D else Direccion.A]
        val vertical = calibraciones[if (direccion.uy > 0) Direccion.S else Direccion.W]
        if (horizontal == null || horizontal.muestras == 0 || vertical == null || vertical.muestras == 0) {
            return null
        }
        val k = Math.abs(direccion.unitarioX)
        return Calibracion(
            direccion,
            (horizontal.vx + vertical.vx) * k,
            (horizontal.vy + vertical.vy) * k,
            minOf(horizontal.muestras, vertical.muestras)
        )
    }
}

/** Divide una pulsación larga en segmentos cortos para poder soltarla casi de inmediato. */
object PlanDeSegmentos {
    fun dividir(duracionMs: Long, segmentoMs: Long): List<Long> {
        val total = max(1L, duracionMs)
        val tamano = max(1L, segmentoMs)
        val partes = ArrayList<Long>()
        var restante = total
        while (restante > 0L) {
            val parte = min(tamano, restante)
            partes.add(parte)
            restante -= parte
        }
        return partes
    }
}
