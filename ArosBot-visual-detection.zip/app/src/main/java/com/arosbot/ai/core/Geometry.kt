package com.arosbot.ai.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Rectángulo en píxeles. Kotlin puro (sin android.graphics) para poder probarlo con JUnit. */
data class Box(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val area: Long get() = max(0, width).toLong() * max(0, height).toLong()

    fun interseccion(otro: Box): Long {
        val l = max(left, otro.left)
        val t = max(top, otro.top)
        val r = min(right, otro.right)
        val b = min(bottom, otro.bottom)
        return if (r > l && b > t) (r - l).toLong() * (b - t).toLong() else 0L
    }

    /** Intersección sobre unión, entre 0 y 1. */
    fun iou(otro: Box): Float {
        val i = interseccion(otro)
        val u = area + otro.area - i
        return if (u <= 0L) 0f else i.toFloat() / u.toFloat()
    }

    /** Recorta el rectángulo para que quepa en una imagen de [ancho] x [alto]. */
    fun recortar(ancho: Int, alto: Int): Box = Box(
        left.coerceIn(0, ancho),
        top.coerceIn(0, alto),
        right.coerceIn(0, ancho),
        bottom.coerceIn(0, alto)
    )
}

/** Un objeto reconocido en un fotograma. */
data class Detection(
    val materialId: Long,
    val nombre: String,
    val box: Box,
    val score: Float
)

object Nms {
    /**
     * Elimina detecciones duplicadas del mismo ejemplar: ordena por puntuación y descarta
     * cada detección que se solape más de [umbralIou] con otra ya aceptada.
     * Si [soloMismoMaterial] es true, solo se comparan detecciones del mismo material.
     */
    fun suprimir(
        detecciones: List<Detection>,
        umbralIou: Float,
        soloMismoMaterial: Boolean
    ): List<Detection> {
        val aceptadas = ArrayList<Detection>()
        for (d in detecciones.sortedByDescending { it.score }) {
            val duplicada = aceptadas.any {
                (!soloMismoMaterial || it.materialId == d.materialId) &&
                    it.box.iou(d.box) > umbralIou
            }
            if (!duplicada) aceptadas.add(d)
        }
        return aceptadas
    }
}

/**
 * Rectángulo en coordenadas normalizadas (0 a 1) relativas al fotograma.
 * Guardar las áreas así evita depender de la resolución con la que se dibujaron.
 */
data class NormRect(val x: Float, val y: Float, val w: Float, val h: Float) {

    fun aBox(ancho: Int, alto: Int): Box {
        val l = (x * ancho).roundToInt().coerceIn(0, ancho - 1)
        val t = (y * alto).roundToInt().coerceIn(0, alto - 1)
        val r = ((x + w) * ancho).roundToInt().coerceIn(l + 1, ancho)
        val b = ((y + h) * alto).roundToInt().coerceIn(t + 1, alto)
        return Box(l, t, r, b)
    }

    companion object {
        fun deBox(box: Box, ancho: Int, alto: Int): NormRect = NormRect(
            box.left / ancho.toFloat(),
            box.top / alto.toFloat(),
            box.width / ancho.toFloat(),
            box.height / alto.toFloat()
        )
    }
}

/** Transformación de una imagen centrada y ajustada dentro de una vista. */
data class FitTransform(val escala: Float, val dx: Float, val dy: Float) {
    fun imagenAVistaX(x: Float): Float = x * escala + dx
    fun imagenAVistaY(y: Float): Float = y * escala + dy
    fun vistaAImagenX(x: Float): Float = (x - dx) / escala
    fun vistaAImagenY(y: Float): Float = (y - dy) / escala
}

object FrameGeometry {

    /** Escala y desplazamiento para mostrar una imagen completa y centrada en una vista. */
    fun ajustar(vistaW: Float, vistaH: Float, imgW: Float, imgH: Float): FitTransform {
        if (imgW <= 0f || imgH <= 0f || vistaW <= 0f || vistaH <= 0f) {
            return FitTransform(1f, 0f, 0f)
        }
        val escala = min(vistaW / imgW, vistaH / imgH)
        return FitTransform(escala, (vistaW - imgW * escala) / 2f, (vistaH - imgH * escala) / 2f)
    }

    /**
     * Indica si un área dibujada sobre una pantalla de [refAncho] x [refAlto] sigue siendo
     * válida para una pantalla de [actualAncho] x [actualAlto]. Si la proporción cambia
     * (por ejemplo, al girar el teléfono), el área ya no corresponde y hay que recalibrarla.
     */
    fun relacionCompatible(
        refAncho: Int,
        refAlto: Int,
        actualAncho: Int,
        actualAlto: Int,
        tolerancia: Float = 0.02f
    ): Boolean {
        if (refAncho <= 0 || refAlto <= 0 || actualAncho <= 0 || actualAlto <= 0) return false
        val a = refAncho.toFloat() / refAlto.toFloat()
        val b = actualAncho.toFloat() / actualAlto.toFloat()
        return abs(a - b) / a <= tolerancia
    }
}
