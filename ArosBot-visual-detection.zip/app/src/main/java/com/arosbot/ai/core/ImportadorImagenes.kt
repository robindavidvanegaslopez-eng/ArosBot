package com.arosbot.ai.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.max

data class ImagenImportada(val archivo: String, val ancho: Int, val alto: Int)

/** Importa una imagen de la galería a la carpeta interna de materiales. Llamar fuera del hilo principal. */
object ImportadorImagenes {

    private const val LADO_MAXIMO = 1024

    fun importar(contexto: Context, uri: Uri, directorio: File): ImagenImportada? {
        return try {
            val resolvedor = contexto.contentResolver

            val bordes = BitmapFactory.Options()
            bordes.inJustDecodeBounds = true
            resolvedor.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bordes) }
            if (bordes.outWidth <= 0 || bordes.outHeight <= 0) return null

            var muestreo = 1
            while (max(bordes.outWidth, bordes.outHeight) / muestreo > LADO_MAXIMO) {
                muestreo *= 2
            }
            val opciones = BitmapFactory.Options()
            opciones.inSampleSize = muestreo
            opciones.inPreferredConfig = Bitmap.Config.ARGB_8888
            val bitmap = resolvedor.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opciones)
            } ?: return null

            val nombre = "m_" + UUID.randomUUID().toString() + ".png"
            FileOutputStream(File(directorio, nombre)).use {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            val resultado = ImagenImportada(nombre, bitmap.width, bitmap.height)
            bitmap.recycle()
            resultado
        } catch (e: Exception) {
            null
        }
    }
}
