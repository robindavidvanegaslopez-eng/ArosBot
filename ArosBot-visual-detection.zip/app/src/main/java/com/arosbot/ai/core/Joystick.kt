package com.arosbot.ai.core

import kotlin.math.min

/**
 * Posición del joystick virtual del juego. El rectángulo está normalizado respecto al fotograma
 * de referencia de [refAncho] x [refAlto]: su centro es el punto donde se pulsa y su lado más corto
 * marca el alcance máximo del arrastre.
 */
data class JoystickConfig(val rect: NormRect, val refAncho: Int, val refAlto: Int)

data class PuntosJoystick(
    val centroX: Float,
    val centroY: Float,
    val destinoX: Float,
    val destinoY: Float
)

object GeometriaJoystick {

    /**
     * Puntos de pantalla (en píxeles) para empujar el joystick en [direccion]. Por defecto al 100 %
     * (el borde del rectángulo marcado): en el juego el desplazamiento del joystick es la velocidad
     * del personaje y una velocidad menor delataría al bot.
     */
    fun puntos(
        rect: NormRect,
        anchoPantalla: Int,
        altoPantalla: Int,
        direccion: Direccion,
        deflexion: Float = 1.0f
    ): PuntosJoystick {
        val cx = (rect.x + rect.w / 2f) * anchoPantalla
        val cy = (rect.y + rect.h / 2f) * altoPantalla
        val radio = min(rect.w * anchoPantalla, rect.h * altoPantalla) / 2f
        return PuntosJoystick(
            cx,
            cy,
            cx + direccion.ux * radio * deflexion,
            cy + direccion.uy * radio * deflexion
        )
    }
}

/** Elección de los materiales especiales por su nombre o categoría. */
object SelectorDeMateriales {

    /** El material que representa al personaje: categoría «Personaje» o nombre que lo contenga. */
    fun personaje(materiales: List<Material>): Material? =
        materiales.firstOrNull { it.categoria.trim().equals("personaje", ignoreCase = true) }
            ?: materiales.firstOrNull { it.nombre.contains("personaje", ignoreCase = true) }

    /** El material del botón «Log in»: nombre que contenga «login» o «log in». */
    fun login(materiales: List<Material>): Material? =
        materiales.firstOrNull {
            it.nombre.replace(" ", "").contains("login", ignoreCase = true)
        }
}
