package com.arosbot.ai.core

import java.util.Locale
import kotlin.math.hypot

/*
 * Macro del cofre: los toques que el usuario hace una vez en el cofre (abrir, depositar, cerrar…) y que el
 * bot repite al llegar. Lógica pura: formato guardado, validación y clasificación de gestos.
 */

enum class TipoDePaso(val clave: String) {
    TOQUE("T"),
    DESLIZAR("D");

    companion object {
        fun deClave(c: String): TipoDePaso? = values().firstOrNull { it.clave == c }
    }
}

/**
 * Un paso del macro. Las posiciones están normalizadas (0 a 1) respecto a la pantalla donde se grabó.
 * [esperaMs] es la pausa antes del paso y [duracionMs] lo que dura el toque o el deslizamiento.
 */
data class PasoDeMacro(
    val tipo: TipoDePaso,
    val x: Float,
    val y: Float,
    val x2: Float,
    val y2: Float,
    val duracionMs: Long,
    val esperaMs: Long
)

data class MacroGrabado(val refAncho: Int, val refAlto: Int, val pasos: List<PasoDeMacro>)

object MacroDeClics {

    const val MAX_PASOS = 40
    const val ESPERA_MINIMA_MS = 150L
    const val ESPERA_MAXIMA_MS = 6000L
    const val DURACION_MINIMA_MS = 40L
    const val DURACION_MAXIMA_MS = 1500L

    /** Un gesto que se mueve menos que esto (px) y es corto cuenta como toque, no como deslizamiento. */
    const val MOVIMIENTO_MAXIMO_TOQUE_PX = 28.0

    fun acotarEspera(ms: Long): Long = ms.coerceIn(ESPERA_MINIMA_MS, ESPERA_MAXIMA_MS)

    fun acotarDuracion(ms: Long): Long = ms.coerceIn(DURACION_MINIMA_MS, DURACION_MAXIMA_MS)

    /**
     * Convierte un gesto del usuario (de ([x0], [y0]) a ([x1], [y1]) píxeles, [duracionMs] con el dedo
     * apoyado) en un paso. Si se movió poco es un toque (en el punto donde bajó); si no, un deslizamiento.
     */
    fun clasificar(
        x0: Float,
        y0: Float,
        x1: Float,
        y1: Float,
        duracionMs: Long,
        ancho: Int,
        alto: Int,
        esperaMs: Long
    ): PasoDeMacro {
        val movimiento = hypot((x1 - x0).toDouble(), (y1 - y0).toDouble())
        val an = ancho.coerceAtLeast(1).toFloat()
        val al = alto.coerceAtLeast(1).toFloat()
        val tipo = if (movimiento <= MOVIMIENTO_MAXIMO_TOQUE_PX) TipoDePaso.TOQUE else TipoDePaso.DESLIZAR
        val fx = if (tipo == TipoDePaso.TOQUE) x0 else x1
        val fy = if (tipo == TipoDePaso.TOQUE) y0 else y1
        return PasoDeMacro(
            tipo,
            (x0 / an).coerceIn(0f, 1f),
            (y0 / al).coerceIn(0f, 1f),
            (fx / an).coerceIn(0f, 1f),
            (fy / al).coerceIn(0f, 1f),
            acotarDuracion(duracionMs),
            acotarEspera(esperaMs)
        )
    }

    /** Problema que impide guardar o usar el macro, o null si es válido. */
    fun problema(macro: MacroGrabado?): String? {
        if (macro == null) return "No hay ningún macro grabado."
        if (macro.refAncho <= 0 || macro.refAlto <= 0) return "El macro no guarda el tamaño de la pantalla."
        if (macro.pasos.isEmpty()) return "El macro está vacío: haz al menos un toque."
        if (macro.pasos.size > MAX_PASOS) return "El macro tiene demasiados pasos (máximo $MAX_PASOS)."
        return null
    }

    fun codificar(macro: MacroGrabado): String {
        val sb = StringBuilder()
        sb.append("P;").append(macro.refAncho).append(';').append(macro.refAlto)
        for (p in macro.pasos) {
            sb.append('\n')
                .append(p.tipo.clave).append(';')
                .append(f(p.x)).append(';').append(f(p.y)).append(';')
                .append(f(p.x2)).append(';').append(f(p.y2)).append(';')
                .append(p.duracionMs).append(';').append(p.esperaMs)
        }
        return sb.toString()
    }

    private fun f(v: Float): String = String.format(Locale.US, "%.5f", v)

    /** Lee un macro guardado. null si el texto no tiene el formato esperado (nunca inventa pasos). */
    fun decodificar(texto: String?): MacroGrabado? {
        if (texto.isNullOrBlank()) return null
        val lineas = texto.lines().filter { it.isNotBlank() }
        val cab = lineas.first().split(';')
        if (cab.size != 3 || cab[0] != "P") return null
        val an = cab[1].toIntOrNull() ?: return null
        val al = cab[2].toIntOrNull() ?: return null
        val pasos = ArrayList<PasoDeMacro>()
        for (l in lineas.drop(1)) {
            val c = l.split(';')
            if (c.size != 7) return null
            val tipo = TipoDePaso.deClave(c[0]) ?: return null
            val x = c[1].toFloatOrNull() ?: return null
            val y = c[2].toFloatOrNull() ?: return null
            val x2 = c[3].toFloatOrNull() ?: return null
            val y2 = c[4].toFloatOrNull() ?: return null
            val d = c[5].toLongOrNull() ?: return null
            val e = c[6].toLongOrNull() ?: return null
            pasos.add(PasoDeMacro(tipo, x, y, x2, y2, d, e))
        }
        return MacroGrabado(an, al, pasos)
    }

    /** Duración aproximada de repetir el macro entero, en milisegundos. */
    fun duracionTotalMs(macro: MacroGrabado): Long = macro.pasos.sumOf { it.esperaMs + it.duracionMs }

    fun resumen(macro: MacroGrabado): String {
        val toques = macro.pasos.count { it.tipo == TipoDePaso.TOQUE }
        val desliza = macro.pasos.size - toques
        val seg = duracionTotalMs(macro) / 1000.0
        return "$toques toque(s)" + (if (desliza > 0) ", $desliza deslizamiento(s)" else "") +
            String.format(Locale.US, ", unos %.1f s", seg)
    }
}
