package com.arosbot.ai.core

enum class EstadoReconocimiento(val etiqueta: String) {
    SIN_PROBAR("Sin probar"),
    RECONOCIDO("Reconocido en la última prueba"),
    NO_ENCONTRADO("No encontrado en la última prueba")
}

/**
 * Material de referencia. [archivos] contiene la imagen principal (primer elemento)
 * y las variantes visuales opcionales (resto), como nombres de archivo dentro de
 * la carpeta interna de materiales.
 */
data class Material(
    val id: Long,
    val nombre: String,
    val categoria: String,
    val umbral: Float,
    val ancho: Int,
    val alto: Int,
    val archivos: List<String>,
    val detecciones: Int,
    val ultimaConfianza: Float?,
    val estado: EstadoReconocimiento
) {
    val archivoPrincipal: String get() = archivos.firstOrNull() ?: ""
    val variantes: Int get() = maxOf(0, archivos.size - 1)
}

/**
 * Área de rastreo. El rectángulo está normalizado respecto al fotograma de referencia
 * de tamaño [refAncho] x [refAlto]. Si [materiales] está vacío, se buscan todos los materiales.
 */
data class Area(
    val id: Long,
    val nombre: String,
    val rect: NormRect,
    val refAncho: Int,
    val refAlto: Int,
    val activa: Boolean,
    val materiales: List<Long>
)
