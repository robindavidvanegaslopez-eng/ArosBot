package com.arosbot.ai.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Estado real de un módulo:
 *  - PENDIENTE: todavía no existe (llega en una fase posterior).
 *  - IMPLEMENTADO: el código existe pero aún no se ha comprobado en este dispositivo.
 *  - VERIFICADO: se ha comprobado con una prueba real (autoprueba o confirmación del usuario).
 */
enum class EstadoModulo { PENDIENTE, IMPLEMENTADO, VERIFICADO }

data class ModuleInfo(
    val id: Int,
    val nombre: String,
    val fase: Int,
    val estado: EstadoModulo
)

/**
 * Lista real de los 18 módulos de la arquitectura. El panel la muestra tal cual y el botón
 * "Iniciar bot" solo se activa cuando [bloqueos] está vacío, es decir, cuando todos los módulos
 * están VERIFICADOS.
 */
class ModuleRegistry {

    private val _modules = MutableStateFlow(modulosIniciales())
    val modules: StateFlow<List<ModuleInfo>> = _modules.asStateFlow()

    @Synchronized
    fun fijar(id: Int, estado: EstadoModulo) {
        _modules.value = _modules.value.map { if (it.id == id) it.copy(estado = estado) else it }
    }

    /** Módulos que impiden iniciar el bot. */
    fun bloqueos(): List<ModuleInfo> = _modules.value.filter { it.estado != EstadoModulo.VERIFICADO }

    private fun modulosIniciales(): List<ModuleInfo> = listOf(
        ModuleInfo(1, "Gestor de captura de pantalla", 2, EstadoModulo.IMPLEMENTADO),
        ModuleInfo(2, "Motor de visión artificial", 2, EstadoModulo.IMPLEMENTADO),
        ModuleInfo(3, "Administrador de imágenes de referencia", 2, EstadoModulo.IMPLEMENTADO),
        ModuleInfo(4, "Selector de áreas de rastreo", 2, EstadoModulo.IMPLEMENTADO),
        ModuleInfo(5, "Localizador del personaje", 3, EstadoModulo.IMPLEMENTADO),
        ModuleInfo(6, "Estimador de posición y movimiento", 3, EstadoModulo.IMPLEMENTADO),
        ModuleInfo(7, "Mapa visual del entorno", 4, EstadoModulo.IMPLEMENTADO),
        ModuleInfo(8, "Gestor de rutas", 4, EstadoModulo.IMPLEMENTADO),
        ModuleInfo(9, "Memoria persistente", 2, EstadoModulo.IMPLEMENTADO),
        ModuleInfo(10, "Motor de aprendizaje progresivo", 4, EstadoModulo.IMPLEMENTADO),
        ModuleInfo(11, "Planificador de navegación", 5, EstadoModulo.PENDIENTE),
        ModuleInfo(12, "Controlador WASD", 3, EstadoModulo.IMPLEMENTADO),
        ModuleInfo(13, "Gestor de spots", 5, EstadoModulo.PENDIENTE),
        ModuleInfo(14, "Detector de inventario lleno", 6, EstadoModulo.PENDIENTE),
        ModuleInfo(15, "Gestor de interacción y cofre", 6, EstadoModulo.PENDIENTE),
        ModuleInfo(16, "Máquina de estados autónoma", 1, EstadoModulo.VERIFICADO),
        ModuleInfo(17, "Interfaz de supervisión", 1, EstadoModulo.VERIFICADO),
        ModuleInfo(18, "Registro de actividad y errores", 1, EstadoModulo.VERIFICADO)
    )
}
