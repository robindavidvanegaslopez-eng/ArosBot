package com.arosbot.ai.core

import kotlin.math.hypot
import kotlin.math.min

/*
 * Lógica pura (sin Android) de la medición del movimiento: cómo se combinan las mediciones de varios
 * recortes, cómo se decide si un paso fue medido, quieto o ilegible, cómo se cierra un bucle al volver al
 * punto de partida y cómo se rodea un obstáculo.
 */

/** Lo que se leyó entre dos fotogramas: desplazamiento (si se pudo medir) y cuánto cambió la imagen. */
data class Lectura(val medicion: Medicion?, val diferencia: Double?)

enum class ClasePaso {
    /** Hay un desplazamiento medido con confianza suficiente (puede ser ~0 px). */
    MEDIDO,

    /** La escena no cambió: el personaje no avanza (choque) aunque no haya textura para correlacionar. */
    QUIETO,

    /** La imagen cambió pero no se pudo medir cuánto. */
    SIN_MEDIDA
}

object ClasificadorDePaso {

    const val CONFIANZA_MINIMA = 0.08

    /** Diferencia media absoluta (niveles de gris, 0-255) por debajo de la cual la escena está quieta. */
    const val DIFERENCIA_QUIETA = 1.0

    /** Un desplazamiento menor que esto se considera ruido para decidir entre medido y quieto. */
    const val MOVIMIENTO_DESPRECIABLE_PX = 2.0

    fun clasificar(lectura: Lectura): ClasePaso {
        val m = lectura.medicion
        val fiable = m != null && m.confianza >= CONFIANZA_MINIMA
        if (m != null && fiable && hypot(m.dx, m.dy) >= MOVIMIENTO_DESPRECIABLE_PX) return ClasePaso.MEDIDO
        val d = lectura.diferencia
        if (d != null && d < DIFERENCIA_QUIETA) return ClasePaso.QUIETO
        if (fiable) return ClasePaso.MEDIDO
        return ClasePaso.SIN_MEDIDA
    }
}

/**
 * Combina las mediciones de varios recortes. Con tres o más usa la mediana de cada componente (un recorte
 * con un elemento fijo de la interfaz, que marca 0 px, no arrastra al resto); con menos se queda con la
 * de mayor confianza.
 */
object ConsensoDeMediciones {

    fun combinar(lista: List<Medicion>): Medicion? {
        if (lista.isEmpty()) return null
        val fuente = lista.first().fuente
        if (lista.size < 3) return lista.maxByOrNull { it.confianza }
        return Medicion(
            mediana(lista.map { it.dx }),
            mediana(lista.map { it.dy }),
            mediana(lista.map { it.confianza }),
            fuente
        )
    }

    fun mediana(valores: List<Double>): Double {
        val o = valores.sorted()
        val n = o.size
        return if (n % 2 == 1) o[n / 2] else (o[n / 2 - 1] + o[n / 2]) / 2.0
    }
}

/**
 * Cierre de bucle: si al terminar de enseñar una ruta se reconoce visualmente la referencia del inicio,
 * el personaje está otra vez en el punto de partida. La diferencia con la posición acumulada es deriva de
 * la medición y se reparte a lo largo del recorrido (más cuanto más lejos del inicio), de modo que el
 * punto final coincide con el inicial.
 */
object CierreDeBucle {

    const val CONFIANZA_MINIMA = 0.7
    const val ERROR_MAXIMO_PX = 350.0
    const val RECORRIDO_MINIMO_PX = 150.0

    fun aplicable(confianza: Double, errorX: Double, errorY: Double, recorridoPx: Double): Boolean =
        confianza >= CONFIANZA_MINIMA &&
            hypot(errorX, errorY) <= ERROR_MAXIMO_PX &&
            recorridoPx >= RECORRIDO_MINIMO_PX

    /** Distancia por debajo de la cual el final se fija exactamente en el píxel del inicio. */
    const val AJUSTE_AL_INICIO_PX = 25.0

    /**
     * Dónde debe quedar el último punto: si lo reconocido ([reconocidoX], [reconocidoY]) está a menos de
     * [AJUSTE_AL_INICIO_PX] del punto inicial, el personaje volvió al mismo sitio y el final se fija
     * exactamente en el inicial (mismo píxel); si no, donde dice el reconocimiento.
     */
    fun objetivoDelFinal(inicial: PuntoDeRuta, reconocidoX: Double, reconocidoY: Double): Pair<Double, Double> =
        if (hypot(reconocidoX - inicial.x, reconocidoY - inicial.y) <= AJUSTE_AL_INICIO_PX) {
            Pair(inicial.x, inicial.y)
        } else {
            Pair(reconocidoX, reconocidoY)
        }

    fun longitud(puntos: List<PuntoDeRuta>): Double {
        var t = 0.0
        for (i in 1 until puntos.size) t += hypot(puntos[i].x - puntos[i - 1].x, puntos[i].y - puntos[i - 1].y)
        return t
    }

    /** Reparte el error ([ex], [ey]) que hay que sumar al último punto, proporcional al recorrido. */
    fun corregir(puntos: List<PuntoDeRuta>, ex: Double, ey: Double): List<PuntoDeRuta> {
        val total = longitud(puntos)
        if (puntos.size < 2 || total < 1e-6) return puntos
        var acumulado = 0.0
        val resultado = ArrayList<PuntoDeRuta>(puntos.size)
        for (i in puntos.indices) {
            if (i > 0) acumulado += hypot(puntos[i].x - puntos[i - 1].x, puntos[i].y - puntos[i - 1].y)
            val f = acumulado / total
            resultado.add(puntos[i].copy(x = puntos[i].x + ex * f, y = puntos[i].y + ey * f))
        }
        return resultado
    }
}

/** Intentos de rodear un obstáculo: puntos laterales por los que pasar antes de volver al objetivo. */
object Rodeo {

    private val DISTANCIAS_PX = listOf(90.0, 90.0, 180.0, 180.0, 300.0, 300.0)

    val INTENTOS_MAXIMOS: Int get() = DISTANCIAS_PX.size

    /**
     * Punto de paso para el intento [intento] (0, 1, 2…): alterna derecha e izquierda del rumbo hacia el
     * objetivo y va separándose más. null si ya se agotaron los intentos.
     */
    fun puntoDePaso(x: Double, y: Double, objetivoX: Double, objetivoY: Double, intento: Int): PuntoXY? {
        if (intento < 0 || intento >= DISTANCIAS_PX.size) return null
        val dx = objetivoX - x
        val dy = objetivoY - y
        val largo = hypot(dx, dy)
        if (largo < 1e-6) return null
        val lado = if (intento % 2 == 0) 1.0 else -1.0
        val nx = -dy / largo * lado
        val ny = dx / largo * lado
        val d = DISTANCIAS_PX[intento]
        // Un pequeño avance hacia el objetivo evita pegarse a la esquina del obstáculo.
        val avance = min(40.0, largo * 0.3)
        return PuntoXY(
            (x + nx * d + dx / largo * avance).toFloat(),
            (y + ny * d + dy / largo * avance).toFloat()
        )
    }

}
