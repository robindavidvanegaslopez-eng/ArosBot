package com.arosbot.ai.core

import java.text.Normalizer
import kotlin.math.hypot

/*
 * Lógica pura de la Fase 6 (recolección, inventario lleno y cofre). Nada de aquí toca Android: son
 * las reglas de decisión que se prueban en JVM. Mirar la pantalla, pulsar y moverse lo hacen los
 * objetos de `automation`, que aplican estas reglas.
 */

// ---------- Qué imagen de referencia cumple cada función ----------

/** Funciones que el usuario asigna a sus imágenes de referencia por categoría o por nombre. */
enum class FuncionVisual(val etiqueta: String, val ejemplo: String) {
    INVENTARIO_LLENO("Aviso de inventario lleno", "Inventario lleno"),
    DEPOSITAR("Botón de depositar", "Depositar"),
    CERRAR("Botón de cerrar el cofre", "Cerrar cofre"),
    INTERACTUAR("Botón de interactuar", "Interactuar"),
    COFRE_ABIERTO("Interfaz del cofre abierto", "Cofre abierto"),
    COFRE("Cofre en el mundo", "Cofre")
}

object SelectorDeFunciones {

    private fun normalizar(t: String): String =
        Normalizer.normalize(t, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase()

    /** La función de un material según su categoría y nombre, o null si no es de ninguna. */
    fun funcionDe(categoria: String, nombre: String): FuncionVisual? {
        val t = normalizar("$categoria $nombre")
        fun tiene(vararg claves: String) = claves.any { t.contains(it) }
        return when {
            tiene("inventario lleno", "inventory full", "inventory is full", "lleno", "full") ->
                FuncionVisual.INVENTARIO_LLENO
            tiene("depositar", "deposit") -> FuncionVisual.DEPOSITAR
            tiene("cerrar", "close") -> FuncionVisual.CERRAR
            tiene("interactuar", "interact") -> FuncionVisual.INTERACTUAR
            tiene("cofre", "chest", "almacen", "storage") &&
                tiene("abierto", "interfaz", "open", "almacen", "storage") -> FuncionVisual.COFRE_ABIERTO
            tiene("cofre", "chest") -> FuncionVisual.COFRE
            else -> null
        }
    }

    /** Todos los materiales que cumplen [funcion] (puede haber varios: indicadores alternativos). */
    fun con(funcion: FuncionVisual, materiales: List<Material>): List<Material> =
        materiales.filter { funcionDe(it.categoria, it.nombre) == funcion }

    /** true si el material de recolección NO es uno de utilidad (cofre, botones, avisos). */
    fun esDeRecoleccion(material: Material): Boolean =
        funcionDe(material.categoria, material.nombre) == null &&
            !material.categoria.trim().equals("personaje", ignoreCase = true) &&
            !material.nombre.contains("personaje", ignoreCase = true)
}

// ---------- Inventario ----------

enum class LecturaInventario(val etiqueta: String) {
    LLENO("Lleno"),
    NO_LLENO("No está lleno"),
    INCIERTO("Incierto")
}

/**
 * Convierte varias observaciones sueltas en una sola lectura fiable. Cada muestra es true (se vio el
 * indicador), false (no se vio) o null (no se pudo mirar: sin fotograma). Solo hay veredicto si hay
 * suficientes muestras válidas y casi todas coinciden; si no, es INCIERTO y el bot debe parar o
 * repetir, nunca adivinar.
 */
object LectorDeInventario {

    const val MUESTRAS_MINIMAS_VALIDAS = 4
    const val POSITIVAS_PARA_LLENO = 3

    fun leer(
        muestras: List<Boolean?>,
        minimasValidas: Int = MUESTRAS_MINIMAS_VALIDAS,
        positivasParaLleno: Int = POSITIVAS_PARA_LLENO
    ): LecturaInventario {
        val validas = muestras.filterNotNull()
        if (validas.size < minimasValidas) return LecturaInventario.INCIERTO
        val positivas = validas.count { it }
        return when {
            positivas >= positivasParaLleno -> LecturaInventario.LLENO
            positivas == 0 -> LecturaInventario.NO_LLENO
            else -> LecturaInventario.INCIERTO
        }
    }
}

// ---------- Recogida de un recurso ----------

enum class ResultadoDeRecogida(val etiqueta: String) {
    RECOGIDO("Recogido"),
    NO_RECOGIDO("No se recogió"),
    DUDOSO("No se pudo comprobar")
}

/**
 * Comprueba si un recurso se recogió: tras interactuar, el recurso que estaba en [objetivo] ya no
 * debe verse en esa posición. Cada muestra es la lista de posiciones del mismo material vistas
 * después. La cámara sigue al personaje y este está quieto, así que la posición no cambia.
 */
object VerificadorDeRecogida {

    const val RADIO_PX = 45f
    const val MUESTRAS_MINIMAS = 3

    fun evaluar(
        objetivo: PuntoXY,
        despues: List<List<PuntoXY>?>,
        radio: Float = RADIO_PX
    ): ResultadoDeRecogida {
        val validas = despues.filterNotNull()
        if (validas.size < MUESTRAS_MINIMAS) return ResultadoDeRecogida.DUDOSO
        val sigue = validas.count { muestra ->
            muestra.any { hypot((it.x - objetivo.x).toDouble(), (it.y - objetivo.y).toDouble()) <= radio }
        }
        return when {
            sigue == 0 -> ResultadoDeRecogida.RECOGIDO
            sigue * 2 > validas.size -> ResultadoDeRecogida.NO_RECOGIDO
            else -> ResultadoDeRecogida.DUDOSO
        }
    }
}

// ---------- Acercarse al recurso ----------

sealed class Acercamiento {
    object EnRango : Acercamiento()
    data class Mover(val direccion: Direccion, val duracionMs: Long) : Acercamiento()
    data class SinCalibracion(val direccion: Direccion) : Acercamiento()
}

/** Decide el siguiente paso para acercarse a un recurso hasta quedar dentro del rango de interacción. */
object GuiaDeAcercamiento {

    const val RANGO_PX = 80.0
    const val PULSACION_MINIMA_MS = 120L
    const val PULSACION_MAXIMA_MS = 700L

    /**
     * [dx], [dy]: del personaje al recurso en píxeles del fotograma (el recurso está a la derecha si
     * dx > 0 y abajo si dy > 0). Se avanza solo la fracción 0.8 de lo que falta para no pasarse.
     */
    fun siguiente(
        dx: Double,
        dy: Double,
        calibraciones: Map<Direccion, Calibracion>,
        diagonales: Boolean,
        rango: Double = RANGO_PX
    ): Acercamiento {
        val distancia = hypot(dx, dy)
        if (distancia <= rango) return Acercamiento.EnRango
        var direccion = Direccion.masCercana(dx, dy)
        if (direccion.esDiagonal && !diagonales) {
            direccion = if (Math.abs(dx) >= Math.abs(dy)) {
                if (dx > 0) Direccion.D else Direccion.A
            } else {
                if (dy > 0) Direccion.S else Direccion.W
            }
        }
        val calibracion = Calibraciones.para(calibraciones, direccion)
            ?: return Acercamiento.SinCalibracion(direccion)
        val rapidez = calibracion.rapidez
        if (rapidez <= 1e-6) return Acercamiento.SinCalibracion(direccion)
        val objetivoPx = (distancia - rango * 0.5) * 0.8
        val ms = (objetivoPx / rapidez * 1000.0).toLong()
        return Acercamiento.Mover(
            direccion,
            ms.coerceIn(PULSACION_MINIMA_MS, PULSACION_MAXIMA_MS)
        )
    }
}

// ---------- Límites, reintentos y paradas ----------

sealed class Decision {
    object Continuar : Decision()
    data class Detener(val motivo: String) : Decision()
}

/**
 * Controla los límites de una sesión de recolección. Cuenta fallos y decide si seguir o parar:
 * el bot nunca insiste sin fin. Se detiene si hay demasiados fallos seguidos, si el inventario es
 * incierto, si el depósito falla o si un spot tras otro no da nada.
 */
class ControlDeSesion(
    private val maxFallosSeguidos: Int = 5,
    private val maxIntentosPorRecurso: Int = 3,
    private val maxFallosDeDeposito: Int = 2,
    private val maxSpotsVaciosSeguidos: Int = 4,
    private val maxRecursosPorSpot: Int = 40
) {
    var recogidos = 0
        private set
    var fallos = 0
        private set
    var depositos = 0
        private set
    private var fallosSeguidos = 0
    private var fallosDeDeposito = 0
    private var spotsVacios = 0
    private var recursosEnSpot = 0

    /** Reinicia el contador de intentos al empezar con un nuevo recurso. */
    fun intentosPermitidos(): Int = maxIntentosPorRecurso

    fun recogida(resultado: ResultadoDeRecogida): Decision {
        if (resultado == ResultadoDeRecogida.RECOGIDO) {
            recogidos++
            recursosEnSpot++
            fallosSeguidos = 0
            spotsVacios = 0
            return if (recursosEnSpot >= maxRecursosPorSpot) {
                Decision.Detener(
                    "Se recogieron $maxRecursosPorSpot recursos seguidos en el mismo spot sin confirmar " +
                        "que el inventario se llene: parece que algo no se comprueba bien."
                )
            } else Decision.Continuar
        }
        fallos++
        fallosSeguidos++
        return if (fallosSeguidos >= maxFallosSeguidos) {
            Decision.Detener("$fallosSeguidos recogidas seguidas sin éxito: algo falla (rango, botón de interactuar o visión).")
        } else Decision.Continuar
    }

    fun nuevoSpot() {
        recursosEnSpot = 0
    }

    /** Se terminó de mirar un spot; [recogidosAhi] son los recursos recogidos en esa visita. */
    fun spotTerminado(recogidosAhi: Int): Decision {
        if (recogidosAhi > 0) {
            spotsVacios = 0
            return Decision.Continuar
        }
        spotsVacios++
        return if (spotsVacios >= maxSpotsVaciosSeguidos) {
            Decision.Detener("$spotsVacios spots seguidos sin recoger nada. Revisa las imágenes de los materiales.")
        } else Decision.Continuar
    }

    fun deposito(exito: Boolean): Decision {
        if (exito) {
            depositos++
            fallosDeDeposito = 0
            return Decision.Continuar
        }
        fallosDeDeposito++
        return if (fallosDeDeposito >= maxFallosDeDeposito) {
            Decision.Detener(
                "El depósito falló $fallosDeDeposito veces seguidas (¿cofre lleno, interfaz o botón sin reconocer?)."
            )
        } else Decision.Continuar
    }

    fun inventarioIncierto(): Decision =
        Decision.Detener("No se pudo saber con seguridad si el inventario está lleno. Por precaución, el bot se detiene.")
}

// ---------- Planificador por objetivos ----------

enum class Objetivo(val etiqueta: String) {
    ELEGIR_SPOT("Elegir spot"),
    IR_AL_SPOT("Ir al spot"),
    RECOGER("Recoger recursos"),
    IR_AL_COFRE("Volver al cofre"),
    DEPOSITAR("Depositar en el cofre"),
    DETENIDO("Detenido")
}

enum class Evento {
    SPOT_ELEGIDO,
    LLEGADO,
    SPOT_AGOTADO,
    INVENTARIO_LLENO,
    LLEGADO_AL_COFRE,
    DEPOSITADO,
    FALLO
}

/**
 * Transiciones entre objetivos. Cada una se basa en un hecho comprobado (un evento), nunca en un
 * temporizador. Cualquier evento inesperado detiene el bot en vez de improvisar.
 */
object PlanificadorDeObjetivos {

    fun siguiente(actual: Objetivo, evento: Evento): Objetivo {
        if (evento == Evento.FALLO) return Objetivo.DETENIDO
        return when (actual) {
            Objetivo.ELEGIR_SPOT -> when (evento) {
                Evento.SPOT_ELEGIDO -> Objetivo.IR_AL_SPOT
                else -> Objetivo.DETENIDO
            }
            Objetivo.IR_AL_SPOT -> when (evento) {
                Evento.LLEGADO -> Objetivo.RECOGER
                Evento.SPOT_AGOTADO -> Objetivo.ELEGIR_SPOT
                Evento.INVENTARIO_LLENO -> Objetivo.IR_AL_COFRE
                else -> Objetivo.DETENIDO
            }
            Objetivo.RECOGER -> when (evento) {
                Evento.SPOT_AGOTADO -> Objetivo.ELEGIR_SPOT
                Evento.INVENTARIO_LLENO -> Objetivo.IR_AL_COFRE
                else -> Objetivo.DETENIDO
            }
            Objetivo.IR_AL_COFRE -> when (evento) {
                Evento.LLEGADO_AL_COFRE -> Objetivo.DEPOSITAR
                else -> Objetivo.DETENIDO
            }
            Objetivo.DEPOSITAR -> when (evento) {
                Evento.DEPOSITADO -> Objetivo.ELEGIR_SPOT
                else -> Objetivo.DETENIDO
            }
            Objetivo.DETENIDO -> Objetivo.DETENIDO
        }
    }
}

// ---------- Depósito en el cofre ----------

enum class PasoDeCofre(val etiqueta: String) {
    RECONOCER_COFRE("Reconocer el cofre"),
    ABRIR("Abrir el cofre"),
    RECONOCER_INTERFAZ("Reconocer la interfaz de almacenamiento"),
    DEPOSITAR("Pulsar depositar"),
    VERIFICAR("Verificar el depósito"),
    CERRAR("Cerrar el cofre"),
    COMPROBAR_INVENTARIO("Comprobar el inventario"),
    LISTO("Depósito completado")
}

object SecuenciaDeCofre {
    val orden: List<PasoDeCofre> = listOf(
        PasoDeCofre.RECONOCER_COFRE,
        PasoDeCofre.ABRIR,
        PasoDeCofre.RECONOCER_INTERFAZ,
        PasoDeCofre.DEPOSITAR,
        PasoDeCofre.VERIFICAR,
        PasoDeCofre.CERRAR,
        PasoDeCofre.COMPROBAR_INVENTARIO,
        PasoDeCofre.LISTO
    )

    fun siguiente(paso: PasoDeCofre): PasoDeCofre? =
        orden.getOrNull(orden.indexOf(paso) + 1)

    /**
     * Imágenes de referencia que faltan para poder hacer la secuencia completa. «Interactuar» es
     * opcional: sin él se abre el cofre pulsando sobre el propio cofre.
     */
    fun faltantes(materiales: List<Material>): List<FuncionVisual> =
        listOf(
            FuncionVisual.INVENTARIO_LLENO,
            FuncionVisual.COFRE,
            FuncionVisual.COFRE_ABIERTO,
            FuncionVisual.DEPOSITAR,
            FuncionVisual.CERRAR
        ).filter { SelectorDeFunciones.con(it, materiales).isEmpty() }
}

/** El depósito solo cuenta si el inventario pasó de lleno a no lleno. */
object VerificadorDeDeposito {
    fun exito(antes: LecturaInventario, despues: LecturaInventario): Boolean =
        antes == LecturaInventario.LLENO && despues == LecturaInventario.NO_LLENO
}

// ---------- Estadísticas de recolección por spot ----------

data class EstadisticaDeRecoleccion(
    val spotId: Long,
    val recogidos: Int,
    val fallos: Int,
    val ultimaMs: Long
) {
    /** Porcentaje de recogidas con éxito, o null si todavía no hay intentos. */
    val tasaDeExito: Double?
        get() = if (recogidos + fallos == 0) null else recogidos.toDouble() / (recogidos + fallos)
}

object ActualizacionDeEstadistica {
    fun sumar(
        actual: EstadisticaDeRecoleccion?,
        spotId: Long,
        recogidos: Int,
        fallos: Int,
        ahoraMs: Long
    ): EstadisticaDeRecoleccion {
        val base = actual ?: EstadisticaDeRecoleccion(spotId, 0, 0, 0L)
        return base.copy(
            recogidos = base.recogidos + recogidos.coerceAtLeast(0),
            fallos = base.fallos + fallos.coerceAtLeast(0),
            ultimaMs = ahoraMs
        )
    }
}
