package com.arosbot.ai.core

import kotlin.math.hypot

/**
 * Lógica pura de la recolección por ruta (sin Android): volver por la misma ruta en sentido contrario,
 * elegir el material al que acercarse, decidir hasta dónde acercarse y descartar los inalcanzables.
 */
object CaminoDeVuelta {

    /** Índice del punto de [puntos] más cercano a ([x], [y]); -1 si no hay puntos. */
    fun indiceMasCercano(puntos: List<PuntoDeRuta>, x: Double, y: Double): Int {
        var mejor = -1
        var mejorD = Double.MAX_VALUE
        for ((i, p) in puntos.withIndex()) {
            val d = hypot(p.x - x, p.y - y)
            if (d < mejorD) {
                mejorD = d
                mejor = i
            }
        }
        return mejor
    }

    /**
     * Camino de vuelta: los puntos de la ida desde [indice] hasta el primero, al revés y SIN cambiar de
     * marco de coordenadas (a diferencia de [Ruta.puntosEnSentido], que recentra), para que las
     * capturas de referencia y la posición medida sigan valiendo.
     */
    fun desde(puntos: List<PuntoDeRuta>, indice: Int): List<PuntoDeRuta> {
        if (puntos.isEmpty()) return emptyList()
        val i = indice.coerceIn(0, puntos.lastIndex)
        return (i downTo 0).map { puntos[it] }
    }
}

/** Materiales descartados (inalcanzables o que no se pudieron recoger), por su posición en el mundo. */
class ListaNegraDeMateriales(private val radioPx: Double = RADIO_PX) {
    private val puntos = ArrayList<Pair<Double, Double>>()

    val tamano: Int get() = puntos.size

    fun agregar(x: Double, y: Double) {
        if (!contiene(x, y)) puntos.add(Pair(x, y))
    }

    fun contiene(x: Double, y: Double): Boolean =
        puntos.any { hypot(it.first - x, it.second - y) <= radioPx }

    fun vaciar() = puntos.clear()

    companion object {
        const val RADIO_PX = 70.0
    }
}

/** Cuenta cuántas veces seguidas se cumplió una condición (para no reaccionar a un solo fotograma). */
class Persistencia(private val minimo: Int) {
    private var seguidas = 0

    fun anotar(cumple: Boolean): Boolean {
        seguidas = if (cumple) seguidas + 1 else 0
        return seguidas >= minimo
    }

    fun reiniciar() {
        seguidas = 0
    }
}

/** Elección del material al que ir: el más cercano al personaje que no esté descartado. */
object ElectorDeMaterial {

    /**
     * [desplazamiento] da (dx, dy) del personaje al material en píxeles del fotograma; [x], [y] es la
     * posición del personaje en el marco de la ruta, con la que se sitúa cada material en el mundo.
     */
    fun <T> elegir(
        candidatos: List<T>,
        desplazamiento: (T) -> Pair<Double, Double>,
        x: Double,
        y: Double,
        negra: ListaNegraDeMateriales
    ): T? {
        var mejor: T? = null
        var mejorD = Double.MAX_VALUE
        for (c in candidatos) {
            val (dx, dy) = desplazamiento(c)
            if (negra.contiene(x + dx, y + dy)) continue
            val d = hypot(dx, dy)
            if (d < mejorD) {
                mejorD = d
                mejor = c
            }
        }
        return mejor
    }
}

/**
 * Hasta dónde acercarse a un material: muy cerca del centro de la pantalla (donde está el personaje)
 * pero sin llegar a él, para no chocar. Se queda a [DISTANCIA_OBJETIVO_PX] del material.
 */
object PuntoDeAcercamiento {

    const val DISTANCIA_OBJETIVO_PX = 38.0

    /** Dentro de este radio ya se puede interactuar sin moverse más. */
    const val RANGO_INTERACCION_PX = 70.0

    /**
     * ([dx], [dy]): del personaje al material. Devuelve cuánto hay que desplazarse (también en px), o
     * null si ya está dentro del rango de interacción.
     */
    fun calcular(dx: Double, dy: Double): Pair<Double, Double>? {
        val d = hypot(dx, dy)
        if (d <= RANGO_INTERACCION_PX) return null
        val k = (d - DISTANCIA_OBJETIVO_PX) / d
        return Pair(dx * k, dy * k)
    }
}

/** Colisión entre cuadros de detección: el material toca al personaje cuando sus cuadros se solapan. */
object Colision {
    /** true si [a] y [b] se solapan o están a menos de [margen] px (el margen agranda [b]). */
    fun tocan(a: Box, b: Box, margen: Int = 0): Boolean =
        a.left < b.right + margen && a.right > b.left - margen &&
            a.top < b.bottom + margen && a.bottom > b.top - margen
}

/** Un material situado en el mundo (marco de la ruta). */
data class MaterialEnMundo(val id: Long, val nombre: String, val x: Double, val y: Double, val ancho: Int, val alto: Int)

/**
 * Filtro contra falsos positivos: un material solo cuenta si aparece en el mismo punto del MUNDO en al
 * menos [minimo] de las últimas [ventana] lecturas. Un reconocimiento suelto (otra textura que se
 * parece) no hace que el bot se desvíe.
 */
class FiltroDeEstabilidad(
    private val ventana: Int = 4,
    private val minimo: Int = 3,
    private val radioPx: Double = 35.0
) {
    private val historial = ArrayDeque<List<MaterialEnMundo>>()

    @Synchronized
    fun anotar(lectura: List<MaterialEnMundo>) {
        historial.addLast(lectura)
        while (historial.size > ventana) historial.removeFirst()
    }

    @Synchronized
    fun vaciar() = historial.clear()

    /** Materiales de la última lectura vistos en el mismo sitio en suficientes lecturas (posición media). */
    @Synchronized
    fun estables(): List<MaterialEnMundo> {
        val ultima = historial.lastOrNull() ?: return emptyList()
        if (historial.size < minimo) return emptyList()
        val salida = ArrayList<MaterialEnMundo>()
        for (m in ultima) {
            val coincidencias = ArrayList<MaterialEnMundo>()
            for (lectura in historial) {
                val c = lectura.firstOrNull { it.id == m.id && hypot(it.x - m.x, it.y - m.y) <= radioPx }
                if (c != null) coincidencias.add(c)
            }
            if (coincidencias.size >= minimo) {
                salida.add(
                    m.copy(x = coincidencias.map { it.x }.average(), y = coincidencias.map { it.y }.average())
                )
            }
        }
        return salida
    }
}
