package com.arosbot.ai.core

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.zip.CRC32

/*
 * Copia de seguridad completa de la aplicación, en un único archivo (.arosbot) con un formato propio
 * que solo ArosBot AI sabe leer: cabecera, entradas con nombre y suma de comprobación. Lleva los
 * materiales con sus imágenes, las áreas, el joystick, el macro del cofre, la captura de trabajo y todo
 * lo aprendido (rutas, spots, calibraciones, referencias visuales).
 */

/** Lo que va en la parte de configuración de la copia. */
data class ConfiguracionCopia(
    val materiales: List<Material>,
    val areas: List<Area>,
    val joystick: JoystickConfig?,
    val macroCofre: String,
    val lugarCofreId: Long
)

/** Todo el contenido de una copia, ya leído. */
class ContenidoDeRespaldo(
    val configuracion: ConfiguracionCopia,
    val aprendizaje: CopiaDeAprendizaje,
    val imagenesMateriales: Map<String, ByteArray>,
    val captura: ByteArray?
) {
    /** Resumen para mostrar al usuario antes de importar. */
    fun resumen(): String =
        "${configuracion.materiales.size} materiales (${imagenesMateriales.size} imágenes), " +
            "${configuracion.areas.size} áreas, ${aprendizaje.rutas.size} rutas, ${aprendizaje.spots.size} spots" +
            (if (configuracion.joystick != null) ", joystick" else "") +
            (if (configuracion.macroCofre.isNotBlank()) ", macro del cofre" else "") +
            (if (captura != null) ", captura de trabajo" else "")
}

object PaqueteDeRespaldo {

    private val MAGIA = byteArrayOf(0x41, 0x52, 0x4F, 0x53, 0x42, 0x4B, 0x01, 0x7F) // «AROSBK» + versión
    private const val MAX_ENTRADAS = 20_000
    private const val MAX_BYTES_ENTRADA = 64 * 1024 * 1024

    const val EXTENSION = "arosbot"

    private const val E_CONFIG = "config"
    private const val E_APRENDIZAJE = "aprendizaje"
    private const val E_CAPTURA = "captura"
    private const val PREFIJO_MATERIAL = "material/"

    fun empaquetar(c: ContenidoDeRespaldo): ByteArray {
        val entradas = LinkedHashMap<String, ByteArray>()
        entradas[E_CONFIG] = FormatoDeConfiguracion.escribir(c.configuracion).toByteArray(Charsets.UTF_8)
        entradas[E_APRENDIZAJE] = FormatoDeCopia.escribir(c.aprendizaje).toByteArray(Charsets.UTF_8)
        for ((nombre, bytes) in c.imagenesMateriales) entradas[PREFIJO_MATERIAL + nombre] = bytes
        c.captura?.let { entradas[E_CAPTURA] = it }
        return escribirEntradas(entradas)
    }

    /** null si el archivo no es de ArosBot AI, está incompleto o dañado. */
    fun desempaquetar(bytes: ByteArray): ContenidoDeRespaldo? {
        val entradas = leerEntradas(bytes) ?: return null
        val config = entradas[E_CONFIG]?.let { FormatoDeConfiguracion.leer(String(it, Charsets.UTF_8)) } ?: return null
        val aprendizaje = entradas[E_APRENDIZAJE]?.let { FormatoDeCopia.leer(String(it, Charsets.UTF_8)) } ?: return null
        val imagenes = LinkedHashMap<String, ByteArray>()
        for ((nombre, datos) in entradas) {
            if (!nombre.startsWith(PREFIJO_MATERIAL)) continue
            val simple = nombre.removePrefix(PREFIJO_MATERIAL)
            if (!nombreSimple(simple)) return null
            imagenes[simple] = datos
        }
        return ContenidoDeRespaldo(config, aprendizaje, imagenes, entradas[E_CAPTURA])
    }

    /** Solo nombres de archivo simples: una copia ajena no puede escribir fuera de su carpeta. */
    fun nombreSimple(nombre: String): Boolean =
        nombre.isNotEmpty() && !nombre.contains('/') && !nombre.contains('\\') && !nombre.startsWith(".")

    fun escribirEntradas(entradas: Map<String, ByteArray>): ByteArray {
        val cuerpo = ByteArrayOutputStream()
        val d = DataOutputStream(cuerpo)
        d.write(MAGIA)
        d.writeInt(entradas.size)
        for ((nombre, datos) in entradas) {
            val n = nombre.toByteArray(Charsets.UTF_8)
            d.writeInt(n.size)
            d.write(n)
            d.writeInt(datos.size)
            d.write(datos)
        }
        d.flush()
        val bytes = cuerpo.toByteArray()
        val crc = CRC32()
        crc.update(bytes)
        val salida = ByteArrayOutputStream(bytes.size + 8)
        salida.write(bytes)
        DataOutputStream(salida).writeLong(crc.value)
        return salida.toByteArray()
    }

    fun leerEntradas(bytes: ByteArray): Map<String, ByteArray>? {
        if (bytes.size < MAGIA.size + 4 + 8) return null
        val cuerpoLen = bytes.size - 8
        val crc = CRC32()
        crc.update(bytes, 0, cuerpoLen)
        val esperado = DataInputStream(ByteArrayInputStream(bytes, cuerpoLen, 8)).readLong()
        if (crc.value != esperado) return null
        return try {
            val d = DataInputStream(ByteArrayInputStream(bytes, 0, cuerpoLen))
            val magia = ByteArray(MAGIA.size)
            d.readFully(magia)
            if (!magia.contentEquals(MAGIA)) return null
            val cuenta = d.readInt()
            if (cuenta < 0 || cuenta > MAX_ENTRADAS) return null
            val resultado = LinkedHashMap<String, ByteArray>()
            repeat(cuenta) {
                val nl = d.readInt()
                if (nl <= 0 || nl > 512 || nl > d.available()) return null
                val n = ByteArray(nl)
                d.readFully(n)
                val dl = d.readInt()
                if (dl < 0 || dl > MAX_BYTES_ENTRADA || dl > d.available()) return null
                val datos = ByteArray(dl)
                d.readFully(datos)
                resultado[String(n, Charsets.UTF_8)] = datos
            }
            resultado
        } catch (e: Exception) {
            null
        }
    }
}

/** Parte de configuración de la copia, en el mismo formato de texto con barras que usa el aprendizaje. */
object FormatoDeConfiguracion {

    private const val CABECERA = "AROSBOT-CONFIG 1"

    private fun esc(s: String): String =
        s.replace("\\", "\\\\").replace("|", "\\p").replace("\n", "\\n").replace("\r", "")

    private fun des(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) {
                    'p' -> sb.append('|')
                    'n' -> sb.append('\n')
                    else -> sb.append(s[i + 1])
                }
                i += 2
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
    }

    fun escribir(c: ConfiguracionCopia): String {
        val sb = StringBuilder()
        sb.append(CABECERA).append('\n')
        for (m in c.materiales) {
            sb.append(
                "M|${m.id}|${esc(m.nombre)}|${esc(m.categoria)}|${m.umbral}|${m.ancho}|${m.alto}|" +
                    "${m.archivos.joinToString(",") { esc(it) }}\n"
            )
        }
        for (a in c.areas) {
            sb.append(
                "A|${a.id}|${esc(a.nombre)}|${a.rect.x}|${a.rect.y}|${a.rect.w}|${a.rect.h}|" +
                    "${a.refAncho}|${a.refAlto}|${if (a.activa) 1 else 0}|${a.materiales.joinToString(",")}\n"
            )
        }
        c.joystick?.let {
            sb.append("J|${it.rect.x}|${it.rect.y}|${it.rect.w}|${it.rect.h}|${it.refAncho}|${it.refAlto}\n")
        }
        sb.append("K|${esc(c.macroCofre)}\n")
        sb.append("Q|${c.lugarCofreId}\n")
        return sb.toString()
    }

    fun leer(texto: String): ConfiguracionCopia? {
        val lineas = texto.lines()
        if (lineas.isEmpty() || lineas[0].trim() != CABECERA) return null
        val materiales = ArrayList<Material>()
        val areas = ArrayList<Area>()
        var joystick: JoystickConfig? = null
        var macro = ""
        var cofre = -1L
        try {
            for (linea in lineas.drop(1)) {
                if (linea.isBlank()) continue
                val c = linea.split("|")
                when (c[0]) {
                    "M" -> materiales.add(
                        Material(
                            id = c[1].toLong(),
                            nombre = des(c[2]),
                            categoria = des(c[3]),
                            umbral = c[4].toFloat(),
                            ancho = c[5].toInt(),
                            alto = c[6].toInt(),
                            archivos = c[7].split(",").filter { it.isNotBlank() }.map { des(it) },
                            detecciones = 0,
                            ultimaConfianza = null,
                            estado = EstadoReconocimiento.SIN_PROBAR
                        )
                    )
                    "A" -> areas.add(
                        Area(
                            id = c[1].toLong(),
                            nombre = des(c[2]),
                            rect = NormRect(c[3].toFloat(), c[4].toFloat(), c[5].toFloat(), c[6].toFloat()),
                            refAncho = c[7].toInt(),
                            refAlto = c[8].toInt(),
                            activa = c[9] == "1",
                            materiales = c[10].split(",").mapNotNull { it.toLongOrNull() }
                        )
                    )
                    "J" -> joystick = JoystickConfig(
                        NormRect(c[1].toFloat(), c[2].toFloat(), c[3].toFloat(), c[4].toFloat()),
                        c[5].toInt(),
                        c[6].toInt()
                    )
                    "K" -> macro = des(c.getOrElse(1) { "" })
                    "Q" -> cofre = c[1].toLong()
                    else -> Unit
                }
            }
        } catch (e: Exception) {
            return null
        }
        // Coherencia: nombres de archivo simples y áreas que solo usan materiales de la copia.
        if (materiales.any { m -> m.archivos.any { !PaqueteDeRespaldo.nombreSimple(it) } }) return null
        val ids = materiales.map { it.id }.toSet()
        if (areas.any { a -> a.materiales.any { it !in ids } }) return null
        return ConfiguracionCopia(materiales, areas, joystick, macro, cofre)
    }
}
