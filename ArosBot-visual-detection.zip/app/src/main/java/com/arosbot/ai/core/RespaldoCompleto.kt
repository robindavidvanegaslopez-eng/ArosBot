package com.arosbot.ai.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.arosbot.ai.capture.CapturaDeTrabajo
import java.io.ByteArrayOutputStream

/** Une la copia de seguridad (formato puro) con lo que hay realmente en el teléfono. */
object RespaldoCompleto {

    /** Reúne todo lo que se guarda en la app y lo empaqueta en un archivo propio. */
    fun exportar(): ByteArray {
        val s = BotCore.store
        val captura = CapturaDeTrabajo.fotograma.value?.let {
            val salida = ByteArrayOutputStream()
            if (it.compress(Bitmap.CompressFormat.PNG, 100, salida)) salida.toByteArray() else null
        }
        val contenido = ContenidoDeRespaldo(
            ConfiguracionCopia(
                s.materiales.value,
                s.areas.value,
                BotCore.settings.joystick,
                BotCore.settings.macroCofre,
                BotCore.settings.lugarCofreId
            ),
            s.exportarAprendizaje(),
            s.imagenesDeMateriales(),
            captura
        )
        return PaqueteDeRespaldo.empaquetar(contenido)
    }

    /** Lee un archivo sin tocar nada: null si no es de ArosBot AI o está dañado. */
    fun leer(bytes: ByteArray): ContenidoDeRespaldo? = PaqueteDeRespaldo.desempaquetar(bytes)

    /** Sustituye la configuración y lo aprendido por el contenido de la copia. */
    fun aplicar(c: ContenidoDeRespaldo) {
        val s = BotCore.store
        s.importarConfiguracion(c.configuracion, c.imagenesMateriales)
        s.importarAprendizaje(c.aprendizaje)
        BotCore.settings.joystick = c.configuracion.joystick
        BotCore.settings.macroCofre = c.configuracion.macroCofre
        BotCore.settings.lugarCofreId = c.configuracion.lugarCofreId
        BotCore.settings.lugarActualId = -1L
        c.captura?.let {
            BitmapFactory.decodeByteArray(it, 0, it.size)?.let { b -> CapturaDeTrabajo.establecer(b) }
        }
    }
}
