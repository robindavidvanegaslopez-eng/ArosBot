package com.arosbot.ai.core

import java.util.Base64
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/*
 * Lógica pura (sin Android) de las rutas y del aprendizaje de la Fase 4. Todo lo de este archivo se
 * compila y se prueba con JUnit; lo que depende de la pantalla vive en `automation` y `vision`.
 *
 * Convención: la posición del personaje es la suma de los desplazamientos de la escena con el signo
 * cambiado (si el personaje avanza hacia arriba, la escena baja). Las coordenadas son píxeles del
 * fotograma capturado y el origen es el punto de partida de la ruta. No son metros del juego.
 */

/**
 * Recorte de pantalla guardado como punto de referencia visual. Estaba en ([sx], [sy]) del fotograma
 * cuando se guardó: al reconocerlo después, la diferencia de posición dice cuánto se ha desplazado
 * el personaje respecto a ese lugar y corrige la deriva del cálculo.
 */
data class ReferenciaVisual(val archivo: String, val sx: Int, val sy: Int, val ancho: Int, val alto: Int)

/** Punto del trayecto: posición del personaje, instante desde que empezó la ruta y referencia opcional. */
data class PuntoDeRuta(
    val x: Double,
    val y: Double,
    val tMs: Long,
    val referencia: ReferenciaVisual? = null
)

/** Nodo del grafo de navegación: un lugar conocido con nombre. */
data class Lugar(val id: Long, val nombre: String)

/** Resultado de un intento real de recorrer una ruta. */
data class Intento(
    val id: Long,
    val rutaId: Long,
    val tMs: Long,
    val exito: Boolean,
    val duracionMs: Long,
    val pasos: Int,
    val correcciones: Int,
    val motivo: String
)

/** Qué tan fiable es lo aprendido. Se distingue lo confirmado, lo estimado y lo incierto. */
enum class Confianza(val etiqueta: String) {
    CONFIRMADO("Confirmada"),
    ESTIMACION("Estimación"),
    INCIERTO("Incierta")
}

/** Cuentas de éxito y fracaso. Ninguna es una red neuronal: son estadísticas simples y explicables. */
object Estadistica {

    /** Probabilidad estimada de éxito con una distribución beta uniforme como punto de partida. */
    fun fiabilidad(intentos: Int, exitos: Int): Double {
        val n = max(0, intentos)
        val s = exitos.coerceIn(0, n)
        return (s + 1.0) / (n + 2.0)
    }

    fun confianza(intentos: Int, exitos: Int): Confianza = when {
        exitos >= EXITOS_PARA_CONFIRMAR && fiabilidad(intentos, exitos) >= FIABILIDAD_PARA_CONFIRMAR ->
            Confianza.CONFIRMADO
        exitos >= 1 -> Confianza.ESTIMACION
        else -> Confianza.INCIERTO
    }

    /** Media incremental al principio y media móvil exponencial después. [previos] = éxitos anteriores. */
    fun nuevaDuracion(media: Double, previos: Int, nueva: Double): Double {
        if (media <= 0.0 || previos <= 0) return nueva
        val alfa = max(1.0 / (previos + 1), ALFA_MINIMO)
        return media + (nueva - media) * alfa
    }

    /** Ajuste gradual de una velocidad aprendida (px/s): nunca se aleja más de la mitad de la calibrada. */
    fun nuevaVelocidad(actual: Double, observada: Double, base: Double): Double {
        if (observada <= 0.0 || actual <= 0.0) return actual
        val ajustada = actual + (observada - actual) * ALFA_VELOCIDAD
        val minimo = base * 0.5
        val maximo = base * 1.5
        return if (base > 0.0) ajustada.coerceIn(minimo, maximo) else ajustada
    }

    const val EXITOS_PARA_CONFIRMAR = 3
    const val FIABILIDAD_PARA_CONFIRMAR = 0.75
    const val ALFA_MINIMO = 0.2
    const val ALFA_VELOCIDAD = 0.3
}

/** Una ruta enseñada entre dos lugares, con su historial aprendido. */
data class Ruta(
    val id: Long,
    val nombre: String,
    val origenId: Long,
    val destinoId: Long,
    val puntos: List<PuntoDeRuta>,
    val intentos: Int,
    val exitos: Int,
    /** Duración media de los recorridos con éxito, o 0 si todavía no hay ninguno. */
    val duracionMediaMs: Double,
    /** Lo que tardó el usuario al enseñarla. */
    val duracionEnsenadaMs: Long,
    val creadaMs: Long
) {
    val longitudPx: Double
        get() {
            var total = 0.0
            for (i in 1 until puntos.size) {
                total += hypot(puntos[i].x - puntos[i - 1].x, puntos[i].y - puntos[i - 1].y)
            }
            return total
        }

    val fiabilidad: Double get() = Estadistica.fiabilidad(intentos, exitos)

    val confianza: Confianza get() = Estadistica.confianza(intentos, exitos)

    val duracionEstimadaMs: Double
        get() = if (duracionMediaMs > 0.0) duracionMediaMs else duracionEnsenadaMs.toDouble()

    /**
     * Los puntos en el sentido pedido. En sentido inverso el recorrido va del destino al origen: las
     * posiciones se expresan respecto al nuevo punto de partida y el tiempo corre al revés. Las
     * referencias visuales valen igual en los dos sentidos, porque son lugares, no movimientos.
     */
    fun puntosEnSentido(inversa: Boolean): List<PuntoDeRuta> {
        if (!inversa || puntos.isEmpty()) return puntos
        val ultimo = puntos.last()
        val total = ultimo.tMs
        return puntos.reversed().map {
            PuntoDeRuta(it.x - ultimo.x, it.y - ultimo.y, total - it.tMs, it.referencia)
        }
    }
}

/** Por qué una ruta enseñada no se puede guardar. */
object ValidacionDeRuta {
    const val LONGITUD_MINIMA_PX = 150.0
    const val PUNTOS_MINIMOS = 2

    fun problema(puntos: List<PuntoDeRuta>): String? {
        if (puntos.size < PUNTOS_MINIMOS) return "La ruta tiene muy pocos puntos."
        var longitud = 0.0
        for (i in 1 until puntos.size) {
            longitud += hypot(puntos[i].x - puntos[i - 1].x, puntos[i].y - puntos[i - 1].y)
        }
        if (longitud < LONGITUD_MINIMA_PX) {
            return "La ruta es demasiado corta (${longitud.toInt()} px). Recorre un trayecto más largo."
        }
        if (puntos.first().referencia == null) return "No se pudo guardar una referencia visual al inicio."
        if (puntos.last().referencia == null) return "No se pudo guardar una referencia visual al final."
        return null
    }
}

/**
 * Acumula lo que se mueve la escena mientras el usuario recorre la ruta y decide cuándo hay que
 * guardar un punto o una referencia visual.
 */
class AcumuladorDeTrayecto(
    private val separacionPuntosPx: Double = 100.0,
    private val separacionReferenciasPx: Double = 300.0,
    private val ruidoPx: Double = 2.0
) {
    var x = 0.0
        private set
    var y = 0.0
        private set

    private val _puntos = ArrayList<PuntoDeRuta>()
    val puntos: List<PuntoDeRuta> get() = _puntos

    private var desdePunto = 0.0
    private var desdeReferencia = 0.0

    /** Incorpora el desplazamiento de la escena entre dos fotogramas. Ignora el ruido pequeño. */
    fun mover(dxEscena: Double, dyEscena: Double) {
        val d = hypot(dxEscena, dyEscena)
        if (d < ruidoPx) return
        x -= dxEscena
        y -= dyEscena
        desdePunto += d
        desdeReferencia += d
    }

    fun puntoPendiente(): Boolean = desdePunto >= separacionPuntosPx

    fun referenciaPendiente(): Boolean = desdeReferencia >= separacionReferenciasPx

    /** Guarda un punto en la posición actual. Si lleva referencia, reinicia su contador. */
    fun registrar(tMs: Long, referencia: ReferenciaVisual?): PuntoDeRuta {
        val punto = PuntoDeRuta(x, y, tMs, referencia)
        _puntos.add(punto)
        desdePunto = 0.0
        if (referencia != null) desdeReferencia = 0.0
        return punto
    }
}

/**
 * Corrección de la posición al reconocer una referencia visual. Si el recorte guardado en un punto
 * ahora se ve desplazado ([escenaDx], [escenaDy]) respecto a donde estaba, la escena se ha movido
 * ese tanto desde entonces y el personaje, lo contrario: su posición real es la del punto menos
 * ese desplazamiento.
 */
object Relocalizacion {

    /** Confianza mínima (0 a 1) de la búsqueda del recorte para fiarse de ella. */
    const val CONFIANZA_MINIMA = 0.6

    /** Error máximo, en píxeles, para dar un lugar por reconocido y alcanzado. */
    const val ERROR_MAXIMO_PX = 40.0

    fun posicion(punto: PuntoDeRuta, escenaDx: Double, escenaDy: Double): Pair<Double, Double> =
        Pair(punto.x - escenaDx, punto.y - escenaDy)

    fun error(escenaDx: Double, escenaDy: Double): Double = hypot(escenaDx, escenaDy)

    fun fiable(confianza: Double): Boolean = confianza >= CONFIANZA_MINIMA
}

/** Qué hacer para llegar al siguiente punto. */
sealed class Guia {
    object Llegado : Guia()

    data class Mover(val direccion: Direccion, val duracionMs: Long) : Guia()

    data class SinCalibracion(val direccion: Direccion) : Guia()
}

/**
 * Elige el siguiente paso corrigiendo siempre el eje con más error. Como cada paso se mide y la
 * posición se actualiza, no hay una secuencia fija de teclas: la duración sale de la calibración
 * aprendida y de lo que falta realmente.
 */
object GuiaDeRuta {

    const val TOLERANCIA_PX = 20.0
    const val FRACCION_DEL_ERROR = 0.85
    const val DURACION_MINIMA_MS = 150L
    const val DURACION_MAXIMA_MS = 1500L

    fun siguientePaso(
        posX: Double,
        posY: Double,
        objetivoX: Double,
        objetivoY: Double,
        calibraciones: Map<Direccion, Calibracion>,
        tolerancia: Double = TOLERANCIA_PX
    ): Guia {
        val ex = objetivoX - posX
        val ey = objetivoY - posY
        if (abs(ex) < tolerancia && abs(ey) < tolerancia) return Guia.Llegado

        val horizontal = abs(ex) >= abs(ey)
        val direccion = if (horizontal) {
            if (ex > 0) Direccion.D else Direccion.A
        } else {
            if (ey > 0) Direccion.S else Direccion.W
        }
        val calibracion = calibraciones[direccion]
        val velocidad = if (calibracion == null || calibracion.muestras == 0) {
            0.0
        } else if (horizontal) {
            abs(calibracion.vx)
        } else {
            abs(calibracion.vy)
        }
        if (velocidad < 1.0) return Guia.SinCalibracion(direccion)

        val distancia = (if (horizontal) abs(ex) else abs(ey)) * FRACCION_DEL_ERROR
        val ms = (distancia / velocidad * 1000.0).toLong()
            .coerceIn(DURACION_MINIMA_MS, DURACION_MAXIMA_MS)
        return Guia.Mover(direccion, ms)
    }
}

/** Un tramo del plan: una ruta recorrida en su sentido o al revés. */
data class TramoDePlan(val ruta: Ruta, val inversa: Boolean)

data class PlanDeRutas(
    val tramos: List<TramoDePlan>,
    val duracionMs: Double,
    val fiabilidad: Double
)

/**
 * Planifica sobre el grafo aprendido: los lugares son nodos y las rutas enseñadas, conexiones. Cada
 * ruta puede recorrerse al revés con un recargo. El coste combina tiempo y fiabilidad.
 */
object PlanificadorDeRutas {

    const val RECARGO_INVERSA = 1.5
    const val FIABILIDAD_INVERSA = 0.9

    fun coste(ruta: Ruta, inversa: Boolean): Double {
        val base = ruta.duracionEstimadaMs.coerceAtLeast(1.0) / ruta.fiabilidad
        return if (inversa) base * RECARGO_INVERSA else base
    }

    fun planificar(rutas: List<Ruta>, origenId: Long, destinoId: Long): PlanDeRutas? {
        if (origenId == destinoId) return PlanDeRutas(emptyList(), 0.0, 1.0)

        val nodos = HashSet<Long>()
        for (r in rutas) {
            nodos.add(r.origenId)
            nodos.add(r.destinoId)
        }
        if (origenId !in nodos || destinoId !in nodos) return null

        val distancia = HashMap<Long, Double>()
        val previo = HashMap<Long, TramoDePlan>()
        val origenDe = HashMap<Long, Long>()
        val pendientes = HashSet(nodos)
        for (n in nodos) distancia[n] = Double.POSITIVE_INFINITY
        distancia[origenId] = 0.0

        while (pendientes.isNotEmpty()) {
            var actual: Long? = null
            var mejor = Double.POSITIVE_INFINITY
            for (n in pendientes) {
                val d = distancia.getValue(n)
                if (d < mejor) {
                    mejor = d
                    actual = n
                }
            }
            if (actual == null) break
            pendientes.remove(actual)
            if (actual == destinoId) break

            for (r in rutas) {
                val vecino: Long
                val inversa: Boolean
                when (actual) {
                    r.origenId -> {
                        vecino = r.destinoId
                        inversa = false
                    }
                    r.destinoId -> {
                        vecino = r.origenId
                        inversa = true
                    }
                    else -> continue
                }
                if (vecino == actual || vecino !in pendientes) continue
                val nuevo = mejor + coste(r, inversa)
                if (nuevo < distancia.getValue(vecino)) {
                    distancia[vecino] = nuevo
                    previo[vecino] = TramoDePlan(r, inversa)
                    origenDe[vecino] = actual
                }
            }
        }

        if (distancia.getValue(destinoId).isInfinite()) return null
        val tramos = ArrayList<TramoDePlan>()
        var nodo = destinoId
        while (nodo != origenId) {
            val tramo = previo[nodo] ?: return null
            tramos.add(tramo)
            nodo = origenDe[nodo] ?: return null
        }
        tramos.reverse()
        var duracion = 0.0
        var fiabilidad = 1.0
        for (t in tramos) {
            duracion += t.ruta.duracionEstimadaMs * (if (t.inversa) RECARGO_INVERSA else 1.0)
            fiabilidad *= t.ruta.fiabilidad * (if (t.inversa) FIABILIDAD_INVERSA else 1.0)
        }
        return PlanDeRutas(tramos, duracion, fiabilidad)
    }
}

// ---------- Codificación de puntos (para la base de datos) ----------

object CodificadorDePuntos {

    private const val SEPARADOR_PUNTO = "~"
    private const val SEPARADOR_CAMPO = ";"

    fun codificar(puntos: List<PuntoDeRuta>): String = puntos.joinToString(SEPARADOR_PUNTO) { p ->
        val r = p.referencia
        listOf(
            p.x.toString(),
            p.y.toString(),
            p.tMs.toString(),
            r?.archivo ?: "-",
            (r?.sx ?: 0).toString(),
            (r?.sy ?: 0).toString(),
            (r?.ancho ?: 0).toString(),
            (r?.alto ?: 0).toString()
        ).joinToString(SEPARADOR_CAMPO)
    }

    fun decodificar(texto: String): List<PuntoDeRuta> {
        if (texto.isBlank()) return emptyList()
        val lista = ArrayList<PuntoDeRuta>()
        for (trozo in texto.split(SEPARADOR_PUNTO)) {
            val c = trozo.split(SEPARADOR_CAMPO)
            if (c.size < 8) continue
            val x = c[0].toDoubleOrNull() ?: continue
            val y = c[1].toDoubleOrNull() ?: continue
            val t = c[2].toLongOrNull() ?: continue
            val referencia = if (c[3] == "-") {
                null
            } else {
                ReferenciaVisual(
                    c[3],
                    c[4].toIntOrNull() ?: 0,
                    c[5].toIntOrNull() ?: 0,
                    c[6].toIntOrNull() ?: 0,
                    c[7].toIntOrNull() ?: 0
                )
            }
            lista.add(PuntoDeRuta(x, y, t, referencia))
        }
        return lista
    }
}

// ---------- Copia de seguridad del aprendizaje ----------

/** Todo lo aprendido, listo para exportarse o importarse. Las imágenes van aparte, por nombre. */
data class CopiaDeAprendizaje(
    val lugares: List<Lugar>,
    val rutas: List<Ruta>,
    val intentos: List<Intento>,
    val calibraciones: List<Calibracion>,
    val imagenes: Map<String, ByteArray>
)

/** Formato de texto propio: legible, sin dependencias y fácil de revisar a mano. */
object FormatoDeCopia {

    private const val CABECERA = "AROSBOT-APRENDIZAJE 1"

    private fun esc(s: String): String =
        s.replace("\\", "\\\\").replace("|", "\\p").replace("\n", "\\n").replace("\r", "")

    private fun des(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) {
                    'p' -> sb.append('|')
                    'n' -> sb.append('\n')
                    else -> sb.append(s[i + 1])
                }
                i += 2
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
    }

    fun escribir(copia: CopiaDeAprendizaje): String {
        val sb = StringBuilder()
        sb.append(CABECERA).append('\n')
        for (l in copia.lugares) sb.append("L|${l.id}|${esc(l.nombre)}\n")
        for (r in copia.rutas) {
            sb.append(
                "R|${r.id}|${esc(r.nombre)}|${r.origenId}|${r.destinoId}|${r.intentos}|${r.exitos}|" +
                    "${r.duracionMediaMs}|${r.duracionEnsenadaMs}|${r.creadaMs}|" +
                    "${CodificadorDePuntos.codificar(r.puntos)}\n"
            )
        }
        for (i in copia.intentos) {
            sb.append(
                "I|${i.id}|${i.rutaId}|${i.tMs}|${if (i.exito) 1 else 0}|${i.duracionMs}|" +
                    "${i.pasos}|${i.correcciones}|${esc(i.motivo)}\n"
            )
        }
        for (c in copia.calibraciones) sb.append("C|${c.direccion.name}|${c.vx}|${c.vy}|${c.muestras}\n")
        for ((nombre, bytes) in copia.imagenes) {
            sb.append("F|${esc(nombre)}|${Base64.getEncoder().encodeToString(bytes)}\n")
        }
        return sb.toString()
    }

    /** Lee una copia. Devuelve null si el archivo no es de ArosBot o está dañado. */
    fun leer(texto: String): CopiaDeAprendizaje? {
        val lineas = texto.lines()
        if (lineas.isEmpty() || lineas[0].trim() != CABECERA) return null
        val lugares = ArrayList<Lugar>()
        val rutas = ArrayList<Ruta>()
        val intentos = ArrayList<Intento>()
        val calibraciones = ArrayList<Calibracion>()
        val imagenes = LinkedHashMap<String, ByteArray>()
        try {
            for (linea in lineas.drop(1)) {
                if (linea.isBlank()) continue
                val c = linea.split("|")
                when (c[0]) {
                    "L" -> lugares.add(Lugar(c[1].toLong(), des(c[2])))
                    "R" -> rutas.add(
                        Ruta(
                            id = c[1].toLong(),
                            nombre = des(c[2]),
                            origenId = c[3].toLong(),
                            destinoId = c[4].toLong(),
                            puntos = CodificadorDePuntos.decodificar(c[10]),
                            intentos = c[5].toInt(),
                            exitos = c[6].toInt(),
                            duracionMediaMs = c[7].toDouble(),
                            duracionEnsenadaMs = c[8].toLong(),
                            creadaMs = c[9].toLong()
                        )
                    )
                    "I" -> intentos.add(
                        Intento(
                            c[1].toLong(), c[2].toLong(), c[3].toLong(), c[4] == "1",
                            c[5].toLong(), c[6].toInt(), c[7].toInt(), des(c[8])
                        )
                    )
                    "C" -> calibraciones.add(
                        Calibracion(Direccion.valueOf(c[1]), c[2].toDouble(), c[3].toDouble(), c[4].toInt())
                    )
                    "F" -> imagenes[des(c[1])] = Base64.getDecoder().decode(c[2])
                    else -> Unit
                }
            }
        } catch (e: Exception) {
            return null
        }
        // Coherencia mínima: toda ruta debe apuntar a lugares que existen.
        val ids = lugares.map { it.id }.toSet()
        if (rutas.any { it.origenId !in ids || it.destinoId !in ids }) return null
        return CopiaDeAprendizaje(lugares, rutas, intentos, calibraciones, imagenes)
    }
}
