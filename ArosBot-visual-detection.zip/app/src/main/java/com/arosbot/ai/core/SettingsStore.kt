package com.arosbot.ai.core

import android.content.Context

/**
 * Ajustes del usuario guardados solo en este teléfono (SharedPreferences privadas).
 * El correo de la cuenta de Google nunca va en el código ni en el ZIP.
 */
class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("arosbot_ajustes", Context.MODE_PRIVATE)

    var inicioSesionAutomatico: Boolean
        get() = prefs.getBoolean(CLAVE_LOGIN_AUTO, false)
        set(valor) {
            prefs.edit().putBoolean(CLAVE_LOGIN_AUTO, valor).apply()
        }

    var cuentaGoogle: String
        get() = prefs.getString(CLAVE_CUENTA, "") ?: ""
        set(valor) {
            prefs.edit().putString(CLAVE_CUENTA, valor).apply()
        }

    /** Módulos que el usuario ha verificado con una prueba real en este dispositivo. */
    var modulosVerificados: Set<Int>
        get() = (prefs.getStringSet(CLAVE_VERIFICADOS, emptySet()) ?: emptySet())
            .mapNotNull { it.toIntOrNull() }
            .toSet()
        set(valor) {
            prefs.edit()
                .putStringSet(CLAVE_VERIFICADOS, valor.map { it.toString() }.toSet())
                .apply()
        }

    /**
     * Posición del joystick virtual del juego, o null si todavía no se ha configurado.
     * Se guarda normalizada respecto al fotograma con el que se dibujó.
     */
    var joystick: JoystickConfig?
        get() {
            val refAncho = prefs.getInt(CLAVE_JOY_REF_ANCHO, 0)
            val refAlto = prefs.getInt(CLAVE_JOY_REF_ALTO, 0)
            if (refAncho <= 0 || refAlto <= 0 || !prefs.contains(CLAVE_JOY_X)) return null
            return JoystickConfig(
                NormRect(
                    prefs.getFloat(CLAVE_JOY_X, 0f),
                    prefs.getFloat(CLAVE_JOY_Y, 0f),
                    prefs.getFloat(CLAVE_JOY_W, 0f),
                    prefs.getFloat(CLAVE_JOY_H, 0f)
                ),
                refAncho,
                refAlto
            )
        }
        set(valor) {
            val editor = prefs.edit()
            if (valor == null) {
                editor.remove(CLAVE_JOY_X).remove(CLAVE_JOY_Y).remove(CLAVE_JOY_W).remove(CLAVE_JOY_H)
                    .remove(CLAVE_JOY_REF_ANCHO).remove(CLAVE_JOY_REF_ALTO)
            } else {
                editor.putFloat(CLAVE_JOY_X, valor.rect.x)
                    .putFloat(CLAVE_JOY_Y, valor.rect.y)
                    .putFloat(CLAVE_JOY_W, valor.rect.w)
                    .putFloat(CLAVE_JOY_H, valor.rect.h)
                    .putInt(CLAVE_JOY_REF_ANCHO, valor.refAncho)
                    .putInt(CLAVE_JOY_REF_ALTO, valor.refAlto)
            }
            editor.apply()
        }

    private companion object {
        const val CLAVE_LOGIN_AUTO = "inicio_sesion_automatico"
        const val CLAVE_CUENTA = "cuenta_google"
        const val CLAVE_VERIFICADOS = "modulos_verificados"
        const val CLAVE_JOY_X = "joystick_x"
        const val CLAVE_JOY_Y = "joystick_y"
        const val CLAVE_JOY_W = "joystick_w"
        const val CLAVE_JOY_H = "joystick_h"
        const val CLAVE_JOY_REF_ANCHO = "joystick_ref_ancho"
        const val CLAVE_JOY_REF_ALTO = "joystick_ref_alto"
    }
}
