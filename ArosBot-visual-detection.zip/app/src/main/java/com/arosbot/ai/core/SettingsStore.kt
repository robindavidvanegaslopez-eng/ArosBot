package com.arosbot.ai.core

import android.content.Context

/**
 * Ajustes del usuario guardados solo en este teléfono (SharedPreferences privadas).
 * El correo de la cuenta de Google nunca va en el código ni en el ZIP.
 */
class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("arosbot_ajustes", Context.MODE_PRIVATE)

    var inicioSesionAutomatico: Boolean
        get() = prefs.getBoolean(CLAVE_LOGIN_AUTO, false)
        set(valor) {
            prefs.edit().putBoolean(CLAVE_LOGIN_AUTO, valor).apply()
        }

    var cuentaGoogle: String
        get() = prefs.getString(CLAVE_CUENTA, "") ?: ""
        set(valor) {
            prefs.edit().putString(CLAVE_CUENTA, valor).apply()
        }

    /** Módulos que el usuario ha verificado con una prueba real en este dispositivo. */
    var modulosVerificados: Set<Int>
        get() = (prefs.getStringSet(CLAVE_VERIFICADOS, emptySet()) ?: emptySet())
            .mapNotNull { it.toIntOrNull() }
            .toSet()
        set(valor) {
            prefs.edit()
                .putStringSet(CLAVE_VERIFICADOS, valor.map { it.toString() }.toSet())
                .apply()
        }

    /**
     * Posición del joystick virtual del juego, o null si todavía no se ha configurado.
     * Se guarda normalizada respecto al fotograma con el que se dibujó.
     */
    var joystick: JoystickConfig?
        get() {
            val refAncho = prefs.getInt(CLAVE_JOY_REF_ANCHO, 0)
            val refAlto = prefs.getInt(CLAVE_JOY_REF_ALTO, 0)
            if (refAncho <= 0 || refAlto <= 0 || !prefs.contains(CLAVE_JOY_X)) return null
            return JoystickConfig(
                NormRect(
                    prefs.getFloat(CLAVE_JOY_X, 0f),
                    prefs.getFloat(CLAVE_JOY_Y, 0f),
                    prefs.getFloat(CLAVE_JOY_W, 0f),
                    prefs.getFloat(CLAVE_JOY_H, 0f)
                ),
                refAncho,
                refAlto
            )
        }
        set(valor) {
            val editor = prefs.edit()
            if (valor == null) {
                editor.remove(CLAVE_JOY_X).remove(CLAVE_JOY_Y).remove(CLAVE_JOY_W).remove(CLAVE_JOY_H)
                    .remove(CLAVE_JOY_REF_ANCHO).remove(CLAVE_JOY_REF_ALTO)
            } else {
                editor.putFloat(CLAVE_JOY_X, valor.rect.x)
                    .putFloat(CLAVE_JOY_Y, valor.rect.y)
                    .putFloat(CLAVE_JOY_W, valor.rect.w)
                    .putFloat(CLAVE_JOY_H, valor.rect.h)
                    .putInt(CLAVE_JOY_REF_ANCHO, valor.refAncho)
                    .putInt(CLAVE_JOY_REF_ALTO, valor.refAlto)
            }
            editor.apply()
        }

    /**
     * Lugar del grafo de rutas donde se sabe que está el personaje, o -1 si no se sabe. Lo fija el
     * usuario («Estoy en…») o una ruta recorrida con éxito; se borra si una ruta falla a medias.
     */
    var lugarActualId: Long
        get() = prefs.getLong(CLAVE_LUGAR_ACTUAL, -1L)
        set(valor) {
            prefs.edit().putLong(CLAVE_LUGAR_ACTUAL, valor).apply()
        }

    /**
     * true cuando la prueba real de diagonales comprobó que el juego mueve al personaje en W+A, W+D,
     * S+A y S+D como se espera. Hasta entonces el bot se mueve solo con W, A, S y D.
     */
    var diagonalesVerificadas: Boolean
        get() = prefs.getBoolean(CLAVE_DIAGONALES, false)
        set(valor) {
            prefs.edit().putBoolean(CLAVE_DIAGONALES, valor).apply()
        }

    /** true si «Probar conducción continua» comprobó que el gesto continuo sobre el joystick mueve al personaje. */
    var conduccionVerificada: Boolean
        get() = prefs.getBoolean(CLAVE_CONDUCCION, false)
        set(valor) {
            prefs.edit().putBoolean(CLAVE_CONDUCCION, valor).apply()
        }

    /** Captura a 60 fotogramas por segundo mientras se enseña o se conduce (30 si es false). */
    var fps60: Boolean
        get() = prefs.getBoolean("fps60", false)
        set(valor) {
            prefs.edit().putBoolean("fps60", valor).apply()
        }

    /** Macro del cofre (texto de [MacroDeClics.codificar]) o vacío si no se ha grabado. */
    var macroCofre: String
        get() = prefs.getString(CLAVE_MACRO_COFRE, "") ?: ""
        set(valor) {
            prefs.edit().putString(CLAVE_MACRO_COFRE, valor).apply()
        }

    /** Lugar del grafo de rutas donde está el cofre de depósito, o -1 si no se ha elegido. */
    var lugarCofreId: Long
        get() = prefs.getLong(CLAVE_LUGAR_COFRE, -1L)
        set(valor) {
            prefs.edit().putLong(CLAVE_LUGAR_COFRE, valor).apply()
        }

    private companion object {
        const val CLAVE_LUGAR_COFRE = "lugar_cofre_id"
        const val CLAVE_MACRO_COFRE = "macro_cofre"
        const val CLAVE_CONDUCCION = "conduccion_verificada"
        private const val CLAVE_DIAGONALES = "diagonales_verificadas"
        const val CLAVE_LUGAR_ACTUAL = "lugar_actual_id"
        const val CLAVE_LOGIN_AUTO = "inicio_sesion_automatico"
        const val CLAVE_CUENTA = "cuenta_google"
        const val CLAVE_VERIFICADOS = "modulos_verificados"
        const val CLAVE_JOY_X = "joystick_x"
        const val CLAVE_JOY_Y = "joystick_y"
        const val CLAVE_JOY_W = "joystick_w"
        const val CLAVE_JOY_H = "joystick_h"
        const val CLAVE_JOY_REF_ANCHO = "joystick_ref_ancho"
        const val CLAVE_JOY_REF_ALTO = "joystick_ref_alto"
    }
}
