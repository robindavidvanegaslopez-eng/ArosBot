package com.arosbot.ai.core

import kotlin.math.max
import kotlin.math.min

/*
 * Lógica pura (sin Android) de los spots y de la elección autónoma de destino de la Fase 5.
 * Todo se compila y se prueba con JUnit; lo que toca la pantalla vive en `automation`.
 */

/** Cuánto se fía el bot de que haya recursos en un spot ahora mismo. */
enum class Disponibilidad(val etiqueta: String) {
    SIN_VISITAR("Sin visitar"),
    DISPONIBLE("Disponible"),
    AGOTADO("Agotado")
}

/**
 * Lugar de recolección conocido. Está en un [lugarId] del grafo de rutas, de modo que se llega a él
 * con las rutas enseñadas. Los tiempos son milisegundos de reloj y 0 significa «nunca».
 */
data class Spot(
    val id: Long,
    val nombre: String,
    val lugarId: Long,
    /** Materiales que se esperan aquí. Vacío = cualquiera. */
    val materiales: List<Long>,
    /** De 1 (poco interesante) a 5 (muy interesante). */
    val prioridad: Int,
    val visitas: Int,
    /** En cuántas visitas se encontraron recursos. */
    val conRecursos: Int,
    val ultimaVisitaMs: Long,
    /** Desde cuándo se sabe que está agotado, o 0 si no lo está. */
    val agotadoDesdeMs: Long,
    /** Lo que se estima que tarda en volver a haber recursos tras agotarse. */
    val recuperacionMs: Double,
    val creadoMs: Long
) {
    fun disponibilidad(ahoraMs: Long): Disponibilidad = when {
        visitas == 0 -> Disponibilidad.SIN_VISITAR
        agotadoDesdeMs > 0L && ahoraMs < agotadoDesdeMs + recuperacionMs.toLong() -> Disponibilidad.AGOTADO
        else -> Disponibilidad.DISPONIBLE
    }

    /** Milisegundos que faltan para que se espere que vuelva a haber recursos, o 0. */
    fun vuelveEnMs(ahoraMs: Long): Long {
        if (agotadoDesdeMs <= 0L) return 0L
        return max(0L, agotadoDesdeMs + recuperacionMs.toLong() - ahoraMs)
    }

    /** Probabilidad estimada, de 0 a 1, de que haya recursos si se va ahora. */
    fun probabilidadDisponible(ahoraMs: Long): Double {
        if (visitas == 0) return PROBABILIDAD_SIN_VISITAR
        if (agotadoDesdeMs <= 0L) return PROBABILIDAD_NUNCA_AGOTADO
        val fraccion = ((ahoraMs - agotadoDesdeMs).toDouble() / max(recuperacionMs, 1.0)).coerceIn(0.0, 1.0)
        return PROBABILIDAD_MINIMA + (PROBABILIDAD_NUNCA_AGOTADO - PROBABILIDAD_MINIMA) * fraccion * fraccion
    }

    /** De cada visita, qué fracción encontró recursos, con una cuenta beta como en las rutas. */
    val tasaDeExito: Double get() = Estadistica.fiabilidad(visitas, conRecursos)

    companion object {
        const val PROBABILIDAD_SIN_VISITAR = 0.5
        const val PROBABILIDAD_NUNCA_AGOTADO = 0.9
        const val PROBABILIDAD_MINIMA = 0.05
        const val RECUPERACION_INICIAL_MS = 5 * 60_000.0
        const val RECUPERACION_MINIMA_MS = 30_000.0
        const val RECUPERACION_MAXIMA_MS = 6 * 3_600_000.0
    }
}

/** Qué se aprende de cada visita real a un spot. */
object ActualizacionDeSpot {

    /**
     * Anota una visita. Si se encontraron recursos, el spot queda disponible y, si estaba marcado
     * como agotado, el tiempo transcurrido acota por arriba lo que tarda en recuperarse. Si no había
     * nada, se marca como agotado y, si ya lo estaba, la recuperación es más lenta de lo previsto.
     */
    fun trasVisita(spot: Spot, encontrado: Boolean, ahoraMs: Long): Spot {
        var agotadoDesde = spot.agotadoDesdeMs
        var recuperacion = spot.recuperacionMs
        val transcurrido = if (agotadoDesde > 0L) max(0L, ahoraMs - agotadoDesde) else 0L

        if (encontrado) {
            if (agotadoDesde > 0L && transcurrido.toDouble() < recuperacion) {
                recuperacion += (transcurrido - recuperacion) * ALFA_RECUPERACION
            }
            agotadoDesde = 0L
        } else {
            if (agotadoDesde == 0L) {
                agotadoDesde = ahoraMs
            } else {
                recuperacion = max(recuperacion, transcurrido * FACTOR_SI_SIGUE_VACIO)
            }
        }
        recuperacion = min(max(recuperacion, Spot.RECUPERACION_MINIMA_MS), Spot.RECUPERACION_MAXIMA_MS)

        return spot.copy(
            visitas = spot.visitas + 1,
            conRecursos = spot.conRecursos + if (encontrado) 1 else 0,
            ultimaVisitaMs = ahoraMs,
            agotadoDesdeMs = agotadoDesde,
            recuperacionMs = recuperacion
        )
    }

    const val ALFA_RECUPERACION = 0.5
    const val FACTOR_SI_SIGUE_VACIO = 1.5
}

/** Un spot posible como destino, con su puntuación y el porqué. */
data class Candidato(
    val spot: Spot,
    val plan: PlanDeRutas,
    val puntuacion: Double,
    val motivo: String
)

data class ResultadoDeEleccion(
    val elegido: Candidato?,
    /** Todos los alcanzables, del mejor al peor. */
    val candidatos: List<Candidato>,
    /** Los que no se pueden elegir y por qué. */
    val descartados: List<Pair<Spot, String>>
)

/**
 * Elige el siguiente destino de forma explicable: valor esperado (prioridad por probabilidad de que
 * haya recursos) dividido entre lo que cuesta (viaje, penalizado por lo poco fiable que sea, más un
 * tiempo fijo de recolección). Solo se consideran los spots a los que hay ruta enseñada.
 */
object EleccionDeSpot {

    const val TIEMPO_RECOLECCION_MS = 30_000.0
    const val FIABILIDAD_MINIMA = 0.05

    fun elegir(
        spots: List<Spot>,
        rutas: List<Ruta>,
        lugarActualId: Long?,
        ahoraMs: Long
    ): ResultadoDeEleccion {
        if (lugarActualId == null) {
            return ResultadoDeEleccion(
                null,
                emptyList(),
                spots.map { Pair(it, "No se sabe dónde estás: indica tu ubicación actual") }
            )
        }
        val candidatos = ArrayList<Candidato>()
        val descartados = ArrayList<Pair<Spot, String>>()
        for (spot in spots) {
            val plan = PlanificadorDeRutas.planificar(rutas, lugarActualId, spot.lugarId)
            if (plan == null) {
                descartados.add(Pair(spot, "No hay ninguna ruta enseñada hasta ese lugar"))
                continue
            }
            val probabilidad = spot.probabilidadDisponible(ahoraMs)
            val valor = spot.prioridad.coerceIn(1, 5) * probabilidad
            val viaje = plan.duracionMs / max(plan.fiabilidad, FIABILIDAD_MINIMA)
            val coste = viaje + TIEMPO_RECOLECCION_MS
            val porMinuto = valor / (coste / 60_000.0)
            val motivo = "prioridad ${spot.prioridad} · disponibilidad ${(probabilidad * 100).toInt()} % · " +
                if (plan.tramos.isEmpty()) {
                    "ya estás en ese lugar"
                } else {
                    "viaje de unos ${(plan.duracionMs / 1000).toInt()} s en ${plan.tramos.size} " +
                        "ruta${if (plan.tramos.size == 1) "" else "s"} (fiabilidad ${(plan.fiabilidad * 100).toInt()} %)"
                }
            candidatos.add(Candidato(spot, plan, porMinuto, motivo))
        }
        val ordenados = candidatos.sortedWith(
            compareByDescending<Candidato> { it.puntuacion }
                .thenByDescending { it.spot.prioridad }
                .thenBy { it.spot.nombre }
        )
        return ResultadoDeEleccion(ordenados.firstOrNull(), ordenados, descartados)
    }
}

/** Qué materiales se buscan en un spot: los suyos, o todos salvo los de apoyo del propio bot. */
object MaterialesDelSpot {

    fun buscados(spot: Spot, materiales: List<Material>): List<Material> {
        val apoyo = setOfNotNull(
            SelectorDeMateriales.personaje(materiales)?.id,
            SelectorDeMateriales.login(materiales)?.id,
            SelectorDeMateriales.cuenta(materiales)?.id
        )
        val base = if (spot.materiales.isEmpty()) {
            materiales
        } else {
            materiales.filter { it.id in spot.materiales }
        }
        return base.filter { it.id !in apoyo }
    }
}

/** Texto de un tiempo restante, para las pantallas. */
object TiempoLegible {
    fun de(ms: Long): String {
        val s = max(0L, ms) / 1000
        return when {
            s < 60 -> "$s s"
            s < 3600 -> "${s / 60} min ${s % 60} s"
            else -> "${s / 3600} h ${(s % 3600) / 60} min"
        }
    }
}
