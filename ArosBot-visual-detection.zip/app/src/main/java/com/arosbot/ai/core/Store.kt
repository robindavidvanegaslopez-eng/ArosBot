package com.arosbot.ai.core

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Memoria persistente (módulo 9) sobre SQLite, la solución equivalente a Room que permite
 * la especificación y que no necesita procesadores de anotaciones. Guarda materiales y áreas.
 * Incluye también calibraciones, rutas, intentos y spots de recolección.
 */
class Store(contexto: Context) {

    private class Ayudante(contexto: Context) :
        SQLiteOpenHelper(contexto, "arosbot.db", null, VERSION_BD) {

        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE materiales (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nombre TEXT NOT NULL, " +
                    "categoria TEXT NOT NULL, " +
                    "umbral REAL NOT NULL, " +
                    "ancho INTEGER NOT NULL, " +
                    "alto INTEGER NOT NULL, " +
                    "archivos TEXT NOT NULL, " +
                    "detecciones INTEGER NOT NULL DEFAULT 0, " +
                    "ultima_confianza REAL, " +
                    "estado TEXT NOT NULL DEFAULT 'SIN_PROBAR')"
            )
            db.execSQL(
                "CREATE TABLE areas (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nombre TEXT NOT NULL, " +
                    "x REAL NOT NULL, y REAL NOT NULL, w REAL NOT NULL, h REAL NOT NULL, " +
                    "ref_ancho INTEGER NOT NULL, " +
                    "ref_alto INTEGER NOT NULL, " +
                    "activa INTEGER NOT NULL DEFAULT 1, " +
                    "materiales TEXT NOT NULL DEFAULT '')"
            )
            db.execSQL("CREATE TABLE meta (clave TEXT PRIMARY KEY, valor TEXT NOT NULL)")
            crearTablaCalibraciones(db)
            crearTablasDeRutas(db)
            crearTablaDeSpots(db)
            crearTablaDeRecoleccion(db)
        }

        override fun onUpgrade(db: SQLiteDatabase, antigua: Int, nueva: Int) {
            // Versión 2 (Fase 3): calibraciones del movimiento. Los datos anteriores se conservan.
            if (antigua < 2) crearTablaCalibraciones(db)
            // Versión 3 (Fase 4): lugares, rutas e intentos. Todo lo anterior se conserva.
            if (antigua < 3) crearTablasDeRutas(db)
            // Versión 4 (Fase 5): spots de recolección. Todo lo anterior se conserva.
            if (antigua < 4) crearTablaDeSpots(db)
            // Versión 5 (Fase 6): estadísticas de recolección por spot. Todo lo anterior se conserva.
            if (antigua < 5) crearTablaDeRecoleccion(db)
        }

        private fun crearTablaDeRecoleccion(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS recoleccion_spots (" +
                    "spot_id INTEGER PRIMARY KEY, " +
                    "recogidos INTEGER NOT NULL DEFAULT 0, " +
                    "fallos INTEGER NOT NULL DEFAULT 0, " +
                    "ultima_ms INTEGER NOT NULL DEFAULT 0)"
            )
        }

        private fun crearTablaDeSpots(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS spots (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nombre TEXT NOT NULL, " +
                    "lugar_id INTEGER NOT NULL, " +
                    "materiales TEXT NOT NULL DEFAULT '', " +
                    "prioridad INTEGER NOT NULL DEFAULT 3, " +
                    "visitas INTEGER NOT NULL DEFAULT 0, " +
                    "con_recursos INTEGER NOT NULL DEFAULT 0, " +
                    "ultima_visita INTEGER NOT NULL DEFAULT 0, " +
                    "agotado_desde INTEGER NOT NULL DEFAULT 0, " +
                    "recuperacion_ms REAL NOT NULL, " +
                    "creado INTEGER NOT NULL)"
            )
        }

        private fun crearTablasDeRutas(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS lugares (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nombre TEXT NOT NULL UNIQUE)"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS rutas (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nombre TEXT NOT NULL, " +
                    "origen_id INTEGER NOT NULL, " +
                    "destino_id INTEGER NOT NULL, " +
                    "puntos TEXT NOT NULL, " +
                    "intentos INTEGER NOT NULL DEFAULT 0, " +
                    "exitos INTEGER NOT NULL DEFAULT 0, " +
                    "duracion_media REAL NOT NULL DEFAULT 0, " +
                    "duracion_ensenada INTEGER NOT NULL, " +
                    "creada INTEGER NOT NULL)"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS intentos_ruta (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "ruta_id INTEGER NOT NULL, " +
                    "t INTEGER NOT NULL, " +
                    "exito INTEGER NOT NULL, " +
                    "duracion INTEGER NOT NULL, " +
                    "pasos INTEGER NOT NULL, " +
                    "correcciones INTEGER NOT NULL, " +
                    "motivo TEXT NOT NULL)"
            )
        }

        private fun crearTablaCalibraciones(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS calibraciones (" +
                    "direccion TEXT PRIMARY KEY, " +
                    "vx REAL NOT NULL, " +
                    "vy REAL NOT NULL, " +
                    "muestras INTEGER NOT NULL)"
            )
        }
    }

    private val ayudante = Ayudante(contexto.applicationContext)

    val directorioMateriales: File = File(contexto.applicationContext.filesDir, "materiales")

    private val _materiales = MutableStateFlow<List<Material>>(emptyList())
    val materiales: StateFlow<List<Material>> = _materiales.asStateFlow()

    private val _areas = MutableStateFlow<List<Area>>(emptyList())
    val areas: StateFlow<List<Area>> = _areas.asStateFlow()

    private val _calibraciones = MutableStateFlow<Map<Direccion, Calibracion>>(emptyMap())
    val calibraciones: StateFlow<Map<Direccion, Calibracion>> = _calibraciones.asStateFlow()

    private val _lugares = MutableStateFlow<List<Lugar>>(emptyList())
    val lugares: StateFlow<List<Lugar>> = _lugares.asStateFlow()

    private val _rutas = MutableStateFlow<List<Ruta>>(emptyList())
    val rutas: StateFlow<List<Ruta>> = _rutas.asStateFlow()

    private val _spots = MutableStateFlow<List<Spot>>(emptyList())
    val spots: StateFlow<List<Spot>> = _spots.asStateFlow()

    private val _recoleccion = MutableStateFlow<Map<Long, EstadisticaDeRecoleccion>>(emptyMap())
    val recoleccion: StateFlow<Map<Long, EstadisticaDeRecoleccion>> = _recoleccion.asStateFlow()

    private val _intentosTotales = MutableStateFlow(0)
    val intentosTotales: StateFlow<Int> = _intentosTotales.asStateFlow()

    /** Imágenes de los puntos de referencia visuales de las rutas. */
    val directorioReferencias: File = File(contexto.applicationContext.filesDir, "referencias")

    /** Se invoca tras cada cambio en la base de datos. */
    @Volatile
    var alCambiar: (() -> Unit)? = null

    init {
        directorioMateriales.mkdirs()
        directorioReferencias.mkdirs()
        refrescar()
    }

    @Synchronized
    fun refrescar() {
        _materiales.value = leerMateriales()
        _areas.value = leerAreas()
        _calibraciones.value = leerCalibraciones()
        _lugares.value = leerLugares()
        _rutas.value = leerRutas()
        _spots.value = leerSpots()
        _recoleccion.value = leerRecoleccion()
        _intentosTotales.value = contarIntentos()
        alCambiar?.invoke()
    }

    // ---------- Calibraciones del movimiento ----------

    private fun leerCalibraciones(): Map<Direccion, Calibracion> {
        val mapa = HashMap<Direccion, Calibracion>()
        val consulta = "SELECT direccion, vx, vy, muestras FROM calibraciones"
        ayudante.readableDatabase.rawQuery(consulta, null).use { c ->
            while (c.moveToNext()) {
                val direccion = try {
                    Direccion.valueOf(c.getString(0))
                } catch (e: IllegalArgumentException) {
                    continue
                }
                mapa[direccion] = Calibracion(direccion, c.getDouble(1), c.getDouble(2), c.getInt(3))
            }
        }
        return mapa
    }

    /** Guarda (o sustituye) la calibración de una dirección. */
    @Synchronized
    fun guardarCalibracion(calibracion: Calibracion) {
        val valores = ContentValues()
        valores.put("direccion", calibracion.direccion.name)
        valores.put("vx", calibracion.vx)
        valores.put("vy", calibracion.vy)
        valores.put("muestras", calibracion.muestras)
        ayudante.writableDatabase.insertWithOnConflict(
            "calibraciones", null, valores, SQLiteDatabase.CONFLICT_REPLACE
        )
        refrescar()
    }

    // ---------- Materiales ----------

    private fun leerMateriales(): List<Material> {
        val lista = ArrayList<Material>()
        val consulta =
            "SELECT id, nombre, categoria, umbral, ancho, alto, archivos, detecciones, " +
                "ultima_confianza, estado FROM materiales ORDER BY id"
        ayudante.readableDatabase.rawQuery(consulta, null).use { c ->
            while (c.moveToNext()) {
                val estado = try {
                    EstadoReconocimiento.valueOf(c.getString(9))
                } catch (e: IllegalArgumentException) {
                    EstadoReconocimiento.SIN_PROBAR
                }
                lista.add(
                    Material(
                        id = c.getLong(0),
                        nombre = c.getString(1),
                        categoria = c.getString(2),
                        umbral = c.getFloat(3),
                        ancho = c.getInt(4),
                        alto = c.getInt(5),
                        archivos = c.getString(6).split(",").filter { it.isNotBlank() },
                        detecciones = c.getInt(7),
                        ultimaConfianza = if (c.isNull(8)) null else c.getFloat(8),
                        estado = estado
                    )
                )
            }
        }
        return lista
    }

    @Synchronized
    fun insertarMaterial(
        nombre: String,
        categoria: String,
        umbral: Float,
        ancho: Int,
        alto: Int,
        archivo: String
    ): Long {
        val valores = ContentValues()
        valores.put("nombre", nombre)
        valores.put("categoria", categoria)
        valores.put("umbral", umbral)
        valores.put("ancho", ancho)
        valores.put("alto", alto)
        valores.put("archivos", archivo)
        valores.put("detecciones", 0)
        valores.put("estado", EstadoReconocimiento.SIN_PROBAR.name)
        val id = ayudante.writableDatabase.insert("materiales", null, valores)
        refrescar()
        return id
    }

    @Synchronized
    fun actualizarDatosMaterial(id: Long, nombre: String, categoria: String, umbral: Float) {
        val valores = ContentValues()
        valores.put("nombre", nombre)
        valores.put("categoria", categoria)
        valores.put("umbral", umbral)
        ayudante.writableDatabase.update("materiales", valores, "id = ?", arrayOf(id.toString()))
        refrescar()
    }

    @Synchronized
    fun agregarVariante(id: Long, archivo: String) {
        val actual = _materiales.value.firstOrNull { it.id == id } ?: return
        val valores = ContentValues()
        valores.put("archivos", (actual.archivos + archivo).joinToString(","))
        ayudante.writableDatabase.update("materiales", valores, "id = ?", arrayOf(id.toString()))
        refrescar()
    }

    /** Anota el resultado de una prueba o de una detección en vivo. */
    @Synchronized
    fun registrarResultado(id: Long, encontrados: Int, mejorConfianza: Float?) {
        val actual = _materiales.value.firstOrNull { it.id == id } ?: return
        val valores = ContentValues()
        valores.put("detecciones", actual.detecciones + encontrados)
        if (mejorConfianza != null) valores.put("ultima_confianza", mejorConfianza)
        valores.put(
            "estado",
            if (encontrados > 0) {
                EstadoReconocimiento.RECONOCIDO.name
            } else {
                EstadoReconocimiento.NO_ENCONTRADO.name
            }
        )
        ayudante.writableDatabase.update("materiales", valores, "id = ?", arrayOf(id.toString()))
        refrescar()
    }

    @Synchronized
    fun eliminarMaterial(id: Long) {
        val actual = _materiales.value.firstOrNull { it.id == id }
        ayudante.writableDatabase.delete("materiales", "id = ?", arrayOf(id.toString()))
        actual?.archivos?.forEach { File(directorioMateriales, it).delete() }
        // Quitar el material de las áreas que lo tenían asociado.
        for (area in _areas.value.filter { id in it.materiales }) {
            guardarMaterialesDeArea(area.id, area.materiales - id)
        }
        refrescar()
    }

    // ---------- Áreas ----------

    private fun leerAreas(): List<Area> {
        val lista = ArrayList<Area>()
        val consulta =
            "SELECT id, nombre, x, y, w, h, ref_ancho, ref_alto, activa, materiales " +
                "FROM areas ORDER BY id"
        ayudante.readableDatabase.rawQuery(consulta, null).use { c ->
            while (c.moveToNext()) {
                lista.add(
                    Area(
                        id = c.getLong(0),
                        nombre = c.getString(1),
                        rect = NormRect(c.getFloat(2), c.getFloat(3), c.getFloat(4), c.getFloat(5)),
                        refAncho = c.getInt(6),
                        refAlto = c.getInt(7),
                        activa = c.getInt(8) != 0,
                        materiales = c.getString(9).split(",").mapNotNull { it.toLongOrNull() }
                    )
                )
            }
        }
        return lista
    }

    @Synchronized
    fun insertarArea(
        nombre: String,
        rect: NormRect,
        refAncho: Int,
        refAlto: Int,
        materiales: List<Long>
    ): Long {
        val valores = ContentValues()
        valores.put("nombre", nombre)
        valores.put("x", rect.x)
        valores.put("y", rect.y)
        valores.put("w", rect.w)
        valores.put("h", rect.h)
        valores.put("ref_ancho", refAncho)
        valores.put("ref_alto", refAlto)
        valores.put("activa", 1)
        valores.put("materiales", materiales.joinToString(","))
        val id = ayudante.writableDatabase.insert("areas", null, valores)
        refrescar()
        return id
    }

    @Synchronized
    fun actualizarRectanguloDeArea(
        id: Long,
        nombre: String,
        rect: NormRect,
        refAncho: Int,
        refAlto: Int
    ) {
        val valores = ContentValues()
        valores.put("nombre", nombre)
        valores.put("x", rect.x)
        valores.put("y", rect.y)
        valores.put("w", rect.w)
        valores.put("h", rect.h)
        valores.put("ref_ancho", refAncho)
        valores.put("ref_alto", refAlto)
        ayudante.writableDatabase.update("areas", valores, "id = ?", arrayOf(id.toString()))
        refrescar()
    }

    @Synchronized
    fun activarArea(id: Long, activa: Boolean) {
        val valores = ContentValues()
        valores.put("activa", if (activa) 1 else 0)
        ayudante.writableDatabase.update("areas", valores, "id = ?", arrayOf(id.toString()))
        refrescar()
    }

    @Synchronized
    fun asignarMaterialesAArea(id: Long, materiales: List<Long>) {
        guardarMaterialesDeArea(id, materiales)
        refrescar()
    }

    private fun guardarMaterialesDeArea(id: Long, materiales: List<Long>) {
        val valores = ContentValues()
        valores.put("materiales", materiales.joinToString(","))
        ayudante.writableDatabase.update("areas", valores, "id = ?", arrayOf(id.toString()))
    }

    @Synchronized
    fun eliminarArea(id: Long) {
        ayudante.writableDatabase.delete("areas", "id = ?", arrayOf(id.toString()))
        refrescar()
    }


    // ---------- Lugares, rutas y aprendizaje (Fase 4) ----------

    private fun leerLugares(): List<Lugar> {
        val lista = ArrayList<Lugar>()
        ayudante.readableDatabase.rawQuery("SELECT id, nombre FROM lugares ORDER BY id", null).use { c ->
            while (c.moveToNext()) lista.add(Lugar(c.getLong(0), c.getString(1)))
        }
        return lista
    }

    private fun leerRutas(): List<Ruta> {
        val lista = ArrayList<Ruta>()
        val consulta =
            "SELECT id, nombre, origen_id, destino_id, puntos, intentos, exitos, duracion_media, " +
                "duracion_ensenada, creada FROM rutas ORDER BY id"
        ayudante.readableDatabase.rawQuery(consulta, null).use { c ->
            while (c.moveToNext()) {
                lista.add(
                    Ruta(
                        id = c.getLong(0),
                        nombre = c.getString(1),
                        origenId = c.getLong(2),
                        destinoId = c.getLong(3),
                        puntos = CodificadorDePuntos.decodificar(c.getString(4)),
                        intentos = c.getInt(5),
                        exitos = c.getInt(6),
                        duracionMediaMs = c.getDouble(7),
                        duracionEnsenadaMs = c.getLong(8),
                        creadaMs = c.getLong(9)
                    )
                )
            }
        }
        return lista
    }

    private fun contarIntentos(): Int =
        ayudante.readableDatabase.rawQuery("SELECT COUNT(*) FROM intentos_ruta", null).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }

    /** Devuelve el lugar con ese nombre, creándolo si no existe. */
    @Synchronized
    fun lugarPorNombre(nombre: String): Lugar {
        val limpio = nombre.trim().ifEmpty { "Sin nombre" }
        val db = ayudante.writableDatabase
        db.rawQuery("SELECT id, nombre FROM lugares WHERE nombre = ? COLLATE NOCASE", arrayOf(limpio))
            .use { c -> if (c.moveToFirst()) return Lugar(c.getLong(0), c.getString(1)) }
        val valores = ContentValues()
        valores.put("nombre", limpio)
        val id = db.insert("lugares", null, valores)
        refrescar()
        return Lugar(id, limpio)
    }

    @Synchronized
    fun insertarRuta(
        nombre: String,
        origen: String,
        destino: String,
        puntos: List<PuntoDeRuta>,
        duracionEnsenadaMs: Long
    ): Long {
        val o = lugarPorNombre(origen)
        val d = lugarPorNombre(destino)
        val valores = ContentValues()
        valores.put("nombre", nombre.trim().ifEmpty { "Ruta" })
        valores.put("origen_id", o.id)
        valores.put("destino_id", d.id)
        valores.put("puntos", CodificadorDePuntos.codificar(puntos))
        valores.put("intentos", 0)
        valores.put("exitos", 0)
        valores.put("duracion_media", 0.0)
        valores.put("duracion_ensenada", duracionEnsenadaMs)
        valores.put("creada", System.currentTimeMillis())
        val id = ayudante.writableDatabase.insert("rutas", null, valores)
        refrescar()
        return id
    }

    @Synchronized
    fun editarRuta(id: Long, nombre: String, origen: String, destino: String) {
        val o = lugarPorNombre(origen)
        val d = lugarPorNombre(destino)
        val valores = ContentValues()
        valores.put("nombre", nombre.trim().ifEmpty { "Ruta" })
        valores.put("origen_id", o.id)
        valores.put("destino_id", d.id)
        ayudante.writableDatabase.update("rutas", valores, "id = ?", arrayOf(id.toString()))
        limpiarLugaresSinRutas()
        refrescar()
    }

    @Synchronized
    fun eliminarRuta(id: Long) {
        val ruta = _rutas.value.firstOrNull { it.id == id }
        val db = ayudante.writableDatabase
        db.delete("intentos_ruta", "ruta_id = ?", arrayOf(id.toString()))
        db.delete("rutas", "id = ?", arrayOf(id.toString()))
        limpiarLugaresSinRutas()
        ruta?.puntos?.mapNotNull { it.referencia?.archivo }?.toSet()?.forEach {
            File(directorioReferencias, it).delete()
        }
        refrescar()
    }

    private fun limpiarLugaresSinRutas() {
        ayudante.writableDatabase.execSQL(
            "DELETE FROM lugares WHERE id NOT IN (SELECT origen_id FROM rutas) " +
                "AND id NOT IN (SELECT destino_id FROM rutas) " +
                "AND id NOT IN (SELECT lugar_id FROM spots)"
        )
    }

    // ---------- Spots de recolección (Fase 5) ----------

    private fun leerSpots(): List<Spot> {
        val lista = ArrayList<Spot>()
        val consulta =
            "SELECT id, nombre, lugar_id, materiales, prioridad, visitas, con_recursos, " +
                "ultima_visita, agotado_desde, recuperacion_ms, creado FROM spots ORDER BY id"
        ayudante.readableDatabase.rawQuery(consulta, null).use { c ->
            while (c.moveToNext()) {
                lista.add(
                    Spot(
                        id = c.getLong(0),
                        nombre = c.getString(1),
                        lugarId = c.getLong(2),
                        materiales = c.getString(3).split(',').mapNotNull { it.trim().toLongOrNull() },
                        prioridad = c.getInt(4),
                        visitas = c.getInt(5),
                        conRecursos = c.getInt(6),
                        ultimaVisitaMs = c.getLong(7),
                        agotadoDesdeMs = c.getLong(8),
                        recuperacionMs = c.getDouble(9),
                        creadoMs = c.getLong(10)
                    )
                )
            }
        }
        return lista
    }

    private fun leerRecoleccion(): Map<Long, EstadisticaDeRecoleccion> {
        val mapa = HashMap<Long, EstadisticaDeRecoleccion>()
        ayudante.readableDatabase.rawQuery(
            "SELECT spot_id, recogidos, fallos, ultima_ms FROM recoleccion_spots", null
        ).use { c ->
            while (c.moveToNext()) {
                mapa[c.getLong(0)] = EstadisticaDeRecoleccion(c.getLong(0), c.getInt(1), c.getInt(2), c.getLong(3))
            }
        }
        return mapa
    }

    /**
     * Suma recogidas y fallos REALES de una sesión a las estadísticas del spot. Devuelve true solo si
     * se pudo escribir y volver a leer con el total esperado.
     */
    @Synchronized
    fun registrarRecoleccion(spotId: Long, recogidos: Int, fallos: Int, ahoraMs: Long): Boolean {
        if (_spots.value.none { it.id == spotId }) return false
        return try {
            val nueva = ActualizacionDeEstadistica.sumar(_recoleccion.value[spotId], spotId, recogidos, fallos, ahoraMs)
            val v = ContentValues()
            v.put("spot_id", spotId)
            v.put("recogidos", nueva.recogidos)
            v.put("fallos", nueva.fallos)
            v.put("ultima_ms", nueva.ultimaMs)
            ayudante.writableDatabase.insertWithOnConflict(
                "recoleccion_spots", null, v, SQLiteDatabase.CONFLICT_REPLACE
            )
            refrescar()
            _recoleccion.value[spotId] == nueva
        } catch (e: Exception) {
            BotCore.log.error("Memoria", "No se pudo guardar la recolección del spot: ${e.message}")
            false
        }
    }

    @Synchronized
    fun insertarSpot(nombre: String, lugar: String, materiales: List<Long>, prioridad: Int): Long {
        val l = lugarPorNombre(lugar)
        val valores = ContentValues()
        valores.put("nombre", nombre.trim().ifEmpty { "Spot" })
        valores.put("lugar_id", l.id)
        valores.put("materiales", materiales.joinToString(","))
        valores.put("prioridad", prioridad.coerceIn(1, 5))
        valores.put("recuperacion_ms", Spot.RECUPERACION_INICIAL_MS)
        valores.put("creado", System.currentTimeMillis())
        val id = ayudante.writableDatabase.insert("spots", null, valores)
        refrescar()
        return id
    }

    @Synchronized
    fun editarSpot(id: Long, nombre: String, lugar: String, materiales: List<Long>, prioridad: Int) {
        val l = lugarPorNombre(lugar)
        val valores = ContentValues()
        valores.put("nombre", nombre.trim().ifEmpty { "Spot" })
        valores.put("lugar_id", l.id)
        valores.put("materiales", materiales.joinToString(","))
        valores.put("prioridad", prioridad.coerceIn(1, 5))
        ayudante.writableDatabase.update("spots", valores, "id = ?", arrayOf(id.toString()))
        limpiarLugaresSinRutas()
        refrescar()
    }

    @Synchronized
    fun eliminarSpot(id: Long) {
        ayudante.writableDatabase.delete("spots", "id = ?", arrayOf(id.toString()))
        ayudante.writableDatabase.delete("recoleccion_spots", "spot_id = ?", arrayOf(id.toString()))
        limpiarLugaresSinRutas()
        refrescar()
    }

    /**
     * Anota una visita real a un spot (si se encontraron recursos o no) y actualiza lo aprendido de su
     * disponibilidad. Devuelve true solo si se pudo escribir y volver a leer.
     */
    @Synchronized
    fun registrarVisita(spotId: Long, encontrado: Boolean, ahoraMs: Long): Boolean {
        val spot = _spots.value.firstOrNull { it.id == spotId } ?: return false
        return try {
            val nuevo = ActualizacionDeSpot.trasVisita(spot, encontrado, ahoraMs)
            val v = ContentValues()
            v.put("visitas", nuevo.visitas)
            v.put("con_recursos", nuevo.conRecursos)
            v.put("ultima_visita", nuevo.ultimaVisitaMs)
            v.put("agotado_desde", nuevo.agotadoDesdeMs)
            v.put("recuperacion_ms", nuevo.recuperacionMs)
            val filas = ayudante.writableDatabase.update("spots", v, "id = ?", arrayOf(spotId.toString()))
            refrescar()
            val releido = _spots.value.firstOrNull { it.id == spotId }
            filas == 1 && releido != null && releido.visitas == spot.visitas + 1 &&
                releido.ultimaVisitaMs == ahoraMs
        } catch (e: Exception) {
            BotCore.log.error("Memoria", "No se pudo guardar la visita al spot: ${e.message}")
            false
        }
    }

    /**
     * Anota el resultado de un intento real y actualiza lo aprendido de la ruta: intentos, éxitos y,
     * si hubo éxito, la duración media. Devuelve true solo si se pudo escribir y volver a leer.
     */
    @Synchronized
    fun registrarIntento(
        rutaId: Long,
        exito: Boolean,
        duracionMs: Long,
        pasos: Int,
        correcciones: Int,
        motivo: String
    ): Boolean {
        val ruta = _rutas.value.firstOrNull { it.id == rutaId } ?: return false
        return try {
            val db = ayudante.writableDatabase
            val fila = ContentValues()
            fila.put("ruta_id", rutaId)
            fila.put("t", System.currentTimeMillis())
            fila.put("exito", if (exito) 1 else 0)
            fila.put("duracion", duracionMs)
            fila.put("pasos", pasos)
            fila.put("correcciones", correcciones)
            fila.put("motivo", motivo)
            val idIntento = db.insert("intentos_ruta", null, fila)

            val nuevos = ContentValues()
            nuevos.put("intentos", ruta.intentos + 1)
            nuevos.put("exitos", ruta.exitos + if (exito) 1 else 0)
            if (exito) {
                nuevos.put(
                    "duracion_media",
                    Estadistica.nuevaDuracion(ruta.duracionMediaMs, ruta.exitos, duracionMs.toDouble())
                )
            }
            db.update("rutas", nuevos, "id = ?", arrayOf(rutaId.toString()))
            // Solo se conservan los últimos intentos por ruta.
            db.execSQL(
                "DELETE FROM intentos_ruta WHERE ruta_id = $rutaId AND id NOT IN " +
                    "(SELECT id FROM intentos_ruta WHERE ruta_id = $rutaId ORDER BY id DESC LIMIT 200)"
            )
            refrescar()
            val releida = _rutas.value.firstOrNull { it.id == rutaId }
            idIntento > 0 && releida != null && releida.intentos == ruta.intentos + 1
        } catch (e: Exception) {
            BotCore.log.error("Memoria", "No se pudo guardar el intento de ruta: ${e.message}")
            false
        }
    }

    fun intentosDe(rutaId: Long, limite: Int = 20): List<Intento> {
        val lista = ArrayList<Intento>()
        val consulta =
            "SELECT id, ruta_id, t, exito, duracion, pasos, correcciones, motivo FROM intentos_ruta " +
                "WHERE ruta_id = ? ORDER BY id DESC LIMIT ?"
        ayudante.readableDatabase.rawQuery(consulta, arrayOf(rutaId.toString(), limite.toString()))
            .use { c ->
                while (c.moveToNext()) {
                    lista.add(
                        Intento(
                            c.getLong(0), c.getLong(1), c.getLong(2), c.getInt(3) == 1,
                            c.getLong(4), c.getInt(5), c.getInt(6), c.getString(7)
                        )
                    )
                }
            }
        return lista
    }

    /**
     * Borra lo aprendido por experiencia (intentos, éxitos, duraciones, calibración del movimiento y
     * visitas a spots). Las rutas enseñadas, los spots, sus referencias, los materiales, las áreas y los
     * ajustes se conservan.
     */
    @Synchronized
    fun restablecerAprendizaje() {
        val db = ayudante.writableDatabase
        db.delete("intentos_ruta", null, null)
        db.delete("calibraciones", null, null)
        val valores = ContentValues()
        valores.put("intentos", 0)
        valores.put("exitos", 0)
        valores.put("duracion_media", 0.0)
        db.update("rutas", valores, null, null)
        // Los spots se conservan, pero se olvida lo que se sabía de su disponibilidad.
        val spot = ContentValues()
        spot.put("visitas", 0)
        spot.put("con_recursos", 0)
        spot.put("ultima_visita", 0)
        spot.put("agotado_desde", 0)
        spot.put("recuperacion_ms", Spot.RECUPERACION_INICIAL_MS)
        db.update("spots", spot, null, null)
        db.delete("recoleccion_spots", null, null)
        refrescar()
    }

    /** Todo lo aprendido, con las imágenes de referencia, listo para guardarse en un archivo. */
    @Synchronized
    fun exportarAprendizaje(): CopiaDeAprendizaje {
        val imagenes = LinkedHashMap<String, ByteArray>()
        for (ruta in _rutas.value) {
            for (p in ruta.puntos) {
                val nombre = p.referencia?.archivo ?: continue
                if (nombre in imagenes) continue
                val archivo = File(directorioReferencias, nombre)
                if (archivo.exists()) imagenes[nombre] = archivo.readBytes()
            }
        }
        val intentos = ArrayList<Intento>()
        for (r in _rutas.value) intentos.addAll(intentosDe(r.id, 200))
        return CopiaDeAprendizaje(
            lugares = _lugares.value,
            rutas = _rutas.value,
            intentos = intentos,
            calibraciones = _calibraciones.value.values.toList(),
            imagenes = imagenes,
            spots = _spots.value
        )
    }

    /** Sustituye lo aprendido por el contenido de una copia. Materiales, áreas y ajustes no cambian. */
    @Synchronized
    fun importarAprendizaje(copia: CopiaDeAprendizaje) {
        val db = ayudante.writableDatabase
        db.beginTransaction()
        try {
            db.delete("intentos_ruta", null, null)
            db.delete("rutas", null, null)
            db.delete("lugares", null, null)
            db.delete("calibraciones", null, null)
            db.delete("spots", null, null)
            for (l in copia.lugares) {
                val v = ContentValues()
                v.put("id", l.id)
                v.put("nombre", l.nombre)
                db.insert("lugares", null, v)
            }
            for (r in copia.rutas) {
                val v = ContentValues()
                v.put("id", r.id)
                v.put("nombre", r.nombre)
                v.put("origen_id", r.origenId)
                v.put("destino_id", r.destinoId)
                v.put("puntos", CodificadorDePuntos.codificar(r.puntos))
                v.put("intentos", r.intentos)
                v.put("exitos", r.exitos)
                v.put("duracion_media", r.duracionMediaMs)
                v.put("duracion_ensenada", r.duracionEnsenadaMs)
                v.put("creada", r.creadaMs)
                db.insert("rutas", null, v)
            }
            for (i in copia.intentos) {
                val v = ContentValues()
                v.put("ruta_id", i.rutaId)
                v.put("t", i.tMs)
                v.put("exito", if (i.exito) 1 else 0)
                v.put("duracion", i.duracionMs)
                v.put("pasos", i.pasos)
                v.put("correcciones", i.correcciones)
                v.put("motivo", i.motivo)
                db.insert("intentos_ruta", null, v)
            }
            for (c in copia.calibraciones) {
                val v = ContentValues()
                v.put("direccion", c.direccion.name)
                v.put("vx", c.vx)
                v.put("vy", c.vy)
                v.put("muestras", c.muestras)
                db.insert("calibraciones", null, v)
            }
            for (sp in copia.spots) {
                val v = ContentValues()
                v.put("id", sp.id)
                v.put("nombre", sp.nombre)
                v.put("lugar_id", sp.lugarId)
                v.put("materiales", sp.materiales.joinToString(","))
                v.put("prioridad", sp.prioridad.coerceIn(1, 5))
                v.put("visitas", sp.visitas)
                v.put("con_recursos", sp.conRecursos)
                v.put("ultima_visita", sp.ultimaVisitaMs)
                v.put("agotado_desde", sp.agotadoDesdeMs)
                v.put("recuperacion_ms", sp.recuperacionMs)
                v.put("creado", sp.creadoMs)
                db.insert("spots", null, v)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        directorioReferencias.mkdirs()
        for ((nombre, bytes) in copia.imagenes) {
            // Solo nombres simples: una copia ajena no puede escribir fuera de la carpeta.
            if (nombre.contains('/') || nombre.contains('\\') || nombre.startsWith(".")) continue
            File(directorioReferencias, nombre).writeBytes(bytes)
        }
        refrescar()
    }

    /** Imágenes de los materiales (por nombre de archivo), para la copia de seguridad. */
    @Synchronized
    fun imagenesDeMateriales(): Map<String, ByteArray> {
        val mapa = LinkedHashMap<String, ByteArray>()
        for (m in _materiales.value) {
            for (nombre in m.archivos) {
                val f = File(directorioMateriales, nombre)
                if (f.exists()) mapa[nombre] = f.readBytes()
            }
        }
        return mapa
    }

    /**
     * Sustituye materiales y áreas por los de una copia (con los mismos identificadores, para que los
     * spots y las áreas sigan apuntando a lo mismo). Lo aprendido se importa aparte.
     */
    @Synchronized
    fun importarConfiguracion(config: ConfiguracionCopia, imagenes: Map<String, ByteArray>) {
        val db = ayudante.writableDatabase
        db.beginTransaction()
        try {
            db.delete("areas", null, null)
            db.delete("materiales", null, null)
            for (m in config.materiales) {
                val v = ContentValues()
                v.put("id", m.id)
                v.put("nombre", m.nombre)
                v.put("categoria", m.categoria)
                v.put("umbral", m.umbral)
                v.put("ancho", m.ancho)
                v.put("alto", m.alto)
                v.put("archivos", m.archivos.joinToString(","))
                v.put("detecciones", 0)
                v.put("estado", EstadoReconocimiento.SIN_PROBAR.name)
                db.insert("materiales", null, v)
            }
            for (a in config.areas) {
                val v = ContentValues()
                v.put("id", a.id)
                v.put("nombre", a.nombre)
                v.put("x", a.rect.x)
                v.put("y", a.rect.y)
                v.put("w", a.rect.w)
                v.put("h", a.rect.h)
                v.put("ref_ancho", a.refAncho)
                v.put("ref_alto", a.refAlto)
                v.put("activa", if (a.activa) 1 else 0)
                v.put("materiales", a.materiales.joinToString(","))
                db.insert("areas", null, v)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        directorioMateriales.mkdirs()
        directorioMateriales.listFiles()?.forEach { it.delete() }
        for ((nombre, bytes) in imagenes) {
            if (!PaqueteDeRespaldo.nombreSimple(nombre)) continue
            File(directorioMateriales, nombre).writeBytes(bytes)
        }
        refrescar()
    }

    // ---------- Autoprueba ----------

    /** Escribe un valor y lo vuelve a leer. Comprueba que la base de datos funciona de verdad. */
    @Synchronized
    fun autoprueba(): Boolean = try {
        val db = ayudante.writableDatabase
        val valor = System.nanoTime().toString()
        val valores = ContentValues()
        valores.put("clave", "autoprueba")
        valores.put("valor", valor)
        db.insertWithOnConflict("meta", null, valores, SQLiteDatabase.CONFLICT_REPLACE)
        db.rawQuery("SELECT valor FROM meta WHERE clave = 'autoprueba'", null).use { c ->
            c.moveToFirst() && c.getString(0) == valor
        }
    } catch (e: Exception) {
        false
    }
}

private const val VERSION_BD = 5
