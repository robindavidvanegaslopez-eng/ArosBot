package com.arosbot.ai.core

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Memoria persistente (módulo 9) sobre SQLite, la solución equivalente a Room que permite
 * la especificación y que no necesita procesadores de anotaciones. Guarda materiales y áreas.
 * Las tablas del aprendizaje (rutas, spots, estadísticas) se añadirán en sus fases.
 */
class Store(contexto: Context) {

    private class Ayudante(contexto: Context) :
        SQLiteOpenHelper(contexto, "arosbot.db", null, VERSION_BD) {

        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE materiales (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nombre TEXT NOT NULL, " +
                    "categoria TEXT NOT NULL, " +
                    "umbral REAL NOT NULL, " +
                    "ancho INTEGER NOT NULL, " +
                    "alto INTEGER NOT NULL, " +
                    "archivos TEXT NOT NULL, " +
                    "detecciones INTEGER NOT NULL DEFAULT 0, " +
                    "ultima_confianza REAL, " +
                    "estado TEXT NOT NULL DEFAULT 'SIN_PROBAR')"
            )
            db.execSQL(
                "CREATE TABLE areas (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nombre TEXT NOT NULL, " +
                    "x REAL NOT NULL, y REAL NOT NULL, w REAL NOT NULL, h REAL NOT NULL, " +
                    "ref_ancho INTEGER NOT NULL, " +
                    "ref_alto INTEGER NOT NULL, " +
                    "activa INTEGER NOT NULL DEFAULT 1, " +
                    "materiales TEXT NOT NULL DEFAULT '')"
            )
            db.execSQL("CREATE TABLE meta (clave TEXT PRIMARY KEY, valor TEXT NOT NULL)")
            crearTablaCalibraciones(db)
        }

        override fun onUpgrade(db: SQLiteDatabase, antigua: Int, nueva: Int) {
            // Versión 2 (Fase 3): calibraciones del movimiento. Los datos anteriores se conservan.
            if (antigua < 2) crearTablaCalibraciones(db)
        }

        private fun crearTablaCalibraciones(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS calibraciones (" +
                    "direccion TEXT PRIMARY KEY, " +
                    "vx REAL NOT NULL, " +
                    "vy REAL NOT NULL, " +
                    "muestras INTEGER NOT NULL)"
            )
        }
    }

    private val ayudante = Ayudante(contexto.applicationContext)

    val directorioMateriales: File = File(contexto.applicationContext.filesDir, "materiales")

    private val _materiales = MutableStateFlow<List<Material>>(emptyList())
    val materiales: StateFlow<List<Material>> = _materiales.asStateFlow()

    private val _areas = MutableStateFlow<List<Area>>(emptyList())
    val areas: StateFlow<List<Area>> = _areas.asStateFlow()

    private val _calibraciones = MutableStateFlow<Map<Direccion, Calibracion>>(emptyMap())
    val calibraciones: StateFlow<Map<Direccion, Calibracion>> = _calibraciones.asStateFlow()

    /** Se invoca tras cada cambio en la base de datos. */
    @Volatile
    var alCambiar: (() -> Unit)? = null

    init {
        directorioMateriales.mkdirs()
        refrescar()
    }

    @Synchronized
    fun refrescar() {
        _materiales.value = leerMateriales()
        _areas.value = leerAreas()
        _calibraciones.value = leerCalibraciones()
        alCambiar?.invoke()
    }

    // ---------- Calibraciones del movimiento ----------

    private fun leerCalibraciones(): Map<Direccion, Calibracion> {
        val mapa = HashMap<Direccion, Calibracion>()
        val consulta = "SELECT direccion, vx, vy, muestras FROM calibraciones"
        ayudante.readableDatabase.rawQuery(consulta, null).use { c ->
            while (c.moveToNext()) {
                val direccion = try {
                    Direccion.valueOf(c.getString(0))
                } catch (e: IllegalArgumentException) {
                    continue
                }
                mapa[direccion] = Calibracion(direccion, c.getDouble(1), c.getDouble(2), c.getInt(3))
            }
        }
        return mapa
    }

    /** Guarda (o sustituye) la calibración de una dirección. */
    @Synchronized
    fun guardarCalibracion(calibracion: Calibracion) {
        val valores = ContentValues()
        valores.put("direccion", calibracion.direccion.name)
        valores.put("vx", calibracion.vx)
        valores.put("vy", calibracion.vy)
        valores.put("muestras", calibracion.muestras)
        ayudante.writableDatabase.insertWithOnConflict(
            "calibraciones", null, valores, SQLiteDatabase.CONFLICT_REPLACE
        )
        refrescar()
    }

    // ---------- Materiales ----------

    private fun leerMateriales(): List<Material> {
        val lista = ArrayList<Material>()
        val consulta =
            "SELECT id, nombre, categoria, umbral, ancho, alto, archivos, detecciones, " +
                "ultima_confianza, estado FROM materiales ORDER BY id"
        ayudante.readableDatabase.rawQuery(consulta, null).use { c ->
            while (c.moveToNext()) {
                val estado = try {
                    EstadoReconocimiento.valueOf(c.getString(9))
                } catch (e: IllegalArgumentException) {
                    EstadoReconocimiento.SIN_PROBAR
                }
                lista.add(
                    Material(
                        id = c.getLong(0),
                        nombre = c.getString(1),
                        categoria = c.getString(2),
                        umbral = c.getFloat(3),
                        ancho = c.getInt(4),
                        alto = c.getInt(5),
                        archivos = c.getString(6).split(",").filter { it.isNotBlank() },
                        detecciones = c.getInt(7),
                        ultimaConfianza = if (c.isNull(8)) null else c.getFloat(8),
                        estado = estado
                    )
                )
            }
        }
        return lista
    }

    @Synchronized
    fun insertarMaterial(
        nombre: String,
        categoria: String,
        umbral: Float,
        ancho: Int,
        alto: Int,
        archivo: String
    ): Long {
        val valores = ContentValues()
        valores.put("nombre", nombre)
        valores.put("categoria", categoria)
        valores.put("umbral", umbral)
        valores.put("ancho", ancho)
        valores.put("alto", alto)
        valores.put("archivos", archivo)
        valores.put("detecciones", 0)
        valores.put("estado", EstadoReconocimiento.SIN_PROBAR.name)
        val id = ayudante.writableDatabase.insert("materiales", null, valores)
        refrescar()
        return id
    }

    @Synchronized
    fun actualizarDatosMaterial(id: Long, nombre: String, categoria: String, umbral: Float) {
        val valores = ContentValues()
        valores.put("nombre", nombre)
        valores.put("categoria", categoria)
        valores.put("umbral", umbral)
        ayudante.writableDatabase.update("materiales", valores, "id = ?", arrayOf(id.toString()))
        refrescar()
    }

    @Synchronized
    fun agregarVariante(id: Long, archivo: String) {
        val actual = _materiales.value.firstOrNull { it.id == id } ?: return
        val valores = ContentValues()
        valores.put("archivos", (actual.archivos + archivo).joinToString(","))
        ayudante.writableDatabase.update("materiales", valores, "id = ?", arrayOf(id.toString()))
        refrescar()
    }

    /** Anota el resultado de una prueba o de una detección en vivo. */
    @Synchronized
    fun registrarResultado(id: Long, encontrados: Int, mejorConfianza: Float?) {
        val actual = _materiales.value.firstOrNull { it.id == id } ?: return
        val valores = ContentValues()
        valores.put("detecciones", actual.detecciones + encontrados)
        if (mejorConfianza != null) valores.put("ultima_confianza", mejorConfianza)
        valores.put(
            "estado",
            if (encontrados > 0) {
                EstadoReconocimiento.RECONOCIDO.name
            } else {
                EstadoReconocimiento.NO_ENCONTRADO.name
            }
        )
        ayudante.writableDatabase.update("materiales", valores, "id = ?", arrayOf(id.toString()))
        refrescar()
    }

    @Synchronized
    fun eliminarMaterial(id: Long) {
        val actual = _materiales.value.firstOrNull { it.id == id }
        ayudante.writableDatabase.delete("materiales", "id = ?", arrayOf(id.toString()))
        actual?.archivos?.forEach { File(directorioMateriales, it).delete() }
        // Quitar el material de las áreas que lo tenían asociado.
        for (area in _areas.value.filter { id in it.materiales }) {
            guardarMaterialesDeArea(area.id, area.materiales - id)
        }
        refrescar()
    }

    // ---------- Áreas ----------

    private fun leerAreas(): List<Area> {
        val lista = ArrayList<Area>()
        val consulta =
            "SELECT id, nombre, x, y, w, h, ref_ancho, ref_alto, activa, materiales " +
                "FROM areas ORDER BY id"
        ayudante.readableDatabase.rawQuery(consulta, null).use { c ->
            while (c.moveToNext()) {
                lista.add(
                    Area(
                        id = c.getLong(0),
                        nombre = c.getString(1),
                        rect = NormRect(c.getFloat(2), c.getFloat(3), c.getFloat(4), c.getFloat(5)),
                        refAncho = c.getInt(6),
                        refAlto = c.getInt(7),
                        activa = c.getInt(8) != 0,
                        materiales = c.getString(9).split(",").mapNotNull { it.toLongOrNull() }
                    )
                )
            }
        }
        return lista
    }

    @Synchronized
    fun insertarArea(
        nombre: String,
        rect: NormRect,
        refAncho: Int,
        refAlto: Int,
        materiales: List<Long>
    ): Long {
        val valores = ContentValues()
        valores.put("nombre", nombre)
        valores.put("x", rect.x)
        valores.put("y", rect.y)
        valores.put("w", rect.w)
        valores.put("h", rect.h)
        valores.put("ref_ancho", refAncho)
        valores.put("ref_alto", refAlto)
        valores.put("activa", 1)
        valores.put("materiales", materiales.joinToString(","))
        val id = ayudante.writableDatabase.insert("areas", null, valores)
        refrescar()
        return id
    }

    @Synchronized
    fun actualizarRectanguloDeArea(
        id: Long,
        nombre: String,
        rect: NormRect,
        refAncho: Int,
        refAlto: Int
    ) {
        val valores = ContentValues()
        valores.put("nombre", nombre)
        valores.put("x", rect.x)
        valores.put("y", rect.y)
        valores.put("w", rect.w)
        valores.put("h", rect.h)
        valores.put("ref_ancho", refAncho)
        valores.put("ref_alto", refAlto)
        ayudante.writableDatabase.update("areas", valores, "id = ?", arrayOf(id.toString()))
        refrescar()
    }

    @Synchronized
    fun activarArea(id: Long, activa: Boolean) {
        val valores = ContentValues()
        valores.put("activa", if (activa) 1 else 0)
        ayudante.writableDatabase.update("areas", valores, "id = ?", arrayOf(id.toString()))
        refrescar()
    }

    @Synchronized
    fun asignarMaterialesAArea(id: Long, materiales: List<Long>) {
        guardarMaterialesDeArea(id, materiales)
        refrescar()
    }

    private fun guardarMaterialesDeArea(id: Long, materiales: List<Long>) {
        val valores = ContentValues()
        valores.put("materiales", materiales.joinToString(","))
        ayudante.writableDatabase.update("areas", valores, "id = ?", arrayOf(id.toString()))
    }

    @Synchronized
    fun eliminarArea(id: Long) {
        ayudante.writableDatabase.delete("areas", "id = ?", arrayOf(id.toString()))
        refrescar()
    }

    // ---------- Autoprueba ----------

    /** Escribe un valor y lo vuelve a leer. Comprueba que la base de datos funciona de verdad. */
    @Synchronized
    fun autoprueba(): Boolean = try {
        val db = ayudante.writableDatabase
        val valor = System.nanoTime().toString()
        val valores = ContentValues()
        valores.put("clave", "autoprueba")
        valores.put("valor", valor)
        db.insertWithOnConflict("meta", null, valores, SQLiteDatabase.CONFLICT_REPLACE)
        db.rawQuery("SELECT valor FROM meta WHERE clave = 'autoprueba'", null).use { c ->
            c.moveToFirst() && c.getString(0) == valor
        }
    } catch (e: Exception) {
        false
    }
}

private const val VERSION_BD = 2
