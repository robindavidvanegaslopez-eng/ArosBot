package com.arosbot.ai.core

/**
 * Datos que muestra el panel de supervisión. En la Fase 1 conservan sus valores
 * iniciales; cada módulo los irá actualizando cuando exista.
 */
data class Telemetry(
    val objetivoActual: String = "Ninguno",
    val spotActivo: String = "Ninguno",
    val recursosDetectados: Int = 0,
    /** Entre 0.0 y 1.0, o null si todavía no hay localización. */
    val confianzaLocalizacion: Float? = null,
    val inventario: String = "Desconocido",
    val rutaSeleccionada: String = "Ninguna"
)
