package com.arosbot.ai.core

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max

/*
 * Lógica pura (sin Android) del trazo del dedo sobre el joystick y de la optimización del camino de
 * una ruta enseñada. Todo se compila y se prueba con JUnit en la JVM.
 */

data class PuntoXY(val x: Float, val y: Float)

/**
 * Trazo del dedo para mantener el joystick empujado: UN SOLO trazo continuo. Primero un arrastre
 * rápido del centro al borde (joystick al 100 %) y después el dedo prácticamente quieto en el borde.
 *
 * Android reparte la duración de un trazo a velocidad constante a lo largo de su recorrido. Para que
 * el tramo de mantener dure lo que toca sin encadenar un segundo gesto (que Android cancelaba), el
 * trazo continúa con un zigzag diminuto (menos de 2 píxeles) en el borde, perpendicular a la
 * dirección: el dedo no se mueve de forma apreciable y el joystick no cambia de dirección.
 */
object TrazoDeJoystick {

    const val ARRASTRE_MS = 80L
    private const val PASO_ZIGZAG_PX = 3.0
    private const val MAX_SEGMENTOS = 4000

    fun puntos(inicioX: Float, inicioY: Float, finX: Float, finY: Float, duracionMs: Long): List<PuntoXY> {
        val lista = ArrayList<PuntoXY>()
        lista.add(PuntoXY(inicioX, inicioY))
        lista.add(PuntoXY(finX, finY))
        val total = max(1L, duracionMs)
        val dx = (finX - inicioX).toDouble()
        val dy = (finY - inicioY).toDouble()
        val largo = hypot(dx, dy)
        if (total <= ARRASTRE_MS || largo < 1.0) return lista

        // Largo extra que hay que recorrer para que el arrastre ocupe solo ARRASTRE_MS del total.
        val extra = largo * (total.toDouble() / ARRASTRE_MS - 1.0)
        val n = minOf(MAX_SEGMENTOS, max(2, ceil(extra / PASO_ZIGZAG_PX).toInt()))
        val paso = extra / (n - 0.5)
        val px = -dy / largo
        val py = dx / largo
        for (k in 1..n) {
            val signo = if (k % 2 == 1) 1.0 else -1.0
            lista.add(PuntoXY((finX + px * signo * paso / 2.0).toFloat(), (finY + py * signo * paso / 2.0).toFloat()))
        }
        return lista
    }

    fun longitud(puntos: List<PuntoXY>): Double {
        var total = 0.0
        for (i in 1 until puntos.size) {
            total += hypot((puntos[i].x - puntos[i - 1].x).toDouble(), (puntos[i].y - puntos[i - 1].y).toDouble())
        }
        return total
    }
}

/** Camino reducido a los puntos que de verdad hacen falta. */
data class TrayectoOptimizado(
    /** Posiciones, en la lista original, de los puntos que se conservan. */
    val indices: List<Int>,
    val puntos: List<PuntoDeRuta>,
    val longitudOriginalPx: Double,
    val longitudOptimizadaPx: Double
) {
    /** Fracción de recorrido que se ahorra, de 0 a 1. */
    val ahorro: Double
        get() = if (longitudOriginalPx <= 0.0) 0.0 else (1.0 - longitudOptimizadaPx / longitudOriginalPx).coerceIn(0.0, 1.0)
}

/**
 * Del camino que hizo el usuario al camino que recorre el bot: se quitan los rodeos, los zigzags y
 * los pasos de más, y se conserva solo lo que se desvía de una línea recta más de [TOLERANCIA_PX]
 * (algoritmo de Ramer-Douglas-Peucker). El inicio, el final y los puntos con referencia visual no se
 * quitan nunca: son donde el bot comprueba y corrige su posición.
 *
 * Límite honesto: el bot solo sabe que es transitable lo que el usuario recorrió. Por eso el atajo
 * nunca se aleja más de [TOLERANCIA_PX] del camino enseñado; no explora terreno que no ha visto.
 */
object OptimizadorDeTrayecto {

    const val TOLERANCIA_PX = 45.0

    fun simplificar(puntos: List<PuntoDeRuta>, tolerancia: Double = TOLERANCIA_PX): TrayectoOptimizado {
        val n = puntos.size
        if (n <= 2) {
            val longitud = longitud(puntos)
            return TrayectoOptimizado(puntos.indices.toList(), puntos, longitud, longitud)
        }
        val conservar = BooleanArray(n)
        val obligatorios = ArrayList<Int>()
        for (i in 0 until n) {
            if (i == 0 || i == n - 1 || puntos[i].referencia != null) {
                conservar[i] = true
                obligatorios.add(i)
            }
        }
        for (k in 1 until obligatorios.size) {
            reducir(puntos, obligatorios[k - 1], obligatorios[k], tolerancia, conservar)
        }
        val indices = ArrayList<Int>()
        for (i in 0 until n) if (conservar[i]) indices.add(i)
        val elegidos = indices.map { puntos[it] }
        return TrayectoOptimizado(indices, elegidos, longitud(puntos), longitud(elegidos))
    }

    /** Índices de la lista original que quedan entre dos puntos consecutivos conservados. */
    fun intermedios(optimizado: TrayectoOptimizado, tramo: Int): IntRange {
        if (tramo < 1 || tramo >= optimizado.indices.size) return IntRange.EMPTY
        return (optimizado.indices[tramo - 1] + 1) until optimizado.indices[tramo]
    }

    private fun reducir(puntos: List<PuntoDeRuta>, a: Int, b: Int, tolerancia: Double, conservar: BooleanArray) {
        if (b - a < 2) return
        var peor = -1
        var mayor = tolerancia
        for (i in a + 1 until b) {
            val d = distanciaASegmento(puntos[i], puntos[a], puntos[b])
            if (d > mayor) {
                mayor = d
                peor = i
            }
        }
        if (peor < 0) return
        conservar[peor] = true
        reducir(puntos, a, peor, tolerancia, conservar)
        reducir(puntos, peor, b, tolerancia, conservar)
    }

    private fun distanciaASegmento(p: PuntoDeRuta, a: PuntoDeRuta, b: PuntoDeRuta): Double {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val largo2 = dx * dx + dy * dy
        if (largo2 < 1e-9) return hypot(p.x - a.x, p.y - a.y)
        val t = (((p.x - a.x) * dx + (p.y - a.y) * dy) / largo2).coerceIn(0.0, 1.0)
        return hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy))
    }

    private fun longitud(puntos: List<PuntoDeRuta>): Double {
        var total = 0.0
        for (i in 1 until puntos.size) {
            total += hypot(puntos[i].x - puntos[i - 1].x, puntos[i].y - puntos[i - 1].y)
        }
        return total
    }
}

/**
 * Detecta que el personaje no avanza: el movimiento medido es mucho menor que el esperado varias
 * veces seguidas (obstáculo, o el juego no responde al joystick).
 */
class DetectorDeBloqueo(
    private val fraccionMinima: Double = FRACCION_MINIMA,
    private val pasosSeguidos: Int = PASOS_SEGUIDOS
) {
    private var seguidos = 0

    companion object {
        const val FRACCION_MINIMA = 0.25
        const val PASOS_SEGUIDOS = 3
    }

    /** Anota un paso medido y devuelve true si ya se considera bloqueado. */
    fun anotar(esperadoPx: Double, medidoPx: Double): Boolean {
        if (esperadoPx <= 0.0) return false
        if (abs(medidoPx) < esperadoPx * fraccionMinima) seguidos++ else seguidos = 0
        return seguidos >= pasosSeguidos
    }

    fun reiniciar() {
        seguidos = 0
    }
}
