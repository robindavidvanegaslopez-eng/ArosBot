package com.arosbot.ai.core

/**
 * Lo que se dibuja sobre el juego: los puntos de la trayectoria (en las coordenadas de la ruta, en
 * píxeles del fotograma), dónde está ahora el personaje en esas coordenadas y a qué punto va.
 * [indiceObjetivo] es -1 mientras se enseña la ruta.
 */
data class VistaDeTrayecto(
    val puntos: List<PuntoXY>,
    val x: Double,
    val y: Double,
    val indiceObjetivo: Int,
    val ensenando: Boolean
)

/** Paso de coordenadas de ruta a coordenadas de pantalla, con el personaje fijo en el ancla. */
object ProyeccionDeTrayecto {

    /**
     * La escena se mueve al revés que el personaje: un punto de la ruta a la derecha de la posición actual
     * aparece a la derecha del ancla. [escala] pasa de píxeles de fotograma a píxeles de pantalla.
     */
    fun aPantalla(
        puntoX: Double,
        puntoY: Double,
        posX: Double,
        posY: Double,
        anclaX: Float,
        anclaY: Float,
        escala: Float
    ): PuntoXY = PuntoXY(
        (anclaX + (puntoX - posX) * escala).toFloat(),
        (anclaY + (puntoY - posY) * escala).toFloat()
    )
}
