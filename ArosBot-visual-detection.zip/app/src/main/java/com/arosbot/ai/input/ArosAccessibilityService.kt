package com.arosbot.ai.input

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.PlanDeSegmentos
import kotlin.coroutines.resume
import kotlin.math.max
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

/**
 * Servicio de accesibilidad. Lo único que hace es lo que Android permite a un servicio de este tipo:
 *  - generar gestos táctiles (toques y arrastres) sobre cualquier app, no teclas de teclado;
 *  - avisar de qué ventana está en primer plano (para detectar el selector de cuentas de Google);
 *  - leer los textos de la ventana activa y pulsar un elemento por su texto.
 * No lee ni escribe campos de contraseña.
 */
class ArosAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instancia = this
        _conectado.value = true
        BotCore.log.info("Accesibilidad", "Servicio de accesibilidad conectado")
    }

    override fun onAccessibilityEvent(evento: AccessibilityEvent?) {
        if (evento == null || evento.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val paquete = evento.packageName?.toString() ?: return
        if (paquete in PAQUETES_GOOGLE) {
            if (!_ventanaGoogle.value) {
                BotCore.log.info("Accesibilidad", "Ventana de Google en primer plano")
            }
            _ventanaGoogle.value = true
        } else if (paquete !in PAQUETES_IGNORADOS) {
            _ventanaGoogle.value = false
        }
    }

    override fun onInterrupt() {
        // Android interrumpe el servicio: se sueltan las pulsaciones en curso.
        BotCore.entrada.soltarTodo()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instancia = null
        _conectado.value = false
        _ventanaGoogle.value = false
        BotCore.entrada.soltarTodo()
        BotCore.log.aviso("Accesibilidad", "Servicio de accesibilidad desconectado")
        return super.onUnbind(intent)
    }

    // ---------- Gestos ----------

    private suspend fun despachar(gesto: GestureDescription): Boolean =
        suspendCancellableCoroutine { continuacion ->
            val aceptado = dispatchGesture(
                gesto,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (continuacion.isActive) continuacion.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (continuacion.isActive) continuacion.resume(false)
                    }
                },
                null
            )
            if (!aceptado && continuacion.isActive) continuacion.resume(false)
        }

    /** Toca la pantalla en ([x], [y]) (píxeles reales). */
    suspend fun tocar(x: Float, y: Float, duracionMs: Long = 60L): Boolean {
        val ruta = Path()
        ruta.moveTo(x, y)
        val trazo = GestureDescription.StrokeDescription(ruta, 0L, duracionMs)
        return despachar(GestureDescription.Builder().addStroke(trazo).build())
    }

    /**
     * Pulsa en ([inicioX], [inicioY]), arrastra hasta ([finX], [finY]) y mantiene el dedo ahí durante
     * [duracionMs]. Se envía en segmentos cortos encadenados; entre segmentos se consulta [seguir] y,
     * si devuelve false (parada de emergencia, captura perdida, soltarTodo), se levanta el dedo.
     * También se levanta si la corrutina se cancela. Devuelve true solo si la pulsación se completó.
     */
    suspend fun mantenerArrastre(
        inicioX: Float,
        inicioY: Float,
        finX: Float,
        finY: Float,
        duracionMs: Long,
        seguir: () -> Boolean
    ): Boolean {
        if (duracionMs <= UN_SOLO_GESTO_MAX_MS) {
            // Pulsación corta: un único gesto (arrastre lento del centro al borde). Es lo más fiable;
            // no se puede soltar a mitad, pero dura como mucho UN_SOLO_GESTO_MAX_MS.
            val ruta = Path()
            ruta.moveTo(inicioX, inicioY)
            ruta.lineTo(finX, finY)
            val trazoUnico = GestureDescription.StrokeDescription(ruta, 0L, max(1L, duracionMs))
            val ok = despachar(GestureDescription.Builder().addStroke(trazoUnico).build())
            if (!ok) {
                JoystickGestos.motivoUltimoFallo =
                    "Android rechazó o canceló el gesto (¿tocaste la pantalla durante la prueba?)"
            }
            return ok
        }
        val partes = PlanDeSegmentos.dividir(duracionMs, SEGMENTO_MS)
        var trazo: GestureDescription.StrokeDescription? = null
        var abierto = false
        try {
            for (i in partes.indices) {
                val ultimo = i == partes.lastIndex
                val ruta = Path()
                if (i == 0) {
                    ruta.moveTo(inicioX, inicioY)
                    ruta.lineTo(finX, finY)
                } else {
                    ruta.moveTo(finX, finY)
                }
                val previo = trazo
                val nuevo = if (previo == null) {
                    GestureDescription.StrokeDescription(ruta, 0L, partes[i], !ultimo)
                } else {
                    previo.continueStroke(ruta, 0L, partes[i], !ultimo)
                }
                trazo = nuevo
                val enviado = despachar(GestureDescription.Builder().addStroke(nuevo).build())
                abierto = !ultimo && enviado
                if (!enviado) {
                    JoystickGestos.motivoUltimoFallo =
                        "Android canceló el gesto en el tramo ${i + 1} de ${partes.size}"
                    return false
                }
                if (ultimo) return true
                if (!seguir()) {
                    JoystickGestos.motivoUltimoFallo =
                        "La pulsación se interrumpió (parada, captura perdida o cancelación)"
                    return false
                }
            }
            return false
        } finally {
            val pendiente = trazo
            if (abierto && pendiente != null) {
                // Levantar el dedo pase lo que pase, incluso si la corrutina está cancelada.
                withContext(NonCancellable) {
                    try {
                        val rutaCierre = Path()
                        rutaCierre.moveTo(finX, finY)
                        val cierre = pendiente.continueStroke(rutaCierre, 0L, 1L, false)
                        despachar(GestureDescription.Builder().addStroke(cierre).build())
                    } catch (e: Exception) {
                        BotCore.log.error("Accesibilidad", "No se pudo levantar el dedo: ${e.message}")
                    }
                }
            }
        }
    }

    // ---------- Lectura de la ventana activa ----------

    /** true si la ventana activa contiene un campo de contraseña. El bot nunca los toca. */
    fun hayCampoDeContrasena(): Boolean {
        val raiz = rootInActiveWindow ?: return false
        return buscar(raiz) { it.isPassword } != null
    }

    /** Pulsa el elemento cuyo texto (o descripción) coincide con [texto]. Devuelve true si lo pulsó. */
    fun pulsarElementoConTexto(texto: String): Boolean {
        val buscado = texto.trim()
        if (buscado.isEmpty()) return false
        val raiz = rootInActiveWindow ?: return false
        val nodo = buscar(raiz) { n ->
            val propio = n.text?.toString()?.trim()
            val descripcion = n.contentDescription?.toString()
            (propio != null && propio.equals(buscado, ignoreCase = true)) ||
                (descripcion != null && descripcion.contains(buscado, ignoreCase = true))
        } ?: return false

        var actual: AccessibilityNodeInfo? = nodo
        while (actual != null) {
            if (actual.isClickable) return actual.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            actual = actual.parent
        }
        return false
    }

    private fun buscar(
        nodo: AccessibilityNodeInfo,
        condicion: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (condicion(nodo)) return nodo
        for (i in 0 until nodo.childCount) {
            val hijo = nodo.getChild(i) ?: continue
            val encontrado = buscar(hijo, condicion)
            if (encontrado != null) return encontrado
        }
        return null
    }

    companion object {
        /** Duración de cada segmento de una pulsación mantenida: es el retraso máximo para soltarla. */
        private const val SEGMENTO_MS = 150L
        private const val UN_SOLO_GESTO_MAX_MS = 1000L

        /** Paquetes de las ventanas de Google donde aparece el selector de cuentas. */
        private val PAQUETES_GOOGLE = setOf(
            "com.google.android.gms",
            "com.android.credentialmanager",
            "com.google.android.gsf"
        )

        /** Ventanas del sistema que no indican un cambio de aplicación. */
        private val PAQUETES_IGNORADOS = setOf(
            "com.android.systemui",
            "android"
        )

        @Volatile
        var instancia: ArosAccessibilityService? = null
            private set

        private val _conectado = MutableStateFlow(false)
        val conectado: StateFlow<Boolean> = _conectado.asStateFlow()

        private val _ventanaGoogle = MutableStateFlow(false)

        /** true mientras una ventana de Google (selector de cuentas) está en primer plano. */
        val ventanaGoogle: StateFlow<Boolean> = _ventanaGoogle.asStateFlow()
    }
}
