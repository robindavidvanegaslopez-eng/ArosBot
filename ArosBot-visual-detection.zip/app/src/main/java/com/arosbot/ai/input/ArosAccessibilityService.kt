package com.arosbot.ai.input

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.TrazoDeJoystick
import kotlin.coroutines.resume
import kotlin.math.max
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Servicio de accesibilidad. Lo único que hace es lo que Android permite a un servicio de este tipo:
 *  - generar gestos táctiles (toques y arrastres) sobre cualquier app, no teclas de teclado;
 *  - avisar de qué ventana está en primer plano (para detectar el selector de cuentas de Google);
 *  - leer los textos de la ventana activa y pulsar un elemento por su texto.
 * No lee ni escribe campos de contraseña.
 */
class ArosAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instancia = this
        _conectado.value = true
        BotCore.log.info("Accesibilidad", "Servicio de accesibilidad conectado")
    }

    override fun onAccessibilityEvent(evento: AccessibilityEvent?) {
        if (evento == null || evento.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val paquete = evento.packageName?.toString() ?: return
        if (paquete in PAQUETES_GOOGLE) {
            if (!_ventanaGoogle.value) {
                BotCore.log.info("Accesibilidad", "Ventana de Google en primer plano")
            }
            _ventanaGoogle.value = true
        } else if (paquete !in PAQUETES_IGNORADOS) {
            _ventanaGoogle.value = false
        }
    }

    override fun onInterrupt() {
        // Android interrumpe el servicio: se sueltan las pulsaciones en curso.
        BotCore.entrada.soltarTodo()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instancia = null
        _conectado.value = false
        _ventanaGoogle.value = false
        BotCore.entrada.soltarTodo()
        BotCore.log.aviso("Accesibilidad", "Servicio de accesibilidad desconectado")
        return super.onUnbind(intent)
    }

    // ---------- Gestos ----------

    private suspend fun despachar(gesto: GestureDescription): Boolean =
        suspendCancellableCoroutine { continuacion ->
            val aceptado = dispatchGesture(
                gesto,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (continuacion.isActive) continuacion.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (continuacion.isActive) continuacion.resume(false)
                    }
                },
                null
            )
            if (!aceptado && continuacion.isActive) continuacion.resume(false)
        }

    /** Toca la pantalla en ([x], [y]) (píxeles reales). */
    suspend fun tocar(x: Float, y: Float, duracionMs: Long = 60L): Boolean {
        val ruta = Path()
        ruta.moveTo(x, y)
        val trazo = GestureDescription.StrokeDescription(ruta, 0L, duracionMs)
        return despachar(GestureDescription.Builder().addStroke(trazo).build())
    }

    /** Desliza el dedo de ([x1], [y1]) a ([x2], [y2]) en [duracionMs] (un solo trazo recto). */
    suspend fun deslizar(x1: Float, y1: Float, x2: Float, y2: Float, duracionMs: Long): Boolean {
        val ruta = Path()
        ruta.moveTo(x1, y1)
        ruta.lineTo(x2, y2)
        val trazo = GestureDescription.StrokeDescription(ruta, 0L, max(1L, duracionMs))
        return despachar(GestureDescription.Builder().addStroke(trazo).build())
    }

    /**
     * Pulsa en ([inicioX], [inicioY]), arrastra hasta ([finX], [finY]) y mantiene el dedo ahí hasta
     * cumplir [duracionMs]. Es UN SOLO trazo continuo (ver [TrazoDeJoystick]): sin segundos gestos
     * encadenados no hay nada que Android pueda cancelar «a mitad». Como contrapartida, una vez
     * enviado el trazo no se puede soltar antes de tiempo: dura lo pedido (en el seguimiento de rutas,
     * 1,5 s como máximo). Si Android cancela el gesto, se reintenta [INTENTOS_GESTO] veces antes de
     * darlo por fallido. [seguir] se consulta antes de cada intento (parada de emergencia, captura
     * perdida o soltarTodo). Devuelve true solo si el gesto se completó.
     */
    suspend fun mantenerArrastre(
        inicioX: Float,
        inicioY: Float,
        finX: Float,
        finY: Float,
        duracionMs: Long,
        seguir: () -> Boolean
    ): Boolean {
        val puntos = TrazoDeJoystick.puntos(inicioX, inicioY, finX, finY, duracionMs)
        val total = max(1L, duracionMs)
        for (intento in 1..INTENTOS_GESTO) {
            if (!seguir()) {
                JoystickGestos.motivoUltimoFallo =
                    "La pulsación se interrumpió (parada, captura perdida o cancelación)"
                return false
            }
            val ruta = Path()
            ruta.moveTo(puntos[0].x, puntos[0].y)
            for (i in 1 until puntos.size) ruta.lineTo(puntos[i].x, puntos[i].y)
            val trazo = GestureDescription.StrokeDescription(ruta, 0L, total)
            if (despachar(GestureDescription.Builder().addStroke(trazo).build())) return true
            JoystickGestos.motivoUltimoFallo =
                "Android canceló el gesto (intento $intento de $INTENTOS_GESTO)"
            BotCore.log.aviso("Accesibilidad", JoystickGestos.motivoUltimoFallo ?: "Gesto cancelado")
            if (intento < INTENTOS_GESTO) delay(PAUSA_REINTENTO_MS)
        }
        return false
    }

    // ---------- Lectura de la ventana activa ----------

    /** true si la ventana activa contiene un campo de contraseña. El bot nunca los toca. */
    fun hayCampoDeContrasena(): Boolean {
        val raiz = rootInActiveWindow ?: return false
        return buscar(raiz) { it.isPassword } != null
    }

    /** Pulsa el elemento cuyo texto (o descripción) coincide con [texto]. Devuelve true si lo pulsó. */
    fun pulsarElementoConTexto(texto: String): Boolean {
        val buscado = texto.trim()
        if (buscado.isEmpty()) return false
        val raiz = rootInActiveWindow ?: return false
        val nodo = buscar(raiz) { n ->
            val propio = n.text?.toString()?.trim()
            val descripcion = n.contentDescription?.toString()
            (propio != null && propio.equals(buscado, ignoreCase = true)) ||
                (descripcion != null && descripcion.contains(buscado, ignoreCase = true))
        } ?: return false

        var actual: AccessibilityNodeInfo? = nodo
        while (actual != null) {
            if (actual.isClickable) return actual.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            actual = actual.parent
        }
        return false
    }

    private fun buscar(
        nodo: AccessibilityNodeInfo,
        condicion: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (condicion(nodo)) return nodo
        for (i in 0 until nodo.childCount) {
            val hijo = nodo.getChild(i) ?: continue
            val encontrado = buscar(hijo, condicion)
            if (encontrado != null) return encontrado
        }
        return null
    }

    companion object {
        /** Cuántas veces se intenta un gesto que Android cancela antes de darlo por fallido. */
        private const val INTENTOS_GESTO = 3
        private const val PAUSA_REINTENTO_MS = 150L

        /** Paquetes de las ventanas de Google donde aparece el selector de cuentas. */
        private val PAQUETES_GOOGLE = setOf(
            "com.google.android.gms",
            "com.android.credentialmanager",
            "com.google.android.gsf"
        )

        /** Ventanas del sistema que no indican un cambio de aplicación. */
        private val PAQUETES_IGNORADOS = setOf(
            "com.android.systemui",
            "android"
        )

        @Volatile
        var instancia: ArosAccessibilityService? = null
            private set

        private val _conectado = MutableStateFlow(false)
        val conectado: StateFlow<Boolean> = _conectado.asStateFlow()

        private val _ventanaGoogle = MutableStateFlow(false)

        /** true mientras una ventana de Google (selector de cuentas) está en primer plano. */
        val ventanaGoogle: StateFlow<Boolean> = _ventanaGoogle.asStateFlow()
    }
}
