package com.arosbot.ai.input

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import com.arosbot.ai.core.ArcoDeJoystick
import com.arosbot.ai.core.PuntoXY
import kotlin.math.atan2

/**
 * Un único toque continuo sobre el joystick que no se levanta mientras dura la conducción. El dedo
 * baja en el centro, sube al borde en el rumbo pedido y, cada [SEGMENTO_MS], se desliza por el borde
 * hasta el rumbo que el piloto indique en ese momento. Android lo recibe como un mismo trazo que
 * continúa (`StrokeDescription.continueStroke`), así que el juego ve un dedo que nunca se levanta y
 * el joystick sigue al 100 % de velocidad en todo momento.
 *
 * Cada segmento se envía desde la devolución de llamada del anterior para que el hueco entre ambos
 * sea mínimo. Si Android cancela o rechaza un segmento, [estado] pasa a CANCELADO y [motivo] lo explica:
 * nunca se da por bueno un gesto que no se completó. Hay que pedir soltar con [deberiaSoltar]; el
 * último segmento levanta el dedo.
 */
class GestoContinuo(
    private val servicio: AccessibilityService,
    private val cx: Float,
    private val cy: Float,
    private val radio: Float,
    private val rumbo: () -> Double,
    private val deberiaSoltar: () -> Boolean
) {
    enum class Estado { PREPARADO, ACTIVO, TERMINADO, CANCELADO }

    @Volatile
    var estado: Estado = Estado.PREPARADO
        private set

    @Volatile
    var motivo: String? = null
        private set

    @Volatile
    var segmentos: Int = 0
        private set

    private var trazo: GestureDescription.StrokeDescription? = null
    private var ultimo: PuntoXY = PuntoXY(0f, 0f)
    private var rumboActual = 0.0
    private var signo = 1
    private val inicioMs = System.nanoTime()

    /** Pone el dedo en el centro y lo sube al borde en el rumbo inicial. false si Android lo rechaza. */
    fun arrancar(): Boolean {
        if (estado != Estado.PREPARADO) return false
        rumboActual = rumbo()
        val borde = ArcoDeJoystick.punto(cx, cy, radio, rumboActual)
        val ruta = Path()
        ruta.moveTo(cx, cy)
        ruta.lineTo(borde.x, borde.y)
        val nuevo = GestureDescription.StrokeDescription(ruta, 0L, ARRASTRE_MS, true)
        trazo = nuevo
        ultimo = borde
        estado = Estado.ACTIVO
        return enviar(nuevo)
    }

    private fun enviar(t: GestureDescription.StrokeDescription): Boolean {
        segmentos++
        val aceptado = try {
            servicio.dispatchGesture(
                GestureDescription.Builder().addStroke(t).build(),
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        alCompletar()
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (estado == Estado.ACTIVO) {
                            motivo = "Android canceló el gesto continuo (segmento $segmentos)"
                            estado = Estado.CANCELADO
                        }
                    }
                },
                null
            )
        } catch (e: Exception) {
            motivo = "No se pudo enviar el gesto: ${e.message}"
            false
        }
        if (!aceptado) {
            if (motivo == null) motivo = "Android rechazó el gesto continuo (segmento $segmentos)"
            estado = Estado.CANCELADO
        }
        return aceptado
    }

    private fun alCompletar() {
        if (estado != Estado.ACTIVO) return
        val previo = trazo
        if (previo == null) {
            // El segmento que acaba de completarse era el último, el que levanta el dedo.
            estado = Estado.TERMINADO
            return
        }
        val soltar = deberiaSoltar() ||
            (System.nanoTime() - inicioMs) / 1_000_000L > DURACION_MAXIMA_MS
        val ruta = Path()
        ruta.moveTo(ultimo.x, ultimo.y)
        if (soltar) {
            val fin = ArcoDeJoystick.deslizar(cx, cy, radio, anguloDe(ultimo), anguloDe(ultimo), signo)
            signo = -signo
            ruta.lineTo(fin[0].x, fin[0].y)
            val ultimoTrazo = previo.continueStroke(ruta, 0L, SEGMENTO_FINAL_MS, false)
            trazo = null
            enviar(ultimoTrazo)
            return
        }
        val nuevoRumbo = rumbo()
        val puntos = ArcoDeJoystick.deslizar(cx, cy, radio, rumboActual, nuevoRumbo, signo)
        signo = -signo
        for (q in puntos) ruta.lineTo(q.x, q.y)
        val fin = puntos.last()
        val siguiente = previo.continueStroke(ruta, 0L, SEGMENTO_MS, true)
        trazo = siguiente
        ultimo = fin
        rumboActual = anguloDe(fin)
        enviar(siguiente)
    }

    private fun anguloDe(p: PuntoXY): Double = atan2((p.y - cy).toDouble(), (p.x - cx).toDouble())

    companion object {
        const val ARRASTRE_MS = 80L
        const val SEGMENTO_MS = 100L
        const val SEGMENTO_FINAL_MS = 30L

        /** Tope de seguridad: ninguna conducción dura más de esto aunque nadie pida soltar. */
        const val DURACION_MAXIMA_MS = 10 * 60_000L
    }
}
