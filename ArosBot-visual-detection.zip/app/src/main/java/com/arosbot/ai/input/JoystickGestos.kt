package com.arosbot.ai.input

import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.capture.PantallaReal
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.ControladorEntrada
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.FrameGeometry
import com.arosbot.ai.core.GeometriaJoystick
import java.util.concurrent.atomic.AtomicInteger

/**
 * Controlador WASD (módulo 12). Una app normal no puede inyectar teclas en otra aplicación, así que
 * W/A/S/D se traducen en un arrastre sobre el joystick virtual del juego mediante gestos del servicio
 * de accesibilidad. Que el juego responda a esos gestos se comprueba con «Probar movimiento».
 *
 * Nunca envía entradas si no hay captura, si hay una parada de emergencia o si el joystick no
 * corresponde a la pantalla actual.
 */
class JoystickGestos : ControladorEntrada {

    private val generacion = AtomicInteger(0)

    override val disponible: Boolean
        get() = ArosAccessibilityService.instancia != null && BotCore.settings.joystick != null

    override suspend fun mantener(direccion: Direccion, duracionMs: Long): Boolean {
        motivoUltimoFallo = null
        val servicio = ArosAccessibilityService.instancia
        if (servicio == null) {
            motivoUltimoFallo = "El servicio de accesibilidad no está conectado"
            return false
        }
        val joystick = BotCore.settings.joystick
        if (joystick == null) {
            motivoUltimoFallo = "El joystick no está configurado"
            return false
        }
        if (!permitido()) {
            motivoUltimoFallo =
                if (!FrameBus.estado.value.activa) "La captura de pantalla no está activa"
                else "Hay una parada de emergencia activa"
            return false
        }

        val (ancho, alto) = PantallaReal.tamano(BotCore.appContext)
        if (!FrameGeometry.relacionCompatible(joystick.refAncho, joystick.refAlto, ancho, alto)) {
            BotCore.log.aviso(
                "Entrada",
                "El joystick ya no corresponde a la pantalla actual: hay que volver a configurarlo"
            )
            motivoUltimoFallo = "El joystick no corresponde a la pantalla actual (vuelve a configurarlo)"
            return false
        }

        val puntos = GeometriaJoystick.puntos(joystick.rect, ancho, alto, direccion)
        val miGeneracion = generacion.get()
        return servicio.mantenerArrastre(
            puntos.centroX,
            puntos.centroY,
            puntos.destinoX,
            puntos.destinoY,
            duracionMs
        ) { permitido() && generacion.get() == miGeneracion }
    }

    /**
     * Impide enviar más gestos. Un gesto ya enviado (un solo trazo, de 1,5 s como máximo en el
     * seguimiento de rutas) no se puede retirar: Android no permite cancelarlo desde un servicio.
     */
    override fun soltarTodo() {
        generacion.incrementAndGet()
    }

    companion object {
        /** Por qué falló la última pulsación (para mostrarlo en las pruebas). */
        @Volatile
        var motivoUltimoFallo: String? = null
    }

    private fun permitido(): Boolean =
        FrameBus.estado.value.activa &&
            BotCore.stateMachine.state.value != BotState.PARADA_EMERGENCIA
}
