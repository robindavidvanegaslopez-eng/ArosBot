package com.arosbot.ai.input

import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.capture.PantallaReal
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.ControladorEntrada
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.FrameGeometry
import com.arosbot.ai.core.GeometriaJoystick
import java.util.concurrent.atomic.AtomicInteger

/**
 * Controlador WASD (módulo 12). Una app normal no puede inyectar teclas en otra aplicación, así que
 * W/A/S/D se traducen en un arrastre sobre el joystick virtual del juego mediante gestos del servicio
 * de accesibilidad. Que el juego responda a esos gestos se comprueba con «Probar movimiento».
 *
 * Nunca envía entradas si no hay captura, si hay una parada de emergencia o si el joystick no
 * corresponde a la pantalla actual.
 */
class JoystickGestos : ControladorEntrada {

    override val disponible: Boolean
        get() = ArosAccessibilityService.instancia != null && BotCore.settings.joystick != null

    override suspend fun mantener(direccion: Direccion, duracionMs: Long): Boolean {
        motivoUltimoFallo = null
        val servicio = ArosAccessibilityService.instancia
        if (servicio == null) {
            motivoUltimoFallo = "El servicio de accesibilidad no está conectado"
            return false
        }
        val joystick = BotCore.settings.joystick
        if (joystick == null) {
            motivoUltimoFallo = "El joystick no está configurado"
            return false
        }
        if (!permitido()) {
            motivoUltimoFallo =
                if (!FrameBus.estado.value.activa) "La captura de pantalla no está activa"
                else "Hay una parada de emergencia activa"
            return false
        }

        val (ancho, alto) = PantallaReal.tamano(BotCore.appContext)
        if (!FrameGeometry.relacionCompatible(joystick.refAncho, joystick.refAlto, ancho, alto)) {
            BotCore.log.aviso(
                "Entrada",
                "El joystick ya no corresponde a la pantalla actual: hay que volver a configurarlo"
            )
            motivoUltimoFallo = "El joystick no corresponde a la pantalla actual (vuelve a configurarlo)"
            return false
        }

        val puntos = GeometriaJoystick.puntos(joystick.rect, ancho, alto, direccion)
        val miGeneracion = generacion.get()
        return servicio.mantenerArrastre(
            puntos.centroX,
            puntos.centroY,
            puntos.destinoX,
            puntos.destinoY,
            duracionMs
        ) { permitido() && generacion.get() == miGeneracion }
    }

    /**
     * Impide enviar más gestos. Un gesto ya enviado (un solo trazo, de 1,5 s como máximo en el
     * seguimiento de rutas) no se puede retirar: Android no permite cancelarlo desde un servicio.
     */
    override fun soltarTodo() {
        generacion.incrementAndGet()
    }


    companion object {
        /** Por qué falló la última pulsación (para mostrarlo en las pruebas). */
        @Volatile
        var motivoUltimoFallo: String? = null

        private val generacion = AtomicInteger(0)

        private fun permitidoAhora(): Boolean =
            FrameBus.estado.value.activa &&
                BotCore.stateMachine.state.value != BotState.PARADA_EMERGENCIA

        /**
         * Crea un gesto continuo sobre el joystick (ver [GestoContinuo]) con las mismas comprobaciones
         * que [mantener]. [rumbo] da el ángulo del dedo (radianes, coordenadas de pantalla) y
         * [soltar] pide levantar el dedo. Devuelve null, con [motivoUltimoFallo], si no se puede.
         */
        fun crearConduccion(rumbo: () -> Double, soltar: () -> Boolean): GestoContinuo? {
            motivoUltimoFallo = null
            val servicio = ArosAccessibilityService.instancia
            if (servicio == null) {
                motivoUltimoFallo = "El servicio de accesibilidad no está conectado"
                return null
            }
            val joystick = BotCore.settings.joystick
            if (joystick == null) {
                motivoUltimoFallo = "El joystick no está configurado"
                return null
            }
            if (!permitidoAhora()) {
                motivoUltimoFallo =
                    if (!FrameBus.estado.value.activa) "La captura de pantalla no está activa"
                    else "Hay una parada de emergencia activa"
                return null
            }
            val (ancho, alto) = PantallaReal.tamano(BotCore.appContext)
            if (!FrameGeometry.relacionCompatible(joystick.refAncho, joystick.refAlto, ancho, alto)) {
                motivoUltimoFallo = "El joystick no corresponde a la pantalla actual (vuelve a configurarlo)"
                return null
            }
            val p = GeometriaJoystick.puntos(joystick.rect, ancho, alto, Direccion.D)
            val radio = p.destinoX - p.centroX
            val mia = generacion.get()
            return GestoContinuo(
                servicio, p.centroX, p.centroY, radio, rumbo
            ) { soltar() || !permitidoAhora() || generacion.get() != mia }
        }
    }

    private fun permitido(): Boolean =
        FrameBus.estado.value.activa &&
            BotCore.stateMachine.state.value != BotState.PARADA_EMERGENCIA
}
