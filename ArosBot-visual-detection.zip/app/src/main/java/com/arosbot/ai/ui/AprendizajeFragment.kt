package com.arosbot.ai.ui

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.arosbot.ai.R
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.Confianza
import com.arosbot.ai.core.CopiaDeAprendizaje
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.FormatoDeCopia
import com.arosbot.ai.core.Ruta
import com.arosbot.ai.databinding.FragmentListaBinding
import com.arosbot.ai.databinding.ItemTarjetaBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Aprendizaje: lo que el bot ha aprendido de sus intentos reales (fiabilidad y duración de cada
 * ruta, velocidad del movimiento), con exportación, importación y restablecimiento. El motor es
 * estadístico y local; aquí solo se muestra y se gestiona.
 */
class AprendizajeFragment : Fragment() {

    private var _binding: FragmentListaBinding? = null
    private val b get() = _binding!!

    private val exportador =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
            if (uri != null) exportar(uri)
        }

    private val importador =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) leerCopia(uri)
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentListaBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        b.tvDescripcion.setText(R.string.desc_aprendizaje)
        b.tvVacio.setText(R.string.aprendizaje_sin_rutas)
        b.btnPrimario.setText(R.string.btn_exportar_aprendizaje)
        b.btnPrimario.setOnClickListener { exportador.launch("arosbot-aprendizaje.txt") }
        b.btnSecundario.setText(R.string.btn_restablecer_aprendizaje)
        b.btnSecundario.setOnClickListener { restablecer() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { BotCore.store.rutas.collect { dibujar() } }
                launch { BotCore.store.calibraciones.collect { dibujar() } }
                launch { BotCore.store.intentosTotales.collect { dibujar() } }
            }
        }
    }

    private fun dibujar() {
        val binding = _binding ?: return
        val contexto = context ?: return
        val rutas = BotCore.store.rutas.value
        val calibraciones = BotCore.store.calibraciones.value

        val velocidades = listOf(Direccion.W, Direccion.S, Direccion.A, Direccion.D)
            .joinToString("\n") { d ->
                val c = calibraciones[d]
                if (c == null || c.muestras == 0) {
                    getString(R.string.calibracion_sin, d.tecla.toString())
                } else {
                    getString(
                        R.string.calibracion_linea,
                        d.tecla.toString(),
                        c.rapidez.roundToInt(),
                        c.muestras
                    )
                }
            }
        binding.tvFotograma.text = getString(
            R.string.aprendizaje_resumen,
            rutas.size,
            BotCore.store.lugares.value.size,
            BotCore.store.intentosTotales.value
        ) + "\n\n" + getString(R.string.aprendizaje_calibracion_titulo) + "\n" + velocidades

        binding.tvVacio.visibility = if (rutas.isEmpty()) View.VISIBLE else View.GONE
        binding.lista.removeAllViews()
        for (ruta in rutas) binding.lista.addView(tarjeta(contexto, ruta, binding.lista))

        val importar = Vistas.botonAccion(contexto, getString(R.string.btn_importar_aprendizaje)) {
            Dialogos.confirmar(
                contexto,
                getString(R.string.confirmar_titulo),
                getString(R.string.confirmar_importar_aprendizaje)
            ) { importador.launch(arrayOf("*/*")) }
        }
        binding.lista.addView(importar)
    }

    private fun tarjeta(contexto: android.content.Context, ruta: Ruta, padre: ViewGroup): View {
        val t = ItemTarjetaBinding.inflate(LayoutInflater.from(contexto), padre, false)
        t.tvTitulo.text = ruta.nombre
        val etiqueta = getString(
            when (ruta.confianza) {
                Confianza.CONFIRMADO -> R.string.confianza_confirmada
                Confianza.ESTIMACION -> R.string.confianza_estimacion
                Confianza.INCIERTO -> R.string.confianza_incierta
            }
        )
        val lineas = ArrayList<String>()
        lineas.add(
            getString(
                R.string.ruta_detalle,
                BotCore.store.lugares.value.firstOrNull { it.id == ruta.origenId }?.nombre ?: "?",
                BotCore.store.lugares.value.firstOrNull { it.id == ruta.destinoId }?.nombre ?: "?",
                ruta.puntos.size,
                ruta.longitudPx.roundToInt(),
                (ruta.duracionEnsenadaMs / 1000L).toInt(),
                ruta.intentos,
                ruta.exitos,
                (ruta.fiabilidad * 100.0).roundToInt(),
                etiqueta
            )
        )
        lineas.add(
            if (ruta.duracionMediaMs > 0.0) {
                getString(R.string.aprendizaje_duracion_media, (ruta.duracionMediaMs / 1000.0).roundToInt())
            } else {
                getString(R.string.aprendizaje_sin_duracion, (ruta.duracionEnsenadaMs / 1000L).toInt())
            }
        )
        val ultimos = BotCore.store.intentosDe(ruta.id, 5)
        if (ultimos.isEmpty()) {
            lineas.add(getString(R.string.aprendizaje_sin_intentos))
        } else {
            lineas.add(getString(R.string.aprendizaje_ultimos))
            val formato = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
            for (i in ultimos) {
                lineas.add(
                    getString(
                        R.string.aprendizaje_intento,
                        if (i.exito) "✓" else "✗",
                        formato.format(Date(i.tMs)),
                        (i.duracionMs / 1000L).toInt(),
                        i.pasos,
                        i.correcciones,
                        i.motivo
                    )
                )
            }
        }
        t.tvDetalle.text = lineas.joinToString("\n")
        return t.root
    }

    private fun restablecer() {
        Dialogos.confirmar(
            requireContext(),
            getString(R.string.confirmar_titulo),
            getString(R.string.confirmar_restablecer_aprendizaje)
        ) {
            BotCore.store.restablecerAprendizaje()
            BotCore.log.info("Aprendizaje", "Aprendizaje restablecido por el usuario")
            Toast.makeText(requireContext(), R.string.aprendizaje_restablecido, Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportar(uri: Uri) {
        val app = requireContext().applicationContext
        lifecycleScope.launch {
            val correcto = withContext(Dispatchers.IO) {
                try {
                    val texto = FormatoDeCopia.escribir(BotCore.store.exportarAprendizaje())
                    val salida = app.contentResolver.openOutputStream(uri) ?: return@withContext false
                    salida.use { it.write(texto.toByteArray(Charsets.UTF_8)) }
                    true
                } catch (e: Exception) {
                    BotCore.log.error("Aprendizaje", "No se pudo exportar: ${e.message}")
                    false
                }
            }
            Toast.makeText(
                app,
                if (correcto) R.string.aprendizaje_exportado else R.string.aprendizaje_error_exportar,
                Toast.LENGTH_LONG
            ).show()
            if (correcto) BotCore.log.info("Aprendizaje", "Aprendizaje exportado")
        }
    }

    private fun leerCopia(uri: Uri) {
        val app = requireContext().applicationContext
        lifecycleScope.launch {
            val texto = withContext(Dispatchers.IO) {
                try {
                    app.contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) }
                } catch (e: Exception) {
                    null
                }
            }
            if (texto == null) {
                Toast.makeText(app, R.string.aprendizaje_error_importar, Toast.LENGTH_LONG).show()
                return@launch
            }
            val copia: CopiaDeAprendizaje? = FormatoDeCopia.leer(texto)
            if (copia == null) {
                Toast.makeText(app, R.string.aprendizaje_archivo_invalido, Toast.LENGTH_LONG).show()
                return@launch
            }
            withContext(Dispatchers.IO) { BotCore.store.importarAprendizaje(copia) }
            BotCore.log.info("Aprendizaje", "Aprendizaje importado (${copia.rutas.size} rutas)")
            Toast.makeText(
                app,
                app.getString(R.string.aprendizaje_importado, copia.rutas.size),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
