package com.arosbot.ai.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.arosbot.ai.R
import com.arosbot.ai.capture.CapturaDeTrabajo
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.JoystickConfig
import com.arosbot.ai.core.NormRect
import com.arosbot.ai.databinding.FragmentAreaEditorBinding
import kotlin.math.min

/**
 * Editor de un rectángulo sobre el fotograma de trabajo. Sirve para dos cosas:
 *  - un área de rastreo (por defecto): al guardar queda calibrada con el tamaño del fotograma;
 *  - el joystick virtual del juego (con [ID_JOYSTICK]): el centro del rectángulo es el punto donde
 *    el bot pulsa y su lado más corto marca hasta dónde arrastra.
 */
class AreaEditorFragment : Fragment() {

    private var _binding: FragmentAreaEditorBinding? = null
    private val b get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAreaEditorBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val id = requireArguments().getLong(ARG_ID, -1L)
        val fotograma = CapturaDeTrabajo.fotograma.value
        if (fotograma == null) {
            Toast.makeText(requireContext(), R.string.captura_sin_fotograma, Toast.LENGTH_LONG).show()
            parentFragmentManager.popBackStack()
            return
        }

        b.editor.establecerImagen(fotograma)
        b.btnCancelar.setOnClickListener { parentFragmentManager.popBackStack() }

        if (id == ID_JOYSTICK) {
            prepararJoystick(fotograma.width, fotograma.height)
            return
        }

        val existente = if (id >= 0) BotCore.store.areas.value.firstOrNull { it.id == id } else null
        val nombrePorDefecto = getString(R.string.area_defecto, BotCore.store.areas.value.size + 1)
        if (existente != null) {
            b.editor.rect = existente.rect
            b.etNombre.setText(existente.nombre)
        } else {
            b.etNombre.setText(nombrePorDefecto)
        }

        b.btnGuardar.setOnClickListener {
            val nombre = b.etNombre.text?.toString()?.trim().orEmpty().ifEmpty { nombrePorDefecto }
            if (existente != null) {
                BotCore.store.actualizarRectanguloDeArea(
                    existente.id, nombre, b.editor.rect, fotograma.width, fotograma.height
                )
            } else {
                BotCore.store.insertarArea(
                    nombre, b.editor.rect, fotograma.width, fotograma.height, emptyList()
                )
            }
            BotCore.log.info("Áreas", "Área «$nombre» guardada (${fotograma.width}x${fotograma.height})")
            Toast.makeText(requireContext(), R.string.area_guardada, Toast.LENGTH_SHORT).show()
            parentFragmentManager.popBackStack()
        }
    }

    private fun prepararJoystick(ancho: Int, alto: Int) {
        b.tilNombre.visibility = View.GONE
        b.tvAyuda.setText(R.string.joystick_editor_ayuda)

        val actual = BotCore.settings.joystick
        b.editor.rect = actual?.rect ?: rectanguloInicial(ancho, alto)

        b.btnAutoajustar.visibility = View.VISIBLE
        b.btnAutoajustar.setOnClickListener {
            val fotogramaActual = CapturaDeTrabajo.fotograma.value
            val r = if (fotogramaActual == null) null else
                com.arosbot.ai.vision.LocalizadorJoystick.refinar(fotogramaActual, b.editor.rect)
            if (r == null) {
                Toast.makeText(requireContext(), R.string.joystick_autoajuste_fallo, Toast.LENGTH_LONG).show()
                BotCore.log.aviso("Joystick", "Autoajuste: no se encontró un círculo creíble en la zona marcada")
            } else {
                b.editor.rect = r.rect
                Toast.makeText(
                    requireContext(),
                    getString(R.string.joystick_autoajuste_ok, r.radioPx.toInt(), r.desplazamientoPx.toInt()),
                    Toast.LENGTH_LONG
                ).show()
                BotCore.log.info("Joystick", "Autoajuste: radio ${r.radioPx.toInt()} px, centro movido ${r.desplazamientoPx.toInt()} px")
            }
        }

        b.btnGuardar.setOnClickListener {
            BotCore.settings.joystick = JoystickConfig(b.editor.rect, ancho, alto)
            BotCore.log.info("Joystick", "Joystick configurado (${ancho}x$alto)")
            Toast.makeText(requireContext(), R.string.joystick_guardado, Toast.LENGTH_SHORT).show()
            parentFragmentManager.popBackStack()
        }
    }

    /** Un cuadrado (en píxeles) en la zona inferior izquierda, donde suele estar el joystick. */
    private fun rectanguloInicial(ancho: Int, alto: Int): NormRect {
        val lado = 0.25f * min(ancho, alto)
        val w = lado / ancho
        val h = lado / alto
        val x = (0.18f - w / 2f).coerceIn(0f, 1f - w)
        val y = (0.70f - h / 2f).coerceIn(0f, 1f - h)
        return NormRect(x, y, w, h)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_ID = "area_id"

        /** Identificador especial: el editor configura el joystick en vez de un área. */
        const val ID_JOYSTICK = -2L

        fun nuevo(areaId: Long): AreaEditorFragment {
            val fragmento = AreaEditorFragment()
            fragmento.arguments = Bundle().apply { putLong(ARG_ID, areaId) }
            return fragmento
        }
    }
}
