package com.arosbot.ai.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.arosbot.ai.core.FitTransform
import com.arosbot.ai.core.FrameGeometry
import com.arosbot.ai.core.NormRect
import kotlin.math.hypot

/**
 * Muestra un fotograma real del juego y un rectángulo ajustable encima. El rectángulo se guarda
 * normalizado (0 a 1) respecto al fotograma, así que la conversión entre la vista y la imagen
 * original es siempre exacta, sea cual sea el tamaño de la pantalla.
 */
class AreaEditorView @JvmOverloads constructor(
    contexto: Context,
    atributos: AttributeSet? = null
) : View(contexto, atributos) {

    private enum class Modo { NINGUNO, MOVER, SUPERIOR_IZQ, SUPERIOR_DER, INFERIOR_IZQ, INFERIOR_DER }

    private var imagen: Bitmap? = null
    private var ajuste = FitTransform(1f, 0f, 0f)
    private var modo = Modo.NINGUNO
    private var ultimoX = 0f
    private var ultimoY = 0f

    var rect: NormRect = NormRect(0.25f, 0.25f, 0.5f, 0.5f)
        set(valor) {
            field = valor
            invalidate()
        }

    private val densidad = contexto.resources.displayMetrics.density
    private val radioToque = 28f * densidad

    private val relleno = Paint().apply {
        color = Color.argb(60, 0, 170, 255)
        style = Paint.Style.FILL
    }
    private val borde = Paint().apply {
        color = Color.rgb(0, 170, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f * densidad
    }
    private val asa = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    private val asaBorde = Paint().apply {
        color = Color.rgb(0, 170, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f * densidad
        isAntiAlias = true
    }

    fun establecerImagen(bitmap: Bitmap) {
        imagen = bitmap
        invalidate()
    }

    private fun recalcular(b: Bitmap) {
        ajuste = FrameGeometry.ajustar(
            width.toFloat(), height.toFloat(), b.width.toFloat(), b.height.toFloat()
        )
    }

    private fun cajaEnVista(b: Bitmap): RectF = RectF(
        ajuste.imagenAVistaX(rect.x * b.width),
        ajuste.imagenAVistaY(rect.y * b.height),
        ajuste.imagenAVistaX((rect.x + rect.w) * b.width),
        ajuste.imagenAVistaY((rect.y + rect.h) * b.height)
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = imagen ?: return
        recalcular(b)

        canvas.save()
        canvas.translate(ajuste.dx, ajuste.dy)
        canvas.scale(ajuste.escala, ajuste.escala)
        canvas.drawBitmap(b, 0f, 0f, null)
        canvas.restore()

        val r = cajaEnVista(b)
        canvas.drawRect(r, relleno)
        canvas.drawRect(r, borde)
        val esquinas = listOf(
            Pair(r.left, r.top), Pair(r.right, r.top),
            Pair(r.left, r.bottom), Pair(r.right, r.bottom)
        )
        for ((x, y) in esquinas) {
            canvas.drawCircle(x, y, 10f * densidad, asa)
            canvas.drawCircle(x, y, 10f * densidad, asaBorde)
        }
    }

    private fun detectar(b: Bitmap, x: Float, y: Float): Modo {
        val r = cajaEnVista(b)
        fun cerca(px: Float, py: Float): Boolean = hypot(x - px, y - py) <= radioToque
        return when {
            cerca(r.left, r.top) -> Modo.SUPERIOR_IZQ
            cerca(r.right, r.top) -> Modo.SUPERIOR_DER
            cerca(r.left, r.bottom) -> Modo.INFERIOR_IZQ
            cerca(r.right, r.bottom) -> Modo.INFERIOR_DER
            r.contains(x, y) -> Modo.MOVER
            else -> Modo.NINGUNO
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val b = imagen ?: return false
        recalcular(b)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                modo = detectar(b, e.x, e.y)
                ultimoX = e.x
                ultimoY = e.y
                if (modo != Modo.NINGUNO) parent?.requestDisallowInterceptTouchEvent(true)
                return modo != Modo.NINGUNO
            }
            MotionEvent.ACTION_MOVE -> {
                if (modo == Modo.NINGUNO) return false
                val dx = (e.x - ultimoX) / ajuste.escala / b.width
                val dy = (e.y - ultimoY) / ajuste.escala / b.height
                ultimoX = e.x
                ultimoY = e.y
                aplicar(dx, dy)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                modo = Modo.NINGUNO
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    /** Mueve o redimensiona el rectángulo en coordenadas normalizadas, sin salirse de la imagen. */
    private fun aplicar(dx: Float, dy: Float) {
        var izq = rect.x
        var arr = rect.y
        var der = rect.x + rect.w
        var aba = rect.y + rect.h
        when (modo) {
            Modo.MOVER -> {
                val ancho = der - izq
                val alto = aba - arr
                izq = (izq + dx).coerceIn(0f, maxOf(0f, 1f - ancho))
                arr = (arr + dy).coerceIn(0f, maxOf(0f, 1f - alto))
                der = izq + ancho
                aba = arr + alto
            }
            Modo.SUPERIOR_IZQ -> {
                izq = (izq + dx).coerceIn(0f, maxOf(0f, der - MINIMO))
                arr = (arr + dy).coerceIn(0f, maxOf(0f, aba - MINIMO))
            }
            Modo.SUPERIOR_DER -> {
                der = (der + dx).coerceIn(minOf(1f, izq + MINIMO), 1f)
                arr = (arr + dy).coerceIn(0f, maxOf(0f, aba - MINIMO))
            }
            Modo.INFERIOR_IZQ -> {
                izq = (izq + dx).coerceIn(0f, maxOf(0f, der - MINIMO))
                aba = (aba + dy).coerceIn(minOf(1f, arr + MINIMO), 1f)
            }
            Modo.INFERIOR_DER -> {
                der = (der + dx).coerceIn(minOf(1f, izq + MINIMO), 1f)
                aba = (aba + dy).coerceIn(minOf(1f, arr + MINIMO), 1f)
            }
            Modo.NINGUNO -> Unit
        }
        rect = NormRect(izq, arr, der - izq, aba - arr)
    }

    private companion object {
        const val MINIMO = 0.03f
    }
}
