package com.arosbot.ai.ui

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.arosbot.ai.R
import com.arosbot.ai.capture.CapturaDeTrabajo
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.core.Area
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.Box
import com.arosbot.ai.core.FrameGeometry
import com.arosbot.ai.databinding.FragmentListaBinding
import com.arosbot.ai.databinding.ItemTarjetaBinding
import com.arosbot.ai.vision.Deteccion
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Selector de áreas de rastreo (módulo 4): crear, editar, activar, asociar materiales, probar y borrar. */
class AreasFragment : Fragment() {

    private var _binding: FragmentListaBinding? = null
    private val b get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentListaBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        b.tvDescripcion.setText(R.string.desc_areas)
        b.tvVacio.setText(R.string.areas_vacia)
        b.btnPrimario.setText(R.string.btn_seleccionar_area)
        b.btnPrimario.setOnClickListener { crearArea() }
        b.btnSecundario.setText(R.string.btn_probar_deteccion)
        b.btnSecundario.setOnClickListener { probarActivas() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { BotCore.store.areas.collect { dibujar() } }
                launch { BotCore.store.materiales.collect { dibujar() } }
                launch { CapturaDeTrabajo.fotograma.collect { dibujar() } }
            }
        }
    }

    /** Tamaño de pantalla de referencia para comprobar si un área sigue siendo válida (0 si no hay ninguno). */
    private fun tamanoActual(): Pair<Int, Int> {
        val captura = FrameBus.estado.value
        if (captura.activa && captura.ancho > 0) return Pair(captura.ancho, captura.alto)
        val fotograma = CapturaDeTrabajo.fotograma.value
        if (fotograma != null) return Pair(fotograma.width, fotograma.height)
        return Pair(0, 0)
    }

    private fun esCompatible(area: Area, ancho: Int, alto: Int): Boolean =
        ancho == 0 || FrameGeometry.relacionCompatible(area.refAncho, area.refAlto, ancho, alto)

    private fun dibujar() {
        val binding = _binding ?: return
        val contexto = context ?: return
        val lista = BotCore.store.areas.value
        val fotograma = CapturaDeTrabajo.fotograma.value

        binding.tvFotograma.text =
            if (fotograma == null) {
                getString(R.string.fotograma_ninguno)
            } else {
                getString(R.string.fotograma_listo, fotograma.width, fotograma.height)
            }
        binding.tvVacio.visibility = if (lista.isEmpty()) View.VISIBLE else View.GONE
        binding.lista.removeAllViews()
        val (ancho, alto) = tamanoActual()
        for (area in lista) {
            binding.lista.addView(tarjeta(contexto, area, binding.lista, ancho, alto))
        }
    }

    private fun tarjeta(
        contexto: Context,
        area: Area,
        padre: ViewGroup,
        anchoActual: Int,
        altoActual: Int
    ): View {
        val t = ItemTarjetaBinding.inflate(LayoutInflater.from(contexto), padre, false)
        t.tvTitulo.text = area.nombre

        val materiales =
            if (area.materiales.isEmpty()) {
                getString(R.string.area_todos_materiales)
            } else {
                getString(R.string.area_n_materiales, area.materiales.size)
            }
        var detalle = getString(
            R.string.area_detalle,
            (area.rect.x * 100f).roundToInt(),
            (area.rect.y * 100f).roundToInt(),
            (area.rect.w * 100f).roundToInt(),
            (area.rect.h * 100f).roundToInt(),
            area.refAncho,
            area.refAlto,
            materiales
        )
        if (!esCompatible(area, anchoActual, altoActual)) {
            detalle += "\n" + getString(R.string.area_recalibrar)
        }
        t.tvDetalle.text = detalle

        t.switchActiva.visibility = View.VISIBLE
        t.switchActiva.isChecked = area.activa
        t.switchActiva.setOnCheckedChangeListener { _, activa ->
            BotCore.store.activarArea(area.id, activa)
        }

        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_editar_rectangulo)) {
                editarRectangulo(area)
            }
        )
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_materiales)) {
                asignarMateriales(area)
            }
        )
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_probar)) { probarArea(area) }
        )
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_eliminar)) { eliminar(area) }
        )
        return t.root
    }

    private fun abrirEditor(areaId: Long) {
        if (PruebasDeteccion.fotograma(requireContext()) == null) return
        (requireActivity() as MainActivity).abrirEditorDeArea(areaId)
    }

    private fun crearArea() = abrirEditor(-1L)

    private fun editarRectangulo(area: Area) = abrirEditor(area.id)

    private fun asignarMateriales(area: Area) {
        val materiales = BotCore.store.materiales.value
        if (materiales.isEmpty()) {
            Toast.makeText(requireContext(), R.string.sin_materiales, Toast.LENGTH_LONG).show()
            return
        }
        val nombres = materiales.map { it.nombre }.toTypedArray()
        val marcados = BooleanArray(materiales.size) { materiales[it].id in area.materiales }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.asignar_materiales_titulo, area.nombre))
            .setMultiChoiceItems(nombres, marcados) { _, indice, activo ->
                marcados[indice] = activo
            }
            .setPositiveButton(R.string.guardar) { _, _ ->
                val elegidos = materiales.filterIndexed { i, _ -> marcados[i] }.map { it.id }
                BotCore.store.asignarMaterialesAArea(area.id, elegidos)
            }
            .setNegativeButton(R.string.cancelar, null)
            .show()
    }

    private fun eliminar(area: Area) {
        Dialogos.confirmar(
            requireContext(),
            getString(R.string.confirmar_titulo),
            getString(R.string.confirmar_eliminar_area, area.nombre)
        ) {
            BotCore.store.eliminarArea(area.id)
            BotCore.log.info("Áreas", "Área «${area.nombre}» eliminada")
        }
    }

    /** Prueba una sola área sobre el fotograma de trabajo. */
    private fun probarArea(area: Area) {
        val materiales = BotCore.store.materiales.value
        if (materiales.isEmpty()) {
            Toast.makeText(requireContext(), R.string.sin_materiales, Toast.LENGTH_LONG).show()
            return
        }
        val fotograma = PruebasDeteccion.fotograma(requireContext()) ?: return
        val directorio = BotCore.store.directorioMateriales
        lifecycleScope.launch {
            val resultado = withContext(Dispatchers.Default) {
                Deteccion.enArea(fotograma, area, materiales, directorio)
            }
            if (!isAdded) return@launch
            // La prueba se considera superada si el área corresponde a la pantalla y OpenCV trabajó.
            if (resultado.avisos.isEmpty()) {
                BotCore.marcarVerificadoPersistente(4)
            }
            BotCore.log.info(
                "Áreas",
                "Prueba del área «${area.nombre}»: ${resultado.detecciones.size} objeto(s) en ${resultado.duracionMs} ms"
            )
            val caja = area.rect.aBox(fotograma.width, fotograma.height)
            PruebasDeteccion.mostrar(
                requireContext(), fotograma, resultado, listOf(Pair(area.nombre, caja))
            )
        }
    }

    /** Prueba todas las áreas activas a la vez, como lo haría la detección en vivo. */
    private fun probarActivas() {
        val areas = BotCore.store.areas.value
        val materiales = BotCore.store.materiales.value
        if (areas.isEmpty()) {
            Toast.makeText(requireContext(), R.string.sin_areas, Toast.LENGTH_LONG).show()
            return
        }
        if (materiales.isEmpty()) {
            Toast.makeText(requireContext(), R.string.sin_materiales, Toast.LENGTH_LONG).show()
            return
        }
        val fotograma = PruebasDeteccion.fotograma(requireContext()) ?: return
        val directorio = BotCore.store.directorioMateriales
        lifecycleScope.launch {
            val resultado = withContext(Dispatchers.Default) {
                Deteccion.enAreasActivas(fotograma, areas, materiales, directorio)
            }
            if (!isAdded) return@launch
            val cajas = ArrayList<Pair<String, Box>>()
            for (area in areas.filter { it.activa }) {
                if (esCompatible(area, fotograma.width, fotograma.height)) {
                    cajas.add(Pair(area.nombre, area.rect.aBox(fotograma.width, fotograma.height)))
                }
            }
            BotCore.log.info(
                "Áreas",
                "Prueba de las áreas activas: ${resultado.detecciones.size} objeto(s) en ${resultado.duracionMs} ms"
            )
            PruebasDeteccion.mostrar(requireContext(), fotograma, resultado, cajas)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
