package com.arosbot.ai.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.arosbot.ai.R
import com.arosbot.ai.automation.PruebasAutomatizacion
import com.arosbot.ai.capture.PantallaReal
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.Direccion
import com.arosbot.ai.core.FrameGeometry
import com.arosbot.ai.databinding.FragmentAutomatizacionBinding
import com.arosbot.ai.input.ArosAccessibilityService
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

/**
 * Automatización: estado de la accesibilidad, configuración del joystick, pruebas reales de
 * movimiento, personaje e inicio de sesión, y calibración obtenida. No contiene lógica de
 * navegación: solo lanza las pruebas y muestra su resultado.
 */
class AutomatizacionFragment : Fragment() {

    private var _binding: FragmentAutomatizacionBinding? = null
    private val b get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAutomatizacionBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val actividad = requireActivity() as MainActivity

        b.tvDescripcion.setText(R.string.desc_automatizacion)
        b.btnAccesibilidad.setOnClickListener { actividad.solicitarAccesibilidad() }
        b.btnAjustesApp.setOnClickListener { actividad.abrirAjustesDeLaApp() }
        b.btnJoystick.setOnClickListener {
            if (PruebasDeteccion.fotograma(requireContext()) != null) actividad.abrirEditorDeJoystick()
        }
        b.btnProbarMovimiento.setOnClickListener { PruebasAutomatizacion.probarMovimiento() }
        b.btnProbarDiagonales.setOnClickListener { PruebasAutomatizacion.probarDiagonales() }
        b.btnAjustarJoystick.setOnClickListener { PruebasAutomatizacion.ajustarJoystick() }
        b.btnProbarConduccion.setOnClickListener { PruebasAutomatizacion.probarConduccion() }
        b.btnProbarPersonaje.setOnClickListener { PruebasAutomatizacion.probarPersonaje() }
        b.btnProbarLogin.setOnClickListener { PruebasAutomatizacion.probarInicioSesion() }
        b.btnCancelarPrueba.setOnClickListener { PruebasAutomatizacion.cancelar() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { ArosAccessibilityService.conectado.collect { dibujar() } }
                launch { PruebasAutomatizacion.estado.collect { dibujar() } }
                launch { BotCore.store.calibraciones.collect { dibujar() } }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Al volver de los ajustes de Android puede haber cambiado algo.
        dibujar()
    }

    private fun dibujar() {
        val binding = _binding ?: return
        val contexto = context ?: return

        val conectado = ArosAccessibilityService.conectado.value
        binding.tvAccesibilidad.setText(
            if (conectado) R.string.accesibilidad_activa else R.string.accesibilidad_inactiva
        )

        val joystick = BotCore.settings.joystick
        binding.tvJoystick.text =
            if (joystick == null) {
                getString(R.string.joystick_sin_configurar)
            } else {
                val (ancho, alto) = PantallaReal.tamano(contexto)
                var texto = getString(R.string.joystick_configurado, joystick.refAncho, joystick.refAlto)
                if (!FrameGeometry.relacionCompatible(joystick.refAncho, joystick.refAlto, ancho, alto)) {
                    texto += "\n" + getString(R.string.joystick_no_corresponde)
                }
                texto
            }

        val prueba = PruebasAutomatizacion.estado.value
        binding.tvPrueba.text =
            if (prueba.texto.isBlank()) getString(R.string.prueba_automatizacion_ninguna) else prueba.texto
        binding.btnProbarMovimiento.isEnabled = !prueba.ejecutando
        binding.btnProbarDiagonales.isEnabled = !prueba.ejecutando
        binding.btnAjustarJoystick.isEnabled = !prueba.ejecutando
        binding.btnProbarConduccion.isEnabled = !prueba.ejecutando
        binding.btnProbarPersonaje.isEnabled = !prueba.ejecutando
        binding.btnProbarLogin.isEnabled = !prueba.ejecutando
        binding.btnCancelarPrueba.isEnabled = prueba.ejecutando

        val calibraciones = BotCore.store.calibraciones.value
        binding.tvCalibracion.text = listOf(Direccion.W, Direccion.S, Direccion.A, Direccion.D)
            .joinToString("\n") { d ->
                val c = calibraciones[d]
                if (c == null || c.muestras == 0) {
                    getString(R.string.calibracion_sin, d.tecla.toString())
                } else {
                    getString(
                        R.string.calibracion_linea,
                        d.tecla.toString(),
                        c.rapidez.roundToInt(),
                        c.muestras
                    )
                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
