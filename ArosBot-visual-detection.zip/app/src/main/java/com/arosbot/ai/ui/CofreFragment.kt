package com.arosbot.ai.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.arosbot.ai.R
import com.arosbot.ai.automation.Recolector
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.FuncionVisual
import com.arosbot.ai.core.SelectorDeFunciones
import com.arosbot.ai.databinding.FragmentListaBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.Locale
import kotlinx.coroutines.launch

/**
 * Inventario y cofre (Fase 6): qué imágenes de referencia faltan, el lugar del cofre, pruebas sueltas
 * y la recolección autónoma. Solo lanza acciones y muestra estado; la lógica está en `core` y `automation`.
 */
class CofreFragment : Fragment() {

    private var _binding: FragmentListaBinding? = null
    private val b get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentListaBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val contexto = requireContext()
        b.tvDescripcion.setText(R.string.desc_cofre)
        b.btnPrimario.setText(R.string.btn_recolectar)
        b.btnPrimario.setOnClickListener {
            if (Recolector.estado.value.ejecutando) Recolector.cancelar() else Recolector.iniciar(Recolector.Modo.SESION)
        }
        b.btnSecundario.setText(R.string.btn_lugar_cofre)
        b.btnSecundario.setOnClickListener { elegirLugar() }

        b.lista.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_probar_inventario)) {
                Recolector.iniciar(Recolector.Modo.LEER_INVENTARIO)
            }
        )
        b.lista.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_probar_interaccion)) {
                Recolector.iniciar(Recolector.Modo.PROBAR_INTERACCION)
            }
        )
        b.lista.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_probar_regreso_cofre)) {
                Recolector.iniciar(Recolector.Modo.PROBAR_DEPOSITO)
            }
        )

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { Recolector.estado.collect { dibujar() } }
                launch { BotCore.store.materiales.collect { dibujar() } }
                launch { BotCore.store.spots.collect { dibujar() } }
                launch { BotCore.store.recoleccion.collect { dibujar() } }
                launch { BotCore.telemetry.collect { dibujar() } }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        dibujar()
    }

    private fun elegirLugar() {
        val lugares = BotCore.store.lugares.value
        if (lugares.isEmpty()) {
            Toast.makeText(requireContext(), R.string.cofre_sin_lugares, Toast.LENGTH_LONG).show()
            return
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.btn_lugar_cofre)
            .setItems(lugares.map { it.nombre }.toTypedArray()) { _, i ->
                BotCore.settings.lugarCofreId = lugares[i].id
                BotCore.log.info("Cofre", "Lugar del cofre: «${lugares[i].nombre}»")
                dibujar()
            }
            .setNegativeButton(R.string.cancelar, null)
            .show()
    }

    private fun dibujar() {
        val binding = _binding ?: return
        val estado = Recolector.estado.value
        val materiales = BotCore.store.materiales.value
        val lineas = ArrayList<String>()
        lineas.add(if (estado.texto.isBlank()) getString(R.string.cofre_inactivo) else estado.texto)
        lineas.add("")
        lineas.add(getString(R.string.cofre_imagenes_titulo))
        for (f in FuncionVisual.values()) {
            val n = SelectorDeFunciones.con(f, materiales).size
            lineas.add(
                (if (n > 0) "✔ " else "✘ ") + f.etiqueta + " — " +
                    if (n > 0) "$n imagen(es)" else "falta (nómbrala «${f.ejemplo}»)"
            )
        }
        val lugarCofre = BotCore.store.lugares.value.firstOrNull { it.id == BotCore.settings.lugarCofreId }
        lineas.add("")
        lineas.add(
            if (lugarCofre != null) getString(R.string.cofre_lugar, lugarCofre.nombre)
            else getString(R.string.cofre_lugar_ninguno)
        )
        lineas.add(getString(R.string.cofre_inventario, BotCore.telemetry.value.inventario))
        val stats = BotCore.store.recoleccion.value
        if (stats.isNotEmpty()) {
            lineas.add("")
            lineas.add(getString(R.string.cofre_estadisticas))
            for (s in BotCore.store.spots.value) {
                val e = stats[s.id] ?: continue
                val tasa = e.tasaDeExito?.let { String.format(Locale.US, "%.0f %%", it * 100) } ?: "–"
                lineas.add("· ${s.nombre}: ${e.recogidos} recogidos, ${e.fallos} fallos ($tasa)")
            }
        }
        binding.tvFotograma.text = lineas.joinToString("\n")
        binding.btnPrimario.setText(if (estado.ejecutando) R.string.btn_cancelar_recoleccion else R.string.btn_recolectar)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
