package com.arosbot.ai.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.arosbot.ai.R
import com.arosbot.ai.automation.Recolector
import com.arosbot.ai.automation.RecolectorDeRuta
import com.arosbot.ai.capture.GrabadorDeMacro
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.MacroDeClics
import com.arosbot.ai.core.PlanificadorDeRutas
import com.arosbot.ai.core.FuncionVisual
import com.arosbot.ai.core.SelectorDeFunciones
import com.arosbot.ai.databinding.FragmentListaBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.Locale
import kotlinx.coroutines.launch

/**
 * Inventario y cofre (Fase 6): qué imágenes de referencia faltan, el lugar del cofre, pruebas sueltas
 * y la recolección autónoma. Solo lanza acciones y muestra estado; la lógica está en `core` y `automation`.
 */
class CofreFragment : Fragment() {

    private var botonPorRuta: com.google.android.material.button.MaterialButton? = null
    private var _binding: FragmentListaBinding? = null
    private val b get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentListaBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val contexto = requireContext()
        b.tvDescripcion.setText(R.string.desc_cofre)
        b.btnPrimario.setText(R.string.btn_recolectar)
        b.btnPrimario.setOnClickListener {
            if (Recolector.estado.value.ejecutando) Recolector.cancelar() else Recolector.iniciar(Recolector.Modo.SESION)
        }
        b.btnSecundario.setText(R.string.btn_lugar_cofre)
        b.btnSecundario.setOnClickListener { elegirLugar() }

        b.lista.addView(
            Vistas.botonAccion(contexto, "Elegir ruta de recolección (cofre → zona)") { elegirRutaDeRecoleccion() }
        )
        var botonEspera: com.google.android.material.button.MaterialButton? = null
        botonEspera = Vistas.botonAccion(
            contexto, "Espera antes de volver a pulsar «Interactuar» (ahora ${BotCore.settings.esperaSinMensajeS} s)"
        ) {
            val opciones = intArrayOf(15, 30, 60, 120, 300, 600)
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Segundos sin ver «recolectando» antes de repetir la pulsación")
                .setItems(opciones.map { "$it s" }.toTypedArray()) { _, i ->
                    BotCore.settings.esperaSinMensajeS = opciones[i]
                    botonEspera?.text = "Espera antes de volver a pulsar «Interactuar» (ahora ${opciones[i]} s)"
                }
                .show()
        }
        b.lista.addView(botonEspera)
        val porRuta = Vistas.botonAccion(contexto, "Recolectar por ruta (ida, vuelta en reversa y cofre)") {
            if (RecolectorDeRuta.estado.value.ejecutando) {
                RecolectorDeRuta.cancelar()
            } else {
                val falta = RecolectorDeRuta.problema()
                if (falta != null) Toast.makeText(requireContext(), falta, Toast.LENGTH_LONG).show()
                else RecolectorDeRuta.iniciar()
            }
        }
        botonPorRuta = porRuta
        b.lista.addView(porRuta)
        b.lista.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_grabar_macro)) {
                GrabadorDeMacro.iniciar()
            }
        )
        b.lista.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_probar_inventario)) {
                Recolector.iniciar(Recolector.Modo.LEER_INVENTARIO)
            }
        )
        b.lista.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_probar_interaccion)) {
                Recolector.iniciar(Recolector.Modo.PROBAR_INTERACCION)
            }
        )
        b.lista.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_probar_regreso_cofre)) {
                Recolector.iniciar(Recolector.Modo.PROBAR_DEPOSITO)
            }
        )

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { Recolector.estado.collect { dibujar() } }
                launch { RecolectorDeRuta.estado.collect { dibujar() } }
                launch { BotCore.store.materiales.collect { dibujar() } }
                launch { BotCore.store.spots.collect { dibujar() } }
                launch { BotCore.store.recoleccion.collect { dibujar() } }
                launch { BotCore.telemetry.collect { dibujar() } }
                launch { GrabadorDeMacro.estado.collect { dibujar() } }
                launch { BotCore.store.rutas.collect { dibujar() } }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        dibujar()
    }

    private fun elegirLugar() {
        val lugares = BotCore.store.lugares.value
        if (lugares.isEmpty()) {
            Toast.makeText(requireContext(), R.string.cofre_sin_lugares, Toast.LENGTH_LONG).show()
            return
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.btn_lugar_cofre)
            .setItems(lugares.map { it.nombre }.toTypedArray()) { _, i ->
                BotCore.settings.lugarCofreId = lugares[i].id
                BotCore.log.info("Cofre", "Lugar del cofre: «${lugares[i].nombre}»")
                dibujar()
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle(R.string.macro_pregunta_titulo)
                    .setMessage(R.string.macro_pregunta)
                    .setPositiveButton(R.string.macro_grabar_ahora) { _, _ -> GrabadorDeMacro.iniciar() }
                    .setNegativeButton(R.string.macro_luego, null)
                    .show()
            }
            .setNegativeButton(R.string.cancelar, null)
            .show()
    }

    private fun elegirRutaDeRecoleccion() {
        val rutas = BotCore.store.rutas.value
        if (rutas.isEmpty()) {
            Toast.makeText(requireContext(), "Primero enseña una ruta del cofre a la zona de materiales.", Toast.LENGTH_LONG).show()
            return
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Ruta de recolección")
            .setItems(rutas.map { it.nombre }.toTypedArray()) { _, i ->
                BotCore.settings.rutaRecoleccionId = rutas[i].id
                BotCore.log.info("Cofre", "Ruta de recolección: «${rutas[i].nombre}»")
                dibujar()
            }
            .setNegativeButton(R.string.cancelar, null)
            .show()
    }

    private fun dibujar() {
        val binding = _binding ?: return
        val estado = Recolector.estado.value
        val estadoRuta = RecolectorDeRuta.estado.value
        val materiales = BotCore.store.materiales.value
        val lineas = ArrayList<String>()
        lineas.add(if (estado.texto.isBlank()) getString(R.string.cofre_inactivo) else estado.texto)
        if (estadoRuta.texto.isNotBlank()) lineas.add("Recolección por ruta: ${estadoRuta.texto}")
        val rutaElegida = BotCore.store.rutas.value.firstOrNull { it.id == BotCore.settings.rutaRecoleccionId }
        lineas.add(
            if (rutaElegida != null) "Ruta de recolección: «${rutaElegida.nombre}» (vuelve por ella al revés)"
            else "Ruta de recolección: sin elegir"
        )
        lineas.add("")
        lineas.add(getString(R.string.cofre_imagenes_titulo))
        for (f in listOf(FuncionVisual.INVENTARIO_LLENO, FuncionVisual.INTERACTUAR, FuncionVisual.MENSAJE_SISTEMA)) {
            val n = SelectorDeFunciones.con(f, materiales).size
            lineas.add(
                (if (n > 0) "✔ " else "✘ ") + f.etiqueta + " (obligatoria) — " +
                    if (n > 0) "$n imagen(es)" else "falta (impórtala en Materiales y nómbrala «${f.ejemplo}»)"
            )
        }
        val macro = MacroDeClics.decodificar(BotCore.settings.macroCofre)
        lineas.add(
            if (MacroDeClics.problema(macro) == null) "✔ Macro del cofre (obligatorio) — ${MacroDeClics.resumen(macro!!)}"
            else "✘ Macro del cofre (obligatorio) — falta: pulsa «Grabar macro del cofre»"
        )
        val estadoMacro = GrabadorDeMacro.estado.value
        if (estadoMacro.texto.isNotBlank()) lineas.add(estadoMacro.texto)
        lineas.add(getString(R.string.cofre_personaje_opcional))
        val lugarCofre = BotCore.store.lugares.value.firstOrNull { it.id == BotCore.settings.lugarCofreId }
        lineas.add("")
        lineas.add(
            if (lugarCofre != null) getString(R.string.cofre_lugar, lugarCofre.nombre)
            else getString(R.string.cofre_lugar_ninguno)
        )
        if (lugarCofre != null) {
            val actual = BotCore.store.lugares.value.firstOrNull { it.id == BotCore.settings.lugarActualId }
            val hayRuta = actual != null && (actual.id == lugarCofre.id ||
                PlanificadorDeRutas.planificar(BotCore.store.rutas.value, actual.id, lugarCofre.id) != null)
            lineas.add(
                if (actual == null) "• Ruta al cofre: no sé dónde estás (pulsa «Estoy en…» en Spots)"
                else if (hayRuta) "✔ Ruta enseñada desde «${actual.nombre}» hasta el cofre"
                else "✘ No hay ruta enseñada desde «${actual.nombre}» hasta «${lugarCofre.nombre}» (obligatoria)"
            )
        }
        lineas.add(getString(R.string.cofre_inventario, BotCore.telemetry.value.inventario))
        val stats = BotCore.store.recoleccion.value
        if (stats.isNotEmpty()) {
            lineas.add("")
            lineas.add(getString(R.string.cofre_estadisticas))
            for (s in BotCore.store.spots.value) {
                val e = stats[s.id] ?: continue
                val tasa = e.tasaDeExito?.let { String.format(Locale.US, "%.0f %%", it * 100) } ?: "–"
                lineas.add("· ${s.nombre}: ${e.recogidos} recogidos, ${e.fallos} fallos ($tasa)")
            }
        }
        binding.tvFotograma.text = lineas.joinToString("\n")
        botonPorRuta?.text = if (estadoRuta.ejecutando) "Cancelar recolección por ruta"
        else "Recolectar por ruta (ida, vuelta en reversa y cofre)"
        binding.btnPrimario.setText(if (estado.ejecutando) R.string.btn_cancelar_recoleccion else R.string.btn_recolectar)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
