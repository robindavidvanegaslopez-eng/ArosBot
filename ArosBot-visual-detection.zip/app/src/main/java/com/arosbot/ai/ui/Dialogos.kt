package com.arosbot.ai.ui

import android.content.Context
import android.graphics.Bitmap
import android.text.InputType
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.arosbot.ai.R
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Diálogos reutilizables. Se construyen en código para no depender de más layouts. */
object Dialogos {

    private fun dp(contexto: Context, valor: Int): Int =
        (valor * contexto.resources.displayMetrics.density).toInt()

    /**
     * Muestra una imagen con un mensaje debajo. [botones] admite hasta tres acciones;
     * si está vacío se muestra solo "Cerrar".
     */
    fun mostrarImagen(
        contexto: Context,
        titulo: String,
        imagen: Bitmap,
        mensaje: String,
        botones: List<Pair<String, () -> Unit>> = emptyList()
    ) {
        val relleno = dp(contexto, 16)
        val columna = LinearLayout(contexto)
        columna.orientation = LinearLayout.VERTICAL
        columna.setPadding(relleno, relleno / 2, relleno, 0)

        val vista = ImageView(contexto)
        vista.adjustViewBounds = true
        vista.setImageBitmap(imagen)
        columna.addView(
            vista,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val texto = TextView(contexto)
        texto.text = mensaje
        texto.setPadding(0, relleno / 2, 0, 0)
        columna.addView(texto)

        val desplazable = ScrollView(contexto)
        desplazable.addView(columna)

        val accionCerrar: () -> Unit = {}
        val acciones: List<Pair<String, () -> Unit>> =
            if (botones.isEmpty()) {
                listOf(Pair(contexto.getString(R.string.cerrar), accionCerrar))
            } else {
                botones
            }

        val constructor = MaterialAlertDialogBuilder(contexto)
            .setTitle(titulo)
            .setView(desplazable)
        if (acciones.isNotEmpty()) {
            constructor.setPositiveButton(acciones[0].first) { _, _ -> acciones[0].second() }
        }
        if (acciones.size > 1) {
            constructor.setNegativeButton(acciones[1].first) { _, _ -> acciones[1].second() }
        }
        if (acciones.size > 2) {
            constructor.setNeutralButton(acciones[2].first) { _, _ -> acciones[2].second() }
        }
        constructor.show()
    }

    /** Pide nombre y categoría de un material. */
    fun pedirDatosMaterial(
        contexto: Context,
        titulo: String,
        nombreInicial: String,
        categoriaInicial: String,
        alCancelar: () -> Unit = {},
        alAceptar: (nombre: String, categoria: String) -> Unit
    ) {
        val relleno = dp(contexto, 20)
        val columna = LinearLayout(contexto)
        columna.orientation = LinearLayout.VERTICAL
        columna.setPadding(relleno, relleno / 2, relleno, 0)

        val nombre = EditText(contexto)
        nombre.hint = contexto.getString(R.string.hint_nombre)
        nombre.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        nombre.setText(nombreInicial)
        columna.addView(nombre)

        val categoria = EditText(contexto)
        categoria.hint = contexto.getString(R.string.hint_categoria)
        categoria.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        categoria.setText(categoriaInicial)
        columna.addView(categoria)

        var aceptado = false
        MaterialAlertDialogBuilder(contexto)
            .setTitle(titulo)
            .setView(columna)
            .setPositiveButton(R.string.guardar) { _, _ ->
                aceptado = true
                val n = nombre.text.toString().trim().ifEmpty { nombreInicial }
                val c = categoria.text.toString().trim().ifEmpty { categoriaInicial }
                alAceptar(n, c)
            }
            .setNegativeButton(R.string.cancelar, null)
            .setOnDismissListener { if (!aceptado) alCancelar() }
            .show()
    }

    fun confirmar(
        contexto: Context,
        titulo: String,
        mensaje: String,
        alAceptar: () -> Unit
    ) {
        MaterialAlertDialogBuilder(contexto)
            .setTitle(titulo)
            .setMessage(mensaje)
            .setPositiveButton(R.string.aceptar) { _, _ -> alAceptar() }
            .setNegativeButton(R.string.cancelar, null)
            .show()
    }
}
