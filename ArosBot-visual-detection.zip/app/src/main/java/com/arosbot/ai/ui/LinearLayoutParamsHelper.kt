package com.arosbot.ai.ui

import android.view.View
import android.widget.LinearLayout

/** Pequeña utilidad para crear parámetros de layout con margen superior en dp. */
internal object LinearLayoutParamsHelper {
    fun conMargenSuperior(vista: View, dp: Int): LinearLayout.LayoutParams {
        val densidad = vista.resources.displayMetrics.density
        val parametros = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        parametros.topMargin = (dp * densidad).toInt()
        return parametros
    }
}
