package com.arosbot.ai.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.arosbot.ai.R
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.databinding.FragmentLogBinding
import kotlinx.coroutines.launch

/** Registro de actividad y errores (módulo 18). */
class LogFragment : Fragment() {

    private var _binding: FragmentLogBinding? = null
    private val b get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLogBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        b.btnLimpiar.setOnClickListener { BotCore.log.clear() }
        b.btnCopiar.setOnClickListener {
            val texto = BotCore.log.entries.value.joinToString("\n") { it.format() }
            val portapapeles =
                requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            portapapeles.setPrimaryClip(ClipData.newPlainText("Registro de ArosBot AI", texto))
            Toast.makeText(requireContext(), R.string.log_copiado, Toast.LENGTH_SHORT).show()
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                BotCore.log.entries.collect { entradas ->
                    val binding = _binding ?: return@collect
                    binding.tvRegistro.text =
                        if (entradas.isEmpty()) {
                            getString(R.string.log_vacio)
                        } else {
                            entradas.joinToString("\n") { it.format() }
                        }
                    binding.scrollRegistro.post {
                        _binding?.scrollRegistro?.fullScroll(View.FOCUS_DOWN)
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
