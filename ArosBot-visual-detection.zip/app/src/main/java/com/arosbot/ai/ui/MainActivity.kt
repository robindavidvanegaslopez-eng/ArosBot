package com.arosbot.ai.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.arosbot.ai.R
import com.arosbot.ai.capture.CaptureService
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var seccionActual: Int = R.id.nav_panel

    private val lanzadorCaptura =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { resultado ->
            val datos = resultado.data
            if (resultado.resultCode == Activity.RESULT_OK && datos != null) {
                CaptureService.iniciar(this, resultado.resultCode, datos)
            } else {
                BotCore.log.aviso("Captura", "No se concedió el permiso de captura de pantalla")
            }
        }

    private val lanzadorNotificaciones =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            // La captura funciona aunque se rechacen las notificaciones; solo no se verá el aviso.
            lanzarCaptura()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val toggle = ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            binding.toolbar,
            R.string.abrir_menu,
            R.string.cerrar_menu
        )
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        binding.navView.setNavigationItemSelectedListener { item ->
            mostrarSeccion(item.itemId)
            binding.drawerLayout.closeDrawers()
            true
        }

        supportFragmentManager.addOnBackStackChangedListener {
            if (supportFragmentManager.backStackEntryCount == 0) {
                supportActionBar?.title = getString(tituloDe(seccionActual))
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    binding.drawerLayout.closeDrawer(GravityCompat.START)
                } else {
                    // Se cede el control al sistema (volver atrás o salir) y se reactiva después.
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })

        if (savedInstanceState == null) {
            mostrarSeccion(R.id.nav_panel)
        } else {
            seccionActual = savedInstanceState.getInt(CLAVE_SECCION, R.id.nav_panel)
            binding.navView.setCheckedItem(seccionActual)
            if (supportFragmentManager.backStackEntryCount == 0) {
                supportActionBar?.title = getString(tituloDe(seccionActual))
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(CLAVE_SECCION, seccionActual)
    }

    // ---------- Permisos y captura (los usan los fragmentos) ----------

    /** Pide el permiso oficial de captura de pantalla y, si se concede, inicia el servicio. */
    fun solicitarCaptura() {
        if (FrameBus.estado.value.activa) return
        val faltaNotificaciones = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (faltaNotificaciones) {
            lanzadorNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            lanzarCaptura()
        }
    }

    private fun lanzarCaptura() {
        val gestor = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        lanzadorCaptura.launch(gestor.createScreenCaptureIntent())
    }

    /** Abre la pantalla de Android donde se concede el permiso de superposición. */
    fun solicitarSuperposicion() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    /** Abre la pantalla de Android donde se activa el servicio de accesibilidad del bot. */
    fun solicitarAccesibilidad() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    /** Abre la ficha de la app en Ajustes (donde Android 13+ permite los «ajustes restringidos»). */
    fun abrirAjustesDeLaApp() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
    }

    // ---------- Navegación ----------

    /** Abre el editor del rectángulo del joystick virtual del juego. */
    fun abrirEditorDeJoystick() {
        supportActionBar?.title = getString(R.string.joystick_editor_titulo)
        supportFragmentManager.beginTransaction()
            .replace(R.id.contenedor, AreaEditorFragment.nuevo(AreaEditorFragment.ID_JOYSTICK))
            .addToBackStack("editor_joystick")
            .commit()
    }

    /** Abre el editor del rectángulo de un área ([areaId] < 0 para crear una nueva). */
    fun abrirEditorDeArea(areaId: Long) {
        supportActionBar?.title = getString(
            if (areaId < 0) R.string.area_editor_nueva else R.string.area_editor_editar
        )
        supportFragmentManager.beginTransaction()
            .replace(R.id.contenedor, AreaEditorFragment.nuevo(areaId))
            .addToBackStack("editor_area")
            .commit()
    }

    private fun mostrarSeccion(id: Int) {
        seccionActual = id
        binding.navView.setCheckedItem(id)
        supportActionBar?.title = getString(tituloDe(id))
        supportFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
        supportFragmentManager.beginTransaction()
            .replace(R.id.contenedor, fragmentoDe(id))
            .commit()
    }

    private fun tituloDe(id: Int): Int = when (id) {
        R.id.nav_materiales -> R.string.seccion_materiales
        R.id.nav_areas -> R.string.seccion_areas
        R.id.nav_spots -> R.string.seccion_spots
        R.id.nav_rutas -> R.string.seccion_rutas
        R.id.nav_aprendizaje -> R.string.seccion_aprendizaje
        R.id.nav_cofre -> R.string.seccion_cofre
        R.id.nav_automatizacion -> R.string.seccion_automatizacion
        R.id.nav_registro -> R.string.seccion_registro
        R.id.nav_configuracion -> R.string.seccion_configuracion
        else -> R.string.seccion_panel
    }

    private fun fragmentoDe(id: Int): Fragment = when (id) {
        R.id.nav_materiales -> MaterialsFragment()
        R.id.nav_areas -> AreasFragment()
        R.id.nav_spots -> PendingFragment.nuevo(
            5, R.string.desc_spots,
            intArrayOf(R.string.btn_anadir_spot)
        )
        R.id.nav_rutas -> PendingFragment.nuevo(
            4, R.string.desc_rutas,
            intArrayOf(R.string.btn_ensenar_ruta, R.string.btn_guardar_ruta)
        )
        R.id.nav_aprendizaje -> PendingFragment.nuevo(
            4, R.string.desc_aprendizaje,
            intArrayOf(R.string.btn_exportar_aprendizaje, R.string.btn_restablecer_aprendizaje)
        )
        R.id.nav_cofre -> PendingFragment.nuevo(
            6, R.string.desc_cofre,
            intArrayOf(R.string.btn_probar_interaccion, R.string.btn_probar_regreso_cofre)
        )
        R.id.nav_automatizacion -> AutomatizacionFragment()
        R.id.nav_registro -> LogFragment()
        R.id.nav_configuracion -> SettingsFragment()
        else -> PanelFragment()
    }

    private companion object {
        const val CLAVE_SECCION = "seccion_actual"
    }
}
