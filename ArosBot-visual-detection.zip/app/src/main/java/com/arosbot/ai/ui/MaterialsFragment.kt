package com.arosbot.ai.ui

import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.arosbot.ai.R
import com.arosbot.ai.capture.CapturaDeTrabajo
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.ImportadorImagenes
import com.arosbot.ai.core.Material
import com.arosbot.ai.databinding.FragmentListaBinding
import com.arosbot.ai.databinding.ItemTarjetaBinding
import com.arosbot.ai.vision.Deteccion
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Administrador de imágenes de referencia (módulo 3): importar, ajustar, probar y borrar materiales. */
class MaterialsFragment : Fragment() {

    private var _binding: FragmentListaBinding? = null
    private val b get() = _binding!!

    private var materialParaVariante = -1L
    private val miniaturas = HashMap<String, Bitmap>()

    private val selectorImagen =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) importar(uri, -1L)
        }

    private val selectorVariante =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null && materialParaVariante >= 0L) importar(uri, materialParaVariante)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        materialParaVariante = savedInstanceState?.getLong(CLAVE_VARIANTE, -1L) ?: -1L
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong(CLAVE_VARIANTE, materialParaVariante)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentListaBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        b.tvDescripcion.setText(R.string.desc_materiales)
        b.tvVacio.setText(R.string.materiales_vacio)
        b.btnPrimario.setText(R.string.btn_importar_material)
        b.btnPrimario.setOnClickListener { selectorImagen.launch("image/*") }
        b.btnSecundario.setText(R.string.btn_probar_deteccion)
        b.btnSecundario.setOnClickListener { probar(BotCore.store.materiales.value) }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { BotCore.store.materiales.collect { dibujar() } }
                launch { CapturaDeTrabajo.fotograma.collect { dibujar() } }
            }
        }
    }

    private fun dibujar() {
        val binding = _binding ?: return
        val contexto = context ?: return
        val lista = BotCore.store.materiales.value
        val fotograma = CapturaDeTrabajo.fotograma.value

        binding.tvFotograma.text =
            if (fotograma == null) {
                getString(R.string.fotograma_ninguno)
            } else {
                getString(R.string.fotograma_listo, fotograma.width, fotograma.height)
            }
        binding.tvVacio.visibility = if (lista.isEmpty()) View.VISIBLE else View.GONE
        binding.lista.removeAllViews()
        for (material in lista) {
            binding.lista.addView(tarjeta(contexto, material, binding.lista))
        }
    }

    private fun tarjeta(
        contexto: android.content.Context,
        m: Material,
        padre: ViewGroup
    ): View {
        val t = ItemTarjetaBinding.inflate(LayoutInflater.from(contexto), padre, false)
        t.tvTitulo.text = m.nombre

        val confianza = m.ultimaConfianza
            ?.let { "${(it * 100f).roundToInt()} %" }
            ?: getString(R.string.panel_sin_datos)
        t.tvDetalle.text = getString(
            R.string.material_detalle,
            m.categoria,
            m.ancho,
            m.alto,
            m.variantes,
            (m.umbral * 100f).roundToInt(),
            m.estado.etiqueta,
            m.detecciones,
            confianza
        )

        val imagen = miniaturas[m.archivoPrincipal]
            ?: Vistas.miniatura(File(BotCore.store.directorioMateriales, m.archivoPrincipal), 160)
                ?.also { miniaturas[m.archivoPrincipal] = it }
        if (imagen != null) {
            t.ivMiniatura.setImageBitmap(imagen)
            t.ivMiniatura.visibility = View.VISIBLE
        }

        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_probar)) { probar(listOf(m)) }
        )
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_umbral)) { ajustarUmbral(m) }
        )
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_variante)) {
                materialParaVariante = m.id
                selectorVariante.launch("image/*")
            }
        )
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_editar)) { editar(m) }
        )
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_eliminar)) { eliminar(m) }
        )
        return t.root
    }

    /** Importa una imagen de la galería. Con [variantDe] >= 0 se añade como variante de ese material. */
    private fun importar(uri: Uri, variantDe: Long) {
        val app = requireContext().applicationContext
        lifecycleScope.launch {
            val importada = withContext(Dispatchers.IO) {
                ImportadorImagenes.importar(app, uri, BotCore.store.directorioMateriales)
            }
            if (!isAdded) return@launch
            if (importada == null) {
                BotCore.log.error("Materiales", "No se pudo importar la imagen elegida")
                Toast.makeText(requireContext(), R.string.material_error_importar, Toast.LENGTH_LONG)
                    .show()
                return@launch
            }
            if (variantDe >= 0L) {
                BotCore.store.agregarVariante(variantDe, importada.archivo)
                BotCore.log.info("Materiales", "Variante añadida (${importada.ancho}x${importada.alto})")
                Toast.makeText(requireContext(), R.string.variante_agregada, Toast.LENGTH_SHORT).show()
                return@launch
            }
            val nombreInicial =
                getString(R.string.material_nombre_defecto, BotCore.store.materiales.value.size + 1)
            Dialogos.pedirDatosMaterial(
                contexto = requireContext(),
                titulo = getString(R.string.material_nuevo_titulo),
                nombreInicial = nombreInicial,
                categoriaInicial = getString(R.string.categoria_defecto),
                alCancelar = { File(BotCore.store.directorioMateriales, importada.archivo).delete() },
                alAceptar = { nombre, categoria ->
                    BotCore.store.insertarMaterial(
                        nombre, categoria, UMBRAL_INICIAL, importada.ancho, importada.alto,
                        importada.archivo
                    )
                    BotCore.log.info(
                        "Materiales",
                        "Material «$nombre» importado (${importada.ancho}x${importada.alto})"
                    )
                    Toast.makeText(requireContext(), R.string.material_importado, Toast.LENGTH_SHORT)
                        .show()
                }
            )
        }
    }

    private fun editar(m: Material) {
        Dialogos.pedirDatosMaterial(
            contexto = requireContext(),
            titulo = getString(R.string.material_editar_titulo),
            nombreInicial = m.nombre,
            categoriaInicial = m.categoria,
            alAceptar = { nombre, categoria ->
                BotCore.store.actualizarDatosMaterial(m.id, nombre, categoria, m.umbral)
            }
        )
    }

    private fun eliminar(m: Material) {
        Dialogos.confirmar(
            requireContext(),
            getString(R.string.confirmar_titulo),
            getString(R.string.confirmar_eliminar_material, m.nombre)
        ) {
            BotCore.store.eliminarMaterial(m.id)
            miniaturas.remove(m.archivoPrincipal)
            BotCore.log.info("Materiales", "Material «${m.nombre}» eliminado")
        }
    }

    private fun ajustarUmbral(m: Material) {
        val contexto = requireContext()
        val relleno = Vistas.dp(contexto, 20)
        val columna = LinearLayout(contexto)
        columna.orientation = LinearLayout.VERTICAL
        columna.setPadding(relleno, relleno / 2, relleno, 0)

        val etiqueta = TextView(contexto)
        val barra = SeekBar(contexto)
        barra.max = UMBRAL_MAXIMO - UMBRAL_MINIMO
        barra.progress = (m.umbral * 100f).roundToInt().coerceIn(UMBRAL_MINIMO, UMBRAL_MAXIMO) -
            UMBRAL_MINIMO
        etiqueta.text = getString(R.string.umbral_valor, barra.progress + UMBRAL_MINIMO)
        barra.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progreso: Int, delUsuario: Boolean) {
                etiqueta.text = getString(R.string.umbral_valor, progreso + UMBRAL_MINIMO)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        columna.addView(etiqueta)
        columna.addView(barra)

        MaterialAlertDialogBuilder(contexto)
            .setTitle(R.string.umbral_titulo)
            .setView(columna)
            .setPositiveButton(R.string.guardar) { _, _ ->
                val nuevo = (barra.progress + UMBRAL_MINIMO) / 100f
                BotCore.store.actualizarDatosMaterial(m.id, m.nombre, m.categoria, nuevo)
            }
            .setNegativeButton(R.string.cancelar, null)
            .show()
    }

    /** Prueba [materiales] sobre el fotograma de trabajo completo y anota el resultado en cada material. */
    private fun probar(materiales: List<Material>) {
        if (materiales.isEmpty()) {
            Toast.makeText(requireContext(), R.string.sin_materiales, Toast.LENGTH_LONG).show()
            return
        }
        val fotograma = PruebasDeteccion.fotograma(requireContext()) ?: return
        val directorio = BotCore.store.directorioMateriales
        lifecycleScope.launch {
            val resultado = withContext(Dispatchers.Default) {
                Deteccion.enPantallaCompleta(fotograma, materiales, directorio)
            }
            if (!isAdded) return@launch
            for (m in materiales) {
                val propias = resultado.detecciones.filter { it.materialId == m.id }
                BotCore.store.registrarResultado(m.id, propias.size, propias.maxOfOrNull { it.score })
            }
            BotCore.log.info(
                "Materiales",
                "Prueba de ${materiales.size} material(es): ${resultado.detecciones.size} objeto(s) en ${resultado.duracionMs} ms"
            )
            PruebasDeteccion.mostrar(requireContext(), fotograma, resultado, emptyList())
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private companion object {
        const val CLAVE_VARIANTE = "material_para_variante"
        const val UMBRAL_INICIAL = 0.80f
        const val UMBRAL_MINIMO = 50
        const val UMBRAL_MAXIMO = 99
    }
}
