package com.arosbot.ai.ui

import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.arosbot.ai.R
import com.arosbot.ai.capture.CaptureService
import com.arosbot.ai.capture.CapturaDeTrabajo
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.capture.LiveDetection
import com.arosbot.ai.automation.RecolectorDeRuta
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.BotState
import com.arosbot.ai.core.EstadoModulo
import com.arosbot.ai.databinding.FragmentPanelBinding
import kotlinx.coroutines.launch

/**
 * Panel principal. Solo muestra el estado y envía órdenes a la máquina de estados y a la captura;
 * no contiene lógica de navegación.
 */
class PanelFragment : Fragment() {

    private var _binding: FragmentPanelBinding? = null
    private val b get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPanelBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val maquina = BotCore.stateMachine
        val actividad = requireActivity() as MainActivity

        // ---- Bot ----
        b.btnIniciar.setOnClickListener {
            val bloqueos = BotCore.modules.bloqueos()
            if (bloqueos.isNotEmpty()) {
                BotCore.log.aviso(
                    "Panel",
                    "No se puede iniciar: faltan ${bloqueos.size} módulos por verificar"
                )
            } else {
                maquina.transition(BotState.PREPARANDO, "Inicio solicitado por el usuario")
            }
        }
        b.btnPausar.setOnClickListener {
            maquina.transition(BotState.PAUSADO, "Pausa solicitada por el usuario")
        }
        b.btnReanudar.setOnClickListener {
            maquina.transition(BotState.ACTIVO, "Reanudación solicitada por el usuario")
        }
        b.btnDetener.setOnClickListener {
            maquina.stop("Detenido por el usuario")
        }
        b.btnReproducirRecoleccion.setOnClickListener {
            if (RecolectorDeRuta.estado.value.ejecutando) {
                RecolectorDeRuta.cancelar()
            } else if (!FrameBus.estado.value.activa) {
                Toast.makeText(requireContext(), "Primero acepta la captura de pantalla y vuelve a pulsar ▶", Toast.LENGTH_LONG).show()
                actividad.solicitarCaptura()
            } else {
                val falta = RecolectorDeRuta.problema()
                if (falta != null) {
                    Toast.makeText(requireContext(), falta, Toast.LENGTH_LONG).show()
                } else {
                    RecolectorDeRuta.iniciar()
                }
            }
            dibujarRecoleccion()
        }
        b.btnCancelarTodo.setOnClickListener {
            BotCore.cancelarTodo()
            Toast.makeText(requireContext(), "Todo cancelado", Toast.LENGTH_SHORT).show()
        }
        b.btnEmergencia.setOnClickListener {
            maquina.emergencyStop()
        }

        // ---- Captura de pantalla ----
        b.btnCaptura.setOnClickListener {
            if (FrameBus.estado.value.activa) {
                CaptureService.detener(requireContext())
            } else {
                actividad.solicitarCaptura()
            }
        }
        b.btnSuperposicion.setOnClickListener { actividad.solicitarSuperposicion() }
        b.btnFotograma.setOnClickListener { CapturaDeTrabajo.capturarAhora() }
        b.btnCuenta.setOnClickListener {
            if (FrameBus.estado.value.activa) {
                CapturaDeTrabajo.iniciarCuentaAtras(SEGUNDOS_CUENTA_ATRAS)
            } else {
                Toast.makeText(requireContext(), R.string.captura_estado_inactiva, Toast.LENGTH_SHORT)
                    .show()
            }
        }
        b.switchDeteccion.setOnClickListener {
            if (b.switchDeteccion.isChecked) {
                if (!LiveDetection.iniciar()) {
                    b.switchDeteccion.isChecked = false
                    Toast.makeText(requireContext(), R.string.deteccion_no_inicia, Toast.LENGTH_LONG)
                        .show()
                }
            } else {
                LiveDetection.detener()
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { maquina.state.collect { dibujar() } }
                launch { maquina.reason.collect { dibujar() } }
                launch { BotCore.modules.modules.collect { dibujar() } }
                launch { BotCore.telemetry.collect { dibujar() } }
                launch { BotCore.log.entries.collect { dibujar() } }
                launch { FrameBus.estado.collect { dibujar() } }
                launch { CapturaDeTrabajo.fotograma.collect { dibujar() } }
                launch { CapturaDeTrabajo.cuentaAtras.collect { dibujar() } }
                launch { LiveDetection.estado.collect { dibujar() } }
                launch { RecolectorDeRuta.estado.collect { dibujarRecoleccion() } }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Al volver de los ajustes de Android puede haber cambiado el permiso de superposición.
        dibujar()
    }

    private fun dibujarRecoleccion() {
        val binding = _binding ?: return
        val estado = RecolectorDeRuta.estado.value
        binding.btnReproducirRecoleccion.setText(
            if (estado.ejecutando) R.string.btn_detener_recoleccion else R.string.btn_reproducir_recoleccion
        )
        binding.tvRecoleccion.text = when {
            estado.texto.isNotBlank() -> estado.texto
            else -> RecolectorDeRuta.problema()?.let { "Falta: $it" } ?: "Todo listo: pulsa ▶ y cambia al juego junto al cofre."
        }
    }

    private fun dibujar() {
        val binding = _binding ?: return
        dibujarRecoleccion()
        val contexto = context ?: return
        val estado = BotCore.stateMachine.state.value
        val motivo = BotCore.stateMachine.reason.value
        val telemetria = BotCore.telemetry.value
        val modulos = BotCore.modules.modules.value
        val ultima = BotCore.log.entries.value.lastOrNull()

        binding.tvEstado.text = estado.etiqueta
        binding.tvMotivo.visibility = if (motivo.isBlank()) View.GONE else View.VISIBLE
        binding.tvMotivo.text = getString(R.string.panel_motivo, motivo)

        val confianza = telemetria.confianzaLocalizacion
            ?.let { "${(it * 100).toInt()} %" }
            ?: getString(R.string.panel_sin_datos)
        binding.tvSupervision.text = listOf(
            getString(R.string.panel_objetivo, telemetria.objetivoActual),
            getString(R.string.panel_spot, telemetria.spotActivo),
            getString(R.string.panel_recursos, telemetria.recursosDetectados),
            getString(R.string.panel_confianza, confianza),
            getString(R.string.panel_inventario, telemetria.inventario),
            getString(R.string.panel_ruta, telemetria.rutaSeleccionada),
            getString(
                R.string.panel_ultima_accion,
                ultima?.format() ?: getString(R.string.panel_sin_actividad)
            )
        ).joinToString("\n")

        // ---- Captura ----
        val captura = FrameBus.estado.value
        val fotograma = CapturaDeTrabajo.fotograma.value
        val deteccion = LiveDetection.estado.value
        val cuentaAtras = CapturaDeTrabajo.cuentaAtras.value
        val permisoCapa = Settings.canDrawOverlays(contexto)

        binding.tvCaptura.text = listOf(
            if (captura.activa) {
                getString(
                    R.string.captura_estado_activa, captura.ancho, captura.alto, captura.fotogramas
                )
            } else {
                getString(R.string.captura_estado_inactiva)
            },
            getString(if (permisoCapa) R.string.capa_permitida else R.string.capa_sin_permiso),
            if (fotograma == null) {
                getString(R.string.fotograma_ninguno)
            } else {
                getString(R.string.fotograma_listo, fotograma.width, fotograma.height)
            },
            if (deteccion.activa) {
                getString(
                    R.string.deteccion_activa, deteccion.detecciones.size, deteccion.duracionMs.toInt(),
                    "%.0f".format(deteccion.fps)
                )
            } else {
                getString(R.string.deteccion_apagada)
            }
        ).joinToString("\n")

        binding.btnCaptura.setText(
            if (captura.activa) R.string.btn_captura_detener else R.string.btn_captura_iniciar
        )
        binding.btnSuperposicion.visibility = if (permisoCapa) View.GONE else View.VISIBLE
        binding.btnFotograma.isEnabled = captura.activa
        binding.btnCuenta.isEnabled = captura.activa && cuentaAtras == 0
        if (cuentaAtras > 0) {
            binding.btnCuenta.text = getString(R.string.cuenta_atras_en_curso, cuentaAtras)
        } else {
            binding.btnCuenta.setText(R.string.btn_cuenta_atras)
        }
        binding.switchDeteccion.isEnabled = captura.activa
        binding.switchDeteccion.isChecked = deteccion.activa

        // ---- Módulos ----
        val verificados = modulos.count { it.estado == EstadoModulo.VERIFICADO }
        binding.tvModulosResumen.text =
            getString(R.string.panel_modulos_resumen, verificados, modulos.size)
        binding.tvModulos.text = modulos.joinToString("\n") {
            when (it.estado) {
                EstadoModulo.VERIFICADO -> getString(R.string.panel_modulo_verificado, it.nombre)
                EstadoModulo.IMPLEMENTADO -> getString(R.string.panel_modulo_implementado, it.nombre)
                EstadoModulo.PENDIENTE ->
                    getString(R.string.panel_modulo_pendiente, it.nombre, it.fase)
            }
        }

        // ---- Controles del bot ----
        val bloqueado = BotCore.modules.bloqueos().isNotEmpty()
        binding.btnIniciar.isEnabled = estado == BotState.DETENIDO && !bloqueado
        binding.btnPausar.isEnabled = estado == BotState.ACTIVO
        binding.btnReanudar.isEnabled = estado == BotState.PAUSADO
        binding.btnDetener.isEnabled = estado != BotState.DETENIDO
        binding.btnDetener.setText(
            if (estado == BotState.PARADA_EMERGENCIA || estado == BotState.DETENIDO_POR_ERROR) {
                R.string.btn_restablecer
            } else {
                R.string.btn_detener
            }
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private companion object {
        const val SEGUNDOS_CUENTA_ATRAS = 5
    }
}
