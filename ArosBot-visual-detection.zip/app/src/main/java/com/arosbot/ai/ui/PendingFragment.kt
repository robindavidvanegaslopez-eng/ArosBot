package com.arosbot.ai.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.arosbot.ai.R
import com.arosbot.ai.databinding.FragmentPendingBinding
import com.google.android.material.button.MaterialButton

/**
 * Sección cuyo módulo llega en una fase posterior. Los botones se muestran
 * desactivados a propósito: no hacen nada hasta que el módulo exista y esté probado.
 */
class PendingFragment : Fragment() {

    private var _binding: FragmentPendingBinding? = null
    private val b get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPendingBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val args = requireArguments()
        val fase = args.getInt(ARG_FASE)
        b.tvFase.text = getString(R.string.pendiente_fase, fase)
        b.tvDescripcion.setText(args.getInt(ARG_DESCRIPCION))

        val botones = args.getIntArray(ARG_BOTONES) ?: IntArray(0)
        for (texto in botones) {
            val boton = MaterialButton(
                requireContext(),
                null,
                com.google.android.material.R.attr.materialButtonOutlinedStyle
            )
            boton.setText(texto)
            boton.isEnabled = false
            val parametros = LinearLayoutParamsHelper.conMargenSuperior(boton, 8)
            b.contenedorBotones.addView(boton, parametros)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_FASE = "fase"
        private const val ARG_DESCRIPCION = "descripcion"
        private const val ARG_BOTONES = "botones"

        fun nuevo(fase: Int, descripcion: Int, botones: IntArray): PendingFragment {
            val fragmento = PendingFragment()
            fragmento.arguments = Bundle().apply {
                putInt(ARG_FASE, fase)
                putInt(ARG_DESCRIPCION, descripcion)
                putIntArray(ARG_BOTONES, botones)
            }
            return fragmento
        }
    }
}
