package com.arosbot.ai.ui

import android.content.Context
import android.graphics.Bitmap
import android.widget.Toast
import com.arosbot.ai.R
import com.arosbot.ai.capture.Anotador
import com.arosbot.ai.capture.CapturaDeTrabajo
import com.arosbot.ai.core.Box
import com.arosbot.ai.vision.ResultadoDeteccion

/** Lo que tienen en común las pruebas de detección de Materiales y Áreas. */
internal object PruebasDeteccion {

    /** Devuelve el fotograma de trabajo, o avisa al usuario de que primero debe capturar uno. */
    fun fotograma(contexto: Context): Bitmap? {
        val fotograma = CapturaDeTrabajo.fotograma.value
        if (fotograma == null) {
            Toast.makeText(contexto, R.string.captura_sin_fotograma, Toast.LENGTH_LONG).show()
        }
        return fotograma
    }

    /** Muestra el fotograma con los recuadros verdes (objetos) y celestes (áreas) y un resumen. */
    fun mostrar(
        contexto: Context,
        fotograma: Bitmap,
        resultado: ResultadoDeteccion,
        areas: List<Pair<String, Box>>
    ) {
        val imagen = Anotador.dibujar(fotograma, resultado.detecciones, areas)
        val lineas = ArrayList<String>()
        lineas.add(
            contexto.getString(
                R.string.prueba_resumen,
                resultado.detecciones.size,
                resultado.duracionMs.toInt()
            )
        )
        val porMaterial = resultado.detecciones.groupBy { it.nombre }
        if (porMaterial.isEmpty()) {
            lineas.add(contexto.getString(R.string.prueba_sin_resultados))
        }
        for ((nombre, lista) in porMaterial) {
            val mejor = (lista.maxOf { it.score } * 100f).toInt()
            lineas.add(contexto.getString(R.string.prueba_linea, nombre, lista.size, mejor))
        }
        for (aviso in resultado.avisos) {
            lineas.add(contexto.getString(R.string.prueba_aviso, aviso))
        }
        lineas.add(contexto.getString(R.string.prueba_leyenda))
        Dialogos.mostrarImagen(
            contexto,
            contexto.getString(R.string.prueba_titulo),
            imagen,
            lineas.joinToString("\n")
        )
    }
}
