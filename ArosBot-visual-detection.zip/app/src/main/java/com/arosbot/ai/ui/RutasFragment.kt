package com.arosbot.ai.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.arosbot.ai.R
import com.arosbot.ai.automation.GrabadorDeRuta
import com.arosbot.ai.automation.RutaPendiente
import com.arosbot.ai.automation.SeguidorDeRuta
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.OptimizadorDeTrayecto
import com.arosbot.ai.core.Ruta
import com.arosbot.ai.databinding.FragmentListaBinding
import com.arosbot.ai.databinding.ItemTarjetaBinding
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

/**
 * Enseñar rutas: recorrer un trayecto a mano para que ArosBot lo registre, guardarlo con nombre,
 * origen y destino, y probar a seguirlo (también al revés). Solo lanza las acciones y muestra el
 * estado; la lógica vive en `automation` y `core`.
 */
class RutasFragment : Fragment() {

    private var _binding: FragmentListaBinding? = null
    private val b get() = _binding!!

    /** Dibujo en vivo de la trayectoria mientras se enseña. */
    private var vistaVivo: TrayectoView? = null

    /** Última ruta pendiente por la que ya se abrió el diálogo de guardar. */
    private var avisada: RutaPendiente? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentListaBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        b.tvDescripcion.setText(R.string.desc_rutas)
        b.tvVacio.setText(R.string.rutas_vacia)
        b.btnPrimario.setOnClickListener {
            if (GrabadorDeRuta.estado.value.grabando) GrabadorDeRuta.terminar() else GrabadorDeRuta.iniciar()
        }
        b.btnSecundario.setText(R.string.cancelar)
        b.btnSecundario.setOnClickListener {
            if (GrabadorDeRuta.estado.value.grabando) GrabadorDeRuta.cancelar()
            if (SeguidorDeRuta.estado.value.ejecutando) SeguidorDeRuta.cancelar()
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { BotCore.store.rutas.collect { dibujar() } }
                launch { GrabadorDeRuta.estado.collect { dibujar() } }
                launch { GrabadorDeRuta.pendiente.collect { dibujar() } }
                launch { GrabadorDeRuta.trayectoVivo.collect { actualizarDibujoVivo(it) } }
                launch { SeguidorDeRuta.estado.collect { dibujar() } }
            }
        }
    }

    private fun dibujar() {
        val binding = _binding ?: return
        val contexto = context ?: return
        val grabacion = GrabadorDeRuta.estado.value
        val seguimiento = SeguidorDeRuta.estado.value
        val pendiente = GrabadorDeRuta.pendiente.value

        binding.tvFotograma.text = when {
            grabacion.grabando -> grabacion.texto + "\n" +
                "Puntos: ${grabacion.puntos} · ${grabacion.distanciaPx} px"
            seguimiento.ejecutando || seguimiento.texto.isNotBlank() -> seguimiento.texto
            grabacion.texto.isNotBlank() -> grabacion.texto
            else -> getString(R.string.rutas_inactivo)
        }

        binding.btnPrimario.setText(
            if (grabacion.grabando) R.string.btn_terminar_ruta else R.string.btn_ensenar_ruta
        )
        binding.btnPrimario.isEnabled =
            grabacion.grabando || (!seguimiento.ejecutando && pendiente == null)
        binding.btnSecundario.isEnabled = grabacion.grabando || seguimiento.ejecutando

        val rutas = BotCore.store.rutas.value
        binding.tvVacio.visibility =
            if (rutas.isEmpty() && pendiente == null) View.VISIBLE else View.GONE
        binding.lista.removeAllViews()
        if (grabacion.grabando) {
            val vivo = vistaVivo ?: TrayectoView(contexto).also { vistaVivo = it }
            val titulo = TextView(contexto)
            titulo.setText(R.string.ruta_trayecto_vivo)
            binding.lista.addView(titulo)
            binding.lista.addView(
                vivo,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            val actual = GrabadorDeRuta.trayectoVivo.value
            vivo.establecer(actual, actual)
        }
        if (pendiente != null) binding.lista.addView(tarjetaPendiente(contexto, pendiente, binding.lista))
        for (ruta in rutas) {
            binding.lista.addView(tarjeta(contexto, ruta, binding.lista, seguimiento.ejecutando))
        }

        // La primera vez que aparece una ruta pendiente se abre directamente el diálogo de guardar.
        if (pendiente != null && pendiente !== avisada && isResumed) {
            avisada = pendiente
            pedirDatosYGuardar()
        }
    }

    private fun actualizarDibujoVivo(puntos: List<com.arosbot.ai.core.PuntoDeRuta>) {
        val vista = vistaVivo ?: return
        if (_binding == null || vista.parent == null) return
        vista.establecer(puntos, puntos)
    }

    /** Añade a una tarjeta el dibujo del recorrido y del camino que seguirá el bot. */
    private fun dibujarTrayecto(
        contexto: android.content.Context,
        t: ItemTarjetaBinding,
        puntos: List<com.arosbot.ai.core.PuntoDeRuta>
    ): String {
        val optimizado = OptimizadorDeTrayecto.simplificar(puntos)
        val vista = TrayectoView(contexto)
        vista.establecer(puntos, optimizado.puntos)
        t.contenedorExtra.visibility = View.VISIBLE
        t.contenedorExtra.addView(
            vista,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        val leyenda = TextView(contexto)
        leyenda.setText(R.string.ruta_leyenda_dibujo)
        leyenda.textSize = 11f
        t.contenedorExtra.addView(leyenda)
        return getString(
            R.string.ruta_camino_bot,
            optimizado.puntos.size,
            puntos.size,
            (optimizado.ahorro * 100.0).roundToInt(),
            optimizado.longitudOptimizadaPx.roundToInt(),
            optimizado.longitudOriginalPx.roundToInt()
        )
    }

    override fun onResume() {
        super.onResume()
        dibujar()
    }

    private fun tarjetaPendiente(contexto: android.content.Context, p: RutaPendiente, padre: ViewGroup): View {
        val t = ItemTarjetaBinding.inflate(LayoutInflater.from(contexto), padre, false)
        t.tvTitulo.setText(R.string.ruta_pendiente_titulo)
        var distancia = 0.0
        for (i in 1 until p.puntos.size) {
            distancia += kotlin.math.hypot(
                p.puntos[i].x - p.puntos[i - 1].x,
                p.puntos[i].y - p.puntos[i - 1].y
            )
        }
        val camino = dibujarTrayecto(contexto, t, p.puntos)
        t.tvDetalle.text = getString(
            R.string.ruta_pendiente_detalle,
            p.puntos.size,
            distancia.roundToInt(),
            (p.duracionMs / 1000L).toInt(),
            p.medicionesDescartadas,
            p.medicionesTotales
        ) + "\n" + camino
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_guardar_ruta)) { pedirDatosYGuardar() }
        )
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_descartar)) {
                GrabadorDeRuta.descartarPendiente()
            }
        )
        return t.root
    }

    private fun pedirDatosYGuardar() {
        if (GrabadorDeRuta.pendiente.value == null) return
        val contexto = requireContext()
        Dialogos.pedirRuta(
            contexto = contexto,
            titulo = getString(R.string.ruta_dialogo_titulo),
            nombreInicial = "",
            origenInicial = getString(R.string.ruta_origen_defecto),
            destinoInicial = getString(R.string.ruta_destino_defecto)
        ) { nombre, origen, destino ->
            val problema = GrabadorDeRuta.guardarPendiente(nombre, origen, destino)
            if (problema == null) {
                Toast.makeText(contexto, R.string.ruta_guardada, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(
                    contexto,
                    getString(R.string.ruta_no_guardada, problema),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun tarjeta(
        contexto: android.content.Context,
        ruta: Ruta,
        padre: ViewGroup,
        ocupado: Boolean
    ): View {
        val t = ItemTarjetaBinding.inflate(LayoutInflater.from(contexto), padre, false)
        t.tvTitulo.text = ruta.nombre
        val lugares = BotCore.store.lugares.value
        val origen = lugares.firstOrNull { it.id == ruta.origenId }?.nombre ?: "?"
        val destino = lugares.firstOrNull { it.id == ruta.destinoId }?.nombre ?: "?"
        val camino = dibujarTrayecto(contexto, t, ruta.puntos)
        t.tvDetalle.text = getString(
            R.string.ruta_detalle,
            origen,
            destino,
            ruta.puntos.size,
            ruta.longitudPx.roundToInt(),
            (ruta.duracionEnsenadaMs / 1000L).toInt(),
            ruta.intentos,
            ruta.exitos,
            (ruta.fiabilidad * 100.0).roundToInt(),
            etiqueta(ruta)
        ) + "\n" + camino

        val seguir = Vistas.botonAccion(contexto, getString(R.string.btn_seguir_ruta)) {
            SeguidorDeRuta.reproducir(ruta.id, false)
        }
        val inversa = Vistas.botonAccion(contexto, getString(R.string.btn_seguir_inversa)) {
            SeguidorDeRuta.reproducir(ruta.id, true)
        }
        seguir.isEnabled = !ocupado
        inversa.isEnabled = !ocupado
        t.acciones.addView(seguir)
        t.acciones.addView(inversa)
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_editar)) { editar(ruta, origen, destino) }
        )
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_eliminar)) { eliminar(ruta) }
        )
        return t.root
    }

    private fun etiqueta(ruta: Ruta): String = getString(
        when (ruta.confianza) {
            com.arosbot.ai.core.Confianza.CONFIRMADO -> R.string.confianza_confirmada
            com.arosbot.ai.core.Confianza.ESTIMACION -> R.string.confianza_estimacion
            com.arosbot.ai.core.Confianza.INCIERTO -> R.string.confianza_incierta
        }
    )

    private fun editar(ruta: Ruta, origen: String, destino: String) {
        Dialogos.pedirRuta(
            contexto = requireContext(),
            titulo = getString(R.string.ruta_editar_titulo),
            nombreInicial = ruta.nombre,
            origenInicial = origen,
            destinoInicial = destino
        ) { nombre, o, d ->
            BotCore.store.editarRuta(ruta.id, nombre, o, d)
            BotCore.log.info("Rutas", "Ruta «$nombre» editada ($o → $d)")
        }
    }

    private fun eliminar(ruta: Ruta) {
        Dialogos.confirmar(
            requireContext(),
            getString(R.string.confirmar_titulo),
            getString(R.string.confirmar_eliminar_ruta, ruta.nombre)
        ) {
            BotCore.store.eliminarRuta(ruta.id)
            BotCore.log.info("Rutas", "Ruta «${ruta.nombre}» eliminada")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        vistaVivo = null
        _binding = null
    }
}
