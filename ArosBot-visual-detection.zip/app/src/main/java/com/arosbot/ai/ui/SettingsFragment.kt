package com.arosbot.ai.ui

import android.os.Bundle
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.arosbot.ai.core.RespaldoCompleto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.arosbot.ai.R
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.databinding.FragmentSettingsBinding

/** Configuración. En la Fase 1 solo guarda las preferencias del inicio de sesión automático. */
class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val b get() = _binding!!

    private val exportador =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            if (uri != null) exportarTodo(uri)
        }

    private val importador =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) leerRespaldo(uri)
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ajustes = BotCore.settings

        b.switchLogin.isChecked = ajustes.inicioSesionAutomatico
        b.etCuenta.setText(ajustes.cuentaGoogle)

        b.switchLogin.setOnCheckedChangeListener { _, activado ->
            ajustes.inicioSesionAutomatico = activado
            BotCore.log.info(
                "Ajustes",
                "Inicio de sesión automático " + if (activado) "activado" else "desactivado"
            )
        }

        b.switchFps60.isChecked = ajustes.fps60
        b.switchFps60.setOnCheckedChangeListener { _, activado ->
            ajustes.fps60 = activado
            BotCore.log.info("Ajustes", "Captura rápida a " + if (activado) "60" else "30" + " fotogramas por segundo")
        }

        b.btnExportarTodo.setOnClickListener { exportador.launch("ArosBot-copia.arosbot") }
        b.btnImportarTodo.setOnClickListener { importador.launch(arrayOf("*/*")) }

        b.btnGuardar.setOnClickListener {
            val correo = b.etCuenta.text?.toString()?.trim().orEmpty()
            if (correo.isNotEmpty() && !Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
                b.tilCuenta.error = getString(R.string.ajustes_correo_invalido)
            } else {
                b.tilCuenta.error = null
                ajustes.cuentaGoogle = correo
                // El correo no se escribe en el registro por privacidad.
                BotCore.log.info("Ajustes", "Cuenta de Google actualizada")
                Toast.makeText(requireContext(), R.string.ajustes_guardado, Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

    private fun exportarTodo(uri: Uri) {
        val app = requireContext().applicationContext
        lifecycleScope.launch {
            val resultado = withContext(Dispatchers.IO) {
                try {
                    val bytes = RespaldoCompleto.exportar()
                    val salida = app.contentResolver.openOutputStream(uri) ?: return@withContext null
                    salida.use { it.write(bytes) }
                    bytes.size
                } catch (e: Exception) {
                    BotCore.log.error("Respaldo", "No se pudo exportar: ${e.message}")
                    null
                }
            }
            val texto = if (resultado != null) "Copia guardada (${resultado / 1024} KB)." else getString(R.string.respaldo_error_exportar)
            if (_binding != null) b.tvRespaldo.text = texto
            Toast.makeText(app, texto, Toast.LENGTH_LONG).show()
            if (resultado != null) BotCore.log.info("Respaldo", "Copia completa exportada ($resultado bytes)")
        }
    }

    private fun leerRespaldo(uri: Uri) {
        val app = requireContext().applicationContext
        lifecycleScope.launch {
            val bytes = withContext(Dispatchers.IO) {
                try {
                    app.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                } catch (e: Exception) {
                    null
                }
            }
            if (bytes == null) {
                Toast.makeText(app, R.string.respaldo_error_leer, Toast.LENGTH_LONG).show()
                return@launch
            }
            val contenido = withContext(Dispatchers.Default) { RespaldoCompleto.leer(bytes) }
            if (contenido == null) {
                Toast.makeText(app, R.string.respaldo_invalido, Toast.LENGTH_LONG).show()
                return@launch
            }
            Dialogos.confirmar(
                requireContext(),
                getString(R.string.confirmar_titulo),
                getString(R.string.respaldo_confirmar_importar) + "\n\n" + contenido.resumen()
            ) {
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { RespaldoCompleto.aplicar(contenido) }
                    val texto = "Copia importada: " + contenido.resumen() + "."
                    if (_binding != null) b.tvRespaldo.text = texto
                    BotCore.log.info("Respaldo", texto)
                    Toast.makeText(app, "Copia importada", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
