package com.arosbot.ai.ui

import android.os.Bundle
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.arosbot.ai.R
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.databinding.FragmentSettingsBinding

/** Configuración. En la Fase 1 solo guarda las preferencias del inicio de sesión automático. */
class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val b get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ajustes = BotCore.settings

        b.switchLogin.isChecked = ajustes.inicioSesionAutomatico
        b.etCuenta.setText(ajustes.cuentaGoogle)

        b.switchLogin.setOnCheckedChangeListener { _, activado ->
            ajustes.inicioSesionAutomatico = activado
            BotCore.log.info(
                "Ajustes",
                "Inicio de sesión automático " + if (activado) "activado" else "desactivado"
            )
        }

        b.btnGuardar.setOnClickListener {
            val correo = b.etCuenta.text?.toString()?.trim().orEmpty()
            if (correo.isNotEmpty() && !Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
                b.tilCuenta.error = getString(R.string.ajustes_correo_invalido)
            } else {
                b.tilCuenta.error = null
                ajustes.cuentaGoogle = correo
                // El correo no se escribe en el registro por privacidad.
                BotCore.log.info("Ajustes", "Cuenta de Google actualizada")
                Toast.makeText(requireContext(), R.string.ajustes_guardado, Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
