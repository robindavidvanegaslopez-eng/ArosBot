package com.arosbot.ai.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.arosbot.ai.R
import com.arosbot.ai.automation.NavegadorDeSpots
import com.arosbot.ai.automation.SeguidorDeRuta
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.Candidato
import com.arosbot.ai.core.Disponibilidad
import com.arosbot.ai.core.Spot
import com.arosbot.ai.core.TiempoLegible
import com.arosbot.ai.databinding.FragmentListaBinding
import com.arosbot.ai.databinding.ItemTarjetaBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

/**
 * Mapa de spots (Fase 5): los sitios de recolección, su disponibilidad aprendida y la elección del
 * siguiente destino. Solo lanza las acciones y muestra el estado; la lógica vive en `core`
 * (elección y aprendizaje) y en `automation` (navegación).
 */
class SpotsFragment : Fragment() {

    private var _binding: FragmentListaBinding? = null
    private val b get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentListaBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        b.tvDescripcion.setText(R.string.desc_spots)
        b.tvVacio.setText(R.string.spots_vacio)
        b.btnPrimario.setText(R.string.btn_anadir_spot)
        b.btnPrimario.setOnClickListener { anadir() }
        b.btnSecundario.setOnClickListener {
            if (NavegadorDeSpots.estado.value.ejecutando) {
                NavegadorDeSpots.cancelar()
            } else {
                NavegadorDeSpots.irAlMejor()
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { BotCore.store.spots.collect { dibujar() } }
                launch { BotCore.store.rutas.collect { dibujar() } }
                launch { BotCore.store.lugares.collect { dibujar() } }
                launch { NavegadorDeSpots.estado.collect { dibujar() } }
                launch { SeguidorDeRuta.estado.collect { dibujar() } }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        dibujar()
    }

    private fun nombreDeLugar(id: Long): String =
        BotCore.store.lugares.value.firstOrNull { it.id == id }?.nombre ?: "?"

    private fun dibujar() {
        val binding = _binding ?: return
        val contexto = context ?: return
        val navegacion = NavegadorDeSpots.estado.value
        val rutaEnMarcha = SeguidorDeRuta.estado.value.ejecutando
        val spots = BotCore.store.spots.value
        val ahora = System.currentTimeMillis()
        val lugar = NavegadorDeSpots.lugarActual()
        val eleccion = NavegadorDeSpots.evaluar()

        val lineas = ArrayList<String>()
        if (navegacion.ejecutando || navegacion.texto.isNotBlank()) {
            lineas.add(navegacion.texto)
        } else {
            lineas.add(getString(R.string.spots_inactivo))
        }
        lineas.add("")
        lineas.add(
            if (lugar != null) getString(R.string.spots_ubicacion, nombreDeLugar(lugar))
            else getString(R.string.spots_ubicacion_desconocida)
        )
        if (spots.isNotEmpty() && lugar != null) {
            lineas.add("")
            lineas.add(getString(R.string.spots_eleccion_titulo))
            eleccion.candidatos.forEachIndexed { i, c ->
                lineas.add(
                    getString(
                        R.string.spots_eleccion_linea,
                        i + 1,
                        c.spot.nombre,
                        String.format(Locale.US, "%.2f", c.puntuacion),
                        c.motivo
                    )
                )
            }
            for ((spot, motivo) in eleccion.descartados) {
                lineas.add(getString(R.string.spots_descartado_linea, spot.nombre, motivo))
            }
        }
        binding.tvFotograma.text = lineas.joinToString("\n")

        binding.btnPrimario.isEnabled = !navegacion.ejecutando
        binding.btnSecundario.setText(
            if (navegacion.ejecutando) R.string.cancelar else R.string.btn_elegir_y_ir
        )
        binding.btnSecundario.isEnabled = navegacion.ejecutando || (!rutaEnMarcha && spots.isNotEmpty())

        binding.tvVacio.visibility = if (spots.isEmpty()) View.VISIBLE else View.GONE
        binding.lista.removeAllViews()
        binding.lista.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_estoy_en)) { dondeEstoy() }
        )
        val ocupado = navegacion.ejecutando || rutaEnMarcha
        for (spot in spots) {
            val candidato = eleccion.candidatos.firstOrNull { it.spot.id == spot.id }
            binding.lista.addView(tarjeta(contexto, spot, candidato, ahora, binding.lista, ocupado))
        }
    }

    private fun tarjeta(
        contexto: android.content.Context,
        spot: Spot,
        candidato: Candidato?,
        ahora: Long,
        padre: ViewGroup,
        ocupado: Boolean
    ): View {
        val t = ItemTarjetaBinding.inflate(LayoutInflater.from(contexto), padre, false)
        t.tvTitulo.text = spot.nombre
        val materiales = BotCore.store.materiales.value
        val nombresMateriales = if (spot.materiales.isEmpty()) {
            getString(R.string.spot_materiales_cualquiera)
        } else {
            spot.materiales.mapNotNull { id -> materiales.firstOrNull { it.id == id }?.nombre }
                .joinToString(", ").ifEmpty { "?" }
        }
        val disponibilidad = spot.disponibilidad(ahora)
        val vuelve = spot.vuelveEnMs(ahora)
        val vuelveTexto = if (disponibilidad == Disponibilidad.AGOTADO && vuelve > 0L) {
            " · " + getString(R.string.spot_vuelve_en, TiempoLegible.de(vuelve))
        } else {
            ""
        }
        val ultima = if (spot.ultimaVisitaMs > 0L) {
            getString(
                R.string.spot_ultima_visita,
                SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(spot.ultimaVisitaMs))
            )
        } else {
            getString(R.string.spot_nunca_visitado)
        }
        t.tvDetalle.text = getString(
            R.string.spot_detalle,
            nombreDeLugar(spot.lugarId),
            spot.prioridad,
            nombresMateriales,
            disponibilidad.etiqueta,
            vuelveTexto,
            spot.visitas,
            spot.conRecursos,
            ultima
        ) + (if (candidato != null) "\n" + candidato.motivo else "")

        val ir = Vistas.botonAccion(contexto, getString(R.string.btn_ir_ahora)) {
            NavegadorDeSpots.irA(spot.id)
        }
        ir.isEnabled = !ocupado
        t.acciones.addView(ir)
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_materiales_spot)) { elegirMateriales(spot) }
        )
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_editar)) { editar(spot) }
        )
        t.acciones.addView(
            Vistas.botonAccion(contexto, getString(R.string.btn_eliminar)) { eliminar(spot) }
        )
        return t.root
    }

    private fun anadir() {
        val contexto = requireContext()
        val lugares = BotCore.store.lugares.value.map { it.nombre }
        Dialogos.pedirSpot(
            contexto = contexto,
            titulo = getString(R.string.spot_dialogo_titulo),
            nombreInicial = "",
            lugarInicial = lugares.firstOrNull() ?: "",
            prioridadInicial = 3,
            lugaresConocidos = lugares
        ) { nombre, lugar, prioridad ->
            if (lugar.isBlank()) {
                Toast.makeText(contexto, R.string.spots_sin_lugares_aviso, Toast.LENGTH_LONG).show()
            } else {
                BotCore.store.insertarSpot(nombre, lugar, emptyList(), prioridad)
                BotCore.log.info("Spots", "Spot «$nombre» añadido en «$lugar» (prioridad $prioridad)")
                Toast.makeText(contexto, R.string.spots_guardado, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun editar(spot: Spot) {
        val contexto = requireContext()
        Dialogos.pedirSpot(
            contexto = contexto,
            titulo = getString(R.string.spot_editar_titulo),
            nombreInicial = spot.nombre,
            lugarInicial = nombreDeLugar(spot.lugarId),
            prioridadInicial = spot.prioridad,
            lugaresConocidos = BotCore.store.lugares.value.map { it.nombre }
        ) { nombre, lugar, prioridad ->
            BotCore.store.editarSpot(spot.id, nombre, lugar, spot.materiales, prioridad)
            BotCore.log.info("Spots", "Spot «$nombre» editado")
        }
    }

    private fun elegirMateriales(spot: Spot) {
        val contexto = requireContext()
        val materiales = BotCore.store.materiales.value
        if (materiales.isEmpty()) {
            Toast.makeText(contexto, R.string.sin_materiales, Toast.LENGTH_LONG).show()
            return
        }
        val nombres = materiales.map { it.nombre }.toTypedArray()
        val marcados = BooleanArray(materiales.size) { materiales[it].id in spot.materiales }
        MaterialAlertDialogBuilder(contexto)
            .setTitle(getString(R.string.asignar_materiales_titulo, spot.nombre))
            .setMultiChoiceItems(nombres, marcados) { _, indice, activo -> marcados[indice] = activo }
            .setPositiveButton(R.string.guardar) { _, _ ->
                val elegidos = materiales.filterIndexed { i, _ -> marcados[i] }.map { it.id }
                BotCore.store.editarSpot(
                    spot.id, spot.nombre, nombreDeLugar(spot.lugarId), elegidos, spot.prioridad
                )
            }
            .setNegativeButton(R.string.cancelar, null)
            .show()
    }

    private fun dondeEstoy() {
        val contexto = requireContext()
        val lugares = BotCore.store.lugares.value
        if (lugares.isEmpty()) {
            Toast.makeText(contexto, R.string.spots_sin_lugares_aviso, Toast.LENGTH_LONG).show()
            return
        }
        val opciones = (lugares.map { it.nombre } + getString(R.string.spots_ubicacion_ninguna)).toTypedArray()
        MaterialAlertDialogBuilder(contexto)
            .setTitle(R.string.spots_ubicacion_titulo)
            .setItems(opciones) { _, indice ->
                BotCore.settings.lugarActualId = if (indice < lugares.size) lugares[indice].id else -1L
                BotCore.log.info(
                    "Spots",
                    if (indice < lugares.size) "Ubicación indicada por el usuario: «${lugares[indice].nombre}»"
                    else "Ubicación borrada por el usuario"
                )
                dibujar()
            }
            .setNegativeButton(R.string.cancelar, null)
            .show()
    }

    private fun eliminar(spot: Spot) {
        Dialogos.confirmar(
            requireContext(),
            getString(R.string.confirmar_titulo),
            getString(R.string.confirmar_eliminar_spot, spot.nombre)
        ) {
            BotCore.store.eliminarSpot(spot.id)
            BotCore.log.info("Spots", "Spot «${spot.nombre}» eliminado")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
