package com.arosbot.ai.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import com.arosbot.ai.core.PuntoDeRuta
import com.google.android.material.color.MaterialColors
import kotlin.math.max
import kotlin.math.min

/**
 * Dibuja el trayecto de una ruta: en gris tu recorrido tal como lo hiciste y en color el camino que
 * seguirá el bot (la misma trayectoria sin rodeos, con sus puntos de control). El inicio va en verde y
 * el final en rojo; los cuadrados son los puntos con referencia visual. Las posiciones son píxeles
 * del fotograma capturado (no metros del juego), con el origen en el punto de partida.
 */
class TrayectoView(contexto: Context) : View(contexto) {

    private var recorrido: List<PuntoDeRuta> = emptyList()
    private var camino: List<PuntoDeRuta> = emptyList()

    private val densidad = contexto.resources.displayMetrics.density

    private val pincelRecorrido = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * densidad
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = MaterialColors.getColor(this@TrayectoView, com.google.android.material.R.attr.colorOutline, 0xFF9E9E9E.toInt())
    }
    private val pincelCamino = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * densidad
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = MaterialColors.getColor(this@TrayectoView, com.google.android.material.R.attr.colorPrimary, 0xFF1565C0.toInt())
    }
    private val pincelPunto = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = MaterialColors.getColor(this@TrayectoView, com.google.android.material.R.attr.colorPrimary, 0xFF1565C0.toInt())
    }
    private val pincelInicio = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF2E7D32.toInt()
    }
    private val pincelFinal = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFC62828.toInt()
    }

    /** [recorrido] es lo que hizo el usuario; [camino] es lo que seguirá el bot (puede ser el mismo). */
    fun establecer(recorrido: List<PuntoDeRuta>, camino: List<PuntoDeRuta>) {
        this.recorrido = recorrido
        this.camino = camino
        invalidate()
    }

    override fun onMeasure(anchoSpec: Int, altoSpec: Int) {
        val ancho = MeasureSpec.getSize(anchoSpec)
        setMeasuredDimension(ancho, (ALTO_DP * densidad).toInt())
    }

    override fun onDraw(lienzo: Canvas) {
        super.onDraw(lienzo)
        val todos = recorrido + camino
        if (todos.size < 2) return

        var minX = Double.MAX_VALUE
        var maxX = -Double.MAX_VALUE
        var minY = Double.MAX_VALUE
        var maxY = -Double.MAX_VALUE
        for (p in todos) {
            minX = min(minX, p.x)
            maxX = max(maxX, p.x)
            minY = min(minY, p.y)
            maxY = max(maxY, p.y)
        }
        val margen = 16f * densidad
        val anchoUtil = max(1f, width - 2 * margen)
        val altoUtil = max(1f, height - 2 * margen)
        val anchoReal = max(1.0, maxX - minX)
        val altoReal = max(1.0, maxY - minY)
        val escala = min(anchoUtil / anchoReal, altoUtil / altoReal).toFloat()
        val offsetX = margen + (anchoUtil - (anchoReal * escala).toFloat()) / 2f
        val offsetY = margen + (altoUtil - (altoReal * escala).toFloat()) / 2f

        fun px(p: PuntoDeRuta) = offsetX + ((p.x - minX) * escala).toFloat()
        fun py(p: PuntoDeRuta) = offsetY + ((p.y - minY) * escala).toFloat()

        fun trazar(puntos: List<PuntoDeRuta>, pincel: Paint) {
            if (puntos.size < 2) return
            val ruta = Path()
            ruta.moveTo(px(puntos[0]), py(puntos[0]))
            for (i in 1 until puntos.size) ruta.lineTo(px(puntos[i]), py(puntos[i]))
            lienzo.drawPath(ruta, pincel)
        }

        trazar(recorrido, pincelRecorrido)
        if (camino !== recorrido) trazar(camino, pincelCamino)

        val r = 4f * densidad
        for (p in camino) {
            if (p.referencia != null) {
                lienzo.drawRect(px(p) - r, py(p) - r, px(p) + r, py(p) + r, pincelPunto)
            } else {
                lienzo.drawCircle(px(p), py(p), r * 0.6f, pincelPunto)
            }
        }
        val primero = (if (camino.isNotEmpty()) camino else recorrido).first()
        val ultimo = (if (camino.isNotEmpty()) camino else recorrido).last()
        lienzo.drawCircle(px(primero), py(primero), r * 1.5f, pincelInicio)
        lienzo.drawCircle(px(ultimo), py(ultimo), r * 1.5f, pincelFinal)
    }

    private companion object {
        const val ALTO_DP = 170
    }
}
