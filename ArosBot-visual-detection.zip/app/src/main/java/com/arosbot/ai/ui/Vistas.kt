package com.arosbot.ai.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.ViewGroup
import android.widget.LinearLayout
import com.google.android.material.button.MaterialButton
import java.io.File
import kotlin.math.max

/** Utilidades pequeñas para construir vistas en código. */
internal object Vistas {

    fun dp(contexto: Context, valor: Int): Int =
        (valor * contexto.resources.displayMetrics.density).toInt()

    /** Botón con borde para las filas de acciones de las tarjetas. */
    fun botonAccion(contexto: Context, texto: String, alPulsar: () -> Unit): MaterialButton {
        val boton = MaterialButton(
            contexto,
            null,
            com.google.android.material.R.attr.materialButtonOutlinedStyle
        )
        boton.text = texto
        boton.setOnClickListener { alPulsar() }
        val parametros = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        parametros.marginEnd = dp(contexto, 8)
        boton.layoutParams = parametros
        return boton
    }

    /** Carga una versión reducida de una imagen del disco, o null si no se puede leer. */
    fun miniatura(archivo: File, ladoObjetivoPx: Int): Bitmap? {
        if (!archivo.exists()) return null
        val bordes = BitmapFactory.Options()
        bordes.inJustDecodeBounds = true
        BitmapFactory.decodeFile(archivo.absolutePath, bordes)
        if (bordes.outWidth <= 0 || bordes.outHeight <= 0) return null
        var muestreo = 1
        while (max(bordes.outWidth, bordes.outHeight) / (muestreo * 2) >= ladoObjetivoPx) {
            muestreo *= 2
        }
        val opciones = BitmapFactory.Options()
        opciones.inSampleSize = muestreo
        return BitmapFactory.decodeFile(archivo.absolutePath, opciones)
    }
}
