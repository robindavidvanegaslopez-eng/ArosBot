package com.arosbot.ai.vision

import android.graphics.Bitmap
import android.os.SystemClock
import com.arosbot.ai.capture.FrameBus
import com.arosbot.ai.core.Area
import com.arosbot.ai.core.Box
import com.arosbot.ai.core.Detection
import com.arosbot.ai.core.FrameGeometry
import com.arosbot.ai.core.Material
import com.arosbot.ai.core.Nms
import java.io.File

data class ResultadoDeteccion(
    val detecciones: List<Detection>,
    val avisos: List<String>,
    val duracionMs: Long
)

/**
 * Orquesta la detección: decide en qué regiones y con qué materiales se busca.
 *
 *  - [enAreasActivas]: uso normal. Solo se procesan las áreas activas cuya proporción
 *    coincide con la pantalla actual; las demás se omiten y se avisa de que hay que recalibrarlas.
 *  - [enArea]: prueba de una sola área.
 *  - [enPantallaCompleta]: prueba de materiales y comprobaciones fuera de las áreas.
 */
object Deteccion {

    private const val IOU_ENTRE_REGIONES = 0.3f

    fun enPantallaCompleta(
        fotograma: Bitmap,
        materiales: List<Material>,
        directorio: File
    ): ResultadoDeteccion {
        val regiones = listOf<Pair<Box?, List<Material>>>(Pair(null, materiales))
        return ejecutar(fotograma, regiones, emptyList(), directorio)
    }

    /** Detección rápida (modo en vivo y recolección): mitad de resolución y 3 escalas. */
    fun rapidaEnAreasActivas(
        fotograma: Bitmap,
        areas: List<Area>,
        materiales: List<Material>,
        directorio: File
    ): ResultadoDeteccion {
        val avisos = ArrayList<String>()
        val regiones = ArrayList<Pair<Box?, List<Material>>>()
        if (areas.none { it.activa }) {
            regiones.add(Pair(null, materiales))
        } else {
            for (area in areas.filter { it.activa }) agregarRegion(fotograma, area, materiales, regiones, avisos)
        }
        return ejecutar(fotograma, regiones, avisos, directorio, rapido = true)
    }

    /** Detección rápida sobre toda la pantalla. */
    fun rapidaEnPantallaCompleta(
        fotograma: Bitmap,
        materiales: List<Material>,
        directorio: File
    ): ResultadoDeteccion = ejecutar(
        fotograma, listOf(Pair<Box?, List<Material>>(null, materiales)), emptyList(), directorio, true
    )

    fun enArea(
        fotograma: Bitmap,
        area: Area,
        materiales: List<Material>,
        directorio: File
    ): ResultadoDeteccion {
        val avisos = ArrayList<String>()
        val regiones = ArrayList<Pair<Box?, List<Material>>>()
        agregarRegion(fotograma, area, materiales, regiones, avisos)
        return ejecutar(fotograma, regiones, avisos, directorio)
    }

    fun enAreasActivas(
        fotograma: Bitmap,
        areas: List<Area>,
        materiales: List<Material>,
        directorio: File
    ): ResultadoDeteccion {
        val avisos = ArrayList<String>()
        val regiones = ArrayList<Pair<Box?, List<Material>>>()
        if (areas.isEmpty()) {
            regiones.add(Pair(null, materiales))
            avisos.add("No hay áreas definidas: se analiza toda la pantalla (solo para pruebas)")
        } else {
            for (area in areas.filter { it.activa }) {
                agregarRegion(fotograma, area, materiales, regiones, avisos)
            }
            if (regiones.isEmpty() && avisos.isEmpty()) {
                avisos.add("Todas las áreas están desactivadas")
            }
        }
        return ejecutar(fotograma, regiones, avisos, directorio)
    }

    private fun agregarRegion(
        fotograma: Bitmap,
        area: Area,
        materiales: List<Material>,
        regiones: MutableList<Pair<Box?, List<Material>>>,
        avisos: MutableList<String>
    ) {
        if (!FrameGeometry.relacionCompatible(
                area.refAncho, area.refAlto, fotograma.width, fotograma.height
            )
        ) {
            avisos.add("El área «${area.nombre}» ya no corresponde a esta pantalla: hay que recalibrarla")
            return
        }
        val usar = if (area.materiales.isEmpty()) {
            materiales
        } else {
            materiales.filter { it.id in area.materiales }
        }
        regiones.add(Pair(area.rect.aBox(fotograma.width, fotograma.height), usar))
    }

    private fun ejecutar(
        fotograma: Bitmap,
        regiones: List<Pair<Box?, List<Material>>>,
        avisosPrevios: List<String>,
        directorio: File,
        rapido: Boolean = false
    ): ResultadoDeteccion {
        val inicio = SystemClock.elapsedRealtime()
        val avisos = ArrayList(avisosPrevios)
        if (!VisionEngine.inicializar()) {
            avisos.add("OpenCV no está disponible en este dispositivo")
            return ResultadoDeteccion(emptyList(), avisos, 0L)
        }
        val todas = ArrayList<Detection>()
        VisionEngine.preparar(fotograma).use { escena ->
            for ((caja, materiales) in regiones) {
                val plantillas = materiales.mapNotNull { PlantillaCache.obtener(it, directorio) }
                if (plantillas.isEmpty()) continue
                todas.addAll(VisionEngine.buscar(escena, caja, plantillas, FrameBus.ESCALA_CAPTURA, rapido))
            }
        }
        val finales = Nms.suprimir(todas, IOU_ENTRE_REGIONES, soloMismoMaterial = true)
        return ResultadoDeteccion(finales, avisos, SystemClock.elapsedRealtime() - inicio)
    }
}
