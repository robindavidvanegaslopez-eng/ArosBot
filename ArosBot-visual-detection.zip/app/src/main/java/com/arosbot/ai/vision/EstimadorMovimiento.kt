package com.arosbot.ai.vision

import android.graphics.Bitmap
import com.arosbot.ai.core.FuenteMedicion
import com.arosbot.ai.core.Medicion
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/**
 * Estimador de movimiento (módulo 6): desplazamiento global de la escena entre dos fotogramas
 * mediante correlación de fase. Si la cámara sigue al personaje, la escena se desplaza al revés
 * que él; si la cámara es fija, la escena casi no se mueve y hay que localizar al personaje
 * directamente (ver [LocalizadorPersonaje]). El resultado está en píxeles del fotograma.
 */
object EstimadorMovimiento {

    /** No se reduce: se trabaja sobre recortes ya pequeños, para no perder precisión. */
    private const val REDUCCION = 1.0

    /**
     * Recortes (x, y, ancho, alto, en fracción del fotograma) donde se mide. Se evitan los bordes,
     * donde suelen estar los botones, el joystick y las barras del juego: son estáticos y, si entran
     * en la medición, la correlación de fase solo ve «0 px de movimiento».
     */
    private val RECORTES = listOf(
        doubleArrayOf(0.20, 0.20, 0.60, 0.45),
        doubleArrayOf(0.15, 0.12, 0.70, 0.36),
        doubleArrayOf(0.25, 0.35, 0.50, 0.30)
    )

    /** Mide en cada recorte y se queda con el de mayor confianza de la correlación. */
    fun estimar(antes: Bitmap, despues: Bitmap): Medicion? {
        if (antes.width != despues.width || antes.height != despues.height) return null
        if (!VisionEngine.inicializar()) return null
        var mejor: Medicion? = null
        for (r in RECORTES) {
            val m = estimarRecorte(antes, despues, r) ?: continue
            if (mejor == null || m.confianza > mejor.confianza) mejor = m
        }
        return mejor
    }

    private fun estimarRecorte(antes: Bitmap, despues: Bitmap, r: DoubleArray): Medicion? {
        val x = (r[0] * antes.width).toInt().coerceIn(0, antes.width - 2)
        val y = (r[1] * antes.height).toInt().coerceIn(0, antes.height - 2)
        val w = (r[2] * antes.width).toInt().coerceAtMost(antes.width - x)
        val h = (r[3] * antes.height).toInt().coerceAtMost(antes.height - y)
        if (w < 16 || h < 16) return null
        val ca = Bitmap.createBitmap(antes, x, y, w, h)
        val cb = Bitmap.createBitmap(despues, x, y, w, h)
        try {
            val ma = prepararGris(ca)
            val mb = prepararGris(cb)
            val ventana = Mat()
            try {
                Imgproc.createHanningWindow(ventana, Size(ma.cols().toDouble(), ma.rows().toDouble()), CvType.CV_32F)
                val respuesta = DoubleArray(1)
                val d = Imgproc.phaseCorrelate(ma, mb, ventana, respuesta)
                val factor = 1.0 / REDUCCION
                return Medicion(d.x * factor, d.y * factor, respuesta[0], FuenteMedicion.ESCENA)
            } finally {
                ventana.release()
                ma.release()
                mb.release()
            }
        } finally {
            ca.recycle()
            cb.recycle()
        }
    }

    /** Escala de grises, reducida y en coma flotante de 32 bits (lo que exige la correlación de fase). */
    private fun prepararGris(bitmap: Bitmap): Mat {
        val bgr = VisionEngine.matDesdeBitmap(bitmap)
        val gris = Mat()
        val reducida = Mat()
        val flotante = Mat()
        try {
            Imgproc.cvtColor(bgr, gris, Imgproc.COLOR_BGR2GRAY)
            Imgproc.resize(
                gris,
                reducida,
                Size(gris.cols() * REDUCCION, gris.rows() * REDUCCION),
                0.0,
                0.0,
                Imgproc.INTER_AREA
            )
            reducida.convertTo(flotante, CvType.CV_32F)
            return flotante
        } catch (e: Throwable) {
            flotante.release()
            throw e
        } finally {
            bgr.release()
            gris.release()
            reducida.release()
        }
    }
}
