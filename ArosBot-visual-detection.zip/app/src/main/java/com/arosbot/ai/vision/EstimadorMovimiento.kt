package com.arosbot.ai.vision

import android.graphics.Bitmap
import com.arosbot.ai.core.ConsensoDeMediciones
import com.arosbot.ai.core.FuenteMedicion
import com.arosbot.ai.core.Lectura
import com.arosbot.ai.core.Medicion
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/**
 * Estimador de movimiento (módulo 6): desplazamiento global de la escena entre dos fotogramas
 * mediante correlación de fase. Si la cámara sigue al personaje, la escena se desplaza al revés
 * que él; si la cámara es fija, la escena casi no se mueve y hay que localizar al personaje
 * directamente (ver [LocalizadorPersonaje]). El resultado está en píxeles del fotograma.
 */
object EstimadorMovimiento {

    /** Mitad de resolución: la correlación de fase sigue dando subpíxeles y se mide el doble de rápido. */
    private const val REDUCCION = 0.5

    /**
     * Recortes (x, y, ancho, alto, en fracción del fotograma) donde se mide. Se evitan los bordes, donde
     * están los botones, el joystick y las barras (estáticos: la correlación solo vería «0 px»), y el
     * centro, donde está el personaje: su sprite también es estático respecto a la cámara y, si entra en
     * la medición, resta velocidad a lo que se mide. Se mide en cuatro franjas alrededor de él.
     */
    private val RECORTES = listOf(
        doubleArrayOf(0.15, 0.08, 0.70, 0.27),
        doubleArrayOf(0.14, 0.32, 0.27, 0.36),
        doubleArrayOf(0.59, 0.32, 0.27, 0.36),
        doubleArrayOf(0.28, 0.64, 0.44, 0.22)
    )

    /** Reducción para comparar fotogramas por diferencia (solo para saber si la escena cambió). */
    private const val REDUCCION_DIFERENCIA = 0.25

    /** Mide en cada recorte y combina por consenso (mediana). */
    fun estimar(antes: Bitmap, despues: Bitmap): Medicion? = medir(antes, despues).medicion

    /**
     * Lectura completa entre dos fotogramas: desplazamiento de la escena por consenso de los recortes y
     * diferencia media de la imagen. La diferencia no depende de que haya textura que correlacionar, por
     * eso sirve para saber si la escena está quieta (choque) aunque la correlación sea poco fiable.
     */
    fun medir(antes: Bitmap, despues: Bitmap): Lectura {
        if (antes.width != despues.width || antes.height != despues.height) return Lectura(null, null)
        if (!VisionEngine.inicializar()) return Lectura(null, null)
        val mediciones = ArrayList<Medicion>()
        var sumaDif = 0.0
        var n = 0
        for (r in RECORTES) {
            val m = try {
                estimarRecorte(antes, despues, r)
            } catch (e: Throwable) {
                null
            }
            if (m != null) mediciones.add(m)
            val d = try {
                diferenciaRecorte(antes, despues, r)
            } catch (e: Throwable) {
                null
            }
            if (d != null) {
                sumaDif += d
                n++
            }
        }
        return Lectura(ConsensoDeMediciones.combinar(mediciones), if (n == 0) null else sumaDif / n)
    }

    private fun diferenciaRecorte(antes: Bitmap, despues: Bitmap, r: DoubleArray): Double? {
        val x = (r[0] * antes.width).toInt().coerceIn(0, antes.width - 2)
        val y = (r[1] * antes.height).toInt().coerceIn(0, antes.height - 2)
        val w = (r[2] * antes.width).toInt().coerceAtMost(antes.width - x)
        val h = (r[3] * antes.height).toInt().coerceAtMost(antes.height - y)
        if (w < 16 || h < 16) return null
        val ca = Bitmap.createBitmap(antes, x, y, w, h)
        val cb = Bitmap.createBitmap(despues, x, y, w, h)
        val ga = Mat()
        val gb = Mat()
        val dif = Mat()
        try {
            val ba = VisionEngine.matDesdeBitmap(ca)
            val bb = VisionEngine.matDesdeBitmap(cb)
            try {
                Imgproc.cvtColor(ba, ga, Imgproc.COLOR_BGR2GRAY)
                Imgproc.cvtColor(bb, gb, Imgproc.COLOR_BGR2GRAY)
            } finally {
                ba.release()
                bb.release()
            }
            Imgproc.resize(ga, ga, Size(), REDUCCION_DIFERENCIA, REDUCCION_DIFERENCIA, Imgproc.INTER_AREA)
            Imgproc.resize(gb, gb, Size(), REDUCCION_DIFERENCIA, REDUCCION_DIFERENCIA, Imgproc.INTER_AREA)
            Core.absdiff(ga, gb, dif)
            return Core.mean(dif).`val`[0]
        } finally {
            ga.release()
            gb.release()
            dif.release()
            ca.recycle()
            cb.recycle()
        }
    }

    private fun estimarRecorte(antes: Bitmap, despues: Bitmap, r: DoubleArray): Medicion? {
        val x = (r[0] * antes.width).toInt().coerceIn(0, antes.width - 2)
        val y = (r[1] * antes.height).toInt().coerceIn(0, antes.height - 2)
        val w = (r[2] * antes.width).toInt().coerceAtMost(antes.width - x)
        val h = (r[3] * antes.height).toInt().coerceAtMost(antes.height - y)
        if (w < 16 || h < 16) return null
        val ca = Bitmap.createBitmap(antes, x, y, w, h)
        val cb = Bitmap.createBitmap(despues, x, y, w, h)
        try {
            val ma = prepararGris(ca)
            val mb = prepararGris(cb)
            val ventana = Mat()
            try {
                Imgproc.createHanningWindow(ventana, Size(ma.cols().toDouble(), ma.rows().toDouble()), CvType.CV_32F)
                val respuesta = DoubleArray(1)
                val d = Imgproc.phaseCorrelate(ma, mb, ventana, respuesta)
                val factor = 1.0 / REDUCCION
                return Medicion(d.x * factor, d.y * factor, respuesta[0], FuenteMedicion.ESCENA)
            } finally {
                ventana.release()
                ma.release()
                mb.release()
            }
        } finally {
            ca.recycle()
            cb.recycle()
        }
    }

    /** Escala de grises, reducida y en coma flotante de 32 bits (lo que exige la correlación de fase). */
    private fun prepararGris(bitmap: Bitmap): Mat {
        val bgr = VisionEngine.matDesdeBitmap(bitmap)
        val gris = Mat()
        val reducida = Mat()
        val flotante = Mat()
        try {
            Imgproc.cvtColor(bgr, gris, Imgproc.COLOR_BGR2GRAY)
            Imgproc.resize(
                gris,
                reducida,
                Size(gris.cols() * REDUCCION, gris.rows() * REDUCCION),
                0.0,
                0.0,
                Imgproc.INTER_AREA
            )
            reducida.convertTo(flotante, CvType.CV_32F)
            return flotante
        } catch (e: Throwable) {
            flotante.release()
            throw e
        } finally {
            bgr.release()
            gris.release()
            reducida.release()
        }
    }
}
