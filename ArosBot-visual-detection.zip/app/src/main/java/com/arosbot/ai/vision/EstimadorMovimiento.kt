package com.arosbot.ai.vision

import android.graphics.Bitmap
import com.arosbot.ai.core.FuenteMedicion
import com.arosbot.ai.core.Medicion
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/**
 * Estimador de movimiento (módulo 6): desplazamiento global de la escena entre dos fotogramas
 * mediante correlación de fase. Si la cámara sigue al personaje, la escena se desplaza al revés
 * que él; si la cámara es fija, la escena casi no se mueve y hay que localizar al personaje
 * directamente (ver [LocalizadorPersonaje]). El resultado está en píxeles del fotograma.
 */
object EstimadorMovimiento {

    /** Se reduce la imagen a esta fracción para que el cálculo sea rápido. */
    private const val REDUCCION = 0.5

    fun estimar(antes: Bitmap, despues: Bitmap): Medicion? {
        if (antes.width != despues.width || antes.height != despues.height) return null
        if (!VisionEngine.inicializar()) return null

        val a = prepararGris(antes)
        val b = prepararGris(despues)
        val ventana = Mat()
        try {
            Imgproc.createHanningWindow(ventana, Size(a.cols().toDouble(), a.rows().toDouble()), CvType.CV_32F)
            val respuesta = DoubleArray(1)
            val desplazamiento = Imgproc.phaseCorrelate(a, b, ventana, respuesta)
            val factor = 1.0 / REDUCCION
            return Medicion(
                desplazamiento.x * factor,
                desplazamiento.y * factor,
                respuesta[0],
                FuenteMedicion.ESCENA
            )
        } finally {
            ventana.release()
            a.release()
            b.release()
        }
    }

    /** Escala de grises, reducida y en coma flotante de 32 bits (lo que exige la correlación de fase). */
    private fun prepararGris(bitmap: Bitmap): Mat {
        val bgr = VisionEngine.matDesdeBitmap(bitmap)
        val gris = Mat()
        val reducida = Mat()
        val flotante = Mat()
        try {
            Imgproc.cvtColor(bgr, gris, Imgproc.COLOR_BGR2GRAY)
            Imgproc.resize(
                gris,
                reducida,
                Size(gris.cols() * REDUCCION, gris.rows() * REDUCCION),
                0.0,
                0.0,
                Imgproc.INTER_AREA
            )
            reducida.convertTo(flotante, CvType.CV_32F)
            return flotante
        } catch (e: Throwable) {
            flotante.release()
            throw e
        } finally {
            bgr.release()
            gris.release()
            reducida.release()
        }
    }
}
