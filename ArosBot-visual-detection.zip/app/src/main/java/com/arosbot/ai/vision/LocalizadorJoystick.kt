package com.arosbot.ai.vision

import android.graphics.Bitmap
import com.arosbot.ai.core.Circulo
import com.arosbot.ai.core.ElegirCirculoJoystick
import com.arosbot.ai.core.NormRect
import kotlin.math.max
import kotlin.math.min
import org.opencv.core.Mat
import org.opencv.core.Rect
import org.opencv.imgproc.Imgproc

/**
 * Autoajuste del joystick: a partir del cuadrado aproximado que marca el usuario, busca el círculo del
 * joystick (base) en una captura real con la transformada de Hough y devuelve el cuadrado centrado y del
 * tamaño exactos de ese círculo. Si no encuentra un círculo creíble devuelve null: nunca inventa uno.
 *
 * Precisión realista: unos pocos píxeles. Si el joystick del juego es muy translúcido o está tapado por el
 * dedo, puede no detectarse; entonces se mantiene el cuadrado marcado a mano.
 */
object LocalizadorJoystick {

    data class Resultado(val rect: NormRect, val radioPx: Double, val desplazamientoPx: Double)

    fun refinar(fotograma: Bitmap, zona: NormRect): Resultado? {
        if (!VisionEngine.inicializar()) return null
        val ancho = fotograma.width
        val alto = fotograma.height
        val zonaCx = (zona.x + zona.w / 2f) * ancho.toDouble()
        val zonaCy = (zona.y + zona.h / 2f) * alto.toDouble()
        val zonaR = min(zona.w * ancho, zona.h * alto) / 2.0
        if (zonaR < 8.0) return null

        // Región de búsqueda: algo mayor que lo marcado.
        val mitad = zonaR * 1.9
        val x0 = max(0.0, zonaCx - mitad).toInt()
        val y0 = max(0.0, zonaCy - mitad).toInt()
        val x1 = min(ancho.toDouble(), zonaCx + mitad).toInt()
        val y1 = min(alto.toDouble(), zonaCy + mitad).toInt()
        if (x1 - x0 < 32 || y1 - y0 < 32) return null

        val bgr = VisionEngine.matDesdeBitmap(fotograma)
        val gris = Mat()
        val suave = Mat()
        val circulos = Mat()
        try {
            val region = Mat(bgr, Rect(x0, y0, x1 - x0, y1 - y0))
            Imgproc.cvtColor(region, gris, Imgproc.COLOR_BGR2GRAY)
            region.release()
            Imgproc.medianBlur(gris, suave, 5)
            Imgproc.GaussianBlur(suave, suave, org.opencv.core.Size(5.0, 5.0), 1.5)
            Imgproc.HoughCircles(
                suave, circulos, Imgproc.HOUGH_GRADIENT, 1.2, zonaR * 0.25,
                90.0, 22.0,
                (zonaR * ElegirCirculoJoystick.RADIO_MINIMO).toInt(),
                (zonaR * ElegirCirculoJoystick.RADIO_MAXIMO).toInt()
            )
            val candidatos = ArrayList<Circulo>()
            for (i in 0 until circulos.cols()) {
                val v = circulos.get(0, i) ?: continue
                candidatos.add(Circulo(x0 + v[0], y0 + v[1], v[2], i))
            }
            val elegido = ElegirCirculoJoystick.elegir(candidatos, zonaCx, zonaCy, zonaR) ?: return null
            val lado = elegido.radio * 2.0
            val w = (lado / ancho).toFloat()
            val h = (lado / alto).toFloat()
            val rx = ((elegido.cx - elegido.radio) / ancho).toFloat().coerceIn(0f, 1f - w)
            val ry = ((elegido.cy - elegido.radio) / alto).toFloat().coerceIn(0f, 1f - h)
            return Resultado(NormRect(rx, ry, w, h), elegido.radio, ElegirCirculoJoystick.desplazamiento(elegido, zonaCx, zonaCy))
        } catch (e: Throwable) {
            return null
        } finally {
            bgr.release()
            gris.release()
            suave.release()
            circulos.release()
        }
    }
}
