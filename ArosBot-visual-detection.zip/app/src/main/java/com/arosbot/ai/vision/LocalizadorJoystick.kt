package com.arosbot.ai.vision

import android.graphics.Bitmap
import com.arosbot.ai.core.Circulo
import com.arosbot.ai.core.PuntoPx
import com.arosbot.ai.core.ElegirCirculoJoystick
import com.arosbot.ai.core.NormRect
import kotlin.math.max
import kotlin.math.min
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Rect
import org.opencv.imgproc.Imgproc

/**
 * Autoajuste del joystick: a partir del cuadrado aproximado que marca el usuario, busca el círculo del
 * joystick (base) en una captura real con la transformada de Hough y devuelve el cuadrado centrado y del
 * tamaño exactos de ese círculo. Si no encuentra un círculo creíble devuelve null: nunca inventa uno.
 *
 * Precisión realista: unos pocos píxeles. Si el joystick del juego es muy translúcido o está tapado por el
 * dedo, puede no detectarse; entonces se mantiene el cuadrado marcado a mano.
 */
object LocalizadorJoystick {

    data class Resultado(val rect: NormRect, val radioPx: Double, val desplazamientoPx: Double)

    fun refinar(fotograma: Bitmap, zona: NormRect): Resultado? {
        if (!VisionEngine.inicializar()) return null
        val ancho = fotograma.width
        val alto = fotograma.height
        val zonaCx = (zona.x + zona.w / 2f) * ancho.toDouble()
        val zonaCy = (zona.y + zona.h / 2f) * alto.toDouble()
        val zonaR = min(zona.w * ancho, zona.h * alto) / 2.0
        if (zonaR < 8.0) return null

        // Región de búsqueda: algo mayor que lo marcado.
        val mitad = zonaR * 1.9
        val x0 = max(0.0, zonaCx - mitad).toInt()
        val y0 = max(0.0, zonaCy - mitad).toInt()
        val x1 = min(ancho.toDouble(), zonaCx + mitad).toInt()
        val y1 = min(alto.toDouble(), zonaCy + mitad).toInt()
        if (x1 - x0 < 32 || y1 - y0 < 32) return null

        val bgr = VisionEngine.matDesdeBitmap(fotograma)
        val gris = Mat()
        val suave = Mat()
        val circulos = Mat()
        try {
            val region = Mat(bgr, Rect(x0, y0, x1 - x0, y1 - y0))
            Imgproc.cvtColor(region, gris, Imgproc.COLOR_BGR2GRAY)
            region.release()
            Imgproc.medianBlur(gris, suave, 5)
            Imgproc.GaussianBlur(suave, suave, org.opencv.core.Size(5.0, 5.0), 1.5)
            Imgproc.HoughCircles(
                suave, circulos, Imgproc.HOUGH_GRADIENT, 1.2, zonaR * 0.25,
                90.0, 22.0,
                (zonaR * ElegirCirculoJoystick.RADIO_MINIMO).toInt(),
                (zonaR * ElegirCirculoJoystick.RADIO_MAXIMO).toInt()
            )
            val candidatos = ArrayList<Circulo>()
            for (i in 0 until circulos.cols()) {
                val v = circulos.get(0, i) ?: continue
                candidatos.add(Circulo(x0 + v[0], y0 + v[1], v[2], i))
            }
            val elegido = ElegirCirculoJoystick.elegir(candidatos, zonaCx, zonaCy, zonaR) ?: return null
            val lado = elegido.radio * 2.0
            val w = (lado / ancho).toFloat()
            val h = (lado / alto).toFloat()
            val rx = ((elegido.cx - elegido.radio) / ancho).toFloat().coerceIn(0f, 1f - w)
            val ry = ((elegido.cy - elegido.radio) / alto).toFloat().coerceIn(0f, 1f - h)
            return Resultado(NormRect(rx, ry, w, h), elegido.radio, ElegirCirculoJoystick.desplazamiento(elegido, zonaCx, zonaCy))
        } catch (e: Throwable) {
            return null
        } finally {
            bgr.release()
            gris.release()
            suave.release()
            circulos.release()
        }
    }
}

/**
 * Localiza la bola del joystick empujada hacia cada dirección comparando cada fotograma con el de reposo.
 * De la diferencia con el reposo queda la bola en el centro (común a todas) y la bola en su nueva posición
 * (distinta en cada una): se quita lo común y se queda con el trozo compacto de mayor tamaño.
 */
object LocalizadorDePerilla {

    private const val UMBRAL_MINIMO = 14.0

    /** Posición (en píxeles del fotograma) de la bola en cada fotograma pulsado, o null si no se localiza. */
    fun localizar(
        reposo: Bitmap,
        pulsados: Map<String, Bitmap>,
        centroX: Double,
        centroY: Double,
        radioAproximado: Double
    ): Map<String, PuntoPx?> {
        val resultado = LinkedHashMap<String, PuntoPx?>()
        for (k in pulsados.keys) resultado[k] = null
        if (!VisionEngine.inicializar() || pulsados.isEmpty()) return resultado
        val ancho = reposo.width
        val alto = reposo.height
        val mitad = radioAproximado * 3.2
        val x0 = max(0.0, centroX - mitad).toInt()
        val y0 = max(0.0, centroY - mitad).toInt()
        val x1 = min(ancho.toDouble(), centroX + mitad).toInt()
        val y1 = min(alto.toDouble(), centroY + mitad).toInt()
        if (x1 - x0 < 32 || y1 - y0 < 32) return resultado
        val roi = Rect(x0, y0, x1 - x0, y1 - y0)

        val grisReposo = gris(reposo, roi)
        val mascaras = LinkedHashMap<String, Mat>()
        try {
            for ((k, bmp) in pulsados) {
                if (bmp.width != ancho || bmp.height != alto) continue
                val g = gris(bmp, roi)
                val dif = Mat()
                Core.absdiff(g, grisReposo, dif)
                Imgproc.GaussianBlur(dif, dif, org.opencv.core.Size(7.0, 7.0), 2.0)
                val minmax = Core.minMaxLoc(dif)
                val mascara = Mat()
                if (minmax.maxVal >= UMBRAL_MINIMO) {
                    val umbral = max(UMBRAL_MINIMO, minmax.maxVal * 0.45)
                    Imgproc.threshold(dif, mascara, umbral, 255.0, Imgproc.THRESH_BINARY)
                } else {
                    mascara.create(dif.size(), dif.type())
                    mascara.setTo(org.opencv.core.Scalar(0.0))
                }
                mascaras[k] = mascara
                g.release()
                dif.release()
            }
            if (mascaras.isEmpty()) return resultado

            // Lo común a todas las direcciones es la bola en su posición de reposo (y el ruido fijo).
            val comun = mascaras.values.first().clone()
            for (m in mascaras.values) Core.bitwise_and(comun, m, comun)
            val grande = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, org.opencv.core.Size(15.0, 15.0))
            Imgproc.dilate(comun, comun, grande)
            val abrir = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, org.opencv.core.Size(5.0, 5.0))

            for ((k, m) in mascaras) {
                val solo = Mat()
                Core.bitwise_not(comun, solo)
                Core.bitwise_and(m, solo, solo)
                Imgproc.morphologyEx(solo, solo, Imgproc.MORPH_OPEN, abrir)
                val p = mayorTrozoCompacto(solo, radioAproximado)
                resultado[k] = p?.let { PuntoPx(it.x + x0, it.y + y0) }
                solo.release()
            }
            comun.release()
            grande.release()
            abrir.release()
        } catch (e: Throwable) {
            for (k in resultado.keys) resultado[k] = null
        } finally {
            grisReposo.release()
            mascaras.values.forEach { it.release() }
        }
        return resultado
    }

    private fun gris(b: Bitmap, roi: Rect): Mat {
        val bgr = VisionEngine.matDesdeBitmap(b)
        val g = Mat()
        try {
            val region = Mat(bgr, roi)
            Imgproc.cvtColor(region, g, Imgproc.COLOR_BGR2GRAY)
            region.release()
            Imgproc.GaussianBlur(g, g, org.opencv.core.Size(5.0, 5.0), 1.2)
        } finally {
            bgr.release()
        }
        return g
    }

    /** Centroide del trozo más grande y razonablemente redondo (la bola), o null si no hay ninguno. */
    private fun mayorTrozoCompacto(mascara: Mat, radio: Double): PuntoPx? {
        val contornos = ArrayList<org.opencv.core.MatOfPoint>()
        val jerarquia = Mat()
        Imgproc.findContours(mascara, contornos, jerarquia, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        jerarquia.release()
        var mejor: PuntoPx? = null
        var mejorArea = 0.0
        for (c in contornos) {
            val area = Imgproc.contourArea(c)
            val c2f = org.opencv.core.MatOfPoint2f(*c.toArray())
            val perimetro = Imgproc.arcLength(c2f, true)
            c2f.release()
            val circularidad = if (perimetro <= 0.0) 0.0 else 4.0 * Math.PI * area / (perimetro * perimetro)
            if (area >= radio * radio * 0.03 && area <= radio * radio * 4.0 && circularidad >= 0.45 && area > mejorArea) {
                val mu = Imgproc.moments(c)
                if (mu.m00 > 0.0) {
                    mejorArea = area
                    mejor = PuntoPx(mu.m10 / mu.m00, mu.m01 / mu.m00)
                }
            }
            c.release()
        }
        return mejor
    }
}
