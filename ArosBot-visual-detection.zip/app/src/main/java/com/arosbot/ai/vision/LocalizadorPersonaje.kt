package com.arosbot.ai.vision

import android.graphics.Bitmap
import com.arosbot.ai.core.BotCore
import com.arosbot.ai.core.Box
import com.arosbot.ai.core.SelectorDeMateriales

/** Posición del personaje en un fotograma, en píxeles del fotograma. */
data class Localizacion(
    val centroX: Float,
    val centroY: Float,
    val confianza: Float,
    val caja: Box
)

/**
 * Localizador del personaje (módulo 5). Busca la imagen de referencia del personaje, que el usuario
 * importa en Materiales con la categoría «Personaje» (o con «personaje» en el nombre), con la misma
 * búsqueda de plantillas que el resto de materiales. Si no hay referencia o no se ve, devuelve null:
 * nunca inventa una posición.
 */
object LocalizadorPersonaje {

    fun hayReferencia(): Boolean =
        SelectorDeMateriales.personaje(BotCore.store.materiales.value) != null

    fun localizar(fotograma: Bitmap): Localizacion? {
        val material = SelectorDeMateriales.personaje(BotCore.store.materiales.value) ?: return null
        val resultado = Deteccion.enPantallaCompleta(
            fotograma,
            listOf(material),
            BotCore.store.directorioMateriales
        )
        val mejor = resultado.detecciones.maxByOrNull { it.score } ?: return null
        return Localizacion(
            (mejor.box.left + mejor.box.right) / 2f,
            (mejor.box.top + mejor.box.bottom) / 2f,
            mejor.score,
            mejor.box
        )
    }
}
