package com.arosbot.ai.vision

import android.graphics.BitmapFactory
import com.arosbot.ai.core.Material
import java.io.File
import org.opencv.core.Mat

/**
 * Mantiene cargadas las imágenes de referencia para no leerlas del disco en cada ciclo.
 * Cuando cambian los archivos de un material se descarta la versión anterior; no se libera
 * explícitamente porque un ciclo de detección en curso podría estar usándola (OpenCV libera
 * la memoria nativa cuando el recolector elimina la matriz).
 */
object PlantillaCache {

    private val cache = HashMap<String, List<Mat>>()

    @Synchronized
    fun obtener(material: Material, directorio: File): PlantillaCargada? {
        val prefijo = material.id.toString() + ":"
        val clave = prefijo + material.archivos.joinToString(",")
        var matrices = cache[clave]
        if (matrices == null) {
            cache.keys.filter { it.startsWith(prefijo) }.forEach { cache.remove(it) }
            VisionEngine.vaciarCachePlantillas()
            matrices = material.archivos.mapNotNull { cargar(File(directorio, it)) }
            cache[clave] = matrices
        }
        if (matrices.isEmpty()) return null
        return PlantillaCargada(material.id, material.nombre, material.umbral, matrices)
    }

    private fun cargar(archivo: File): Mat? {
        val bitmap = BitmapFactory.decodeFile(archivo.absolutePath) ?: return null
        val mat = VisionEngine.matDesdeBitmap(bitmap)
        bitmap.recycle()
        return mat
    }
}
