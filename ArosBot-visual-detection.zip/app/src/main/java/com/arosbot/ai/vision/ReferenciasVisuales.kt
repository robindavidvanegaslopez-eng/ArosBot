package com.arosbot.ai.vision

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.arosbot.ai.core.ReferenciaVisual
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.Rect
import org.opencv.imgproc.Imgproc

/**
 * Mapa visual del entorno (módulo 7): puntos de referencia hechos con recortes reales del juego.
 *
 * Al enseñar una ruta se guarda, de cuando en cuando, un recorte del fotograma tomado lejos del
 * personaje (que siempre está en el centro) y de los bordes (donde están los botones). Al volver a
 * pasar por ahí, se busca ese recorte con búsqueda de plantillas: dónde aparece ahora, comparado con
 * dónde estaba, dice cuánto se ha desplazado el personaje y corrige la deriva del cálculo de
 * movimiento. Si el lugar no se parece lo bastante, devuelve null: nunca inventa una posición.
 */
object ReferenciasVisuales {

    /** Zonas candidatas (x, y, ancho, alto, en fracción del fotograma). Se elige la de más textura. */
    private val CANDIDATOS = listOf(
        doubleArrayOf(0.35, 0.10, 0.30, 0.20),
        doubleArrayOf(0.08, 0.38, 0.30, 0.20),
        doubleArrayOf(0.62, 0.38, 0.30, 0.20)
    )

    /** Desviación típica mínima de grises para que un recorte sirva (un fondo liso no se reconoce). */
    private const val TEXTURA_MINIMA = 12.0

    /** Cuánto se busca alrededor de la posición original, en fracción del fotograma. */
    private const val MARGEN_X = 0.30
    private const val MARGEN_Y = 0.25

    /**
     * Desplazamiento de la escena respecto a cuando se guardó la referencia (en píxeles del
     * fotograma) y confianza de la búsqueda, de 0 a 1.
     */
    data class Hallazgo(val dx: Double, val dy: Double, val confianza: Double)

    /** Guarda un recorte del fotograma como referencia. Devuelve null si no hay zona con textura. */
    fun capturar(fotograma: Bitmap, directorio: File): ReferenciaVisual? {
        if (!VisionEngine.inicializar()) return null
        return try {
            VisionEngine.preparar(fotograma).use { escena ->
                var mejor: Rect? = null
                var mejorTextura = 0.0
                for (c in CANDIDATOS) {
                    val r = rectangulo(c, escena.ancho, escena.alto) ?: continue
                    val textura = textura(escena.bgr, r)
                    if (textura > mejorTextura) {
                        mejorTextura = textura
                        mejor = r
                    }
                }
                val zona = mejor
                if (zona == null || mejorTextura < TEXTURA_MINIMA) {
                    null
                } else {
                    directorio.mkdirs()
                    val recorte = Bitmap.createBitmap(fotograma, zona.x, zona.y, zona.width, zona.height)
                    val nombre = "ref_" + UUID.randomUUID().toString() + ".png"
                    FileOutputStream(File(directorio, nombre)).use {
                        recorte.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                    recorte.recycle()
                    ReferenciaVisual(nombre, zona.x, zona.y, zona.width, zona.height)
                }
            }
        } catch (e: Throwable) {
            null
        }
    }

    /**
     * Recortes ya decodificados, para no leer el archivo cada vez: al seguir una ruta se busca un ancla
     * varias veces por segundo. Se vacía al pasar de [MAX_EN_CACHE].
     */
    private val cache = object : LinkedHashMap<String, Mat>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Mat>?): Boolean {
            if (size > MAX_EN_CACHE) {
                eldest?.value?.release()
                return true
            }
            return false
        }
    }
    private const val MAX_EN_CACHE = 80

    @Synchronized
    private fun parche(referencia: ReferenciaVisual, directorio: File): Mat? {
        cache[referencia.archivo]?.let { return it }
        val archivo = File(directorio, referencia.archivo)
        val imagen = BitmapFactory.decodeFile(archivo.absolutePath) ?: return null
        val mat = VisionEngine.matDesdeBitmap(imagen)
        imagen.recycle()
        cache[referencia.archivo] = mat
        return mat
    }

    /** Olvida los recortes en memoria (al borrar una ruta). */
    @Synchronized
    fun vaciarCache() {
        cache.values.forEach { it.release() }
        cache.clear()
    }

    /** Busca la referencia en el fotograma actual. null si no se encuentra o no se puede leer. */
    @Synchronized
    fun reconocer(fotograma: Bitmap, referencia: ReferenciaVisual, directorio: File): Hallazgo? {
        if (!VisionEngine.inicializar()) return null
        val parche = parche(referencia, directorio) ?: return null
        return try {
            VisionEngine.preparar(fotograma).use { escena -> buscar(escena, parche, referencia) }
        } catch (e: Throwable) {
            null
        }
    }

    private fun buscar(escena: Escena, parche: Mat, referencia: ReferenciaVisual): Hallazgo? {
        val mx = (MARGEN_X * escena.ancho).toInt()
        val my = (MARGEN_Y * escena.alto).toInt()
        val x0 = maxOf(0, referencia.sx - mx)
        val y0 = maxOf(0, referencia.sy - my)
        val x1 = minOf(escena.ancho, referencia.sx + parche.cols() + mx)
        val y1 = minOf(escena.alto, referencia.sy + parche.rows() + my)
        if (x1 - x0 <= parche.cols() || y1 - y0 <= parche.rows()) return null

        val ventana = Mat(escena.bgr, Rect(x0, y0, x1 - x0, y1 - y0))
        val resultado = Mat()
        try {
            Imgproc.matchTemplate(ventana, parche, resultado, Imgproc.TM_CCOEFF_NORMED)
            Core.patchNaNs(resultado, 0.0)
            val mejor = Core.minMaxLoc(resultado)
            val x = x0 + mejor.maxLoc.x
            val y = y0 + mejor.maxLoc.y
            return Hallazgo(x - referencia.sx, y - referencia.sy, mejor.maxVal)
        } finally {
            ventana.release()
            resultado.release()
        }
    }

    private fun rectangulo(c: DoubleArray, ancho: Int, alto: Int): Rect? {
        val x = (c[0] * ancho).toInt().coerceIn(0, ancho - 1)
        val y = (c[1] * alto).toInt().coerceIn(0, alto - 1)
        val w = (c[2] * ancho).toInt().coerceAtMost(ancho - x)
        val h = (c[3] * alto).toInt().coerceAtMost(alto - y)
        if (w < 24 || h < 24) return null
        return Rect(x, y, w, h)
    }

    private fun textura(bgr: Mat, zona: Rect): Double {
        val recorte = Mat(bgr, zona)
        val gris = Mat()
        val media = MatOfDouble()
        val desviacion = MatOfDouble()
        try {
            Imgproc.cvtColor(recorte, gris, Imgproc.COLOR_BGR2GRAY)
            Core.meanStdDev(gris, media, desviacion)
            return desviacion.get(0, 0)[0]
        } finally {
            gris.release()
            media.release()
            desviacion.release()
        }
    }
}
