package com.arosbot.ai.vision

import org.opencv.core.Mat

/**
 * Seguidor de un objeto por plantilla local con apariencia adaptable: busca en cada fotograma solo cerca
 * de donde debería estar y, cuando lo reconoce con mucha seguridad, renueva su plantilla con lo que ve
 * ahora. Así tolera que al acercarse cambie la textura, el tamaño o la animación (el problema de usar
 * solo la imagen de referencia original). También prueba siempre la original.
 */
class SeguidorLocal(inicial: Mat, private val umbralAdaptar: Double = 0.8) {

    private val original: Mat = inicial
    private var actual: Mat = inicial.clone()

    val ancho: Int get() = original.cols()
    val alto: Int get() = original.rows()

    class Hallazgo(val centroX: Double, val centroY: Double, val score: Double)

    fun buscar(escena: Escena, cx: Double, cy: Double, radio: Int): Hallazgo? {
        val a = VisionEngine.buscarLocal(escena, actual, cx, cy, radio)
        val b = VisionEngine.buscarLocal(escena, original, cx, cy, radio)
        val usar = listOfNotNull(a?.let { Pair(it, actual) }, b?.let { Pair(it, original) })
            .maxByOrNull { it.first.score } ?: return null
        val r = usar.first
        if (r.score >= umbralAdaptar) {
            val nueva = VisionEngine.recortar(
                escena, com.arosbot.ai.core.Box(r.x, r.y, r.x + ancho, r.y + alto)
            )
            if (nueva != null && nueva.cols() == ancho && nueva.rows() == alto) {
                actual.release()
                actual = nueva
            } else {
                nueva?.release()
            }
        }
        return Hallazgo(r.x + ancho / 2.0, r.y + alto / 2.0, r.score)
    }

    fun liberar() {
        actual.release()
        original.release()
    }
}
