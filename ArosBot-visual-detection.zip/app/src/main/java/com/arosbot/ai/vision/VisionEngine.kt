package com.arosbot.ai.vision

import android.graphics.Bitmap
import com.arosbot.ai.core.Box
import com.arosbot.ai.core.Detection
import com.arosbot.ai.core.Nms
import kotlin.math.abs
import kotlin.math.roundToInt
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/** Imágenes de un material ya cargadas como matrices de OpenCV (BGR). */
class PlantillaCargada(
    val materialId: Long,
    val nombre: String,
    val umbral: Float,
    val variantes: List<Mat>
)

/** Fotograma convertido a BGR, listo para buscar en él. Cerrar siempre con use { }. */
class Escena(val bgr: Mat) : AutoCloseable {
    val ancho: Int get() = bgr.cols()
    val alto: Int get() = bgr.rows()

    override fun close() {
        bgr.release()
    }
}

/**
 * Motor de visión artificial (módulo 2).
 *
 * Técnica: búsqueda de plantillas multiescala con correlación normalizada en color
 * (TM_CCOEFF_NORMED sobre 3 canales). Encuentra varios ejemplares por captura, tolera
 * pequeños cambios de tamaño y elimina duplicados con supresión de no máximos.
 */
object VisionEngine {

    private val ESCALAS = floatArrayOf(0.8f, 0.9f, 1.0f, 1.12f, 1.25f)
    private val ESCALAS_RAPIDAS = floatArrayOf(0.9f, 1.0f, 1.12f)
    private const val MAX_PICOS_POR_ESCALA = 12
    private const val MAX_PICOS_RAPIDO = 6

    /** Reducción de la escena y las plantillas en el modo rápido (la correlación cuesta ~1/16). */
    const val REDUCCION_RAPIDA = 0.5f

    /** Plantillas ya redimensionadas (clave: imagen + tamaño) para no rehacerlas en cada fotograma. */
    private val cachePlantillas = object : LinkedHashMap<String, Mat>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Mat>?): Boolean {
            if (size > 160) {
                eldest?.value?.release()
                return true
            }
            return false
        }
    }

    @Synchronized
    fun plantillaRedimensionada(imagen: Mat, tw: Int, th: Int): Mat {
        val clave = "${System.identityHashCode(imagen)}:${imagen.nativeObj}:$tw:$th"
        cachePlantillas[clave]?.let { return it }
        val m = Mat()
        Imgproc.resize(imagen, m, Size(tw.toDouble(), th.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
        cachePlantillas[clave] = m
        return m
    }

    @Synchronized
    fun vaciarCachePlantillas() {
        for (m in cachePlantillas.values) m.release()
        cachePlantillas.clear()
    }
    private const val TAMANO_MINIMO_PLANTILLA = 6
    private const val TAMANO_MINIMO_REGION = 16
    private const val IOU_DUPLICADOS = 0.3f

    @Volatile
    var disponible: Boolean = false
        private set

    /** Carga la biblioteca nativa de OpenCV. Es seguro llamarla varias veces. */
    @Synchronized
    fun inicializar(): Boolean {
        if (disponible) return true
        disponible = try {
            OpenCVLoader.initLocal()
        } catch (e: Throwable) {
            false
        }
        return disponible
    }

    /** Mejor coincidencia local: esquina superior izquierda y puntuación. */
    class ResultadoLocal(val x: Int, val y: Int, val score: Double)

    /**
     * Busca [plantilla] solo en un entorno de [radio] px alrededor de ([cx], [cy]) (centro esperado). Es
     * mucho más barato que buscar en toda la pantalla: sirve para seguir un objeto en cada fotograma.
     */
    fun buscarLocal(escena: Escena, plantilla: Mat, cx: Double, cy: Double, radio: Int): ResultadoLocal? {
        val tw = plantilla.cols()
        val th = plantilla.rows()
        val x0 = (cx - tw / 2.0 - radio).toInt().coerceAtLeast(0)
        val y0 = (cy - th / 2.0 - radio).toInt().coerceAtLeast(0)
        val x1 = (cx + tw / 2.0 + radio).toInt().coerceAtMost(escena.ancho)
        val y1 = (cy + th / 2.0 + radio).toInt().coerceAtMost(escena.alto)
        if (x1 - x0 <= tw || y1 - y0 <= th) return null
        val roi = Mat(escena.bgr, Rect(x0, y0, x1 - x0, y1 - y0))
        val res = Mat()
        try {
            Imgproc.matchTemplate(roi, plantilla, res, Imgproc.TM_CCOEFF_NORMED)
            Core.patchNaNs(res, 0.0)
            val mm = Core.minMaxLoc(res)
            return ResultadoLocal(x0 + mm.maxLoc.x.toInt(), y0 + mm.maxLoc.y.toInt(), mm.maxVal)
        } finally {
            roi.release()
            res.release()
        }
    }

    /** Copia independiente de una región de la escena (null si queda fuera). */
    fun recortar(escena: Escena, caja: Box): Mat? {
        val c = caja.recortar(escena.ancho, escena.alto)
        if (c.width < 4 || c.height < 4) return null
        val m = Mat(escena.bgr, Rect(c.left, c.top, c.width, c.height))
        val copia = m.clone()
        m.release()
        return copia
    }

    fun matDesdeBitmap(bitmap: Bitmap): Mat {
        val rgba = Mat()
        val bgr = Mat()
        try {
            Utils.bitmapToMat(bitmap, rgba)
            Imgproc.cvtColor(rgba, bgr, Imgproc.COLOR_RGBA2BGR)
        } finally {
            rgba.release()
        }
        return bgr
    }

    fun preparar(fotograma: Bitmap): Escena = Escena(matDesdeBitmap(fotograma))

    /**
     * Busca todas las [plantillas] en [region] de la [escena] (o en toda ella si es null).
     * [escalaBase] relaciona el tamaño de las imágenes de referencia con el del fotograma.
     * Devuelve cajas en coordenadas del fotograma completo, sin duplicados.
     */
    fun buscar(
        escena: Escena,
        region: Box?,
        plantillas: List<PlantillaCargada>,
        escalaBase: Float,
        rapido: Boolean = false
    ): List<Detection> {
        val caja = (region ?: Box(0, 0, escena.ancho, escena.alto)).recortar(escena.ancho, escena.alto)
        if (caja.width < TAMANO_MINIMO_REGION || caja.height < TAMANO_MINIMO_REGION) {
            return emptyList()
        }
        val detecciones = ArrayList<Detection>()
        val roiCompleto = Mat(escena.bgr, Rect(caja.left, caja.top, caja.width, caja.height))
        // Modo rápido: se busca sobre una copia a la mitad de tamaño y se devuelven las cajas ampliadas.
        val r = if (rapido) REDUCCION_RAPIDA else 1f
        val roi = if (rapido) {
            val m = Mat()
            Imgproc.resize(roiCompleto, m, Size(), r.toDouble(), r.toDouble(), Imgproc.INTER_AREA)
            m
        } else roiCompleto
        val escalas = if (rapido) ESCALAS_RAPIDAS else ESCALAS
        val picos = if (rapido) MAX_PICOS_RAPIDO else MAX_PICOS_POR_ESCALA
        try {
            for (plantilla in plantillas) {
                for (imagen in plantilla.variantes) {
                    for (s in escalas) {
                        val factor = escalaBase * s * r
                        val tw = (imagen.cols() * factor).roundToInt()
                        val th = (imagen.rows() * factor).roundToInt()
                        if (tw < (if (rapido) 4 else TAMANO_MINIMO_PLANTILLA) ||
                            th < (if (rapido) 4 else TAMANO_MINIMO_PLANTILLA)
                        ) continue
                        if (tw >= roi.cols() || th >= roi.rows()) continue
                        buscarEscala(roi, imagen, tw, th, plantilla, caja, detecciones, r, picos, rapido)
                    }
                }
            }
        } finally {
            if (rapido) roi.release()
            roiCompleto.release()
        }
        return Nms.suprimir(detecciones, IOU_DUPLICADOS, soloMismoMaterial = true)
    }

    private fun buscarEscala(
        roi: Mat,
        imagen: Mat,
        tw: Int,
        th: Int,
        plantilla: PlantillaCargada,
        caja: Box,
        salida: MutableList<Detection>,
        reduccion: Float,
        maxPicos: Int,
        rapido: Boolean
    ) {
        var redimensionada: Mat? = null
        val resultado = Mat()
        try {
            val plantillaEscalada = if (rapido) {
                plantillaRedimensionada(imagen, tw, th)
            } else {
                Mat().also {
                    redimensionada = it
                    Imgproc.resize(imagen, it, Size(tw.toDouble(), th.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
                }
            }
            Imgproc.matchTemplate(roi, plantillaEscalada, resultado, Imgproc.TM_CCOEFF_NORMED)
            Core.patchNaNs(resultado, 0.0)
            val inv = 1f / reduccion

            for (k in 0 until maxPicos) {
                val mm = Core.minMaxLoc(resultado)
                if (mm.maxVal < plantilla.umbral) break
                val px = mm.maxLoc.x.toInt()
                val py = mm.maxLoc.y.toInt()
                salida.add(
                    Detection(
                        materialId = plantilla.materialId,
                        nombre = plantilla.nombre,
                        box = Box(
                            caja.left + (px * inv).roundToInt(),
                            caja.top + (py * inv).roundToInt(),
                            caja.left + ((px + tw) * inv).roundToInt(),
                            caja.top + ((py + th) * inv).roundToInt()
                        ),
                        score = mm.maxVal.toFloat()
                    )
                )
                // Anular el entorno del pico encontrado para localizar el siguiente ejemplar.
                val x0 = maxOf(0, px - tw / 2)
                val y0 = maxOf(0, py - th / 2)
                val x1 = minOf(resultado.cols() - 1, px + tw / 2)
                val y1 = minOf(resultado.rows() - 1, py + th / 2)
                Imgproc.rectangle(
                    resultado,
                    Point(x0.toDouble(), y0.toDouble()),
                    Point(x1.toDouble(), y1.toDouble()),
                    Scalar(-1.0),
                    -1
                )
            }
        } finally {
            redimensionada?.release()
            resultado.release()
        }
    }

    /**
     * Autoprueba real en el dispositivo: carga OpenCV, crea una escena de ruido, recorta una
     * plantilla de ella y comprueba que [buscar] la encuentra en su posición exacta.
     */
    fun autoprueba(): Boolean {
        if (!inicializar()) return false
        val ruido = Mat(240, 320, CvType.CV_8UC3)
        val plantillaMat = Mat()
        return try {
            Core.randu(ruido, 0.0, 255.0)
            val recorte = Mat(ruido, Rect(100, 70, 48, 48))
            recorte.copyTo(plantillaMat)
            recorte.release()
            val plantilla = PlantillaCargada(0L, "autoprueba", 0.9f, listOf(plantillaMat))
            val encontradas = buscar(Escena(ruido), null, listOf(plantilla), 1f)
            val mejor = encontradas.maxByOrNull { it.score }
            mejor != null &&
                mejor.score > 0.99f &&
                abs(mejor.box.left - 100) <= 1 &&
                abs(mejor.box.top - 70) <= 1
        } catch (e: Throwable) {
            false
        } finally {
            plantillaMat.release()
            ruido.release()
        }
    }
}
