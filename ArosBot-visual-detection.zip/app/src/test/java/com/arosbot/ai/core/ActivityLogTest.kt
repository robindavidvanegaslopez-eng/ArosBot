package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ActivityLogTest {

    @Test
    fun conservaSoloLasUltimasEntradas() {
        val log = ActivityLog(null, capacity = 3)
        for (i in 1..5) log.info("prueba", "mensaje $i")

        val entradas = log.entries.value
        assertEquals(3, entradas.size)
        assertEquals("mensaje 3", entradas.first().message)
        assertEquals("mensaje 5", entradas.last().message)
    }

    @Test
    fun registraNivelYOrigen() {
        val log = ActivityLog(null)
        log.aviso("Origen", "texto")
        log.error("Origen", "fallo")

        val entradas = log.entries.value
        assertEquals(LogLevel.AVISO, entradas[0].level)
        assertEquals(LogLevel.ERROR, entradas[1].level)
        assertTrue(entradas[1].format().contains("[ERROR] Origen: fallo"))
    }

    @Test
    fun limpiarVaciaLaLista() {
        val log = ActivityLog(null)
        log.info("a", "b")
        log.clear()
        assertTrue(log.entries.value.isEmpty())
    }
}
