package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class AjusteJoystickTest {

    @Test
    fun sinCandidatosNoHayResultado() {
        assertNull(ElegirCirculoJoystick.elegir(emptyList(), 300.0, 800.0, 150.0))
    }

    @Test
    fun prefiereLaBaseGrandeSobreLaBolaInterior() {
        val base = Circulo(305.0, 802.0, 150.0, 1)
        val bola = Circulo(300.0, 800.0, 60.0, 0)
        val e = ElegirCirculoJoystick.elegir(listOf(bola, base), 300.0, 800.0, 140.0)!!
        assertEquals(150.0, e.radio, 1e-9)
    }

    @Test
    fun descartaCirculosLejosDeLaZonaMarcada() {
        val lejos = Circulo(900.0, 300.0, 140.0, 0)
        assertNull(ElegirCirculoJoystick.elegir(listOf(lejos), 300.0, 800.0, 140.0))
    }

    @Test
    fun descartaTamanosDisparatados() {
        val enorme = Circulo(300.0, 800.0, 400.0, 0)
        val diminuto = Circulo(300.0, 800.0, 10.0, 1)
        assertNull(ElegirCirculoJoystick.elegir(listOf(enorme, diminuto), 300.0, 800.0, 140.0))
    }

    @Test
    fun entreRadiosParecidosGanaElMejorPuntuado() {
        val a = Circulo(300.0, 800.0, 150.0, 2)
        val b = Circulo(302.0, 801.0, 152.0, 0)
        val e = ElegirCirculoJoystick.elegir(listOf(a, b), 300.0, 800.0, 140.0)!!
        assertEquals(0, e.rango)
    }

    @Test
    fun soloSeConsideranLosMejoresCandidatos() {
        val ruido = List(ElegirCirculoJoystick.CANDIDATOS_CONSIDERADOS) { Circulo(900.0 + it, 100.0, 140.0, it) }
        val bueno = Circulo(300.0, 800.0, 140.0, ElegirCirculoJoystick.CANDIDATOS_CONSIDERADOS + 3)
        assertNull(ElegirCirculoJoystick.elegir(ruido + bueno, 300.0, 800.0, 140.0))
    }

    @Test
    fun medidasAuxiliares() {
        val c = Circulo(303.0, 804.0, 150.0, 0)
        assertEquals(5.0, ElegirCirculoJoystick.desplazamiento(c, 300.0, 800.0), 1e-9)
        assertEquals(10.0, ElegirCirculoJoystick.cambioDeRadio(c, 140.0), 1e-9)
        assertNotNull(ElegirCirculoJoystick.elegir(listOf(c), 300.0, 800.0, 140.0))
    }
}
