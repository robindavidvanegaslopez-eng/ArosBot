package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class AjusteJoystickTest {

    @Test
    fun sinCandidatosNoHayResultado() {
        assertNull(ElegirCirculoJoystick.elegir(emptyList(), 300.0, 800.0, 150.0))
    }

    @Test
    fun prefiereLaBaseGrandeSobreLaBolaInterior() {
        val base = Circulo(305.0, 802.0, 150.0, 1)
        val bola = Circulo(300.0, 800.0, 60.0, 0)
        val e = ElegirCirculoJoystick.elegir(listOf(bola, base), 300.0, 800.0, 140.0)!!
        assertEquals(150.0, e.radio, 1e-9)
    }

    @Test
    fun repetirElAjusteNoHaceCrecerElCirculo() {
        val base = Circulo(300.0, 800.0, 150.0, 1)
        val fondo = Circulo(300.0, 800.0, 235.0, 0)
        var zona = 140.0
        repeat(5) {
            val e = ElegirCirculoJoystick.elegir(listOf(fondo, base), 300.0, 800.0, zona)!!
            zona = e.radio
        }
        assertEquals(150.0, zona, 1e-9)
    }

    @Test
    fun descartaCirculosLejosDeLaZonaMarcada() {
        val lejos = Circulo(900.0, 300.0, 140.0, 0)
        assertNull(ElegirCirculoJoystick.elegir(listOf(lejos), 300.0, 800.0, 140.0))
    }

    @Test
    fun descartaTamanosDisparatados() {
        val enorme = Circulo(300.0, 800.0, 400.0, 0)
        val diminuto = Circulo(300.0, 800.0, 10.0, 1)
        assertNull(ElegirCirculoJoystick.elegir(listOf(enorme, diminuto), 300.0, 800.0, 140.0))
    }

    @Test
    fun entreRadiosParecidosGanaElMejorPuntuado() {
        val a = Circulo(300.0, 800.0, 150.0, 2)
        val b = Circulo(302.0, 801.0, 152.0, 0)
        val e = ElegirCirculoJoystick.elegir(listOf(a, b), 300.0, 800.0, 140.0)!!
        assertEquals(0, e.rango)
    }

    @Test
    fun soloSeConsideranLosMejoresCandidatos() {
        val ruido = List(ElegirCirculoJoystick.CANDIDATOS_CONSIDERADOS) { Circulo(900.0 + it, 100.0, 140.0, it) }
        val bueno = Circulo(300.0, 800.0, 140.0, ElegirCirculoJoystick.CANDIDATOS_CONSIDERADOS + 3)
        assertNull(ElegirCirculoJoystick.elegir(ruido + bueno, 300.0, 800.0, 140.0))
    }

    @Test
    fun medidasAuxiliares() {
        val c = Circulo(303.0, 804.0, 150.0, 0)
        assertEquals(5.0, ElegirCirculoJoystick.desplazamiento(c, 300.0, 800.0), 1e-9)
        assertEquals(10.0, ElegirCirculoJoystick.cambioDeRadio(c, 140.0), 1e-9)
        assertNotNull(ElegirCirculoJoystick.elegir(listOf(c), 300.0, 800.0, 140.0))
    }
}

class AjusteActivoJoystickTest {

    private fun cruz(cx: Double, cy: Double, r: Double) = listOf(
        PuntoPx(cx + r, cy), PuntoPx(cx - r, cy), PuntoPx(cx, cy - r), PuntoPx(cx, cy + r)
    )

    @Test
    fun cruzPerfectaDaCentroYRadio() {
        val (d, a, w, s) = cruz(200.0, 480.0, 90.0)
        val m = AjusteActivoJoystick.calcular(d, a, w, s).medida!!
        assertEquals(200.0, m.cx, 1e-9)
        assertEquals(480.0, m.cy, 1e-9)
        assertEquals(90.0, m.radio, 1e-9)
    }

    @Test
    fun faltaUnaDireccionNoDaMedida() {
        val (d, a, w, _) = cruz(200.0, 480.0, 90.0)
        val r = AjusteActivoJoystick.calcular(d, a, w, null)
        assertNull(r.medida)
        assertEquals(true, r.motivo!!.contains("abajo"))
    }

    @Test
    fun radiosHorizontalYVerticalQueNoCoincidenSeRechaza() {
        val r = AjusteActivoJoystick.calcular(
            PuntoPx(300.0, 480.0), PuntoPx(100.0, 480.0), PuntoPx(200.0, 430.0), PuntoPx(200.0, 530.0)
        )
        assertNull(r.medida)
    }

    @Test
    fun posicionesFueraDeLaCruzSeRechazan() {
        val r = AjusteActivoJoystick.calcular(
            PuntoPx(290.0, 560.0), PuntoPx(110.0, 480.0), PuntoPx(200.0, 390.0), PuntoPx(200.0, 570.0)
        )
        assertNull(r.medida)
    }

    @Test
    fun bolaQuieta() {
        val r = AjusteActivoJoystick.calcular(
            PuntoPx(201.0, 480.0), PuntoPx(199.0, 480.0), PuntoPx(200.0, 479.0), PuntoPx(200.0, 481.0)
        )
        assertNull(r.medida)
    }

    @Test
    fun rectNormalizadoCentradoEnLaMedida() {
        val m = MedidaJoystick(200.0, 480.0, 90.0, 0.0)
        val r = m.aRect(1356, 610)
        assertEquals((200.0 - 90.0) / 1356, r.x.toDouble(), 1e-6)
        assertEquals(180.0 / 610, r.h.toDouble(), 1e-6)
    }

    @Test
    fun tramoDeConduccionJusto() {
        // Recorrido largo: algo más lento que la pulsación corta pero en la dirección correcta.
        assertNull(EvaluadorProgreso.tramoCorrecto(0.0, -150.0, 0.0, -226.0))
        // Demasiado poco.
        assertEquals(true, EvaluadorProgreso.tramoCorrecto(0.0, -20.0, 0.0, -226.0)!!.contains("poco"))
        // Dirección equivocada.
        assertEquals("fue en otra dirección", EvaluadorProgreso.tramoCorrecto(150.0, 0.0, 0.0, -226.0))
        // Más de lo esperado ya no es fallo.
        assertNull(EvaluadorProgreso.tramoCorrecto(0.0, -600.0, 0.0, -226.0))
    }
}
