package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pruebas de LÓGICA en entorno simulado (JVM). No prueban nada dentro del juego.
 */
class BotStateMachineTest {

    private fun nueva() = BotStateMachine(ActivityLog(null))

    @Test
    fun empiezaDetenido() {
        assertEquals(BotState.DETENIDO, nueva().state.value)
    }

    @Test
    fun aceptaTransicionPermitida() {
        val m = nueva()
        assertTrue(m.transition(BotState.PREPARANDO, "inicio"))
        assertTrue(m.transition(BotState.ACTIVO, "listo"))
        assertEquals(BotState.ACTIVO, m.state.value)
        assertEquals("listo", m.reason.value)
    }

    @Test
    fun rechazaTransicionNoPermitida() {
        val m = nueva()
        assertFalse(m.transition(BotState.ACTIVO, "salto indebido"))
        assertEquals(BotState.DETENIDO, m.state.value)
    }

    @Test
    fun paradaDeEmergenciaFuncionaDesdeDetenidoYDesdeActivo() {
        val desdeDetenido = nueva()
        desdeDetenido.emergencyStop()
        assertEquals(BotState.PARADA_EMERGENCIA, desdeDetenido.state.value)

        val desdeActivo = nueva()
        desdeActivo.transition(BotState.PREPARANDO, "x")
        desdeActivo.transition(BotState.ACTIVO, "x")
        desdeActivo.emergencyStop("prueba")
        assertEquals(BotState.PARADA_EMERGENCIA, desdeActivo.state.value)
        assertEquals("prueba", desdeActivo.reason.value)
    }

    @Test
    fun trasParadaDeEmergenciaSoloSePuedeIrADetenido() {
        val m = nueva()
        m.emergencyStop()
        assertFalse(m.transition(BotState.ACTIVO, "no"))
        assertFalse(m.transition(BotState.PREPARANDO, "no"))
        assertTrue(m.stop("restablecer"))
        assertEquals(BotState.DETENIDO, m.state.value)
    }

    @Test
    fun paradaDeEmergenciaEjecutaTodosLosGanchosAunqueUnoFalle() {
        val m = nueva()
        var primero = 0
        var tercero = 0
        m.registrarGanchoDeParada("primero") { primero++ }
        m.registrarGanchoDeParada("falla") { throw IllegalStateException("fallo simulado") }
        m.registrarGanchoDeParada("tercero") { tercero++ }

        m.emergencyStop()

        assertEquals(1, primero)
        assertEquals(1, tercero)
        assertEquals(BotState.PARADA_EMERGENCIA, m.state.value)
    }

    @Test
    fun detenerLiberaEntradas() {
        val m = nueva()
        var liberadas = 0
        m.registrarGanchoDeParada("entradas") { liberadas++ }
        m.transition(BotState.PREPARANDO, "x")
        m.transition(BotState.ACTIVO, "x")

        assertTrue(m.stop("fin"))

        assertEquals(1, liberadas)
        assertEquals(BotState.DETENIDO, m.state.value)
    }

    @Test
    fun fallarDetieneYLiberaEntradas() {
        val m = nueva()
        var liberadas = 0
        m.registrarGanchoDeParada("entradas") { liberadas++ }
        m.transition(BotState.PREPARANDO, "x")
        m.transition(BotState.ACTIVO, "x")

        assertTrue(m.fail("captura perdida"))

        assertEquals(1, liberadas)
        assertEquals(BotState.DETENIDO_POR_ERROR, m.state.value)
        assertEquals("captura perdida", m.reason.value)
    }

    @Test
    fun detenerEstandoDetenidoNoHaceNada() {
        val m = nueva()
        var liberadas = 0
        m.registrarGanchoDeParada("entradas") { liberadas++ }
        assertFalse(m.stop("nada que detener"))
        assertEquals(0, liberadas)
    }
}
