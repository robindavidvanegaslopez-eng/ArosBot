package com.arosbot.ai.core

import kotlin.math.PI
import kotlin.math.hypot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas de LÓGICA en entorno simulado (JVM): conducción continua del joystick. No prueban el juego. */
class ConduccionTest {

    private fun p(x: Double, y: Double) = PuntoDeRuta(x, y, 0L)

    @Test
    fun todosLosPuntosDelArcoEstanEnElBorde() {
        val pts = ArcoDeJoystick.deslizar(500f, 900f, 120f, 0.0, PI * 0.9)
        assertTrue(pts.size > 1)
        for (q in pts) assertEquals(120.0, hypot((q.x - 500f).toDouble(), (q.y - 900f).toDouble()), 0.01)
    }

    @Test
    fun elArcoTerminaEnElRumboPedido() {
        val pts = ArcoDeJoystick.deslizar(0f, 0f, 100f, 0.0, PI / 2)
        val fin = pts.last()
        assertEquals(0.0, fin.x.toDouble(), 0.01)
        assertEquals(100.0, fin.y.toDouble(), 0.01)
    }

    @Test
    fun elArcoVaPorElCaminoCortoAunqueCruceElCero() {
        val pts = ArcoDeJoystick.deslizar(0f, 0f, 100f, 0.1, 2 * PI - 0.1)
        // Del ángulo 0.1 al -0.1: cambio de 0.2 rad, no de casi 2π.
        assertTrue(pts.size <= 2)
    }

    @Test
    fun sinCambioDeRumboElDedoSeMueveUnPixel() {
        val pts = ArcoDeJoystick.deslizar(0f, 0f, 120f, 1.0, 1.0)
        assertEquals(1, pts.size)
        val ant = ArcoDeJoystick.punto(0f, 0f, 120f, 1.0)
        val mov = hypot((pts[0].x - ant.x).toDouble(), (pts[0].y - ant.y).toDouble())
        assertTrue(mov in 0.5..2.0)
    }

    @Test
    fun diferenciaDeAngulosNormalizada() {
        assertEquals(0.2, ArcoDeJoystick.diferencia(2 * PI - 0.1, 0.1), 1e-9)
        assertEquals(-0.2, ArcoDeJoystick.diferencia(0.1, 2 * PI - 0.1), 1e-9)
    }

    @Test
    fun conDiagonalesApuntaAlAnguloExacto() {
        val r = PilotoDeRumbo(true).rumbo(100.0, 100.0)
        assertEquals(PI / 4, r, 1e-9)
    }

    @Test
    fun sinDiagonalesSoloUsaLosCuatroEjes() {
        val piloto = PilotoDeRumbo(false)
        assertEquals(0.0, piloto.rumbo(100.0, 20.0), 1e-9)
        val vertical = PilotoDeRumbo(false)
        assertEquals(-PI / 2, vertical.rumbo(10.0, -200.0), 1e-9)
    }

    @Test
    fun laHisteresisEvitaCambiarDeEjeAcadaFotograma() {
        val piloto = PilotoDeRumbo(false)
        assertEquals(0.0, piloto.rumbo(100.0, 90.0), 1e-9)
        // Casi empate: sigue en horizontal.
        assertEquals(0.0, piloto.rumbo(95.0, 100.0), 1e-9)
        // Claramente más lejos en vertical: cambia.
        assertEquals(PI / 2, piloto.rumbo(40.0, 200.0), 1e-9)
    }

    @Test
    fun avanzaAlPuntoSiguienteAlLlegar() {
        val pts = listOf(p(0.0, 0.0), p(100.0, 0.0), p(200.0, 0.0), p(300.0, 0.0))
        assertEquals(1, SeguimientoDeCamino.avanzar(10.0, 0.0, pts, 1))
        assertEquals(2, SeguimientoDeCamino.avanzar(80.0, 5.0, pts, 1))
    }

    @Test
    fun noSaltaElUltimoPunto() {
        val pts = listOf(p(0.0, 0.0), p(100.0, 0.0))
        assertEquals(1, SeguimientoDeCamino.avanzar(100.0, 0.0, pts, 1))
        assertEquals(1, SeguimientoDeCamino.avanzar(500.0, 0.0, pts, 1))
    }

    @Test
    fun siSePasaDeLargoCercaDelPuntoLoDaPorHecho() {
        val pts = listOf(p(0.0, 0.0), p(100.0, 0.0), p(100.0, 200.0), p(100.0, 400.0))
        assertEquals(2, SeguimientoDeCamino.avanzar(130.0, 60.0, pts, 1))
    }

    @Test
    fun noSaltaPuntosSiEstaMuyLejos() {
        val pts = listOf(p(0.0, 0.0), p(100.0, 0.0), p(200.0, 0.0), p(300.0, 0.0))
        assertEquals(1, SeguimientoDeCamino.avanzar(0.0, 300.0, pts, 1))
    }

    @Test
    fun suelta_conAnticipacionSegunLaVelocidad() {
        val v = 150.0
        val freno = SeguimientoDeCamino.distanciaDeFrenado(v)
        assertEquals(150.0 * 0.18, freno, 1e-9)
        assertFalse(SeguimientoDeCamino.hayQueSoltar(freno + 5, v))
        assertTrue(SeguimientoDeCamino.hayQueSoltar(freno - 1, v))
    }

    @Test
    fun velocidadNominalPromediaLasCardinales() {
        val cal = mapOf(
            Direccion.W to Calibracion(Direccion.W, 0.0, 150.0, 2),
            Direccion.S to Calibracion(Direccion.S, 0.0, -150.0, 2),
            Direccion.A to Calibracion(Direccion.A, 160.0, 0.0, 2),
            Direccion.D to Calibracion(Direccion.D, -140.0, 0.0, 0)
        )
        assertEquals((150.0 + 150.0 + 160.0) / 3, SeguimientoDeCamino.velocidadNominal(cal), 1e-9)
        assertEquals(0.0, SeguimientoDeCamino.velocidadNominal(emptyMap()), 1e-9)
    }

    @Test
    fun tiempoMaximoConMargenYLimites() {
        assertEquals(8_000L, SeguimientoDeCamino.tiempoMaximoMs(10.0, 150.0))
        assertEquals(4_000.0 * 1500 / 150.0 / 1000 * 1000, SeguimientoDeCamino.tiempoMaximoMs(1500.0, 150.0).toDouble(), 1.0)
        assertEquals(60_000L, SeguimientoDeCamino.tiempoMaximoMs(500.0, 0.0))
        assertEquals(60_000L, SeguimientoDeCamino.tiempoMaximoMs(1e9, 0.5))
    }
}
