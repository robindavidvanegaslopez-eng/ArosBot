package com.arosbot.ai.core

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas de LÓGICA en entorno simulado (JVM): calibración, geometría del joystick y secuencias. */
class DireccionTest {

    private fun cal(d: Direccion, vx: Double, vy: Double) = Calibracion(d, vx, vy, 1)

    private fun calibracionBuena() = mapOf(
        Direccion.W to cal(Direccion.W, 0.0, -100.0),
        Direccion.S to cal(Direccion.S, 0.0, 100.0),
        Direccion.A to cal(Direccion.A, -100.0, 0.0),
        Direccion.D to cal(Direccion.D, 100.0, 0.0)
    )

    private fun material(id: Long, nombre: String, categoria: String) =
        Material(id, nombre, categoria, 0.8f, 10, 10, listOf("a.png"), 0, null, EstadoReconocimiento.SIN_PROBAR)

    // ---------- Direcciones ----------

    @Test
    fun cadaDireccionTieneSuOpuesta() {
        assertEquals(Direccion.S, Direccion.W.opuesta)
        assertEquals(Direccion.W, Direccion.S.opuesta)
        assertEquals(Direccion.D, Direccion.A.opuesta)
        assertEquals(Direccion.A, Direccion.D.opuesta)
    }

    @Test
    fun vectoresDeLasDirecciones() {
        assertEquals(-1, Direccion.W.uy)
        assertEquals(1, Direccion.S.uy)
        assertEquals(-1, Direccion.A.ux)
        assertEquals(1, Direccion.D.ux)
    }

    // ---------- Calibración ----------

    @Test
    fun primeraMedicionFijaLaVelocidad() {
        val c = Calibracion.vacia(Direccion.D).actualizar(100.0, 0.0, 500L)
        assertEquals(200.0, c.vx, 1e-9)
        assertEquals(0.0, c.vy, 1e-9)
        assertEquals(1, c.muestras)
    }

    @Test
    fun medicionesPosterioresPromedianGradualmente() {
        val c = Calibracion(Direccion.D, 200.0, 0.0, 1).actualizar(150.0, 0.0, 500L)
        // nuevo = 300 px/s; alfa = max(1/2, 0.2) = 0.5 -> 250
        assertEquals(250.0, c.vx, 1e-9)
        assertEquals(2, c.muestras)
    }

    @Test
    fun conMuchasMuestrasElPesoDeLaNuevaSeLimita() {
        val c = Calibracion(Direccion.D, 100.0, 0.0, 50).actualizar(200.0, 0.0, 1000L)
        // alfa = max(1/51, 0.2) = 0.2 -> 100 + (200-100)*0.2 = 120
        assertEquals(120.0, c.vx, 1e-9)
    }

    @Test
    fun duracionDeCeroNoCambiaLaCalibracion() {
        val original = Calibracion(Direccion.W, 1.0, 2.0, 3)
        assertEquals(original, original.actualizar(50.0, 50.0, 0L))
    }

    @Test
    fun duracionParaUnaDistancia() {
        val c = Calibracion(Direccion.D, 200.0, 0.0, 3)
        assertEquals(500L, c.duracionParaMs(100.0))
        assertEquals(Calibracion.DURACION_MINIMA_MS, c.duracionParaMs(1.0))
        assertEquals(Calibracion.DURACION_MAXIMA_MS, c.duracionParaMs(1_000_000.0))
    }

    @Test
    fun sinCalibracionNoHayDuracion() {
        assertNull(Calibracion.vacia(Direccion.W).duracionParaMs(100.0))
    }

    // ---------- Coherencia de la calibración ----------

    @Test
    fun calibracionCorrectaNoTieneProblemas() {
        assertTrue(EvaluadorProgreso.calibracionCoherente(calibracionBuena()).isEmpty())
    }

    @Test
    fun detectaDireccionesSinCalibrar() {
        val sinD = calibracionBuena() - Direccion.D
        val problemas = EvaluadorProgreso.calibracionCoherente(sinD)
        assertTrue(problemas.any { it.contains("D") })
    }

    @Test
    fun detectaFaltaDeMovimiento() {
        val parada = calibracionBuena() + (Direccion.A to cal(Direccion.A, -1.0, 0.0))
        val problemas = EvaluadorProgreso.calibracionCoherente(parada)
        assertTrue(problemas.any { it.contains("A") && it.contains("movimiento") })
    }

    @Test
    fun detectaEjeIncorrecto() {
        val torcida = calibracionBuena() + (Direccion.W to cal(Direccion.W, 100.0, -10.0))
        assertFalse(EvaluadorProgreso.calibracionCoherente(torcida).isEmpty())
    }

    @Test
    fun detectaSentidosNoOpuestos() {
        val mismoSentido = calibracionBuena() + (Direccion.S to cal(Direccion.S, 0.0, -100.0))
        val problemas = EvaluadorProgreso.calibracionCoherente(mismoSentido)
        assertTrue(problemas.any { it.contains("W y S") })
    }

    @Test
    fun valeIgualSiSeObservaLaEscenaEnVezDelPersonaje() {
        // La escena se mueve al revés que el personaje: todos los signos invertidos.
        val invertida = calibracionBuena().mapValues { (d, c) -> cal(d, -c.vx, -c.vy) }
        assertTrue(EvaluadorProgreso.calibracionCoherente(invertida).isEmpty())
    }

    @Test
    fun hayMovimientoSegunElMinimo() {
        val m = Medicion(3.0, 4.0, 0.9, FuenteMedicion.ESCENA)
        assertTrue(EvaluadorProgreso.hayMovimiento(m, 5.0))
        assertFalse(EvaluadorProgreso.hayMovimiento(m, 5.1))
    }

    // ---------- Geometría del joystick ----------

    @Test
    fun puntosDelJoystickHaciaCadaDireccion() {
        // Cuadrado de 200x200 px centrado en (500, 1500) sobre una pantalla de 1000x2000.
        val rect = NormRect(0.4f, 0.7f, 0.2f, 0.1f)
        val w = GeometriaJoystick.puntos(rect, 1000, 2000, Direccion.W, deflexion = 1f)
        assertEquals(500f, w.centroX, 1e-3f)
        assertEquals(1500f, w.centroY, 1e-3f)
        assertEquals(500f, w.destinoX, 1e-3f)
        // radio = min(200, 200) / 2 = 100
        assertEquals(1400f, w.destinoY, 1e-3f)

        val d = GeometriaJoystick.puntos(rect, 1000, 2000, Direccion.D, deflexion = 0.5f)
        assertEquals(550f, d.destinoX, 1e-3f)
        assertEquals(1500f, d.destinoY, 1e-3f)
    }

    @Test
    fun elAlcanceLoMarcaElLadoMasCorto() {
        val rect = NormRect(0.0f, 0.0f, 0.5f, 0.1f) // 500 x 200 px -> radio 100
        val a = GeometriaJoystick.puntos(rect, 1000, 2000, Direccion.A, deflexion = 1f)
        assertEquals(a.centroX - 100f, a.destinoX, 1e-3f)
    }

    // ---------- Segmentos ----------

    @Test
    fun divideUnaPulsacionEnSegmentos() {
        assertEquals(listOf(100L, 100L, 50L), PlanDeSegmentos.dividir(250L, 100L))
        assertEquals(listOf(100L), PlanDeSegmentos.dividir(100L, 100L))
        assertEquals(listOf(30L), PlanDeSegmentos.dividir(30L, 100L))
    }

    @Test
    fun unaDuracionNulaSigueTeniendoUnSegmento() {
        assertEquals(listOf(1L), PlanDeSegmentos.dividir(0L, 100L))
    }

    @Test
    fun losSegmentosSumanLaDuracion() {
        assertEquals(1234L, PlanDeSegmentos.dividir(1234L, 150L).sum())
    }

    // ---------- Secuencias ----------

    private class Falso(private val falloEn: Int = -1) : ControladorEntrada {
        val llamadas = ArrayList<Direccion>()
        var soltadoTodo = 0
        override val disponible: Boolean = true

        override suspend fun mantener(direccion: Direccion, duracionMs: Long): Boolean {
            llamadas.add(direccion)
            return llamadas.size - 1 != falloEn
        }

        override fun soltarTodo() {
            soltadoTodo++
        }
    }

    @Test
    fun laSecuenciaEjecutaLosPasosEnOrden() = runBlocking {
        val c = Falso()
        val ok = c.ejecutar(
            listOf(Paso(Direccion.W, 100), Paso(Direccion.D, 100), Paso(Direccion.S, 100))
        )
        assertTrue(ok)
        assertEquals(listOf(Direccion.W, Direccion.D, Direccion.S), c.llamadas)
        assertEquals(0, c.soltadoTodo)
    }

    @Test
    fun laSecuenciaSeDetieneYLiberaSiUnPasoFalla() = runBlocking {
        val c = Falso(falloEn = 1)
        val ok = c.ejecutar(
            listOf(Paso(Direccion.W, 100), Paso(Direccion.D, 100), Paso(Direccion.S, 100))
        )
        assertFalse(ok)
        assertEquals(listOf(Direccion.W, Direccion.D), c.llamadas)
        assertEquals(1, c.soltadoTodo)
    }

    // ---------- Selección de materiales ----------

    @Test
    fun encuentraElMaterialDelPersonajePorCategoriaOPorNombre() {
        val lista = listOf(material(1, "Mena", "General"), material(2, "Yo", "Personaje"))
        assertEquals(2L, SelectorDeMateriales.personaje(lista)?.id)

        val porNombre = listOf(material(1, "Mena", "General"), material(3, "Mi personaje", "General"))
        assertEquals(3L, SelectorDeMateriales.personaje(porNombre)?.id)

        assertNull(SelectorDeMateriales.personaje(listOf(material(1, "Mena", "General"))))
    }

    @Test
    fun encuentraElMaterialDelBotonLogin() {
        assertNotNull(SelectorDeMateriales.login(listOf(material(1, "Log in", "Menú"))))
        assertNotNull(SelectorDeMateriales.login(listOf(material(1, "LOGIN", "Menú"))))
        assertNull(SelectorDeMateriales.login(listOf(material(1, "Mena", "General"))))
    }
}
