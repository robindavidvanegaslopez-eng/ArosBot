package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas de LÓGICA en entorno simulado (JVM): geometría, supresión de duplicados y áreas. */
class GeometryTest {

    @Test
    fun iouDeCajasIgualesEsUno() {
        val caja = Box(0, 0, 10, 10)
        assertEquals(1f, caja.iou(caja), 1e-6f)
    }

    @Test
    fun iouSinSolapeEsCero() {
        assertEquals(0f, Box(0, 0, 10, 10).iou(Box(20, 20, 30, 30)), 1e-6f)
    }

    @Test
    fun iouDeCajasSolapadasPorLaMitad() {
        // Intersección 5x10 = 50; unión 100 + 100 - 50 = 150.
        assertEquals(1f / 3f, Box(0, 0, 10, 10).iou(Box(5, 0, 15, 10)), 1e-6f)
    }

    @Test
    fun recortarMantieneLaCajaDentroDeLaImagen() {
        val recortada = Box(-5, -5, 120, 80).recortar(100, 60)
        assertEquals(Box(0, 0, 100, 60), recortada)
    }

    @Test
    fun supresionEliminaElDuplicadoDeMenorPuntuacion() {
        val buena = Detection(1L, "mena", Box(0, 0, 10, 10), 0.9f)
        val duplicada = Detection(1L, "mena", Box(1, 1, 11, 11), 0.8f)
        val lejana = Detection(1L, "mena", Box(50, 50, 60, 60), 0.7f)

        val resultado = Nms.suprimir(listOf(duplicada, lejana, buena), 0.3f, true)

        assertEquals(2, resultado.size)
        assertTrue(resultado.contains(buena))
        assertTrue(resultado.contains(lejana))
        assertFalse(resultado.contains(duplicada))
    }

    @Test
    fun supresionRespetaMaterialesDistintosSolapadosSiSeIndica() {
        val a = Detection(1L, "mena", Box(0, 0, 10, 10), 0.9f)
        val b = Detection(2L, "madera", Box(0, 0, 10, 10), 0.8f)

        assertEquals(2, Nms.suprimir(listOf(a, b), 0.3f, true).size)
        assertEquals(1, Nms.suprimir(listOf(a, b), 0.3f, false).size)
    }

    @Test
    fun areaNormalizadaVuelveALaMismaCaja() {
        val original = Box(100, 200, 300, 500)
        val norm = NormRect.deBox(original, 1000, 2000)
        assertEquals(original, norm.aBox(1000, 2000))
    }

    @Test
    fun areaNormalizadaEscalaConLaResolucion() {
        val norm = NormRect(0.1f, 0.2f, 0.5f, 0.25f)
        assertEquals(Box(100, 400, 600, 900), norm.aBox(1000, 2000))
        assertEquals(Box(50, 200, 300, 450), norm.aBox(500, 1000))
    }

    @Test
    fun ajusteCentraLaImagenEnLaVista() {
        // Imagen 100x100 en una vista 1000x500: escala 5, sobran 500 px en horizontal.
        val ajuste = FrameGeometry.ajustar(1000f, 500f, 100f, 100f)
        assertEquals(5f, ajuste.escala, 1e-6f)
        assertEquals(250f, ajuste.dx, 1e-4f)
        assertEquals(0f, ajuste.dy, 1e-4f)
    }

    @Test
    fun conversionVistaImagenEsReversible() {
        val ajuste = FrameGeometry.ajustar(720f, 1280f, 540f, 1200f)
        val xVista = ajuste.imagenAVistaX(123f)
        val yVista = ajuste.imagenAVistaY(456f)
        assertEquals(123f, ajuste.vistaAImagenX(xVista), 1e-3f)
        assertEquals(456f, ajuste.vistaAImagenY(yVista), 1e-3f)
    }

    @Test
    fun ajusteConDatosInvalidosNoDivideEntreCero() {
        val ajuste = FrameGeometry.ajustar(0f, 0f, 0f, 0f)
        assertEquals(1f, ajuste.escala, 1e-6f)
    }

    @Test
    fun relacionCompatibleAceptaLaMismaProporcionAOtraResolucion() {
        assertTrue(FrameGeometry.relacionCompatible(1080, 2400, 540, 1200))
    }

    @Test
    fun relacionCompatibleRechazaUnaPantallaGirada() {
        assertFalse(FrameGeometry.relacionCompatible(1080, 2400, 2400, 1080))
    }

    @Test
    fun relacionCompatibleRechazaDatosInvalidos() {
        assertFalse(FrameGeometry.relacionCompatible(0, 2400, 540, 1200))
        assertFalse(FrameGeometry.relacionCompatible(1080, 2400, 540, 0))
    }
}
