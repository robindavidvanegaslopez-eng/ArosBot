package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MacroTest {

    private fun toque(x: Float, y: Float, espera: Long = 500L) =
        PasoDeMacro(TipoDePaso.TOQUE, x, y, x, y, 60L, espera)

    @Test
    fun codificarYDecodificarEsReversible() {
        val m = MacroGrabado(
            2400, 1080,
            listOf(
                toque(0.5f, 0.4f, 800L),
                PasoDeMacro(TipoDePaso.DESLIZAR, 0.2f, 0.7f, 0.6f, 0.7f, 300L, 1200L)
            )
        )
        val d = MacroDeClics.decodificar(MacroDeClics.codificar(m))!!
        assertEquals(2400, d.refAncho)
        assertEquals(1080, d.refAlto)
        assertEquals(2, d.pasos.size)
        assertEquals(TipoDePaso.DESLIZAR, d.pasos[1].tipo)
        assertEquals(0.6f, d.pasos[1].x2, 1e-4f)
        assertEquals(1200L, d.pasos[1].esperaMs)
    }

    @Test
    fun decodificarTextoMalFormadoDevuelveNuloYNoInventaPasos() {
        assertNull(MacroDeClics.decodificar(null))
        assertNull(MacroDeClics.decodificar(""))
        assertNull(MacroDeClics.decodificar("hola"))
        assertNull(MacroDeClics.decodificar("P;2400;1080\nT;0.5;0.5"))
        assertNull(MacroDeClics.decodificar("P;2400;1080\nX;0.5;0.5;0.5;0.5;60;500"))
        assertNull(MacroDeClics.decodificar("P;2400;1080\nT;a;0.5;0.5;0.5;60;500"))
    }

    @Test
    fun unMovimientoPequenoEsUnToqueYUnoGrandeUnDeslizamiento() {
        val t = MacroDeClics.clasificar(1200f, 540f, 1210f, 545f, 90L, 2400, 1080, 700L)
        assertEquals(TipoDePaso.TOQUE, t.tipo)
        assertEquals(0.5f, t.x, 1e-3f)
        assertEquals(0.5f, t.y, 1e-3f)
        val d = MacroDeClics.clasificar(200f, 540f, 800f, 540f, 250L, 2400, 1080, 700L)
        assertEquals(TipoDePaso.DESLIZAR, d.tipo)
        assertEquals(200f / 2400f, d.x, 1e-4f)
        assertEquals(800f / 2400f, d.x2, 1e-4f)
    }

    @Test
    fun esperasYDuracionesSeAcotan() {
        val p = MacroDeClics.clasificar(10f, 10f, 10f, 10f, 20_000L, 100, 100, 99_999L)
        assertEquals(MacroDeClics.DURACION_MAXIMA_MS, p.duracionMs)
        assertEquals(MacroDeClics.ESPERA_MAXIMA_MS, p.esperaMs)
        val q = MacroDeClics.clasificar(10f, 10f, 10f, 10f, 1L, 100, 100, 0L)
        assertEquals(MacroDeClics.DURACION_MINIMA_MS, q.duracionMs)
        assertEquals(MacroDeClics.ESPERA_MINIMA_MS, q.esperaMs)
    }

    @Test
    fun lasPosicionesQuedanDentroDeLaPantalla() {
        val p = MacroDeClics.clasificar(-50f, 5000f, -50f, 5000f, 60L, 1000, 500, 500L)
        assertTrue(p.x in 0f..1f)
        assertTrue(p.y in 0f..1f)
    }

    @Test
    fun validacion() {
        assertNotNull(MacroDeClics.problema(null))
        assertNotNull(MacroDeClics.problema(MacroGrabado(2400, 1080, emptyList())))
        assertNotNull(MacroDeClics.problema(MacroGrabado(0, 0, listOf(toque(0.5f, 0.5f)))))
        val demasiados = MacroGrabado(2400, 1080, List(MacroDeClics.MAX_PASOS + 1) { toque(0.5f, 0.5f) })
        assertNotNull(MacroDeClics.problema(demasiados))
        assertNull(MacroDeClics.problema(MacroGrabado(2400, 1080, listOf(toque(0.5f, 0.5f)))))
    }

    @Test
    fun resumenYDuracion() {
        val m = MacroGrabado(
            2400, 1080,
            listOf(toque(0.1f, 0.1f, 1000L), PasoDeMacro(TipoDePaso.DESLIZAR, 0f, 0f, 1f, 1f, 440L, 500L))
        )
        assertEquals(1000L + 60L + 500L + 440L, MacroDeClics.duracionTotalMs(m))
        val r = MacroDeClics.resumen(m)
        assertTrue(r.contains("1 toque"))
        assertTrue(r.contains("1 deslizamiento"))
    }
}
