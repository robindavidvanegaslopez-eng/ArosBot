package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas de LÓGICA en entorno simulado (JVM). */
class ModuleRegistryTest {

    @Test
    fun tieneLos18ModulosDeLaArquitectura() {
        val registro = ModuleRegistry()
        assertEquals(18, registro.modules.value.size)
        assertEquals((1..18).toList(), registro.modules.value.map { it.id })
    }

    @Test
    fun estadoInicialDeLaFase6() {
        val registro = ModuleRegistry()
        fun con(estado: EstadoModulo): List<Int> =
            registro.modules.value.filter { it.estado == estado }.map { it.id }.sorted()

        assertEquals(listOf(16, 17, 18), con(EstadoModulo.VERIFICADO))
        assertEquals(listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15), con(EstadoModulo.IMPLEMENTADO))
        assertEquals(emptyList<Int>(), con(EstadoModulo.PENDIENTE))
    }

    @Test
    fun implementadoNoBastaParaIniciar() {
        val registro = ModuleRegistry()
        for (id in 1..18) registro.fijar(id, EstadoModulo.IMPLEMENTADO)
        assertEquals(18, registro.bloqueos().size)
    }

    @Test
    fun noSePuedeIniciarMientrasFaltenModulos() {
        val registro = ModuleRegistry()
        assertFalse(registro.bloqueos().isEmpty())
    }

    @Test
    fun verificarTodosLevantaElBloqueo() {
        val registro = ModuleRegistry()
        for (id in 1..18) registro.fijar(id, EstadoModulo.VERIFICADO)
        assertTrue(registro.bloqueos().isEmpty())
    }

    @Test
    fun fijarCambiaSoloElModuloIndicado() {
        val registro = ModuleRegistry()
        registro.fijar(1, EstadoModulo.VERIFICADO)
        val estados = registro.modules.value.associate { it.id to it.estado }
        assertEquals(EstadoModulo.VERIFICADO, estados[1])
        assertEquals(EstadoModulo.IMPLEMENTADO, estados[2])
        assertEquals(EstadoModulo.IMPLEMENTADO, estados[14])
    }
}
