package com.arosbot.ai.core

import kotlin.math.hypot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MovimientoTest {

    private fun med(dx: Double, dy: Double, c: Double) = Medicion(dx, dy, c, FuenteMedicion.ESCENA)

    // ---------- Clasificación de pasos ----------

    @Test
    fun movimientoFiableEsMedido() {
        assertEquals(ClasePaso.MEDIDO, ClasificadorDePaso.clasificar(Lectura(med(12.0, 0.0, 0.3), 9.0)))
    }

    @Test
    fun escenaSinCambioEsQuietaAunqueNoHayaConfianza() {
        // Fondo liso: la correlación no es fiable, pero la imagen no cambia: choque, no «estimar avance».
        assertEquals(ClasePaso.QUIETO, ClasificadorDePaso.clasificar(Lectura(med(0.0, 0.0, 0.01), 0.2)))
        assertEquals(ClasePaso.QUIETO, ClasificadorDePaso.clasificar(Lectura(null, 0.3)))
    }

    @Test
    fun imagenQueCambiaSinMedidaFiableEsSinMedida() {
        assertEquals(ClasePaso.SIN_MEDIDA, ClasificadorDePaso.clasificar(Lectura(med(30.0, 0.0, 0.02), 6.0)))
        assertEquals(ClasePaso.SIN_MEDIDA, ClasificadorDePaso.clasificar(Lectura(null, 5.0)))
        assertEquals(ClasePaso.SIN_MEDIDA, ClasificadorDePaso.clasificar(Lectura(null, null)))
    }

    @Test
    fun correlacionFiableDeCeroPxEsMedidaYNoSeConfundeConQuieta() {
        assertEquals(ClasePaso.MEDIDO, ClasificadorDePaso.clasificar(Lectura(med(0.3, 0.1, 0.5), 4.0)))
    }

    @Test
    fun medicionFiableGrandeGanaAUnaDiferenciaPequena() {
        // Fondo casi liso pero la correlación sí ve un desplazamiento claro: se fía de ella.
        assertEquals(ClasePaso.MEDIDO, ClasificadorDePaso.clasificar(Lectura(med(15.0, 0.0, 0.4), 0.5)))
    }

    // ---------- Consenso ----------

    @Test
    fun consensoIgnoraUnRecorteConElementoFijo() {
        val lista = listOf(med(15.0, 0.0, 0.3), med(0.0, 0.0, 0.9), med(14.0, 1.0, 0.3), med(16.0, 0.0, 0.3))
        val c = ConsensoDeMediciones.combinar(lista)!!
        assertEquals(14.5, c.dx, 1.0)
    }

    @Test
    fun consensoConDosUsaLaDeMayorConfianza() {
        val c = ConsensoDeMediciones.combinar(listOf(med(1.0, 0.0, 0.1), med(9.0, 0.0, 0.5)))!!
        assertEquals(9.0, c.dx, 1e-9)
    }

    @Test
    fun consensoVacioEsNulo() {
        assertNull(ConsensoDeMediciones.combinar(emptyList()))
    }

    @Test
    fun medianaDePares() {
        assertEquals(2.5, ConsensoDeMediciones.mediana(listOf(1.0, 2.0, 3.0, 4.0)), 1e-9)
        assertEquals(3.0, ConsensoDeMediciones.mediana(listOf(5.0, 1.0, 3.0)), 1e-9)
    }

    // ---------- Cierre de bucle ----------

    private fun ruta(vararg xy: Pair<Double, Double>) =
        xy.mapIndexed { i, (x, y) -> PuntoDeRuta(x, y, i * 100L, null) }

    @Test
    fun cierreDeBucleHaceCoincidirElFinalConElInicio() {
        // Recorrido cuadrado que debería cerrar en (0,0) pero acumuló deriva y acabó en (40, -30).
        val puntos = ruta(0.0 to 0.0, 200.0 to 0.0, 200.0 to 200.0, 0.0 to 200.0, 40.0 to -30.0)
        val ex = 0.0 - 40.0
        val ey = 0.0 - (-30.0)
        val corregida = CierreDeBucle.corregir(puntos, ex, ey)
        assertEquals(0.0, corregida.last().x, 1e-9)
        assertEquals(0.0, corregida.last().y, 1e-9)
        assertEquals(0.0, corregida.first().x, 1e-9)
        assertEquals(0.0, corregida.first().y, 1e-9)
        assertEquals(puntos.size, corregida.size)
    }

    @Test
    fun cierreDeBucleRepartePorElRecorrido() {
        val puntos = ruta(0.0 to 0.0, 100.0 to 0.0, 200.0 to 0.0)
        val c = CierreDeBucle.corregir(puntos, 0.0, 20.0)
        assertEquals(0.0, c[0].y, 1e-9)
        assertEquals(10.0, c[1].y, 1e-9)
        assertEquals(20.0, c[2].y, 1e-9)
    }

    @Test
    fun cierreDeBucleConservaLasReferencias() {
        val ref = ReferenciaVisual("a.png", 1, 2, 3, 4)
        val puntos = listOf(
            PuntoDeRuta(0.0, 0.0, 0L, ref),
            PuntoDeRuta(100.0, 0.0, 10L, null),
            PuntoDeRuta(200.0, 0.0, 20L, ref)
        )
        val c = CierreDeBucle.corregir(puntos, 5.0, 5.0)
        assertEquals(ref, c.first().referencia)
        assertEquals(ref, c.last().referencia)
        assertEquals(10L, c[1].tMs)
    }

    @Test
    fun cierreDeBucleSoloSiSeReconoceConConfianzaYElErrorEsRazonable() {
        assertTrue(CierreDeBucle.aplicable(0.9, 30.0, 20.0, 800.0))
        assertFalse(CierreDeBucle.aplicable(0.5, 30.0, 20.0, 800.0))
        assertFalse(CierreDeBucle.aplicable(0.9, 400.0, 0.0, 800.0))
        assertFalse(CierreDeBucle.aplicable(0.9, 10.0, 0.0, 50.0))
    }

    @Test
    fun cierreDeBucleConRutaCortaODegeneradaNoCambiaNada() {
        val una = ruta(0.0 to 0.0)
        assertEquals(una, CierreDeBucle.corregir(una, 5.0, 5.0))
        val quieta = ruta(0.0 to 0.0, 0.0 to 0.0)
        assertEquals(quieta, CierreDeBucle.corregir(quieta, 5.0, 5.0))
    }

    @Test
    fun longitudDeLaRuta() {
        assertEquals(300.0, CierreDeBucle.longitud(ruta(0.0 to 0.0, 300.0 to 0.0)), 1e-9)
        assertEquals(5.0, CierreDeBucle.longitud(ruta(0.0 to 0.0, 3.0 to 4.0)), 1e-9)
    }

    // ---------- Rodeo ----------

    @Test
    fun rodeoAlternaLadosYSeSeparaCadaVezMas() {
        // Objetivo a la derecha: el lado «derecho» del rumbo es hacia abajo en pantalla (y positiva).
        val a = Rodeo.puntoDePaso(0.0, 0.0, 200.0, 0.0, 0)!!
        val b = Rodeo.puntoDePaso(0.0, 0.0, 200.0, 0.0, 1)!!
        val c = Rodeo.puntoDePaso(0.0, 0.0, 200.0, 0.0, 2)!!
        assertTrue(a.y > 0f)
        assertTrue(b.y < 0f)
        assertTrue(Math.abs(c.y) > Math.abs(a.y))
        assertTrue(a.x > 0f)
    }

    @Test
    fun rodeoSeAgotaTrasElMaximoDeIntentos() {
        assertNotNull(Rodeo.puntoDePaso(0.0, 0.0, 100.0, 0.0, Rodeo.INTENTOS_MAXIMOS - 1))
        assertNull(Rodeo.puntoDePaso(0.0, 0.0, 100.0, 0.0, Rodeo.INTENTOS_MAXIMOS))
        assertNull(Rodeo.puntoDePaso(0.0, 0.0, 100.0, 0.0, -1))
    }

    @Test
    fun rodeoSinDistanciaAlObjetivoNoSeInventa() {
        assertNull(Rodeo.puntoDePaso(5.0, 5.0, 5.0, 5.0, 0))
    }

    @Test
    fun rodeoEsPerpendicularAlRumbo() {
        val p = Rodeo.puntoDePaso(0.0, 0.0, 0.0, 200.0, 0)!!
        // Objetivo hacia abajo: el desvío es lateral (x), con algo de avance en y.
        assertTrue(Math.abs(p.x) >= 89f)
        assertTrue(hypot(p.x.toDouble(), p.y.toDouble()) > 90.0)
    }

    // ---------- Detector de bloqueo con escena quieta ----------

    @Test
    fun unChoqueSeDetectaConDosVentanasSinMovimiento() {
        val d = DetectorDeBloqueo(pasosSeguidos = 2)
        val esperado = 151.0 * 0.6
        assertFalse(d.anotar(esperado, 0.0))
        assertTrue(d.anotar(esperado, 0.0))
    }

    // ---------- Proyección sobre el juego ----------

    @Test
    fun unPuntoALaDerechaDelPersonajeSeDibujaALaDerechaDelAncla() {
        val p = ProyeccionDeTrayecto.aPantalla(300.0, 100.0, 100.0, 100.0, 1000f, 500f, 2f)
        assertEquals(1400f, p.x, 1e-3f)
        assertEquals(500f, p.y, 1e-3f)
    }

    @Test
    fun elPersonajeSeDibujaEnElAncla() {
        val p = ProyeccionDeTrayecto.aPantalla(42.0, -7.0, 42.0, -7.0, 640f, 250f, 2f)
        assertEquals(640f, p.x, 1e-3f)
        assertEquals(250f, p.y, 1e-3f)
    }
}
