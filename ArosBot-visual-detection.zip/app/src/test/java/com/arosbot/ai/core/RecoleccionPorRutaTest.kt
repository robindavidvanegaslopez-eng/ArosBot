package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RecoleccionPorRutaTest {

    private fun ruta(vararg xy: Pair<Double, Double>) =
        xy.mapIndexed { i, p -> PuntoDeRuta(p.first, p.second, i * 100L) }

    @Test
    fun vueltaVaDesdeElPuntoMasCercanoHastaElInicioSinRecentrar() {
        val r = ruta(0.0 to 0.0, 100.0 to 0.0, 200.0 to 0.0, 300.0 to 0.0)
        val i = CaminoDeVuelta.indiceMasCercano(r, 210.0, 10.0)
        assertEquals(2, i)
        val v = CaminoDeVuelta.desde(r, i)
        assertEquals(listOf(200.0, 100.0, 0.0), v.map { it.x })
    }

    @Test
    fun vueltaConIndiceFueraDeRangoSeAjusta() {
        val r = ruta(0.0 to 0.0, 50.0 to 0.0)
        assertEquals(2, CaminoDeVuelta.desde(r, 99).size)
        assertTrue(CaminoDeVuelta.desde(emptyList(), 3).isEmpty())
        assertEquals(-1, CaminoDeVuelta.indiceMasCercano(emptyList(), 0.0, 0.0))
    }

    @Test
    fun listaNegraDescartaPorRadio() {
        val n = ListaNegraDeMateriales()
        n.agregar(100.0, 100.0)
        n.agregar(110.0, 100.0)
        assertEquals(1, n.tamano)
        assertTrue(n.contiene(150.0, 100.0))
        assertFalse(n.contiene(300.0, 100.0))
        n.vaciar()
        assertFalse(n.contiene(100.0, 100.0))
    }

    @Test
    fun electorTomaElMasCercanoNoDescartado() {
        val n = ListaNegraDeMateriales()
        val cands = listOf(Pair(30.0, 0.0), Pair(110.0, 0.0), Pair(0.0, 200.0))
        // Personaje en (0,0): el primero está en el mundo (30,0).
        assertEquals(cands[0], ElectorDeMaterial.elegir(cands, { it }, 0.0, 0.0, n))
        n.agregar(30.0, 0.0)
        assertEquals(cands[1], ElectorDeMaterial.elegir(cands, { it }, 0.0, 0.0, n))
        // Si el personaje se movió, la lista negra se compara en coordenadas del mundo.
        assertNull(ElectorDeMaterial.elegir(listOf(Pair(-70.0, 0.0)), { it }, 100.0, 0.0, n))
    }

    @Test
    fun acercamientoNoLlegaAlCentro() {
        assertNull(PuntoDeAcercamiento.calcular(40.0, 30.0))
        val m = PuntoDeAcercamiento.calcular(200.0, 0.0)
        assertNotNull(m)
        assertEquals(200.0 - PuntoDeAcercamiento.DISTANCIA_OBJETIVO_PX, m!!.first, 1e-9)
        assertEquals(0.0, m.second, 1e-9)
        val d = PuntoDeAcercamiento.calcular(-120.0, -160.0)!!
        // Queda a DISTANCIA_OBJETIVO_PX del material, nunca encima.
        assertEquals(PuntoDeAcercamiento.DISTANCIA_OBJETIVO_PX, Math.hypot(-120.0 - d.first, -160.0 - d.second), 1e-9)
    }

    @Test
    fun persistenciaExigeVariasSeguidas() {
        val p = Persistencia(3)
        assertFalse(p.anotar(true))
        assertFalse(p.anotar(true))
        assertTrue(p.anotar(true))
        assertFalse(p.anotar(false))
        assertFalse(p.anotar(true))
    }

    @Test
    fun colisionDeCuadros() {
        val pj = Box(100, 100, 140, 160)
        assertTrue(Colision.tocan(Box(130, 120, 170, 150), pj))
        assertFalse(Colision.tocan(Box(145, 100, 185, 160), pj))
        // El margen agranda el cuadro del personaje.
        assertTrue(Colision.tocan(Box(145, 100, 185, 160), pj, 6))
        assertFalse(Colision.tocan(Box(100, 170, 140, 200), pj, 6))
        // Tocarse justo por el borde no cuenta sin margen.
        assertFalse(Colision.tocan(Box(140, 100, 180, 160), pj))
    }

    @Test
    fun filtroDeEstabilidadIgnoraLecturasSueltas() {
        val f = FiltroDeEstabilidad()
        val a = MaterialEnMundo(1, "roca", 100.0, 100.0, 30, 30)
        val falso = MaterialEnMundo(2, "otro", 300.0, 50.0, 30, 30)
        f.anotar(listOf(a))
        f.anotar(listOf(a.copy(x = 102.0)))
        assertTrue(f.estables().isEmpty())
        f.anotar(listOf(a.copy(x = 101.0), falso))
        val e = f.estables()
        assertEquals(1, e.size)
        assertEquals(1L, e[0].id)
        assertEquals(101.0, e[0].x, 1.0)
        // Lo que se mueve de sitio de una lectura a otra no es estable.
        val g = FiltroDeEstabilidad()
        g.anotar(listOf(a)); g.anotar(listOf(a.copy(x = 200.0))); g.anotar(listOf(a.copy(x = 300.0)))
        assertTrue(g.estables().isEmpty())
    }

    private fun mat(id: Long, nombre: String, cat: String = "") =
        Material(id, nombre, cat, 0.8f, 0, 0, emptyList(), 0, null, EstadoReconocimiento.SIN_PROBAR)

    @Test
    fun mensajeDelSistemaSeReconocePorNombre() {
        assertEquals(FuncionVisual.MENSAJE_SISTEMA, SelectorDeFunciones.funcionDe("", "Sistema recolectando Roble"))
        assertEquals(FuncionVisual.MENSAJE_SISTEMA, SelectorDeFunciones.funcionDe("Sistema", "Roble"))
        assertEquals(FuncionVisual.INVENTARIO_LLENO, SelectorDeFunciones.funcionDe("", "Sistema inventario lleno"))
        assertFalse(SelectorDeFunciones.esDeRecoleccion(mat(1, "Sistema recolectando Roble")))
    }

    @Test
    fun mensajeEspecificoParaCadaMaterial() {
        val mats = listOf(
            mat(1, "Roble"), mat(2, "Sistema Roble"), mat(3, "Sistema Pino"), mat(4, "Hierro")
        )
        assertEquals(listOf(2L), SelectorDeFunciones.mensajesPara("Roble", mats).map { it.id })
        // Sin mensaje con su nombre sirven todos los mensajes del sistema.
        assertEquals(listOf(2L, 3L), SelectorDeFunciones.mensajesPara("Hierro", mats).map { it.id })
    }
}
