package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RecoleccionPorRutaTest {

    private fun ruta(vararg xy: Pair<Double, Double>) =
        xy.mapIndexed { i, p -> PuntoDeRuta(p.first, p.second, i * 100L) }

    @Test
    fun vueltaVaDesdeElPuntoMasCercanoHastaElInicioSinRecentrar() {
        val r = ruta(0.0 to 0.0, 100.0 to 0.0, 200.0 to 0.0, 300.0 to 0.0)
        val i = CaminoDeVuelta.indiceMasCercano(r, 210.0, 10.0)
        assertEquals(2, i)
        val v = CaminoDeVuelta.desde(r, i)
        assertEquals(listOf(200.0, 100.0, 0.0), v.map { it.x })
    }

    @Test
    fun vueltaConIndiceFueraDeRangoSeAjusta() {
        val r = ruta(0.0 to 0.0, 50.0 to 0.0)
        assertEquals(2, CaminoDeVuelta.desde(r, 99).size)
        assertTrue(CaminoDeVuelta.desde(emptyList(), 3).isEmpty())
        assertEquals(-1, CaminoDeVuelta.indiceMasCercano(emptyList(), 0.0, 0.0))
    }

    @Test
    fun listaNegraDescartaPorRadio() {
        val n = ListaNegraDeMateriales()
        n.agregar(100.0, 100.0)
        n.agregar(110.0, 100.0)
        assertEquals(1, n.tamano)
        assertTrue(n.contiene(150.0, 100.0))
        assertFalse(n.contiene(300.0, 100.0))
        n.vaciar()
        assertFalse(n.contiene(100.0, 100.0))
    }

    @Test
    fun electorTomaElMasCercanoNoDescartado() {
        val n = ListaNegraDeMateriales()
        val cands = listOf(Pair(30.0, 0.0), Pair(110.0, 0.0), Pair(0.0, 200.0))
        // Personaje en (0,0): el primero está en el mundo (30,0).
        assertEquals(cands[0], ElectorDeMaterial.elegir(cands, { it }, 0.0, 0.0, n))
        n.agregar(30.0, 0.0)
        assertEquals(cands[1], ElectorDeMaterial.elegir(cands, { it }, 0.0, 0.0, n))
        // Si el personaje se movió, la lista negra se compara en coordenadas del mundo.
        assertNull(ElectorDeMaterial.elegir(listOf(Pair(-70.0, 0.0)), { it }, 100.0, 0.0, n))
    }

    @Test
    fun acercamientoNoLlegaAlCentro() {
        assertNull(PuntoDeAcercamiento.calcular(40.0, 30.0))
        val m = PuntoDeAcercamiento.calcular(200.0, 0.0)
        assertNotNull(m)
        assertEquals(200.0 - PuntoDeAcercamiento.DISTANCIA_OBJETIVO_PX, m!!.first, 1e-9)
        assertEquals(0.0, m.second, 1e-9)
        val d = PuntoDeAcercamiento.calcular(-120.0, -160.0)!!
        // Queda a DISTANCIA_OBJETIVO_PX del material, nunca encima.
        assertEquals(PuntoDeAcercamiento.DISTANCIA_OBJETIVO_PX, Math.hypot(-120.0 - d.first, -160.0 - d.second), 1e-9)
    }

    @Test
    fun persistenciaExigeVariasSeguidas() {
        val p = Persistencia(3)
        assertFalse(p.anotar(true))
        assertFalse(p.anotar(true))
        assertTrue(p.anotar(true))
        assertFalse(p.anotar(false))
        assertFalse(p.anotar(true))
    }
}
