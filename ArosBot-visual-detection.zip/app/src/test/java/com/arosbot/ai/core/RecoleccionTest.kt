package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas de LÓGICA en entorno simulado (JVM): recolección, inventario y cofre. No prueban el juego. */
class RecoleccionTest {

    private fun material(id: Long, nombre: String, categoria: String = "Recurso") = Material(
        id, nombre, categoria, 0.8f, 10, 10, listOf("a.png"), 0, null, EstadoReconocimiento.SIN_PROBAR
    )

    private fun calibraciones(rapidez: Double = 150.0): Map<Direccion, Calibracion> = mapOf(
        Direccion.W to Calibracion(Direccion.W, 0.0, rapidez, 3),
        Direccion.S to Calibracion(Direccion.S, 0.0, -rapidez, 3),
        Direccion.A to Calibracion(Direccion.A, rapidez, 0.0, 3),
        Direccion.D to Calibracion(Direccion.D, -rapidez, 0.0, 3)
    )

    // ---------- Funciones visuales ----------

    @Test
    fun funcionesSegunNombreOCategoria() {
        assertEquals(FuncionVisual.INVENTARIO_LLENO, SelectorDeFunciones.funcionDe("Aviso", "Inventario lleno"))
        assertEquals(FuncionVisual.INVENTARIO_LLENO, SelectorDeFunciones.funcionDe("", "Your inventory is full"))
        assertEquals(FuncionVisual.COFRE, SelectorDeFunciones.funcionDe("Cofre", "Cofre de casa"))
        assertEquals(FuncionVisual.COFRE_ABIERTO, SelectorDeFunciones.funcionDe("", "Cofre abierto"))
        assertEquals(FuncionVisual.CERRAR, SelectorDeFunciones.funcionDe("", "Cerrar cofre"))
        assertEquals(FuncionVisual.DEPOSITAR, SelectorDeFunciones.funcionDe("Botón", "Depositar todo"))
        assertEquals(FuncionVisual.INTERACTUAR, SelectorDeFunciones.funcionDe("", "Botón Interactuar"))
        assertNull(SelectorDeFunciones.funcionDe("Mineral", "Hierro"))
    }

    @Test
    fun losAcentosNoImportan() {
        assertEquals(FuncionVisual.COFRE_ABIERTO, SelectorDeFunciones.funcionDe("", "Interfaz del cofre"))
        assertEquals(FuncionVisual.DEPOSITAR, SelectorDeFunciones.funcionDe("", "DEPOSITAR"))
    }

    @Test
    fun variosIndicadoresDeInventarioLleno() {
        val lista = listOf(
            material(1, "Inventario lleno"),
            material(2, "Mochila full"),
            material(3, "Hierro")
        )
        assertEquals(2, SelectorDeFunciones.con(FuncionVisual.INVENTARIO_LLENO, lista).size)
    }

    @Test
    fun losMaterialesDeUtilidadNoSeRecogen() {
        assertFalse(SelectorDeFunciones.esDeRecoleccion(material(1, "Cofre")))
        assertFalse(SelectorDeFunciones.esDeRecoleccion(material(2, "Yo", "Personaje")))
        assertTrue(SelectorDeFunciones.esDeRecoleccion(material(3, "Hierro")))
    }

    // ---------- Inventario ----------

    @Test
    fun inventarioLlenoConfirmadoVariasVeces() {
        assertEquals(
            LecturaInventario.LLENO,
            LectorDeInventario.leer(listOf(true, true, true, false, true))
        )
    }

    @Test
    fun inventarioNoLlenoSiNuncaSeVio() {
        assertEquals(
            LecturaInventario.NO_LLENO,
            LectorDeInventario.leer(listOf(false, false, false, false, false))
        )
    }

    @Test
    fun unaSolaVistaEsIncierta() {
        assertEquals(
            LecturaInventario.INCIERTO,
            LectorDeInventario.leer(listOf(true, false, false, false, false))
        )
    }

    @Test
    fun sinSuficientesFotogramasEsIncierto() {
        assertEquals(
            LecturaInventario.INCIERTO,
            LectorDeInventario.leer(listOf(true, true, null, null, null))
        )
        assertEquals(LecturaInventario.INCIERTO, LectorDeInventario.leer(emptyList()))
    }

    // ---------- Recogida ----------

    @Test
    fun recursoQueDesapareceSeDaPorRecogido() {
        val objetivo = PuntoXY(300f, 200f)
        val despues = listOf<List<PuntoXY>?>(emptyList(), emptyList(), listOf(PuntoXY(600f, 50f)))
        assertEquals(ResultadoDeRecogida.RECOGIDO, VerificadorDeRecogida.evaluar(objetivo, despues))
    }

    @Test
    fun recursoQueSigueNoSeDaPorRecogido() {
        val objetivo = PuntoXY(300f, 200f)
        val despues = listOf<List<PuntoXY>?>(
            listOf(PuntoXY(305f, 198f)), listOf(PuntoXY(301f, 202f)), listOf(PuntoXY(299f, 200f))
        )
        assertEquals(ResultadoDeRecogida.NO_RECOGIDO, VerificadorDeRecogida.evaluar(objetivo, despues))
    }

    @Test
    fun sinMuestrasSuficientesEsDudoso() {
        val objetivo = PuntoXY(300f, 200f)
        assertEquals(
            ResultadoDeRecogida.DUDOSO,
            VerificadorDeRecogida.evaluar(objetivo, listOf(emptyList(), null, null))
        )
    }

    @Test
    fun mezclaDeMuestrasEsDudosa() {
        val objetivo = PuntoXY(300f, 200f)
        val aqui = listOf(PuntoXY(300f, 200f))
        val despues = listOf<List<PuntoXY>?>(aqui, emptyList(), emptyList(), emptyList())
        assertEquals(ResultadoDeRecogida.DUDOSO, VerificadorDeRecogida.evaluar(objetivo, despues))
    }

    // ---------- Acercamiento ----------

    @Test
    fun dentroDelRangoNoSeMueve() {
        assertTrue(GuiaDeAcercamiento.siguiente(30.0, 20.0, calibraciones(), true) is Acercamiento.EnRango)
    }

    @Test
    fun seAcercaPorElEjeMasLargoSinDiagonales() {
        val r = GuiaDeAcercamiento.siguiente(300.0, 40.0, calibraciones(), false)
        assertEquals(Direccion.D, (r as Acercamiento.Mover).direccion)
        val r2 = GuiaDeAcercamiento.siguiente(-20.0, -300.0, calibraciones(), false)
        assertEquals(Direccion.W, (r2 as Acercamiento.Mover).direccion)
    }

    @Test
    fun usaDiagonalSoloSiEstaVerificada() {
        val sin = GuiaDeAcercamiento.siguiente(300.0, 300.0, calibraciones(), false) as Acercamiento.Mover
        assertFalse(sin.direccion.esDiagonal)
        val con = GuiaDeAcercamiento.siguiente(300.0, 300.0, calibraciones(), true) as Acercamiento.Mover
        assertTrue(con.direccion.esDiagonal)
    }

    @Test
    fun pulsacionAcotada() {
        val lejos = GuiaDeAcercamiento.siguiente(5000.0, 0.0, calibraciones(), false) as Acercamiento.Mover
        assertEquals(GuiaDeAcercamiento.PULSACION_MAXIMA_MS, lejos.duracionMs)
        val cerca = GuiaDeAcercamiento.siguiente(85.0, 0.0, calibraciones(1000.0), false) as Acercamiento.Mover
        assertEquals(GuiaDeAcercamiento.PULSACION_MINIMA_MS, cerca.duracionMs)
    }

    @Test
    fun sinCalibracionNoSeInventaUnMovimiento() {
        val r = GuiaDeAcercamiento.siguiente(300.0, 0.0, emptyMap(), false)
        assertTrue(r is Acercamiento.SinCalibracion)
    }

    // ---------- Límites ----------

    @Test
    fun fallosSeguidosDetienenElBot() {
        val c = ControlDeSesion(maxFallosSeguidos = 3)
        assertEquals(Decision.Continuar, c.recogida(ResultadoDeRecogida.NO_RECOGIDO))
        assertEquals(Decision.Continuar, c.recogida(ResultadoDeRecogida.DUDOSO))
        assertTrue(c.recogida(ResultadoDeRecogida.NO_RECOGIDO) is Decision.Detener)
    }

    @Test
    fun unExitoReiniciaLosFallosSeguidos() {
        val c = ControlDeSesion(maxFallosSeguidos = 3)
        c.recogida(ResultadoDeRecogida.NO_RECOGIDO)
        c.recogida(ResultadoDeRecogida.NO_RECOGIDO)
        c.recogida(ResultadoDeRecogida.RECOGIDO)
        assertEquals(Decision.Continuar, c.recogida(ResultadoDeRecogida.NO_RECOGIDO))
        assertEquals(1, c.recogidos)
        assertEquals(3, c.fallos)
    }

    @Test
    fun spotsVaciosSeguidosDetienen() {
        val c = ControlDeSesion(maxSpotsVaciosSeguidos = 2)
        assertEquals(Decision.Continuar, c.spotTerminado(0))
        assertTrue(c.spotTerminado(0) is Decision.Detener)
    }

    @Test
    fun spotConRecogidasReiniciaLaCuenta() {
        val c = ControlDeSesion(maxSpotsVaciosSeguidos = 2)
        c.spotTerminado(0)
        c.spotTerminado(3)
        assertEquals(Decision.Continuar, c.spotTerminado(0))
    }

    @Test
    fun depositoFallidoDosVecesDetiene() {
        val c = ControlDeSesion(maxFallosDeDeposito = 2)
        assertEquals(Decision.Continuar, c.deposito(false))
        assertTrue(c.deposito(false) is Decision.Detener)
    }

    @Test
    fun depositoCorrectoSeCuenta() {
        val c = ControlDeSesion()
        c.deposito(false)
        assertEquals(Decision.Continuar, c.deposito(true))
        assertEquals(1, c.depositos)
        assertEquals(Decision.Continuar, c.deposito(false))
    }

    @Test
    fun inventarioInciertoSiempreDetiene() {
        assertTrue(ControlDeSesion().inventarioIncierto() is Decision.Detener)
    }

    @Test
    fun demasiadosRecursosSeguidosEnUnSpotDetiene() {
        val c = ControlDeSesion(maxRecursosPorSpot = 3)
        c.recogida(ResultadoDeRecogida.RECOGIDO)
        c.recogida(ResultadoDeRecogida.RECOGIDO)
        assertTrue(c.recogida(ResultadoDeRecogida.RECOGIDO) is Decision.Detener)
        c.nuevoSpot()
        assertEquals(Decision.Continuar, c.recogida(ResultadoDeRecogida.RECOGIDO))
    }

    // ---------- Objetivos ----------

    @Test
    fun cicloCompletoDeObjetivos() {
        var o = Objetivo.ELEGIR_SPOT
        o = PlanificadorDeObjetivos.siguiente(o, Evento.SPOT_ELEGIDO)
        assertEquals(Objetivo.IR_AL_SPOT, o)
        o = PlanificadorDeObjetivos.siguiente(o, Evento.LLEGADO)
        assertEquals(Objetivo.RECOGER, o)
        o = PlanificadorDeObjetivos.siguiente(o, Evento.INVENTARIO_LLENO)
        assertEquals(Objetivo.IR_AL_COFRE, o)
        o = PlanificadorDeObjetivos.siguiente(o, Evento.LLEGADO_AL_COFRE)
        assertEquals(Objetivo.DEPOSITAR, o)
        o = PlanificadorDeObjetivos.siguiente(o, Evento.DEPOSITADO)
        assertEquals(Objetivo.ELEGIR_SPOT, o)
    }

    @Test
    fun spotAgotadoVuelveAElegir() {
        assertEquals(
            Objetivo.ELEGIR_SPOT,
            PlanificadorDeObjetivos.siguiente(Objetivo.RECOGER, Evento.SPOT_AGOTADO)
        )
    }

    @Test
    fun spotVacioAlLlegarVuelveAElegir() {
        assertEquals(
            Objetivo.ELEGIR_SPOT,
            PlanificadorDeObjetivos.siguiente(Objetivo.IR_AL_SPOT, Evento.SPOT_AGOTADO)
        )
    }

    @Test
    fun unEventoInesperadoDetiene() {
        assertEquals(
            Objetivo.DETENIDO,
            PlanificadorDeObjetivos.siguiente(Objetivo.IR_AL_COFRE, Evento.SPOT_ELEGIDO)
        )
        assertEquals(
            Objetivo.DETENIDO,
            PlanificadorDeObjetivos.siguiente(Objetivo.RECOGER, Evento.FALLO)
        )
        assertEquals(
            Objetivo.DETENIDO,
            PlanificadorDeObjetivos.siguiente(Objetivo.DETENIDO, Evento.SPOT_ELEGIDO)
        )
    }

    // ---------- Cofre ----------

    @Test
    fun secuenciaDelCofreEnOrden() {
        var paso: PasoDeCofre? = PasoDeCofre.RECONOCER_COFRE
        val vistos = ArrayList<PasoDeCofre>()
        while (paso != null) {
            vistos.add(paso)
            paso = SecuenciaDeCofre.siguiente(paso)
        }
        assertEquals(SecuenciaDeCofre.orden, vistos)
        assertEquals(PasoDeCofre.LISTO, vistos.last())
    }

    @Test
    fun faltantesParaElCofre() {
        val todo = listOf(
            material(1, "Inventario lleno"),
            material(2, "Cofre"),
            material(3, "Cofre abierto"),
            material(4, "Depositar"),
            material(5, "Cerrar cofre")
        )
        assertTrue(SecuenciaDeCofre.faltantes(todo).isEmpty())
        val sinCerrar = todo.filter { it.id != 5L }
        assertEquals(listOf(FuncionVisual.CERRAR), SecuenciaDeCofre.faltantes(sinCerrar))
        assertEquals(5, SecuenciaDeCofre.faltantes(emptyList()).size)
    }

    @Test
    fun depositoSoloValeSiElInventarioDejaDeEstarLleno() {
        assertTrue(VerificadorDeDeposito.exito(LecturaInventario.LLENO, LecturaInventario.NO_LLENO))
        assertFalse(VerificadorDeDeposito.exito(LecturaInventario.LLENO, LecturaInventario.LLENO))
        assertFalse(VerificadorDeDeposito.exito(LecturaInventario.LLENO, LecturaInventario.INCIERTO))
        assertFalse(VerificadorDeDeposito.exito(LecturaInventario.INCIERTO, LecturaInventario.NO_LLENO))
    }

    // ---------- Estadísticas ----------

    @Test
    fun estadisticasSeAcumulan() {
        val a = ActualizacionDeEstadistica.sumar(null, 7, 3, 1, 100L)
        val b = ActualizacionDeEstadistica.sumar(a, 7, 2, 0, 200L)
        assertEquals(5, b.recogidos)
        assertEquals(1, b.fallos)
        assertEquals(200L, b.ultimaMs)
        assertEquals(5.0 / 6.0, b.tasaDeExito!!, 1e-9)
        assertNull(EstadisticaDeRecoleccion(1, 0, 0, 0L).tasaDeExito)
    }
}
