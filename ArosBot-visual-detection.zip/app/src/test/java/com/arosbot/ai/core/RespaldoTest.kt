package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RespaldoTest {

    private fun material(id: Long, archivo: String) = Material(
        id, "Árbol|x", "Madera", 0.8f, 40, 50, listOf(archivo), 0, null, EstadoReconocimiento.SIN_PROBAR
    )

    private fun contenido(captura: ByteArray? = byteArrayOf(1, 2, 3)): ContenidoDeRespaldo {
        val config = ConfiguracionCopia(
            listOf(material(1, "a.png"), material(2, "b.png")),
            listOf(Area(7, "Bosque", NormRect(0.1f, 0.2f, 0.3f, 0.4f), 2400, 1080, true, listOf(1L, 2L))),
            JoystickConfig(NormRect(0.05f, 0.6f, 0.2f, 0.3f), 2400, 1080),
            "macro|con\nsaltos",
            3L
        )
        val aprendizaje = CopiaDeAprendizaje(
            listOf(Lugar(3, "Cofre")), emptyList(), emptyList(), emptyList(),
            mapOf("ref_1.png" to byteArrayOf(9, 8)), emptyList()
        )
        return ContenidoDeRespaldo(config, aprendizaje, mapOf("a.png" to byteArrayOf(5, 6), "b.png" to byteArrayOf(7)), captura)
    }

    @Test
    fun ida_y_vuelta_conserva_todo() {
        val bytes = PaqueteDeRespaldo.empaquetar(contenido())
        val c = PaqueteDeRespaldo.desempaquetar(bytes)
        assertNotNull(c)
        c!!
        assertEquals(2, c.configuracion.materiales.size)
        assertEquals("Árbol|x", c.configuracion.materiales[0].nombre)
        assertEquals(listOf(1L, 2L), c.configuracion.areas[0].materiales)
        assertEquals(0.05f, c.configuracion.joystick!!.rect.x, 1e-6f)
        assertEquals("macro|con\nsaltos", c.configuracion.macroCofre)
        assertEquals(3L, c.configuracion.lugarCofreId)
        assertEquals(setOf("a.png", "b.png"), c.imagenesMateriales.keys)
        assertTrue(c.imagenesMateriales.getValue("a.png").contentEquals(byteArrayOf(5, 6)))
        assertTrue(c.captura!!.contentEquals(byteArrayOf(1, 2, 3)))
        assertTrue(c.aprendizaje.imagenes.containsKey("ref_1.png"))
    }

    @Test
    fun sin_captura_ni_joystick() {
        val base = contenido(null)
        val sin = ContenidoDeRespaldo(base.configuracion.copy(joystick = null), base.aprendizaje, base.imagenesMateriales, null)
        val c = PaqueteDeRespaldo.desempaquetar(PaqueteDeRespaldo.empaquetar(sin))!!
        assertNull(c.captura)
        assertNull(c.configuracion.joystick)
    }

    @Test
    fun archivo_ajeno_o_danado_se_rechaza() {
        assertNull(PaqueteDeRespaldo.desempaquetar("hola".toByteArray()))
        assertNull(PaqueteDeRespaldo.desempaquetar(ByteArray(0)))
        val bytes = PaqueteDeRespaldo.empaquetar(contenido())
        val roto = bytes.copyOf()
        roto[20] = (roto[20] + 1).toByte()
        assertNull(PaqueteDeRespaldo.desempaquetar(roto))
        assertNull(PaqueteDeRespaldo.desempaquetar(bytes.copyOf(bytes.size - 10)))
    }

    @Test
    fun el_texto_del_aprendizaje_no_vale_como_copia() {
        val texto = FormatoDeCopia.escribir(contenido().aprendizaje).toByteArray()
        assertNull(PaqueteDeRespaldo.desempaquetar(texto))
    }

    @Test
    fun nombres_con_rutas_se_rechazan() {
        val entradas = linkedMapOf(
            "config" to FormatoDeConfiguracion.escribir(contenido().configuracion).toByteArray(),
            "aprendizaje" to FormatoDeCopia.escribir(contenido().aprendizaje).toByteArray(),
            "material/../evil.png" to byteArrayOf(1)
        )
        assertNull(PaqueteDeRespaldo.desempaquetar(PaqueteDeRespaldo.escribirEntradas(entradas)))
    }

    @Test
    fun area_con_material_inexistente_se_rechaza() {
        val c = contenido().configuracion
        val mala = c.copy(areas = listOf(c.areas[0].copy(materiales = listOf(99L))))
        assertNull(FormatoDeConfiguracion.leer(FormatoDeConfiguracion.escribir(mala)))
    }

    @Test
    fun resumen_menciona_lo_que_lleva() {
        val r = contenido().resumen()
        assertTrue(r.contains("2 materiales"))
        assertTrue(r.contains("joystick"))
        assertTrue(r.contains("macro del cofre"))
    }
}
