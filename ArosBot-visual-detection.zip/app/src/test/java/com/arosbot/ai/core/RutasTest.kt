package com.arosbot.ai.core

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas de LÓGICA en entorno simulado (JVM): rutas, grafo, estadísticas, guía y copia de seguridad. */
class RutasTest {

    private fun ruta(
        id: Long,
        origen: Long,
        destino: Long,
        duracionMs: Long = 10_000L,
        intentos: Int = 0,
        exitos: Int = 0,
        media: Double = 0.0,
        puntos: List<PuntoDeRuta> = emptyList()
    ) = Ruta(id, "Ruta $id", origen, destino, puntos, intentos, exitos, media, duracionMs, 1000L)

    private fun calibraciones() = mapOf(
        Direccion.W to Calibracion(Direccion.W, 0.0, 150.0, 1),
        Direccion.S to Calibracion(Direccion.S, 0.0, -150.0, 1),
        Direccion.A to Calibracion(Direccion.A, 150.0, 0.0, 1),
        Direccion.D to Calibracion(Direccion.D, -150.0, 0.0, 1)
    )

    // ---------- Estadística ----------

    @Test
    fun fiabilidadParteDeUnaMitadYSube() {
        assertEquals(0.5, Estadistica.fiabilidad(0, 0), 1e-9)
        assertEquals(0.8, Estadistica.fiabilidad(3, 3), 1e-9)
        assertEquals(2.0 / 3.0, Estadistica.fiabilidad(4, 3), 1e-9)
        assertEquals(1.0 / 12.0, Estadistica.fiabilidad(10, 0), 1e-9)
    }

    @Test
    fun confianzaDistingueConfirmadoEstimadoEIncierto() {
        assertEquals(Confianza.CONFIRMADO, Estadistica.confianza(3, 3))
        assertEquals(Confianza.ESTIMACION, Estadistica.confianza(1, 1))
        assertEquals(Confianza.ESTIMACION, Estadistica.confianza(4, 3))
        assertEquals(Confianza.INCIERTO, Estadistica.confianza(2, 0))
        assertEquals(Confianza.INCIERTO, Estadistica.confianza(0, 0))
    }

    @Test
    fun duracionSeAjustaGradualmente() {
        assertEquals(1000.0, Estadistica.nuevaDuracion(0.0, 0, 1000.0), 1e-9)
        assertEquals(1500.0, Estadistica.nuevaDuracion(1000.0, 1, 2000.0), 1e-9)
        assertEquals(1200.0, Estadistica.nuevaDuracion(1000.0, 10, 2000.0), 1e-9)
    }

    @Test
    fun velocidadAprendidaNoSeDisparaDeLaCalibrada() {
        assertEquals(130.0, Estadistica.nuevaVelocidad(100.0, 200.0, 100.0), 1e-9)
        assertEquals(150.0, Estadistica.nuevaVelocidad(100.0, 1000.0, 100.0), 1e-9)
        assertEquals(100.0, Estadistica.nuevaVelocidad(100.0, 0.0, 100.0), 1e-9)
    }

    // ---------- Ruta ----------

    @Test
    fun longitudSumaLosTramos() {
        val r = ruta(
            1, 1, 2,
            puntos = listOf(
                PuntoDeRuta(0.0, 0.0, 0L),
                PuntoDeRuta(3.0, 4.0, 100L),
                PuntoDeRuta(3.0, 10.0, 200L)
            )
        )
        assertEquals(11.0, r.longitudPx, 1e-9)
    }

    @Test
    fun sentidoInversoRecorreAlReves() {
        val r = ruta(
            1, 1, 2,
            puntos = listOf(
                PuntoDeRuta(0.0, 0.0, 0L),
                PuntoDeRuta(10.0, 0.0, 100L),
                PuntoDeRuta(10.0, 20.0, 300L)
            )
        )
        val inversa = r.puntosEnSentido(true)
        assertEquals(3, inversa.size)
        assertEquals(PuntoDeRuta(0.0, 0.0, 0L), inversa[0])
        assertEquals(PuntoDeRuta(0.0, -20.0, 200L), inversa[1])
        assertEquals(PuntoDeRuta(-10.0, -20.0, 300L), inversa[2])
        assertEquals(r.puntos, r.puntosEnSentido(false))
    }

    @Test
    fun duracionEstimadaPrefiereLoAprendido() {
        assertEquals(10_000.0, ruta(1, 1, 2, duracionMs = 10_000L).duracionEstimadaMs, 1e-9)
        assertEquals(7_000.0, ruta(1, 1, 2, duracionMs = 10_000L, intentos = 2, exitos = 2, media = 7000.0).duracionEstimadaMs, 1e-9)
    }

    @Test
    fun validacionPideLongitudYReferencias() {
        val ref = ReferenciaVisual("a.png", 10, 10, 50, 50)
        assertNotNull(ValidacionDeRuta.problema(emptyList()))
        val corta = listOf(PuntoDeRuta(0.0, 0.0, 0L, ref), PuntoDeRuta(10.0, 0.0, 100L, ref))
        assertNotNull(ValidacionDeRuta.problema(corta))
        val sinFinal = listOf(PuntoDeRuta(0.0, 0.0, 0L, ref), PuntoDeRuta(300.0, 0.0, 100L, null))
        assertNotNull(ValidacionDeRuta.problema(sinFinal))
        val sinInicio = listOf(PuntoDeRuta(0.0, 0.0, 0L, null), PuntoDeRuta(300.0, 0.0, 100L, ref))
        assertNotNull(ValidacionDeRuta.problema(sinInicio))
        val buena = listOf(PuntoDeRuta(0.0, 0.0, 0L, ref), PuntoDeRuta(300.0, 0.0, 100L, ref))
        assertNull(ValidacionDeRuta.problema(buena))
    }

    // ---------- Acumulador ----------

    @Test
    fun acumuladorInvierteElSignoDeLaEscena() {
        val a = AcumuladorDeTrayecto()
        a.mover(0.0, 50.0) // la escena baja: el personaje subió
        assertEquals(0.0, a.x, 1e-9)
        assertEquals(-50.0, a.y, 1e-9)
        a.mover(-30.0, 0.0) // la escena va a la izquierda: el personaje fue a la derecha
        assertEquals(30.0, a.x, 1e-9)
    }

    @Test
    fun acumuladorIgnoraElRuido() {
        val a = AcumuladorDeTrayecto()
        a.mover(1.0, 1.0)
        assertEquals(0.0, a.x, 1e-9)
        assertEquals(0.0, a.y, 1e-9)
        assertFalse(a.puntoPendiente())
    }

    @Test
    fun acumuladorPideUnPuntoCadaCienPixeles() {
        val a = AcumuladorDeTrayecto()
        a.mover(0.0, 60.0)
        assertFalse(a.puntoPendiente())
        a.mover(0.0, 60.0)
        assertTrue(a.puntoPendiente())
        a.registrar(500L, null)
        assertFalse(a.puntoPendiente())
        assertEquals(1, a.puntos.size)
        assertEquals(-120.0, a.puntos[0].y, 1e-9)
    }

    @Test
    fun acumuladorPideReferenciaCadaTrescientosPixeles() {
        val a = AcumuladorDeTrayecto()
        for (i in 1..5) a.mover(0.0, 50.0)
        assertFalse(a.referenciaPendiente())
        a.mover(0.0, 50.0)
        assertTrue(a.referenciaPendiente())
        a.registrar(1L, ReferenciaVisual("r.png", 0, 0, 10, 10))
        assertFalse(a.referenciaPendiente())
    }

    // ---------- Guía ----------

    @Test
    fun guiaCorrigeElEjeConMasError() {
        val g = GuiaDeRuta.siguientePaso(0.0, 0.0, 0.0, -100.0, calibraciones())
        assertEquals(Guia.Mover(Direccion.W, 566L), g)
        val h = GuiaDeRuta.siguientePaso(0.0, 0.0, 200.0, 50.0, calibraciones())
        assertEquals(Guia.Mover(Direccion.D, 1133L), h)
        val i = GuiaDeRuta.siguientePaso(0.0, 0.0, -200.0, 50.0, calibraciones())
        assertEquals(Guia.Mover(Direccion.A, 1133L), i)
        val j = GuiaDeRuta.siguientePaso(0.0, 0.0, 10.0, 200.0, calibraciones())
        assertEquals(Guia.Mover(Direccion.S, 1133L), j)
    }

    @Test
    fun guiaDaPorLlegadoDentroDeLaTolerancia() {
        assertEquals(Guia.Llegado, GuiaDeRuta.siguientePaso(0.0, 0.0, 5.0, 5.0, calibraciones()))
        assertEquals(Guia.Llegado, GuiaDeRuta.siguientePaso(100.0, 100.0, 119.0, 81.0, calibraciones()))
    }

    @Test
    fun guiaAcotaLaDuracion() {
        val corta = GuiaDeRuta.siguientePaso(0.0, 0.0, 0.0, -25.0, calibraciones())
        assertEquals(Guia.Mover(Direccion.W, GuiaDeRuta.DURACION_MINIMA_MS), corta)
        val larga = GuiaDeRuta.siguientePaso(0.0, 0.0, 0.0, -5000.0, calibraciones())
        assertEquals(Guia.Mover(Direccion.W, GuiaDeRuta.DURACION_MAXIMA_MS), larga)
    }

    @Test
    fun guiaSinCalibracionNoInventaNada() {
        val g = GuiaDeRuta.siguientePaso(0.0, 0.0, 0.0, -100.0, emptyMap())
        assertEquals(Guia.SinCalibracion(Direccion.W), g)
        val vacia = mapOf(Direccion.W to Calibracion.vacia(Direccion.W))
        assertEquals(Guia.SinCalibracion(Direccion.W), GuiaDeRuta.siguientePaso(0.0, 0.0, 0.0, -100.0, vacia))
    }

    // ---------- Planificador ----------

    @Test
    fun planificaPorElCaminoMasBarato() {
        val rutas = listOf(
            ruta(1, 1, 2, 10_000L),
            ruta(2, 2, 3, 10_000L),
            ruta(3, 1, 3, 50_000L)
        )
        val plan = PlanificadorDeRutas.planificar(rutas, 1L, 3L)
        assertNotNull(plan)
        assertEquals(listOf(1L, 2L), plan!!.tramos.map { it.ruta.id })
        assertTrue(plan.tramos.none { it.inversa })
        assertEquals(20_000.0, plan.duracionMs, 1e-9)
        assertEquals(0.25, plan.fiabilidad, 1e-9)
    }

    @Test
    fun planificaAlReves() {
        val rutas = listOf(
            ruta(1, 1, 2, 10_000L),
            ruta(2, 2, 3, 10_000L),
            ruta(3, 1, 3, 50_000L)
        )
        val plan = PlanificadorDeRutas.planificar(rutas, 3L, 1L)
        assertNotNull(plan)
        assertEquals(listOf(2L, 1L), plan!!.tramos.map { it.ruta.id })
        assertTrue(plan.tramos.all { it.inversa })
        assertEquals(30_000.0, plan.duracionMs, 1e-9)
    }

    @Test
    fun planificadorPrefiereLaRutaFiableAunqueSeaMasLenta() {
        val mala = ruta(1, 1, 2, 10_000L, intentos = 10, exitos = 0)
        val buena = ruta(2, 1, 2, 30_000L, intentos = 10, exitos = 10)
        val plan = PlanificadorDeRutas.planificar(listOf(mala, buena), 1L, 2L)
        assertEquals(listOf(2L), plan!!.tramos.map { it.ruta.id })
    }

    @Test
    fun planificadorCasosLimite() {
        val rutas = listOf(ruta(1, 1, 2))
        val mismo = PlanificadorDeRutas.planificar(rutas, 1L, 1L)
        assertNotNull(mismo)
        assertTrue(mismo!!.tramos.isEmpty())
        assertNull(PlanificadorDeRutas.planificar(rutas, 1L, 9L))
        assertNull(PlanificadorDeRutas.planificar(listOf(ruta(1, 1, 2), ruta(2, 3, 4)), 1L, 4L))
        assertNull(PlanificadorDeRutas.planificar(emptyList(), 1L, 2L))
    }

    // ---------- Codificación ----------

    @Test
    fun puntosSobrevivenAlCodificar() {
        val puntos = listOf(
            PuntoDeRuta(0.0, 0.0, 0L, ReferenciaVisual("a.png", 12, 34, 56, 78)),
            PuntoDeRuta(-12.5, 99.25, 1500L, null)
        )
        val texto = CodificadorDePuntos.codificar(puntos)
        assertEquals(puntos, CodificadorDePuntos.decodificar(texto))
        assertTrue(CodificadorDePuntos.decodificar("").isEmpty())
        assertTrue(CodificadorDePuntos.decodificar("basura").isEmpty())
    }

    // ---------- Copia de seguridad ----------

    private fun copiaDeEjemplo(): CopiaDeAprendizaje {
        val puntos = listOf(
            PuntoDeRuta(0.0, 0.0, 0L, ReferenciaVisual("r1.png", 1, 2, 3, 4)),
            PuntoDeRuta(0.0, -300.0, 2000L, ReferenciaVisual("r2.png", 5, 6, 7, 8))
        )
        return CopiaDeAprendizaje(
            lugares = listOf(Lugar(1L, "Cofre | principal"), Lugar(2L, "Spot\nuno")),
            rutas = listOf(
                Ruta(7L, "Cofre → Spot | 1", 1L, 2L, puntos, 5, 4, 2100.5, 2000L, 123456L)
            ),
            intentos = listOf(
                Intento(1L, 7L, 999L, true, 2100L, 8, 2, "ok"),
                Intento(2L, 7L, 1999L, false, 5000L, 20, 6, "perdí la referencia | fin")
            ),
            calibraciones = listOf(Calibracion(Direccion.W, 0.5, 151.25, 6)),
            imagenes = mapOf("r1.png" to byteArrayOf(1, 2, 3, -1), "r2.png" to byteArrayOf())
        )
    }

    @Test
    fun copiaSobreviveAEscribirYLeer() {
        val original = copiaDeEjemplo()
        val leida = FormatoDeCopia.leer(FormatoDeCopia.escribir(original))
        assertNotNull(leida)
        assertEquals(original.lugares, leida!!.lugares)
        assertEquals(original.rutas, leida.rutas)
        assertEquals(original.intentos, leida.intentos)
        assertEquals(original.calibraciones, leida.calibraciones)
        assertEquals(original.imagenes.keys, leida.imagenes.keys)
        assertArrayEquals(original.imagenes.getValue("r1.png"), leida.imagenes.getValue("r1.png"))
        assertArrayEquals(original.imagenes.getValue("r2.png"), leida.imagenes.getValue("r2.png"))
    }

    @Test
    fun copiaRechazaArchivosAjenosOCorruptos() {
        assertNull(FormatoDeCopia.leer(""))
        assertNull(FormatoDeCopia.leer("otra cosa\nL|1|x"))
        assertNull(FormatoDeCopia.leer("AROSBOT-APRENDIZAJE 1\nL|uno|x"))
        // Una ruta que apunta a un lugar que no existe.
        assertNull(FormatoDeCopia.leer("AROSBOT-APRENDIZAJE 1\nL|1|A\nR|1|r|1|2|0|0|0.0|0|0|"))
    }

    @Test
    fun relocalizacionRestaElDesplazamientoDeLaEscena() {
        val punto = PuntoDeRuta(100.0, 50.0, 0L)
        // La escena se ve 30 px a la derecha y 10 arriba: el personaje está 30 a la izquierda y 10 abajo.
        val (x, y) = Relocalizacion.posicion(punto, 30.0, -10.0)
        assertEquals(70.0, x, 1e-9)
        assertEquals(60.0, y, 1e-9)
    }

    @Test
    fun relocalizacionSinDesplazamientoDejaLaPosicion() {
        val punto = PuntoDeRuta(-12.0, 7.5, 0L)
        val (x, y) = Relocalizacion.posicion(punto, 0.0, 0.0)
        assertEquals(-12.0, x, 1e-9)
        assertEquals(7.5, y, 1e-9)
    }

    @Test
    fun relocalizacionMideElErrorYExigeConfianza() {
        assertEquals(5.0, Relocalizacion.error(3.0, -4.0), 1e-9)
        assertTrue(Relocalizacion.fiable(0.61))
        assertFalse(Relocalizacion.fiable(0.59))
    }
}
