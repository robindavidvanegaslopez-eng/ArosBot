package com.arosbot.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas de LÓGICA en entorno simulado (JVM): spots y elección de destino. */
class SpotsTest {

    private fun spot(
        id: Long = 1,
        nombre: String = "Cantera",
        lugarId: Long = 1,
        materiales: List<Long> = emptyList(),
        prioridad: Int = 3,
        visitas: Int = 0,
        conRecursos: Int = 0,
        agotadoDesde: Long = 0,
        recuperacion: Double = 300_000.0
    ) = Spot(
        id, nombre, lugarId, materiales, prioridad, visitas, conRecursos,
        0L, agotadoDesde, recuperacion, 0L
    )

    private fun ruta(id: Long, origen: Long, destino: Long, duracionMs: Long = 60_000) = Ruta(
        id, "Ruta $id", origen, destino, emptyList(), 0, 0, 0.0, duracionMs, 0L
    )

    private fun material(id: Long, nombre: String, categoria: String = "Recurso") = Material(
        id, nombre, categoria, 0.8f, 10, 10, listOf("a.png"), 0, null, EstadoReconocimiento.SIN_PROBAR
    )

    // ---------- Disponibilidad ----------

    @Test
    fun probabilidadSegunLoQueSeSabe() {
        assertEquals(0.5, spot(visitas = 0).probabilidadDisponible(1_000L), 1e-9)
        assertEquals(0.9, spot(visitas = 2, conRecursos = 2).probabilidadDisponible(1_000L), 1e-9)
        val agotado = spot(visitas = 1, agotadoDesde = 1_000L)
        assertEquals(0.05, agotado.probabilidadDisponible(1_000L), 1e-9)
        assertEquals(0.2625, agotado.probabilidadDisponible(151_000L), 1e-9)
        assertEquals(0.9, agotado.probabilidadDisponible(301_000L), 1e-9)
    }

    @Test
    fun disponibilidadYTiempoParaQueVuelva() {
        assertEquals(Disponibilidad.SIN_VISITAR, spot(visitas = 0).disponibilidad(0L))
        val agotado = spot(visitas = 1, agotadoDesde = 1_000L)
        assertEquals(Disponibilidad.AGOTADO, agotado.disponibilidad(101_000L))
        assertEquals(Disponibilidad.DISPONIBLE, agotado.disponibilidad(301_001L))
        assertEquals(200_000L, agotado.vuelveEnMs(101_000L))
        assertEquals(0L, agotado.vuelveEnMs(999_999L))
        assertEquals(0L, spot(visitas = 1).vuelveEnMs(5L))
    }

    // ---------- Aprendizaje de visitas ----------

    @Test
    fun primeraVisitaVaciaMarcaAgotado() {
        val s = ActualizacionDeSpot.trasVisita(spot(), encontrado = false, ahoraMs = 50_000L)
        assertEquals(1, s.visitas)
        assertEquals(0, s.conRecursos)
        assertEquals(50_000L, s.agotadoDesdeMs)
        assertEquals(50_000L, s.ultimaVisitaMs)
        assertEquals(300_000.0, s.recuperacionMs, 1e-9)
    }

    @Test
    fun visitaConRecursosSinAgotarNoCambiaLaRecuperacion() {
        val s = ActualizacionDeSpot.trasVisita(spot(visitas = 1), encontrado = true, ahoraMs = 9_000L)
        assertEquals(2, s.visitas)
        assertEquals(1, s.conRecursos)
        assertEquals(0L, s.agotadoDesdeMs)
        assertEquals(300_000.0, s.recuperacionMs, 1e-9)
    }

    @Test
    fun siVuelveAHaberRecursosAntesLaRecuperacionBaja() {
        val agotado = spot(visitas = 1, agotadoDesde = 1_000L)
        val s = ActualizacionDeSpot.trasVisita(agotado, encontrado = true, ahoraMs = 121_000L)
        // Pasaron 120 s: 300 000 + (120 000 - 300 000) * 0,5 = 210 000.
        assertEquals(210_000.0, s.recuperacionMs, 1e-6)
        assertEquals(0L, s.agotadoDesdeMs)
    }

    @Test
    fun siHayRecursosDespuesDeMasTiempoNoSeCambiaLaEstimacion() {
        val agotado = spot(visitas = 1, agotadoDesde = 1_000L)
        val s = ActualizacionDeSpot.trasVisita(agotado, encontrado = true, ahoraMs = 401_000L)
        assertEquals(300_000.0, s.recuperacionMs, 1e-9)
    }

    @Test
    fun siSigueVacioLaRecuperacionEsMasLenta() {
        val agotado = spot(visitas = 1, agotadoDesde = 1_000L)
        val s = ActualizacionDeSpot.trasVisita(agotado, encontrado = false, ahoraMs = 401_000L)
        // Pasaron 400 s y seguía vacío: 400 000 * 1,5 = 600 000. Se conserva el momento de agotarse.
        assertEquals(600_000.0, s.recuperacionMs, 1e-6)
        assertEquals(1_000L, s.agotadoDesdeMs)
        assertEquals(2, s.visitas)
    }

    @Test
    fun laRecuperacionNuncaSeSaleDeLosLimites() {
        val agotado = spot(visitas = 1, agotadoDesde = 1L)
        val largo = ActualizacionDeSpot.trasVisita(agotado, encontrado = false, ahoraMs = 1_000_000_000L)
        assertEquals(Spot.RECUPERACION_MAXIMA_MS, largo.recuperacionMs, 1e-6)
        val corto = ActualizacionDeSpot.trasVisita(
            spot(visitas = 1, agotadoDesde = 1L, recuperacion = 40_000.0), encontrado = true, ahoraMs = 2L
        )
        assertTrue(corto.recuperacionMs >= Spot.RECUPERACION_MINIMA_MS)
    }

    // ---------- Elección de destino ----------

    @Test
    fun gananLosSpotsBaratosYBuenos() {
        val rutas = listOf(ruta(1, 1, 2))
        val lejano = spot(id = 1, lugarId = 2, prioridad = 3, visitas = 0)
        val aqui = spot(id = 2, nombre = "Aquí", lugarId = 1, prioridad = 1, visitas = 2, conRecursos = 2)
        val r = EleccionDeSpot.elegir(listOf(lejano, aqui), rutas, 1L, 0L)
        // aquí: 0,9 / 0,5 min = 1,8; lejano: 1,5 / 2,5 min = 0,6.
        assertEquals(2L, r.elegido?.spot?.id)
        assertEquals(1.8, r.candidatos[0].puntuacion, 1e-9)
        assertEquals(0.6, r.candidatos[1].puntuacion, 1e-9)
        assertTrue(r.candidatos[0].plan.tramos.isEmpty())
    }

    @Test
    fun laPrioridadAltaCompensaElViaje() {
        val rutas = listOf(ruta(1, 1, 2))
        val bueno = spot(id = 1, lugarId = 2, prioridad = 5, visitas = 2, conRecursos = 2)
        val flojo = spot(id = 2, nombre = "Flojo", lugarId = 1, prioridad = 1, visitas = 0)
        val r = EleccionDeSpot.elegir(listOf(flojo, bueno), rutas, 1L, 0L)
        // bueno: 4,5 / 2,5 = 1,8; flojo: 0,5 / 0,5 = 1,0.
        assertEquals(1L, r.elegido?.spot?.id)
    }

    @Test
    fun unSpotAgotadoSePenaliza() {
        val rutas = listOf(ruta(1, 1, 2))
        val agotado = spot(id = 1, nombre = "Agotado", lugarId = 1, prioridad = 5, visitas = 1, agotadoDesde = 0L + 1L)
        val bueno = spot(id = 2, nombre = "Bueno", lugarId = 2, prioridad = 3, visitas = 2, conRecursos = 2)
        val r = EleccionDeSpot.elegir(listOf(agotado, bueno), rutas, 1L, 1L)
        // agotado ahora mismo: 5 * 0,05 / 0,5 = 0,5; bueno: 2,7 / 2,5 = 1,08.
        assertEquals(2L, r.elegido?.spot?.id)
        assertEquals(0.5, r.candidatos[1].puntuacion, 1e-9)
    }

    @Test
    fun sinRutaHastaUnSpotSeDescarta() {
        val rutas = listOf(ruta(1, 1, 2))
        val aislado = spot(id = 1, nombre = "Aislado", lugarId = 9)
        val alcanzable = spot(id = 2, nombre = "Alcanzable", lugarId = 2)
        val r = EleccionDeSpot.elegir(listOf(aislado, alcanzable), rutas, 1L, 0L)
        assertEquals(2L, r.elegido?.spot?.id)
        assertEquals(1, r.descartados.size)
        assertEquals(1L, r.descartados[0].first.id)
        assertTrue(r.descartados[0].second.contains("ruta"))
    }

    @Test
    fun sinUbicacionNoSeEligeNada() {
        val r = EleccionDeSpot.elegir(listOf(spot(id = 1), spot(id = 2)), listOf(ruta(1, 1, 2)), null, 0L)
        assertNull(r.elegido)
        assertEquals(2, r.descartados.size)
        assertTrue(r.candidatos.isEmpty())
    }

    @Test
    fun sinSpotsNoSeEligeNada() {
        val r = EleccionDeSpot.elegir(emptyList(), listOf(ruta(1, 1, 2)), 1L, 0L)
        assertNull(r.elegido)
    }

    @Test
    fun puedeIrAlReves() {
        val rutas = listOf(ruta(1, 1, 2))
        val s = spot(id = 1, lugarId = 1, visitas = 2, conRecursos = 2)
        val r = EleccionDeSpot.elegir(listOf(s), rutas, 2L, 0L)
        val elegido = r.elegido
        assertNotNull(elegido)
        assertEquals(1, elegido!!.plan.tramos.size)
        assertTrue(elegido.plan.tramos[0].inversa)
    }

    @Test
    fun elEmpateSeResuelvePorPrioridadYNombre() {
        val rutas = emptyList<Ruta>()
        val a = spot(id = 1, nombre = "B", lugarId = 1, prioridad = 3, visitas = 2, conRecursos = 2)
        val b = spot(id = 2, nombre = "A", lugarId = 1, prioridad = 3, visitas = 2, conRecursos = 2)
        val r = EleccionDeSpot.elegir(listOf(a, b), rutas, 1L, 0L)
        // Los dos están en el mismo lugar: no hace falta ninguna ruta y gana el de nombre «A».
        assertEquals(2L, r.elegido?.spot?.id)
    }

    // ---------- Materiales buscados ----------

    @Test
    fun sinMaterialesPropiosSeBuscaTodoMenosLoDeApoyo() {
        val mats = listOf(
            material(1, "Piedra"), material(2, "Hierro"),
            material(3, "Mi personaje", "Personaje"), material(4, "Log in"), material(5, "Cuenta Google")
        )
        val buscados = MaterialesDelSpot.buscados(spot(), mats).map { it.id }
        assertEquals(listOf(1L, 2L), buscados)
    }

    @Test
    fun conMaterialesPropiosSoloEsosYNuncaLosDeApoyo() {
        val mats = listOf(material(1, "Piedra"), material(2, "Hierro"), material(3, "Mi personaje", "Personaje"))
        val buscados = MaterialesDelSpot.buscados(spot(materiales = listOf(2L, 3L)), mats).map { it.id }
        assertEquals(listOf(2L), buscados)
    }

    // ---------- Copia de seguridad ----------

    @Test
    fun losSpotsSobrevivenALaCopia() {
        val s = spot(
            id = 7, nombre = "Cantera | norte", lugarId = 1, materiales = listOf(1L, 2L),
            prioridad = 4, visitas = 3, conRecursos = 2, agotadoDesde = 5_000L, recuperacion = 210_000.0
        )
        val sin = spot(id = 8, nombre = "Cualquiera", lugarId = 1)
        val copia = CopiaDeAprendizaje(
            lugares = listOf(Lugar(1, "Campamento")),
            rutas = emptyList(),
            intentos = emptyList(),
            calibraciones = emptyList(),
            imagenes = emptyMap(),
            spots = listOf(s, sin)
        )
        val leida = FormatoDeCopia.leer(FormatoDeCopia.escribir(copia))
        assertNotNull(leida)
        assertEquals(listOf(s, sin), leida!!.spots)
    }

    @Test
    fun unaCopiaConUnSpotEnUnLugarInexistenteSeRechaza() {
        val copia = CopiaDeAprendizaje(
            lugares = listOf(Lugar(1, "Campamento")),
            rutas = emptyList(),
            intentos = emptyList(),
            calibraciones = emptyList(),
            imagenes = emptyMap(),
            spots = listOf(spot(id = 1, lugarId = 99))
        )
        assertNull(FormatoDeCopia.leer(FormatoDeCopia.escribir(copia)))
    }

    @Test
    fun tiemposLegibles() {
        assertEquals("45 s", TiempoLegible.de(45_000))
        assertEquals("2 min 5 s", TiempoLegible.de(125_000))
        assertEquals("1 h 1 min", TiempoLegible.de(3_660_000))
        assertEquals("0 s", TiempoLegible.de(-5))
    }
}
