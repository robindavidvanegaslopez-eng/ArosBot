package com.arosbot.ai.core

import kotlin.math.hypot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas de LÓGICA en entorno simulado (JVM): trazo del joystick, diagonales y optimización. */
class TrazosTest {

    private fun pr(x: Double, y: Double, t: Long = 0, ref: Boolean = false) = PuntoDeRuta(
        x, y, t, if (ref) ReferenciaVisual("r.png", 0, 0, 10, 10) else null
    )

    private val cardinales = mapOf(
        Direccion.W to Calibracion(Direccion.W, 0.0, 150.0, 3),
        Direccion.S to Calibracion(Direccion.S, 0.0, -150.0, 3),
        Direccion.A to Calibracion(Direccion.A, 150.0, 0.0, 3),
        Direccion.D to Calibracion(Direccion.D, -150.0, 0.0, 3)
    )

    // ---------- Ocho direcciones ----------

    @Test
    fun lasDiagonalesSonUnitarias() {
        for (d in Direccion.values()) {
            assertEquals(1.0, hypot(d.unitarioX, d.unitarioY), 1e-9)
        }
        assertEquals(8, Direccion.values().size)
        assertTrue(Direccion.WD.esDiagonal)
        assertFalse(Direccion.W.esDiagonal)
    }

    @Test
    fun cadaDireccionTieneOpuestaYVuelve() {
        for (d in Direccion.values()) {
            assertEquals(d, d.opuesta.opuesta)
            assertEquals(-d.ux, d.opuesta.ux)
            assertEquals(-d.uy, d.opuesta.uy)
        }
    }

    @Test
    fun laDireccionMasCercanaSigueElAngulo() {
        assertEquals(Direccion.D, Direccion.masCercana(100.0, 5.0))
        assertEquals(Direccion.SD, Direccion.masCercana(100.0, 100.0))
        assertEquals(Direccion.S, Direccion.masCercana(5.0, 100.0))
        assertEquals(Direccion.SA, Direccion.masCercana(-100.0, 100.0))
        assertEquals(Direccion.A, Direccion.masCercana(-100.0, -5.0))
        assertEquals(Direccion.WA, Direccion.masCercana(-100.0, -100.0))
        assertEquals(Direccion.W, Direccion.masCercana(2.0, -100.0))
        assertEquals(Direccion.WD, Direccion.masCercana(100.0, -100.0))
        // Entre D (0°) y SD (45°): 20° se queda en D y 25° pasa a SD.
        assertEquals(Direccion.D, Direccion.masCercana(100.0, 36.0))
        assertEquals(Direccion.SD, Direccion.masCercana(100.0, 47.0))
    }

    @Test
    fun lasDiagonalesSeDerivanDeLasCardinales() {
        val wd = Calibraciones.para(cardinales, Direccion.WD)!!
        // W: la escena baja (vy +150); D: la escena va a la izquierda (vx -150).
        assertEquals(-106.066, wd.vx, 0.01)
        assertEquals(106.066, wd.vy, 0.01)
        assertEquals(150.0, wd.rapidez, 0.01)
        val sa = Calibraciones.para(cardinales, Direccion.SA)!!
        assertEquals(106.066, sa.vx, 0.01)
        assertEquals(-106.066, sa.vy, 0.01)
    }

    @Test
    fun sinCardinalesNoHayDiagonal() {
        val sinD = cardinales - Direccion.D
        assertEquals(null, Calibraciones.para(sinD, Direccion.WD))
        assertEquals(null, Calibraciones.para(sinD, Direccion.SD))
        assertTrue(Calibraciones.para(sinD, Direccion.WA) != null)
        assertEquals(null, Calibraciones.para(mapOf(Direccion.D to Calibracion.vacia(Direccion.D)), Direccion.D))
    }

    @Test
    fun laGuiaConDiagonalesVaEnLineaRecta() {
        val g = GuiaDeRuta.siguientePaso(0.0, 0.0, 200.0, 200.0, cardinales, diagonales = true)
        assertTrue(g is Guia.Mover)
        g as Guia.Mover
        assertEquals(Direccion.SD, g.direccion)
        // Falta 282,8 px en la diagonal: 282,8 * 0,85 / 150 = 1,6 s, recortado al máximo de 1,5 s.
        assertEquals(GuiaDeRuta.DURACION_MAXIMA_MS, g.duracionMs)
        val corta = GuiaDeRuta.siguientePaso(0.0, 0.0, -60.0, -60.0, cardinales, diagonales = true) as Guia.Mover
        assertEquals(Direccion.WA, corta.direccion)
        val esperado = ((60.0 * 1.4142135 * 0.85) / 150.0 * 1000.0).toLong()
        assertTrue(kotlin.math.abs(esperado - corta.duracionMs) <= 2L)
    }

    @Test
    fun sinDiagonalesSigueSiendoEscalera() {
        val g = GuiaDeRuta.siguientePaso(0.0, 0.0, 200.0, 200.0, cardinales) as Guia.Mover
        assertFalse(g.direccion.esDiagonal)
    }

    @Test
    fun laGuiaConDiagonalesLlegaSimulandoPasos() {
        // Simulación: cada paso mueve exactamente lo calibrado. Debe llegar en pocos pasos.
        var x = 0.0
        var y = 0.0
        var pasos = 0
        while (pasos < 40) {
            val g = GuiaDeRuta.siguientePaso(x, y, 300.0, 120.0, cardinales, diagonales = true)
            if (g is Guia.Llegado) break
            g as Guia.Mover
            val c = Calibraciones.para(cardinales, g.direccion)!!
            x -= c.vx * g.duracionMs / 1000.0
            y -= c.vy * g.duracionMs / 1000.0
            pasos++
        }
        assertTrue("llegó en $pasos pasos", pasos in 1..12)
        assertTrue(hypot(300.0 - x, 120.0 - y) < 30.0)
    }

    @Test
    fun lasDiagonalesNoNecesitanCalibracionPropiaParaLaCoherencia() {
        // Con solo las cuatro cardinales la calibración ya es coherente: las diagonales se derivan.
        assertTrue(EvaluadorProgreso.calibracionCoherente(cardinales).isEmpty())
    }

    @Test
    fun laGeometriaDelJoystickEnDiagonalNoSeSaleDelCirculo() {
        val rect = NormRect(0.1f, 0.5f, 0.2f, 0.1f)
        val p = GeometriaJoystick.puntos(rect, 1000, 2000, Direccion.SD)
        val radio = minOf(0.2f * 1000, 0.1f * 2000) / 2f
        assertEquals(radio.toDouble(), hypot((p.destinoX - p.centroX).toDouble(), (p.destinoY - p.centroY).toDouble()), 0.01)
        assertTrue(p.destinoX > p.centroX && p.destinoY > p.centroY)
    }

    // ---------- Trazo del joystick ----------

    @Test
    fun unPulsoCortoEsSoloElArrastre() {
        val t = TrazoDeJoystick.puntos(100f, 100f, 200f, 100f, 60)
        assertEquals(2, t.size)
    }

    @Test
    fun elTrazoLargoReparteElTiempoComoSeEspera() {
        val total = 1500L
        val t = TrazoDeJoystick.puntos(100f, 100f, 200f, 100f, total)
        val largoTotal = TrazoDeJoystick.longitud(t)
        val fraccionArrastre = 100.0 / largoTotal
        // El arrastre del centro al borde debe ocupar ~80 ms de los 1500 ms.
        assertEquals(80.0 / total, fraccionArrastre, 0.002)
    }

    @Test
    fun elZigzagNoSeSaleDeUnosPixelesDelBorde() {
        val t = TrazoDeJoystick.puntos(100f, 100f, 100f, 0f, 1500L)
        for (i in 2 until t.size) {
            assertTrue(hypot((t[i].x - 100f).toDouble(), (t[i].y - 0f).toDouble()) < 2.0)
        }
        // Es perpendicular: en un empuje vertical solo cambia la x.
        assertTrue(t.drop(2).all { kotlin.math.abs(it.y - 0f) < 0.01f })
    }

    @Test
    fun elTrazoEnDiagonalTambienEsUnSoloTrazoContinuo() {
        val t = TrazoDeJoystick.puntos(0f, 0f, 70.7f, 70.7f, 1000L)
        assertTrue(t.size > 10)
        assertEquals(PuntoXY(0f, 0f), t[0])
        assertEquals(PuntoXY(70.7f, 70.7f), t[1])
    }

    @Test
    fun elNumeroDeSegmentosEstaAcotado() {
        val t = TrazoDeJoystick.puntos(0f, 0f, 400f, 0f, 60_000L)
        assertTrue(t.size <= 4002)
    }

    // ---------- Optimización del camino ----------

    @Test
    fun unaRectaConTemblorSeReduceADosPuntos() {
        val ruido = listOf(0.0, 12.0, -9.0, 15.0, -11.0, 8.0, 0.0)
        val puntos = ruido.mapIndexed { i, r -> pr(i * 100.0, r, i * 400L, ref = i == 0 || i == 6) }
        val o = OptimizadorDeTrayecto.simplificar(puntos)
        assertEquals(listOf(0, 6), o.indices)
        assertEquals(600.0, o.longitudOptimizadaPx, 1e-6)
        assertTrue(o.longitudOriginalPx > o.longitudOptimizadaPx)
        assertTrue(o.ahorro > 0.0)
    }

    @Test
    fun unaEsquinaSeConserva() {
        val puntos = listOf(
            pr(0.0, 0.0, ref = true), pr(100.0, 0.0), pr(200.0, 0.0), pr(300.0, 0.0),
            pr(300.0, 100.0), pr(300.0, 200.0), pr(300.0, 300.0, ref = true)
        )
        val o = OptimizadorDeTrayecto.simplificar(puntos)
        assertEquals(listOf(0, 3, 6), o.indices)
        assertEquals(600.0, o.longitudOptimizadaPx, 1e-6)
    }

    @Test
    fun laDiagonalSuaveSeAtajaPeroElRodeoGrandeNo() {
        // Escalera de 40 px de lado: se aplana en una diagonal (queda dentro de la tolerancia).
        val escalera = ArrayList<PuntoDeRuta>()
        var x = 0.0
        var y = 0.0
        escalera.add(pr(x, y, ref = true))
        repeat(8) {
            x += 40.0
            escalera.add(pr(x, y))
            y += 40.0
            escalera.add(pr(x, y))
        }
        val ultimo = escalera.removeAt(escalera.lastIndex)
        escalera.add(PuntoDeRuta(ultimo.x, ultimo.y, ultimo.tMs, ReferenciaVisual("f.png", 0, 0, 10, 10)))
        val o = OptimizadorDeTrayecto.simplificar(escalera)
        assertEquals(2, o.puntos.size)
        // Un rodeo de 200 px fuera de la recta sí se respeta.
        val rodeo = listOf(pr(0.0, 0.0, ref = true), pr(0.0, 200.0), pr(200.0, 200.0), pr(200.0, 0.0, ref = true))
        assertEquals(4, OptimizadorDeTrayecto.simplificar(rodeo).puntos.size)
    }

    @Test
    fun lasCapturasAnclaNoImpidenSimplificarElCamino() {
        val puntos = listOf(
            pr(0.0, 0.0, ref = true), pr(100.0, 0.0), pr(200.0, 0.0, ref = true),
            pr(300.0, 0.0), pr(400.0, 0.0, ref = true)
        )
        val o = OptimizadorDeTrayecto.simplificar(puntos)
        // Las capturas son anclas de posición, no puntos de paso: el camino recto se reduce a sus extremos.
        assertEquals(listOf(0, 4), o.indices)
    }

    @Test
    fun conPocosPuntosNoCambiaNada() {
        val dos = listOf(pr(0.0, 0.0, ref = true), pr(200.0, 0.0, ref = true))
        assertEquals(listOf(0, 1), OptimizadorDeTrayecto.simplificar(dos).indices)
        assertEquals(emptyList<Int>(), OptimizadorDeTrayecto.simplificar(emptyList()).indices)
    }

    @Test
    fun losIntermediosPermitenVolverAlCaminoFiel() {
        val puntos = listOf(
            pr(0.0, 0.0, ref = true), pr(100.0, 0.0), pr(200.0, 0.0), pr(300.0, 0.0),
            pr(300.0, 100.0), pr(300.0, 200.0), pr(300.0, 300.0, ref = true)
        )
        val o = OptimizadorDeTrayecto.simplificar(puntos)
        assertEquals(1..2, OptimizadorDeTrayecto.intermedios(o, 1))
        assertEquals(4..5, OptimizadorDeTrayecto.intermedios(o, 2))
        assertTrue(OptimizadorDeTrayecto.intermedios(o, 0).isEmpty())
        assertTrue(OptimizadorDeTrayecto.intermedios(o, 9).isEmpty())
    }

    @Test
    fun laRutaInversaSeOptimizaIgual() {
        val ruta = Ruta(
            1, "R", 1, 2,
            listOf(pr(0.0, 0.0, 0, true), pr(100.0, 8.0, 400), pr(200.0, -6.0, 800), pr(300.0, 0.0, 1200, true)),
            0, 0, 0.0, 1200, 0
        )
        val ida = OptimizadorDeTrayecto.simplificar(ruta.puntosEnSentido(false))
        val vuelta = OptimizadorDeTrayecto.simplificar(ruta.puntosEnSentido(true))
        assertEquals(ida.puntos.size, vuelta.puntos.size)
        assertEquals(ida.longitudOptimizadaPx, vuelta.longitudOptimizadaPx, 1e-6)
    }

    // ---------- Bloqueo ----------

    @Test
    fun elBloqueoSeDetectaTrasVariosPasosSinAvance() {
        val d = DetectorDeBloqueo()
        assertFalse(d.anotar(100.0, 5.0))
        assertFalse(d.anotar(100.0, 10.0))
        assertTrue(d.anotar(100.0, 0.0))
    }

    @Test
    fun unPasoConAvanceReiniciaLaCuenta() {
        val d = DetectorDeBloqueo()
        d.anotar(100.0, 0.0)
        d.anotar(100.0, 0.0)
        assertFalse(d.anotar(100.0, 90.0))
        assertFalse(d.anotar(100.0, 0.0))
        assertFalse(d.anotar(100.0, 0.0))
        assertTrue(d.anotar(100.0, 0.0))
    }

    @Test
    fun sinEsperadoNoHayBloqueo() {
        val d = DetectorDeBloqueo()
        repeat(10) { assertFalse(d.anotar(0.0, 0.0)) }
    }
}

/** Veredicto de la prueba real de diagonales, con mediciones simuladas. */
class DiagonalCorrectaTest {

    @Test
    fun unaDiagonalBienMedidaEsCorrecta() {
        assertEquals(null, EvaluadorProgreso.diagonalCorrecta(-37.0, 37.0, -37.1, 37.1))
        assertEquals(null, EvaluadorProgreso.diagonalCorrecta(-30.0, 45.0, -37.1, 37.1))
    }

    @Test
    fun sinMovimientoOConMovimientoDeMasFalla() {
        assertEquals("se movió muy poco", EvaluadorProgreso.diagonalCorrecta(-3.0, 3.0, -37.1, 37.1))
        assertEquals("se movió demasiado", EvaluadorProgreso.diagonalCorrecta(-90.0, 90.0, -37.1, 37.1))
    }

    @Test
    fun unaDireccionDistintaFalla() {
        // Mide un movimiento horizontal de la misma rapidez cuando se esperaba una diagonal.
        assertEquals("fue en otra dirección", EvaluadorProgreso.diagonalCorrecta(-52.0, 0.0, -37.1, 37.1))
        // El sentido contrario también falla.
        assertEquals("fue en otra dirección", EvaluadorProgreso.diagonalCorrecta(37.0, -37.0, -37.1, 37.1))
    }

    @Test
    fun sinCalibracionNoSePuedeComparar() {
        assertEquals("no hay calibración con la que comparar", EvaluadorProgreso.diagonalCorrecta(10.0, 10.0, 0.0, 0.0))
    }
}
