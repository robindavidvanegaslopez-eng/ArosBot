# Limitaciones de Android y decisiones de diseño

Este documento recoge lo que Android permite y no permite, y cómo lo resolverá cada fase. Se actualizará cuando las pruebas reales confirmen o desmientan algo.

## Permisos

| Permiso / servicio | Fase | Para qué | Estado |
|---|---|---|---|
| Captura de pantalla (MediaProjection) + servicio en primer plano | 2 | Ver el juego en tiempo real | En uso |
| Superposición sobre otras apps | 2 | Burbuja de control y recuadros sobre el juego | En uso (opcional) |
| Notificaciones | 2 | Aviso de captura con «Detener» y «Parada de emergencia» | En uso (opcional) |
| Servicio de accesibilidad | 3 | Gestos táctiles y lectura del selector de cuentas de Google | En uso (lo activas tú) |

## Captura de pantalla

- Android pide autorización cada vez que se inicia una sesión de captura. Desde Android 14 el permiso concedido sirve para una sola sesión: si la captura se pierde, el bot se detiene y hay que volver a concederla.
- Mientras captura, Android muestra su propio indicador de grabación. No se puede ocultar.
- Si el juego marca su ventana como protegida (`FLAG_SECURE`), la captura sale en negro. La aplicación lo detecta al capturar un fotograma de trabajo y lo avisa; no puede evitarse.
- La captura es a **media resolución** (para ahorrar CPU y memoria). Las imágenes de referencia se escalan a ese tamaño, por eso deben recortarse de capturas de pantalla reales del teléfono a tamaño completo.

## Detección de materiales

- Técnica: búsqueda de plantillas multiescala en color (cinco escalas entre 0,8 y 1,25). Es rápida y funciona bien con sprites que se dibujan siempre igual.
- **No es un detector que generalice.** Tolera pequeños cambios de tamaño y posición, pero no rotaciones, ni cambios fuertes de iluminación o de aspecto, ni elementos semitransparentes sobre fondos muy distintos. Para ampliar la cobertura se pueden añadir **variantes** del material.
- El umbral de confianza se ajusta por material: bajarlo encuentra más, pero aumenta los falsos positivos.
- La detección en vivo analiza solo las áreas activas. Cada ciclo tarda lo que indica el Panel (milisegundos reales medidos en el teléfono).

## Áreas de rastreo

- Se guardan normalizadas (0 a 1) respecto al fotograma con el que se dibujaron, junto con su tamaño.
- Si la proporción de la pantalla cambia (giro del teléfono, otro modo de pantalla), el área **no se usa** y se avisa de que hay que recalibrarla; recalibrar es volver a guardar el rectángulo sobre un fotograma nuevo.

## Entrada WASD (Fase 3)

- Una app normal **no puede inyectar teclas de teclado** en otras aplicaciones (el permiso necesario es solo para apps firmadas por el sistema).
- El servicio de accesibilidad **sí puede generar gestos táctiles** (`dispatchGesture`). Si el juego se controla en el móvil con un joystick virtual, WASD se implementará como gestos sobre ese joystick.
- **Implementado así en la Fase 3**: el bot pulsa en el centro del joystick que tú marcas, lleva el dedo al borde en 80 ms y lo mantiene QUIETO ahí, siempre al 100 % (en Curse of Aros el desplazamiento del joystick es la velocidad del personaje, y ir más lento delataría al bot). Son siempre dos gestos (arrastre y mantener): encadenar más tramos cortos hacía que Android cancelara el gesto. Por eso una pulsación no se puede soltar a mitad: el seguimiento de rutas las limita a 1,5 s y la parada de emergencia puede tardar ese tiempo en frenar el movimiento en curso.
- Que el juego responda a esos gestos **solo se sabe con la prueba real** (*Probar movimiento*). El módulo no se marca verificado hasta que la escena se mueve de verdad. Si no responde, se documentará aquí.
- Las pulsaciones largas dependen de que Android permita gestos continuos; en pantallas con el juego en otra orientación hay que reconfigurar el joystick.

## Superposición y selector de cuentas de Google

- Android no permite colocar una superposición *por debajo* de la ventana de otra app: siempre queda encima.
- Estrategia (implementada en la Fase 3): al detectar el selector de cuentas (ventana de Google Play Services) el bot **oculta la superposición, suelta todas las teclas y se pausa** y se muestra de nuevo cuando el selector desaparece. El bot **no se reanuda solo**: hasta que exista el orquestador (Fase 5) lo reanudas tú desde el Panel.
- Desde Android 12, una superposición con opacidad superior a 0,8 bloquea los toques hacia la app de debajo. La burbuja y la capa de recuadros tienen opacidad 0,8 y esta última no captura toques. (La versión 0.3.0 olvidó fijar la opacidad de la capa de recuadros y bloqueaba los toques al juego, al selector de cuentas y al selector de archivos; corregido en 0.3.1.)

## Inicio de sesión automático (Fase 3)

- El bot pulsa «Log in» (por reconocimiento visual) y elige la cuenta cuyo correo coincide exactamente con el configurado.
- **Nunca toca campos de contraseña ni de verificación en dos pasos.** Si aparece cualquiera de ellos, se detiene y lo indica.
- El correo se guarda solo en el teléfono; no va en el código ni en el ZIP.
- El selector de cuentas lo dibuja Google Play Services y debería ser legible por accesibilidad, pero depende del dispositivo y de la versión. Se verificará en una prueba real.
- Está desactivado por defecto. En la Fase 3 solo se usa desde *Probar inicio de sesión*; el bot lo usará solo cuando exista el bucle autónomo (Fase 5).
- En Android 13 o superior, un APK instalado fuera de Play Store puede tener el servicio de accesibilidad bloqueado hasta permitir los «ajustes restringidos» en la ficha de la app.

## Rutas y mapa visual (Fase 4)

- La posición no son coordenadas del mundo del juego: es la suma de lo que se mueve la escena entre fotogramas, en píxeles del fotograma, con origen en el punto de partida de la ruta. Esto supone que **la cámara sigue al personaje** (se comprobó en la Fase 3).
- Esa suma acumula error (deriva). Se corrige con **recortes de referencia visual**: al llegar a un punto con referencia, se busca el recorte con búsqueda de plantillas. Si el lugar cambió (otro momento del día, objetos que aparecen o desaparecen, animaciones) puede no reconocerse; entonces el bot lo dice y sigue por estimación.
- Las referencias se toman en zonas alejadas del personaje y de los bordes. Una zona demasiado lisa (agua, cielo, hierba uniforme) no sirve y la ruta no se puede enseñar desde ahí.
- Una ruta solo vale para la proporción de pantalla con la que se enseñó. Girar el teléfono o cambiar el modo de pantalla obliga a enseñarla de nuevo.
- El bot solo se mueve en las cuatro direcciones (W, A, S, D), corrigiendo siempre el eje con más error; no hace diagonales.
- Seguir una ruta al revés usa los mismos puntos en orden contrario; no tiene en cuenta que el camino de vuelta pueda ser distinto.
- Los módulos 7, 8 y 10 no se dan por verificados hasta una ruta real seguida con éxito, destino reconocido visualmente y el intento guardado y releído.

## Aprendizaje (Fase 4)

El «Aros Learning Engine» es **local y estadístico**: grafo de rutas, tasas de éxito y fracaso, estimaciones de tiempo y fiabilidad, y una política de selección de acciones que mejora con la experiencia. **No es una red neuronal** y no usa servicios externos ni claves API.

## Memoria persistente

SQLite local (la solución equivalente a Room que permite la especificación). La versión 3 de la base de datos guarda materiales, áreas, calibraciones de movimiento, lugares, rutas e intentos; las tablas de rutas, spots y estadísticas se añaden en sus fases, con migración.

## OCR (Fase 6)

OCR local para «Your inventory is full.». Si el texto resultara poco fiable, se usará reconocimiento de plantilla del aviso.
