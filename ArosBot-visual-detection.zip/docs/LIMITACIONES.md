# Limitaciones de Android y decisiones de diseño

Este documento recoge lo que Android permite y no permite, y cómo lo resolverá cada fase. Se actualizará cuando las pruebas reales confirmen o desmientan algo.

## Permisos

| Permiso / servicio | Fase | Para qué | Estado |
|---|---|---|---|
| Captura de pantalla (MediaProjection) + servicio en primer plano | 2 | Ver el juego en tiempo real | En uso |
| Superposición sobre otras apps | 2 | Burbuja de control y recuadros sobre el juego | En uso (opcional) |
| Notificaciones | 2 | Aviso de captura con «Detener» y «Parada de emergencia» | En uso (opcional) |
| Servicio de accesibilidad | 3 | Gestos táctiles y lectura del selector de cuentas de Google | En uso (lo activas tú) |

## Captura de pantalla

- Android pide autorización cada vez que se inicia una sesión de captura. Desde Android 14 el permiso concedido sirve para una sola sesión: si la captura se pierde, el bot se detiene y hay que volver a concederla.
- Mientras captura, Android muestra su propio indicador de grabación. No se puede ocultar.
- Si el juego marca su ventana como protegida (`FLAG_SECURE`), la captura sale en negro. La aplicación lo detecta al capturar un fotograma de trabajo y lo avisa; no puede evitarse.
- La captura es a **media resolución** (para ahorrar CPU y memoria). Las imágenes de referencia se escalan a ese tamaño, por eso deben recortarse de capturas de pantalla reales del teléfono a tamaño completo.

## Detección de materiales

- Técnica: búsqueda de plantillas multiescala en color (cinco escalas entre 0,8 y 1,25). Es rápida y funciona bien con sprites que se dibujan siempre igual.
- **No es un detector que generalice.** Tolera pequeños cambios de tamaño y posición, pero no rotaciones, ni cambios fuertes de iluminación o de aspecto, ni elementos semitransparentes sobre fondos muy distintos. Para ampliar la cobertura se pueden añadir **variantes** del material.
- El umbral de confianza se ajusta por material: bajarlo encuentra más, pero aumenta los falsos positivos.
- La detección en vivo analiza solo las áreas activas. Cada ciclo tarda lo que indica el Panel (milisegundos reales medidos en el teléfono).

## Áreas de rastreo

- Se guardan normalizadas (0 a 1) respecto al fotograma con el que se dibujaron, junto con su tamaño.
- Si la proporción de la pantalla cambia (giro del teléfono, otro modo de pantalla), el área **no se usa** y se avisa de que hay que recalibrarla; recalibrar es volver a guardar el rectángulo sobre un fotograma nuevo.

## Entrada WASD (Fase 3)

- Una app normal **no puede inyectar teclas de teclado** en otras aplicaciones (el permiso necesario es solo para apps firmadas por el sistema).
- El servicio de accesibilidad **sí puede generar gestos táctiles** (`dispatchGesture`). Si el juego se controla en el móvil con un joystick virtual, WASD se implementará como gestos sobre ese joystick.
- **Implementado así en la Fase 3**: el bot pulsa en el centro del joystick que tú marcas, lleva el dedo al borde en 80 ms y lo mantiene QUIETO ahí, siempre al 100 % (en Curse of Aros el desplazamiento del joystick es la velocidad del personaje, y ir más lento delataría al bot). Desde la 0.5.0 es **un solo trazo continuo**: encadenar gestos (tramos cortos, o arrastre + mantener como dos gestos) hacía que Android cancelara el segundo. Para que el trazo dure lo que toca, tras llegar al borde el dedo hace un zigzag diminuto (menos de 2 px, perpendicular a la dirección) en vez de quedarse literalmente quieto; el joystick no cambia de dirección. Si Android cancela el gesto, se reintenta hasta 3 veces antes de darlo por fallido. Por eso una pulsación no se puede soltar a mitad: el seguimiento de rutas las limita a 1,5 s y la parada de emergencia puede tardar ese tiempo en frenar el movimiento en curso. Que el juego acepte ese trazo solo se sabe con la prueba real.
- **Ocho direcciones** (0.5.0): W, A, S, D y W+A, W+D, S+A, S+D. Las cuatro cardinales se calibran con *Probar movimiento*; las diagonales se derivan de ellas (el joystick al 100 % da la misma rapidez en todas las direcciones) y se comprueban con *Probar diagonales*. Hasta que esa prueba salga bien, el bot solo usa W/A/S/D. Una diagonal es el joystick empujado hacia la esquina: no son dos teclas pulsadas a la vez.
- Que el juego responda a esos gestos **solo se sabe con la prueba real** (*Probar movimiento*). El módulo no se marca verificado hasta que la escena se mueve de verdad. Si no responde, se documentará aquí.
- Las pulsaciones largas dependen de que Android permita gestos continuos; en pantallas con el juego en otra orientación hay que reconfigurar el joystick.

## Superposición y selector de cuentas de Google

- Android no permite colocar una superposición *por debajo* de la ventana de otra app: siempre queda encima.
- Estrategia (implementada en la Fase 3): al detectar el selector de cuentas (ventana de Google Play Services) el bot **oculta la superposición, suelta todas las teclas y se pausa** y se muestra de nuevo cuando el selector desaparece. El bot **no se reanuda solo**: hasta que exista el orquestador (Fase 5) lo reanudas tú desde el Panel.
- Desde Android 12, una superposición con opacidad superior a 0,8 bloquea los toques hacia la app de debajo. La burbuja y la capa de recuadros tienen opacidad 0,8 y esta última no captura toques. (La versión 0.3.0 olvidó fijar la opacidad de la capa de recuadros y bloqueaba los toques al juego, al selector de cuentas y al selector de archivos; corregido en 0.3.1.)

## Inicio de sesión automático (Fase 3)

- El bot pulsa «Log in» (por reconocimiento visual) y elige la cuenta cuyo correo coincide exactamente con el configurado.
- **Nunca toca campos de contraseña ni de verificación en dos pasos.** Si aparece cualquiera de ellos, se detiene y lo indica.
- El correo se guarda solo en el teléfono; no va en el código ni en el ZIP.
- El selector de cuentas lo dibuja Google Play Services y debería ser legible por accesibilidad, pero depende del dispositivo y de la versión. Se verificará en una prueba real.
- Está desactivado por defecto. En la Fase 3 solo se usa desde *Probar inicio de sesión*; el bot lo usará solo cuando exista el bucle autónomo (Fase 5).
- En Android 13 o superior, un APK instalado fuera de Play Store puede tener el servicio de accesibilidad bloqueado hasta permitir los «ajustes restringidos» en la ficha de la app.

## Rutas y mapa visual (Fase 4)

- La posición no son coordenadas del mundo del juego: es la suma de lo que se mueve la escena entre fotogramas, en píxeles del fotograma, con origen en el punto de partida de la ruta. Esto supone que **la cámara sigue al personaje** (se comprobó en la Fase 3).
- Esa suma acumula error (deriva). Se corrige con **recortes de referencia visual**: al llegar a un punto con referencia, se busca el recorte con búsqueda de plantillas. Si el lugar cambió (otro momento del día, objetos que aparecen o desaparecen, animaciones) puede no reconocerse; entonces el bot lo dice y sigue por estimación.
- Las referencias se toman en zonas alejadas del personaje y de los bordes. Una zona demasiado lisa (agua, cielo, hierba uniforme) no sirve y la ruta no se puede enseñar desde ahí.
- Una ruta solo vale para la proporción de pantalla con la que se enseñó. Girar el teléfono o cambiar el modo de pantalla obliga a enseñarla de nuevo.
- **Camino optimizado** (0.5.0): el bot no repite tus pasos. Reduce tu trayectoria a menos puntos (Ramer-Douglas-Peucker, tolerancia 45 px) y va de uno a otro en línea casi recta, con diagonales si están verificadas; sin ellas, corrige el eje con más error. Inicio, final y puntos con referencia visual se conservan siempre.
- **Qué NO sabe el bot**: no ve el mapa ni los obstáculos. Solo sabe que es transitable lo que tú recorriste, por eso sus atajos nunca se alejan más de 45 px de tu camino. «El camino más viable» es el más directo dentro de lo que tú le enseñaste; no explora terreno nuevo.
- **Bloqueo**: si en 3 pasos seguidos mide menos del 25 % del movimiento esperado, lo da por bloqueado. En un atajo vuelve a tu camino enseñado en ese tramo; si tampoco avanza, se detiene y lo explica. Cada paso queda en el Registro de actividad, con la tecla, la duración y lo que se movió.
- Seguir una ruta al revés usa los mismos puntos en orden contrario; no tiene en cuenta que el camino de vuelta pueda ser distinto.
- Los módulos 7, 8 y 10 no se dan por verificados hasta una ruta real seguida con éxito, destino reconocido visualmente y el intento guardado y releído.

## Conducción continua (0.6.1)

- **No probada todavía en el juego.** Es un cambio de diseño: un solo toque sobre el joystick que se mantiene todo el recorrido, encadenando segmentos de 100 ms con la API de «trazo que continúa» de Android (8.0 o superior). Si Android cancela un segmento, el bot reintenta hasta 3 veces y, si no, se detiene y lo dice con el motivo. Si ves que sigue cancelando, el Registro de actividad lo mostrará.
- El juego debe aceptar un ángulo cualquiera del joystick (analógico). Con «Probar diagonales» sin pasar, el bot solo usa los 4 ejes, con histéresis para no alternar, y la ruta sale en escalera.
- La posición se mide con la correlación de fase entre fotogramas consecutivos. Si la escena tiene poca textura o hay mucho movimiento propio (animaciones), la medición pierde confianza y el bot la sustituye por una estimación con la velocidad calibrada; el resultado indica cuántos fotogramas se midieron y cuántos se estimaron.
- Al soltar en el último punto el personaje avanza algo por inercia; el bot se anticipa con ~0,18 s de latencia supuesta (valor estimado, no medido) y corrige si queda lejos.
- La cadencia real depende de cuántos fotogramas entrega la captura de pantalla; no se puede subir más desde la aplicación.

## Spots y destino autónomo (Fase 5)

- **Dónde está el personaje** no se puede ver en el juego: el bot lo sabe porque tú se lo dices («Estoy en…») o porque acaba de terminar una ruta con éxito. Si una ruta falla a mitad, la ubicación se borra y hay que indicarla otra vez. Sin ubicación conocida no elige destino.
- Solo se eligen spots a los que hay una **ruta enseñada** (o una cadena de rutas, también al revés). Un spot en un lugar sin rutas aparece como no alcanzable.
- La **disponibilidad** de un spot es una estimación estadística: no se puede leer cuándo reaparecen los recursos. Se aprende de las visitas: sin visitar, 50 %; nunca agotado, 90 %; agotado, sube poco a poco hasta 90 % durante el tiempo estimado de recuperación (empieza en 5 minutos, entre 30 s y 6 h). Es una aproximación y se equivoca, sobre todo con pocas visitas.
- «Había recursos» = el detector visual vio algún material buscado en al menos 2 de 4 observaciones al llegar. Detecta lo que ve; no cuenta cuántos hay ni los recoge (eso es la sección Inventario y cofre).
- Los módulos 11 y 13 no se dan por verificados hasta un destino elegido por el propio bot, recorrido de verdad (al menos una ruta) y con la visita guardada y releída.

## Aprendizaje (Fase 4)

El «Aros Learning Engine» es **local y estadístico**: grafo de rutas, tasas de éxito y fracaso, estimaciones de tiempo y fiabilidad, y una política de selección de acciones que mejora con la experiencia. **No es una red neuronal** y no usa servicios externos ni claves API.

## Memoria persistente

SQLite local (la solución equivalente a Room que permite la especificación). La versión 3 de la base de datos guarda materiales, áreas, calibraciones de movimiento, lugares, rutas e intentos; las tablas de rutas, spots y estadísticas se añaden en sus fases, con migración.

## Recolección, inventario y cofre (Fase 6)

- **Sin OCR**: se descartó el OCR para «Your inventory is full.». Añadirlo exige una librería nueva que aquí no se puede compilar ni comprobar. En su lugar se reconoce el aviso **por imagen** (la misma búsqueda de plantillas que los materiales). Puedes importar varias imágenes alternativas del aviso (por ejemplo, otro idioma o fondo). Si el aviso cambia de aspecto, hay que importar la nueva imagen.
- **El aviso es breve**: «Your inventory is full.» aparece unos instantes. Por eso se mira 8 veces seguidas justo tras interactuar y se exigen 2 coincidencias; con 1 sola, el estado es *incierto* y el bot se detiene. Si el aviso dura menos que ~0,7 s, puede no verse y el bot no sabrá que está lleno.
- **El depósito no se puede comprobar directamente** (el bot no lee el contenido del inventario): se da por bueno si el aviso no sale tras cerrar el cofre y se confirma con la siguiente recogida real. Es una prueba indirecta.
- **El recurso «recogido» = ya no se ve en su sitio.** Si el juego lo oculta sin recogerlo, o aparece otro idéntico en el mismo punto, el bot puede equivocarse.
- **Pulsar botones**: el servicio de accesibilidad envía toques en coordenadas de pantalla. Android no garantiza que cualquier botón del juego los acepte. Si no responde, la comprobación visual lo detecta y cuenta como fallo; el bot no da por hecho que pulsó.
- **Deriva al recoger**: al acercarse a un recurso el personaje se aleja del final de la ruta. El bot mide ese desplazamiento y vuelve al punto antes de seguir otra ruta; si no lo consigue, borra la ubicación («no sé dónde estoy») y se detiene.
- **Interacción**: si no importas «Interactuar», el bot toca el propio recurso o cofre; si tu juego exige otro gesto (mantener, botón fijo), importa la imagen del botón.
- Las estadísticas por spot no se exportan en la copia de aprendizaje de esta versión (sí se borran al restablecer).
- Los módulos 14 y 15 no se dan por verificados hasta una prueba real: el aviso visto de verdad (14) y una recogida o un depósito reales (15). **Nada de esto se ha probado todavía en el juego**; las pruebas en JVM solo comprueban la lógica de decisión.
